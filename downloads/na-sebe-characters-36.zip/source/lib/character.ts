import type { Solo } from './game';

export type CharacterId = 'boy' | 'girl';
export type PlayerSolo = Solo & { character: CharacterId; eventsPerMonth?:1|2|3; storySeed?:number };
export const characterId = (value: unknown): CharacterId => value === 'girl' ? 'girl' : 'boy';
export const CHARACTERS = {
  boy: { label: 'Мальчик', note: 'Синий бомбер, кеды и рюкзак', color: '#4966ba', background: '#e9eefb' },
  girl: { label: 'Девочка', note: 'Зелёная куртка, кеды и рюкзак', color: '#527b6d', background: '#e9f0e9' },
} as const;
