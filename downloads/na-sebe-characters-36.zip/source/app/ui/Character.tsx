'use client';
import { Check } from 'lucide-react';
import { CHARACTERS, type CharacterId } from '@/lib/character';

/** One figure is shared by the selector, identity chip and all twelve scenes. */
export function CharacterFigure({character}:{character:CharacterId}) {
  const girl=character==='girl',ink='#344652',skin=girl?'#e4b292':'#e5b48d',jacket=girl?'#6c9180':'#5675be';
  return <g className="character-figure" data-character={character} strokeLinejoin="round" strokeLinecap="round">
    <ellipse cx="111" cy="307" rx="62" ry="9" fill="#273b4a" opacity=".11"/>
    {girl&&<path d="M77 64q-6-47 34-47 40 0 39 50l10 66q-49 23-97-1Z" fill="#775442" stroke={ink} strokeWidth="2.5"/>}
    <path d="M144 134q26-8 29 24l1 56-30 9-14-73Z" fill={girl?'#cfaa7c':'#82a99b'} stroke={ink} strokeWidth="2.5"/>
    <path d="m88 205-7 86 27 2 8-71 5 71 28-2-12-88Z" fill={girl?'#465b70':'#3d4d69'} stroke={ink} strokeWidth="2.5"/>
    <path d="m92 224-4 59m40-59 10 59" stroke="#7f90a1" strokeWidth="2" opacity=".55"/>
    <path d="m80 286-15 10q-6 10 5 11h37l1-16Z" fill="#f8f5e9" stroke={ink} strokeWidth="2.5"/>
    <path d="m122 288 1 18h39q9-3 1-10l-16-10Z" fill="#f8f5e9" stroke={ink} strokeWidth="2.5"/>
    <path d="M68 301h38m19 0h37" stroke="#c4cac6" strokeWidth="3"/>
    <path d="m88 293-8 1m10 4-9 1m58-6 8 2m-10 2 8 2" stroke="#8a9ca7" strokeWidth="2"/>
    <path d="M84 127q-18 4-22 25l-9 56 17 5 17-48 1 38q27 14 57 0l-4-48 17 42 15-8-12-45q-5-16-24-19Z" fill={jacket} stroke={ink} strokeWidth="2.5"/>
    <path d="m67 157-9 39m92-40 14 28" stroke={girl?'#89ab96':'#7794d1'} strokeWidth="4"/>
    <path d="M96 126h28l6 71-35 1Z" fill="#f6f1de" stroke={ink} strokeWidth="2"/>
    <path d="m86 126 12-6 9 18-14 16m38-28-10-7-10 19 17 15" fill={girl?'#85a492':'#7893d0'} stroke={ink} strokeWidth="2"/>
    <path d="m91 157-3 37m41-39 7 38" fill="none" stroke={girl?'#486d5d':'#3b59a0'} strokeWidth="2.5"/>
    <path d="m70 189 13 3m55-3 11-4" stroke={ink} strokeWidth="2"/>
    <path d="m53 207-1 11q3 10 12 4l6-11M159 197l5 10q8 7 13-1l-4-17" fill={skin} stroke={ink} strokeWidth="2.5"/>
    <path d="M100 108v18q12 15 25-1v-19Z" fill={skin} stroke={ink} strokeWidth="2"/>
    <path d="m101 111 22-1v9q-12 8-22 0Z" fill="#ce9476"/>
    <ellipse cx="82" cy="78" rx="7" ry="12" fill={skin} stroke={ink} strokeWidth="2"/>
    <ellipse cx="140" cy="78" rx="7" ry="12" fill={skin} stroke={ink} strokeWidth="2"/>
    <path d="M83 56q25-28 56 0v29q-2 27-28 31-26-3-29-31Z" fill={skin} stroke={ink} strokeWidth="2.5"/>
    <path d="m89 69 10-2m22 0 10 3" stroke={girl?'#775442':'#35414b'} strokeWidth="3"/>
    <ellipse cx="96" cy="79" rx="3.2" ry="4" fill={ink}/><ellipse cx="125" cy="79" rx="3.2" ry="4" fill={ink}/>
    <circle cx="97" cy="78" r="1" fill="#fff"/><circle cx="126" cy="78" r="1" fill="#fff"/>
    <path d="m110 79-2 10h5" fill="none" stroke="#b67e67" strokeWidth="2"/>
    <ellipse cx="91" cy="92" rx="6" ry="3.2" fill="#d68d7f" opacity=".5"/><ellipse cx="132" cy="92" rx="6" ry="3.2" fill="#d68d7f" opacity=".5"/>
    <path d="M100 98q11 10 22-1" fill="#fbf6e9" stroke="#985e52" strokeWidth="2"/>
    {girl?<><path d="M79 73q-11-46 31-49 36-3 35 40l-10-17q-19 21-51 16Z" fill="#775442" stroke={ink} strokeWidth="2.5"/><path d="M87 48q16-16 38-11M141 75l-2 30" stroke="#a37c5d" strokeWidth="3" fill="none"/><path d="m80 51 7 9" stroke="#d3bd7f" strokeWidth="4"/><circle cx="142" cy="89" r="2.5" fill="#e9ce84"/></>:<><path d="M80 74q-10-28 5-40-2-18 15-12 24-13 37 6 17 2 12 25l-10 20-5-22q-20 11-43 6Z" fill="#344550" stroke={ink} strokeWidth="2.5"/><path d="m90 40 16-6m-8 12 22-8" stroke="#52616b" strokeWidth="3" fill="none"/></>}
    <path d="M143 132q-9 28 0 55" stroke={girl?'#af855e':'#4f786c'} strokeWidth="7" fill="none"/>
  </g>;
}

export function CharacterArt({character,portrait=false}:{character:CharacterId;portrait?:boolean}) {
  return <svg className={`character-art ${portrait?'portrait':''}`} viewBox={portrait?'56 13 112 145':'0 0 220 320'} role="img" aria-label={`Персонаж: ${CHARACTERS[character].label.toLowerCase()}`}><CharacterFigure character={character}/></svg>;
}

export function CharacterPicker({value,onChange}:{value:CharacterId;onChange:(id:CharacterId)=>void}) {
 return <fieldset className="character-picker"><legend>Кем проживёшь этот год?</legend><p>Выбери своего персонажа. Правила и стартовые условия одинаковые.</p><div className="character-options">{(Object.keys(CHARACTERS) as CharacterId[]).map(id=><label className={`character-option ${value===id?'chosen':''}`} key={id}>
  <input type="radio" name="character" value={id} checked={value===id} onChange={()=>onChange(id)}/><div className="character-preview" style={{background:CHARACTERS[id].background}}><span className="character-backdrop"/><CharacterArt character={id}/><span className="character-selected">{value===id?<Check size={15}/>:null}</span></div><div className="character-option-label"><b>{CHARACTERS[id].label}</b><span>{value===id?'Выбран':'Выбрать'}</span></div>
 </label>)}</div><span className="character-picker-note">Сменить внешность можно и во время игры — прогресс сохранится.</span></fieldset>;
}
