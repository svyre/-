// Капитал, обязательные расходы и полная стоимость кредита.

import { HOUSING, OFFERS, macroFor } from './config';
import type { DifficultyId, GameState, Plan } from './types';
import { roundMoney } from './utils';

export const debt = (state: GameState) => state.loans.reduce((a, l) => a + l.balance, 0);

export const capital = (state: GameState) =>
  roundMoney(
    state.cash +
      state.savings +
      state.fund -
      debt(state) +
      state.pending.reduce((a, p) => a + Math.min(0, p.cash || 0), 0),
  );

export const essential = (plan: Plan, month: number, difficulty: DifficultyId = 'balance') => {
  const housing = HOUSING.find((x) => x.id === plan.housing) || HOUSING[0];
  return Math.round(
    (housing.cost + housing.transport + 8500 + 900) * macroFor(month, difficulty).inflation,
  );
};

export function annuity(amount: number, rate: number, months: number) {
  const monthlyRate = rate / 1200;
  return roundMoney(
    monthlyRate === 0
      ? amount / months
      : (amount * monthlyRate) / (1 - (1 + monthlyRate) ** -months),
  );
}

export function creditQuote(amount: number, offerId: string) {
  const offer = OFFERS.find((x) => x.id === offerId) || OFFERS[0];
  const payment = annuity(amount, offer.rate, offer.term);
  return {
    ...offer,
    payment: roundMoney(payment + offer.monthlyFee),
    total: roundMoney(payment * offer.term + offer.fee + offer.monthlyFee * offer.term),
    overpay: roundMoney(payment * offer.term + offer.fee + offer.monthlyFee * offer.term - amount),
  };
}
