import {
  monthLabel,
  campaignMonths,
  campaignYears,
  ROOM_ITEMS,
  rub,
  type Report,
} from '@/lib/game';
import { reviewMonth } from '@/lib/month-review';
import { Check, Compass, Lightbulb, TriangleAlert } from 'lucide-react';
import { bankLogo } from './bank-brand';
import { AnnualReview, ProjectSummary } from './ProjectsPanel';
import { DevelopmentSummary } from './DevelopmentPanel';

export function MonthlyReview({ report: r }: { report: Report }) {
  const review = reviewMonth(r);
  return (
    <section
      className="monthly-review"
      aria-label={`Разбор решений: ${monthLabel(r.month, campaignYears(r.before) > 1)}`}
    >
      <header className="review-header">
        <span className="review-badge">
          <Compass size={22} />
        </span>
        <div>
          <span>{monthLabel(r.month, campaignYears(r.before) > 1)} позади</span>
          <h3>Что получилось за этот месяц?</h3>
        </div>
        <span className="review-completed">
          Месяц {r.month + 1} / {campaignMonths(r.before)}
        </span>
      </header>
      {r.room && (
        <div className="room-month-review">
          <h4>Твоя комната</h4>
          {r.room.purchased.length > 0 && (
            <p>
              Куплено:{' '}
              {r.room.purchased
                .map((id) => `${ROOM_ITEMS[id].name.toLowerCase()} — ${rub(ROOM_ITEMS[id].cost)}`)
                .join(', ')}
              . Оплата уже включена в расходы.
            </p>
          )}
          {r.room.gifted.length > 0 && (
            <p>
              Из ситуаций: {r.room.gifted.map((id) => ROOM_ITEMS[id].name.toLowerCase()).join(', ')}
              . Повторной оплаты нет.
            </p>
          )}
          {!!(r.room.purchased.length + r.room.gifted.length) && (
            <p>Новые вещи помогут со следующего месяца и сохранятся при смене жилья.</p>
          )}
          <p>
            {r.room.education || r.room.energy
              ? `Помощь уже установленных улучшений: учёба +${r.room.education}, ресурс +${r.room.energy} до ограничения 100.`
              : 'Базовая обстановка: дополнительных эффектов в этом месяце нет.'}
          </p>
        </div>
      )}
      <DevelopmentSummary report={r} />
      <ProjectSummary report={r} />
      {(r.month + 1) % 12 === 0 && <AnnualReview report={r} />}
      <div className="review-columns">
        <section className="review-good">
          <h4>
            <Check size={18} />
            Что получилось
          </h4>
          {review.good.length ? (
            review.good.map((item) => (
              <div className="review-item" key={item.title}>
                <span>
                  <Check size={13} />
                </span>
                <div>
                  <b>{item.title}</b>
                  <p>{item.text}</p>
                </div>
              </div>
            ))
          ) : (
            <p className="review-empty">Посмотри операции и причины изменений в отчёте ниже.</p>
          )}
        </section>
        <section className="review-improve">
          <h4>
            <TriangleAlert size={17} />
            Что стоит пересмотреть
          </h4>
          {review.improve.length ? (
            review.improve.map((item) => (
              <div className="review-item" key={item.title}>
                <span>!</span>
                <div>
                  <b>{item.title}</b>
                  <p>{item.text}</p>
                </div>
              </div>
            ))
          ) : (
            <p className="review-empty">Дефицита и других заметных проблем в этом месяце нет.</p>
          )}
        </section>
      </div>
      <div className="review-next">
        <Lightbulb size={20} />
        <div>
          <b>
            {r.month === campaignMonths(r.before) - 1
              ? 'После завершения игры'
              : 'Идея на следующий месяц'}
          </b>
          <p>{review.next}</p>
        </div>
      </div>
      <footer className="review-footer">
        <img src={bankLogo} alt="Газпромбанк" />
      </footer>
    </section>
  );
}
