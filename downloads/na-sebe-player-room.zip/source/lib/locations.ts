export const LOCATIONS={
 home:{name:'Комната',wall:'#e7e7e0',floor:'#bdc8c1',accent:'#9caec4',outdoor:false},
 kitchen:{name:'Общая кухня',wall:'#e7eee5',floor:'#b7c6b8',accent:'#90ada2',outdoor:false},
 campus:{name:'Университет',wall:'#e7e5db',floor:'#c0c5b8',accent:'#8ca7b3',outdoor:true},
 library:{name:'Библиотека',wall:'#e8e3d9',floor:'#c6bda9',accent:'#91a494',outdoor:false},
 cafe:{name:'Кафе',wall:'#e9e1d5',floor:'#c6b5a0',accent:'#9aaf98',outdoor:false},
 shop:{name:'Магазин',wall:'#e9e8e3',floor:'#c3c8c8',accent:'#a5b3c5',outdoor:false},
 bank:{name:'Газпромбанк',wall:'#e4ecf8',floor:'#b6c4d8',accent:'#315fdf',outdoor:false},
 office:{name:'Коворкинг',wall:'#e3e9ec',floor:'#b6c3cb',accent:'#8fa7c4',outdoor:false},
 station:{name:'Городская станция',wall:'#dce7eb',floor:'#b5c2c8',accent:'#7b9aaf',outdoor:true},
 park:{name:'Парк',wall:'#d2e6ec',floor:'#bdd0af',accent:'#8db69d',outdoor:true},
 waterfront:{name:'Набережная',wall:'#c8e5ef',floor:'#cbc5ae',accent:'#81abbc',outdoor:true},
 workshop:{name:'Мастерская',wall:'#e5e7df',floor:'#bdc3b6',accent:'#91a7a5',outdoor:false},
 laundry:{name:'Прачечная',wall:'#e2edf0',floor:'#b7cdd0',accent:'#8eafb9',outdoor:false},
 pickup:{name:'Пункт выдачи',wall:'#e6e3ed',floor:'#c5bdcd',accent:'#a69bbd',outdoor:false},
 event:{name:'Городское событие',wall:'#d4e6ec',floor:'#c6cdb4',accent:'#a3b69b',outdoor:true},
 street:{name:'Улица',wall:'#d0e1e8',floor:'#b7c2c5',accent:'#9bb0b7',outdoor:true},
} as const;
export type LocationId=keyof typeof LOCATIONS;
/** Every authored situation has a deliberate setting, independent of its random month. */
export const STORY_LOCATIONS:Record<string,LocationId>={
 'main-0':'home','main-1':'campus','main-2':'workshop','main-3':'shop',
 'main-4':'library','main-5':'home','main-6':'kitchen','main-7':'office',
 'main-8':'park','main-9':'library','main-10':'waterfront','main-11':'home',
 '0-0':'street','0-1':'station','1-0':'office','1-1':'home',
 '2-0':'kitchen','2-1':'home','3-0':'station','3-1':'shop',
 '4-0':'library','4-1':'campus','5-0':'pickup','5-1':'station',
 '6-0':'kitchen','6-1':'cafe','7-0':'office','7-1':'campus',
 '8-0':'street','8-1':'home','9-0':'library','9-1':'event',
 '10-0':'station','10-1':'office','11-0':'street','11-1':'home',
 parcel:'pickup',qr:'cafe',cashback:'bank','lost-card':'bank',
 'loan-friend':'cafe',pass:'campus',desk:'home',laundry:'laundry',
 'team-budget':'office','internship-road':'station',grant:'campus',volunteer:'event',
 printer:'library','mobile-plan':'shop',backup:'home','pet-job':'park',
 ticket:'event','card-courier':'home','platform-fee':'office',wallet:'park',
 software:'office',collection:'campus',weather:'street','meal-course':'kitchen',
};
export function storyLocation(id:string):LocationId{return STORY_LOCATIONS[id]||'home';}
