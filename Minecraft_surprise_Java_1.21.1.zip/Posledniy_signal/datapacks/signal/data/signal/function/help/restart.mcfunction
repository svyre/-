scoreboard players set @s sig.restart 0
tellraw @s [{"text":"Начать заново и стереть прогресс этой экспедиции? ","color":"gray"},{"text":"[Да, новая игра]","color":"red","clickEvent":{"action":"run_command","value":"/trigger sig.restart set 2"}}]
