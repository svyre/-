scoreboard players set @s sig.help 0
tellraw @s {"text":"Управление: WASD и пробел. Площадки срабатывают, когда вы на них наступаете. Чтобы нажать повторно, сойдите и вернитесь.","color":"white"}
tellraw @s {"text":"Белая площадка у входа в отсек возвращает в зал. Ошибка не отнимает уже полученные модули.","color":"gray"}
tellraw @s {"text":"Разговоры и подсказки остаются в чате (T). При необходимости: /trigger sig.hint.","color":"gray"}
execute if score @s sig.room matches 0 run function signal:help/room0
execute if score @s sig.room matches 1 run function signal:help/room1
execute if score @s sig.room matches 2 run function signal:help/room2
execute if score @s sig.room matches 3 run function signal:help/room3
execute if score @s sig.room matches 4 run function signal:help/room4
execute if score @s sig.room matches 5 run function signal:help/room5
execute if score @s sig.room matches 6 run function signal:help/room6
function signal:help/links
