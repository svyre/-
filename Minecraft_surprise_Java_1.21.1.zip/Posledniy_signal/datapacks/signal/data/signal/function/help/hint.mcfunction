scoreboard players set @s sig.hint 0
scoreboard players add @s sig.hints 1
execute if score @s sig.room matches 0 run function signal:hint/0
execute if score @s sig.room matches 1 run function signal:hint/1
execute if score @s sig.room matches 2 run function signal:hint/2
execute if score @s sig.room matches 3 run function signal:hint/3
execute if score @s sig.room matches 4 run function signal:hint/4
execute if score @s sig.room matches 5 run function signal:hint/5
execute if score @s sig.room matches 6 run function signal:hint/6
