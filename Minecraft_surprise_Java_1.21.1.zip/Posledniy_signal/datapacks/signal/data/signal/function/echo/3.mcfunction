tag @s add sig.e3
scoreboard players add @s sig.echo 1
execute at @s run playsound minecraft:block.amethyst_cluster.break master @s ~ ~ ~ 0.65 0.7
tellraw @s {"text":"Эхо III: «Автоматика запомнит команды. Но только человек заметит, что на другом конце кто-то ещё ждёт».","color":"light_purple"}
execute if score @s sig.echo matches 4 run tellraw @s {"text":"Четыре голоса складываются в один. Теперь вы знаете, кому принадлежит последний сигнал.","color":"light_purple"}
