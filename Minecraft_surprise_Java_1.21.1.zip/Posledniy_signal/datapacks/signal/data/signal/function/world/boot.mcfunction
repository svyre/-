function signal:load
forceload add -32 -32 351 31
execute unless data storage signal:world {ready:1b} run function signal:world/prepare
