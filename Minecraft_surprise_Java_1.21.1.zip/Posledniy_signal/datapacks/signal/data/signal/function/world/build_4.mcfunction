fill 240 55 -16 272 84 16 minecraft:air
fill 240 61 -16 272 61 -16 minecraft:bedrock
fill 240 61 -15 272 61 -15 minecraft:bedrock
fill 240 61 -14 272 61 -14 minecraft:bedrock
fill 240 61 -13 272 61 -13 minecraft:bedrock
fill 240 61 -12 272 61 -12 minecraft:bedrock
fill 240 61 -11 272 61 -11 minecraft:bedrock
fill 240 61 -10 272 61 -10 minecraft:bedrock
fill 240 61 -9 272 61 -9 minecraft:bedrock
fill 240 61 -8 272 61 -8 minecraft:bedrock
fill 240 61 -7 272 61 -7 minecraft:bedrock
fill 240 61 -6 272 61 -6 minecraft:bedrock
fill 240 61 -5 272 61 -5 minecraft:bedrock
fill 240 61 -4 272 61 -4 minecraft:bedrock
fill 240 61 -3 272 61 -3 minecraft:bedrock
fill 240 61 -2 272 61 -2 minecraft:bedrock
fill 240 61 -1 272 61 -1 minecraft:bedrock
fill 240 61 0 272 61 0 minecraft:bedrock
fill 240 61 1 272 61 1 minecraft:bedrock
fill 240 61 2 272 61 2 minecraft:bedrock
fill 240 61 3 272 61 3 minecraft:bedrock
fill 240 61 4 272 61 4 minecraft:bedrock
fill 240 61 5 272 61 5 minecraft:bedrock
fill 240 61 6 272 61 6 minecraft:bedrock
fill 240 61 7 272 61 7 minecraft:bedrock
fill 240 61 8 272 61 8 minecraft:bedrock
fill 240 61 9 272 61 9 minecraft:bedrock
fill 240 61 10 272 61 10 minecraft:bedrock
fill 240 61 11 272 61 11 minecraft:bedrock
fill 240 61 12 272 61 12 minecraft:bedrock
fill 240 61 13 272 61 13 minecraft:bedrock
fill 240 61 14 272 61 14 minecraft:bedrock
fill 240 61 15 272 61 15 minecraft:bedrock
fill 240 61 16 272 61 16 minecraft:bedrock
fill 240 62 -16 272 62 -16 minecraft:bedrock
fill 240 62 -15 272 62 -15 minecraft:bedrock
fill 240 62 -14 272 62 -14 minecraft:bedrock
fill 240 62 -13 272 62 -13 minecraft:bedrock
fill 240 62 -12 272 62 -12 minecraft:bedrock
fill 240 62 -11 272 62 -11 minecraft:bedrock
fill 240 62 -10 272 62 -10 minecraft:bedrock
fill 240 62 -9 272 62 -9 minecraft:bedrock
fill 240 62 -8 272 62 -8 minecraft:bedrock
fill 240 62 -7 272 62 -7 minecraft:bedrock
fill 240 62 -6 272 62 -6 minecraft:bedrock
fill 240 62 -5 272 62 -5 minecraft:bedrock
fill 240 62 -4 272 62 -4 minecraft:bedrock
fill 240 62 -3 272 62 -3 minecraft:bedrock
fill 240 62 -2 272 62 -2 minecraft:bedrock
fill 240 62 -1 272 62 -1 minecraft:bedrock
fill 240 62 0 272 62 0 minecraft:bedrock
fill 240 62 1 272 62 1 minecraft:bedrock
fill 240 62 2 272 62 2 minecraft:bedrock
fill 240 62 3 272 62 3 minecraft:bedrock
fill 240 62 4 272 62 4 minecraft:bedrock
fill 240 62 5 272 62 5 minecraft:bedrock
fill 240 62 6 272 62 6 minecraft:bedrock
fill 240 62 7 272 62 7 minecraft:bedrock
fill 240 62 8 272 62 8 minecraft:bedrock
fill 240 62 9 272 62 9 minecraft:bedrock
fill 240 62 10 272 62 10 minecraft:bedrock
fill 240 62 11 272 62 11 minecraft:bedrock
fill 240 62 12 272 62 12 minecraft:bedrock
fill 240 62 13 272 62 13 minecraft:bedrock
fill 240 62 14 272 62 14 minecraft:bedrock
fill 240 62 15 272 62 15 minecraft:bedrock
fill 240 62 16 272 62 16 minecraft:bedrock
fill 240 63 -16 272 63 -16 minecraft:deepslate_tiles
setblock 240 63 -15 minecraft:deepslate_tiles
setblock 272 63 -15 minecraft:deepslate_tiles
fill 241 63 -15 271 63 -15 minecraft:waxed_exposed_cut_copper
setblock 240 63 -14 minecraft:deepslate_tiles
setblock 272 63 -14 minecraft:deepslate_tiles
fill 242 63 -14 270 63 -14 minecraft:polished_basalt[axis=y]
setblock 241 63 -14 minecraft:waxed_exposed_cut_copper
setblock 271 63 -14 minecraft:waxed_exposed_cut_copper
setblock 240 63 -13 minecraft:deepslate_tiles
setblock 243 63 -13 minecraft:deepslate_tiles
setblock 245 63 -13 minecraft:deepslate_tiles
setblock 247 63 -13 minecraft:deepslate_tiles
setblock 249 63 -13 minecraft:deepslate_tiles
setblock 251 63 -13 minecraft:deepslate_tiles
setblock 253 63 -13 minecraft:deepslate_tiles
setblock 255 63 -13 minecraft:deepslate_tiles
setblock 257 63 -13 minecraft:deepslate_tiles
setblock 259 63 -13 minecraft:deepslate_tiles
setblock 261 63 -13 minecraft:deepslate_tiles
setblock 263 63 -13 minecraft:deepslate_tiles
setblock 265 63 -13 minecraft:deepslate_tiles
setblock 267 63 -13 minecraft:deepslate_tiles
setblock 269 63 -13 minecraft:deepslate_tiles
setblock 272 63 -13 minecraft:deepslate_tiles
setblock 242 63 -13 minecraft:polished_basalt[axis=y]
setblock 270 63 -13 minecraft:polished_basalt[axis=y]
setblock 244 63 -13 minecraft:polished_deepslate
setblock 246 63 -13 minecraft:polished_deepslate
setblock 248 63 -13 minecraft:polished_deepslate
setblock 250 63 -13 minecraft:polished_deepslate
setblock 252 63 -13 minecraft:polished_deepslate
setblock 254 63 -13 minecraft:polished_deepslate
setblock 256 63 -13 minecraft:polished_deepslate
setblock 258 63 -13 minecraft:polished_deepslate
setblock 260 63 -13 minecraft:polished_deepslate
setblock 262 63 -13 minecraft:polished_deepslate
setblock 264 63 -13 minecraft:polished_deepslate
setblock 266 63 -13 minecraft:polished_deepslate
setblock 268 63 -13 minecraft:polished_deepslate
setblock 241 63 -13 minecraft:waxed_exposed_cut_copper
setblock 271 63 -13 minecraft:waxed_exposed_cut_copper
setblock 240 63 -12 minecraft:deepslate_tiles
setblock 244 63 -12 minecraft:deepslate_tiles
setblock 246 63 -12 minecraft:deepslate_tiles
setblock 248 63 -12 minecraft:deepslate_tiles
setblock 250 63 -12 minecraft:deepslate_tiles
setblock 252 63 -12 minecraft:deepslate_tiles
setblock 254 63 -12 minecraft:deepslate_tiles
setblock 256 63 -12 minecraft:deepslate_tiles
setblock 258 63 -12 minecraft:deepslate_tiles
setblock 260 63 -12 minecraft:deepslate_tiles
setblock 262 63 -12 minecraft:deepslate_tiles
setblock 264 63 -12 minecraft:deepslate_tiles
setblock 266 63 -12 minecraft:deepslate_tiles
setblock 268 63 -12 minecraft:deepslate_tiles
setblock 272 63 -12 minecraft:deepslate_tiles
setblock 242 63 -12 minecraft:polished_basalt[axis=y]
setblock 270 63 -12 minecraft:polished_basalt[axis=y]
setblock 243 63 -12 minecraft:polished_deepslate
setblock 247 63 -12 minecraft:polished_deepslate
setblock 249 63 -12 minecraft:polished_deepslate
setblock 251 63 -12 minecraft:polished_deepslate
setblock 253 63 -12 minecraft:polished_deepslate
setblock 255 63 -12 minecraft:polished_deepslate
setblock 257 63 -12 minecraft:polished_deepslate
setblock 259 63 -12 minecraft:polished_deepslate
setblock 261 63 -12 minecraft:polished_deepslate
setblock 263 63 -12 minecraft:polished_deepslate
setblock 265 63 -12 minecraft:polished_deepslate
setblock 269 63 -12 minecraft:polished_deepslate
setblock 241 63 -12 minecraft:waxed_exposed_cut_copper
setblock 245 63 -12 minecraft:waxed_exposed_cut_copper
setblock 267 63 -12 minecraft:waxed_exposed_cut_copper
setblock 271 63 -12 minecraft:waxed_exposed_cut_copper
setblock 240 63 -11 minecraft:deepslate_tiles
setblock 243 63 -11 minecraft:deepslate_tiles
setblock 247 63 -11 minecraft:deepslate_tiles
setblock 249 63 -11 minecraft:deepslate_tiles
setblock 251 63 -11 minecraft:deepslate_tiles
setblock 253 63 -11 minecraft:deepslate_tiles
setblock 255 63 -11 minecraft:deepslate_tiles
setblock 257 63 -11 minecraft:deepslate_tiles
setblock 259 63 -11 minecraft:deepslate_tiles
setblock 261 63 -11 minecraft:deepslate_tiles
setblock 263 63 -11 minecraft:deepslate_tiles
setblock 265 63 -11 minecraft:deepslate_tiles
setblock 269 63 -11 minecraft:deepslate_tiles
setblock 272 63 -11 minecraft:deepslate_tiles
setblock 242 63 -11 minecraft:polished_basalt[axis=y]
setblock 270 63 -11 minecraft:polished_basalt[axis=y]
setblock 248 63 -11 minecraft:polished_deepslate
setblock 250 63 -11 minecraft:polished_deepslate
setblock 252 63 -11 minecraft:polished_deepslate
setblock 254 63 -11 minecraft:polished_deepslate
setblock 256 63 -11 minecraft:polished_deepslate
setblock 258 63 -11 minecraft:polished_deepslate
setblock 260 63 -11 minecraft:polished_deepslate
setblock 262 63 -11 minecraft:polished_deepslate
setblock 264 63 -11 minecraft:polished_deepslate
setblock 245 63 -11 minecraft:sea_lantern
setblock 267 63 -11 minecraft:sea_lantern
setblock 241 63 -11 minecraft:waxed_exposed_cut_copper
setblock 244 63 -11 minecraft:waxed_exposed_cut_copper
setblock 246 63 -11 minecraft:waxed_exposed_cut_copper
setblock 266 63 -11 minecraft:waxed_exposed_cut_copper
setblock 268 63 -11 minecraft:waxed_exposed_cut_copper
setblock 271 63 -11 minecraft:waxed_exposed_cut_copper
setblock 246 63 -10 minecraft:chiseled_deepslate
setblock 251 63 -10 minecraft:chiseled_deepslate
setblock 261 63 -10 minecraft:chiseled_deepslate
setblock 266 63 -10 minecraft:chiseled_deepslate
setblock 240 63 -10 minecraft:deepslate_tiles
setblock 244 63 -10 minecraft:deepslate_tiles
setblock 248 63 -10 minecraft:deepslate_tiles
setblock 250 63 -10 minecraft:deepslate_tiles
setblock 252 63 -10 minecraft:deepslate_tiles
setblock 260 63 -10 minecraft:deepslate_tiles
setblock 262 63 -10 minecraft:deepslate_tiles
setblock 264 63 -10 minecraft:deepslate_tiles
setblock 268 63 -10 minecraft:deepslate_tiles
setblock 272 63 -10 minecraft:deepslate_tiles
setblock 242 63 -10 minecraft:polished_basalt[axis=y]
setblock 270 63 -10 minecraft:polished_basalt[axis=y]
setblock 243 63 -10 minecraft:polished_deepslate
setblock 247 63 -10 minecraft:polished_deepslate
setblock 249 63 -10 minecraft:polished_deepslate
setblock 263 63 -10 minecraft:polished_deepslate
setblock 265 63 -10 minecraft:polished_deepslate
setblock 269 63 -10 minecraft:polished_deepslate
setblock 241 63 -10 minecraft:waxed_exposed_cut_copper
setblock 245 63 -10 minecraft:waxed_exposed_cut_copper
fill 253 63 -10 259 63 -10 minecraft:waxed_exposed_cut_copper
setblock 267 63 -10 minecraft:waxed_exposed_cut_copper
setblock 271 63 -10 minecraft:waxed_exposed_cut_copper
setblock 240 63 -9 minecraft:deepslate_tiles
setblock 243 63 -9 minecraft:deepslate_tiles
setblock 245 63 -9 minecraft:deepslate_tiles
setblock 247 63 -9 minecraft:deepslate_tiles
setblock 249 63 -9 minecraft:deepslate_tiles
setblock 253 63 -9 minecraft:deepslate_tiles
setblock 255 63 -9 minecraft:deepslate_tiles
setblock 257 63 -9 minecraft:deepslate_tiles
setblock 259 63 -9 minecraft:deepslate_tiles
setblock 263 63 -9 minecraft:deepslate_tiles
setblock 265 63 -9 minecraft:deepslate_tiles
setblock 267 63 -9 minecraft:deepslate_tiles
setblock 269 63 -9 minecraft:deepslate_tiles
setblock 272 63 -9 minecraft:deepslate_tiles
setblock 242 63 -9 minecraft:polished_basalt[axis=y]
setblock 270 63 -9 minecraft:polished_basalt[axis=y]
setblock 244 63 -9 minecraft:polished_deepslate
setblock 246 63 -9 minecraft:polished_deepslate
setblock 248 63 -9 minecraft:polished_deepslate
setblock 250 63 -9 minecraft:polished_deepslate
setblock 254 63 -9 minecraft:polished_deepslate
setblock 256 63 -9 minecraft:polished_deepslate
setblock 258 63 -9 minecraft:polished_deepslate
setblock 262 63 -9 minecraft:polished_deepslate
setblock 264 63 -9 minecraft:polished_deepslate
setblock 266 63 -9 minecraft:polished_deepslate
setblock 268 63 -9 minecraft:polished_deepslate
setblock 241 63 -9 minecraft:waxed_exposed_cut_copper
fill 251 63 -9 252 63 -9 minecraft:waxed_exposed_cut_copper
fill 260 63 -9 261 63 -9 minecraft:waxed_exposed_cut_copper
setblock 271 63 -9 minecraft:waxed_exposed_cut_copper
setblock 240 63 -8 minecraft:deepslate_tiles
setblock 244 63 -8 minecraft:deepslate_tiles
setblock 246 63 -8 minecraft:deepslate_tiles
setblock 248 63 -8 minecraft:deepslate_tiles
setblock 252 63 -8 minecraft:deepslate_tiles
setblock 254 63 -8 minecraft:deepslate_tiles
setblock 256 63 -8 minecraft:deepslate_tiles
setblock 258 63 -8 minecraft:deepslate_tiles
setblock 260 63 -8 minecraft:deepslate_tiles
setblock 264 63 -8 minecraft:deepslate_tiles
setblock 266 63 -8 minecraft:deepslate_tiles
setblock 268 63 -8 minecraft:deepslate_tiles
setblock 272 63 -8 minecraft:deepslate_tiles
setblock 242 63 -8 minecraft:polished_basalt[axis=y]
setblock 270 63 -8 minecraft:polished_basalt[axis=y]
setblock 243 63 -8 minecraft:polished_deepslate
setblock 245 63 -8 minecraft:polished_deepslate
setblock 247 63 -8 minecraft:polished_deepslate
setblock 249 63 -8 minecraft:polished_deepslate
setblock 251 63 -8 minecraft:polished_deepslate
setblock 253 63 -8 minecraft:polished_deepslate
setblock 255 63 -8 minecraft:polished_deepslate
setblock 257 63 -8 minecraft:polished_deepslate
setblock 259 63 -8 minecraft:polished_deepslate
setblock 261 63 -8 minecraft:polished_deepslate
setblock 263 63 -8 minecraft:polished_deepslate
setblock 265 63 -8 minecraft:polished_deepslate
setblock 267 63 -8 minecraft:polished_deepslate
setblock 269 63 -8 minecraft:polished_deepslate
setblock 241 63 -8 minecraft:waxed_exposed_cut_copper
setblock 250 63 -8 minecraft:waxed_exposed_cut_copper
setblock 262 63 -8 minecraft:waxed_exposed_cut_copper
setblock 271 63 -8 minecraft:waxed_exposed_cut_copper
setblock 240 63 -7 minecraft:deepslate_tiles
setblock 243 63 -7 minecraft:deepslate_tiles
setblock 245 63 -7 minecraft:deepslate_tiles
setblock 247 63 -7 minecraft:deepslate_tiles
setblock 251 63 -7 minecraft:deepslate_tiles
setblock 253 63 -7 minecraft:deepslate_tiles
setblock 255 63 -7 minecraft:deepslate_tiles
setblock 257 63 -7 minecraft:deepslate_tiles
setblock 259 63 -7 minecraft:deepslate_tiles
setblock 261 63 -7 minecraft:deepslate_tiles
setblock 265 63 -7 minecraft:deepslate_tiles
setblock 267 63 -7 minecraft:deepslate_tiles
setblock 269 63 -7 minecraft:deepslate_tiles
setblock 272 63 -7 minecraft:deepslate_tiles
setblock 242 63 -7 minecraft:polished_basalt[axis=y]
setblock 270 63 -7 minecraft:polished_basalt[axis=y]
setblock 244 63 -7 minecraft:polished_deepslate
setblock 246 63 -7 minecraft:polished_deepslate
setblock 248 63 -7 minecraft:polished_deepslate
setblock 250 63 -7 minecraft:polished_deepslate
setblock 252 63 -7 minecraft:polished_deepslate
setblock 254 63 -7 minecraft:polished_deepslate
setblock 256 63 -7 minecraft:polished_deepslate
setblock 258 63 -7 minecraft:polished_deepslate
setblock 260 63 -7 minecraft:polished_deepslate
setblock 262 63 -7 minecraft:polished_deepslate
setblock 264 63 -7 minecraft:polished_deepslate
setblock 266 63 -7 minecraft:polished_deepslate
setblock 268 63 -7 minecraft:polished_deepslate
setblock 241 63 -7 minecraft:waxed_exposed_cut_copper
setblock 249 63 -7 minecraft:waxed_exposed_cut_copper
setblock 263 63 -7 minecraft:waxed_exposed_cut_copper
setblock 271 63 -7 minecraft:waxed_exposed_cut_copper
setblock 240 63 -6 minecraft:deepslate_tiles
setblock 244 63 -6 minecraft:deepslate_tiles
setblock 246 63 -6 minecraft:deepslate_tiles
setblock 250 63 -6 minecraft:deepslate_tiles
setblock 252 63 -6 minecraft:deepslate_tiles
setblock 254 63 -6 minecraft:deepslate_tiles
setblock 258 63 -6 minecraft:deepslate_tiles
setblock 260 63 -6 minecraft:deepslate_tiles
setblock 262 63 -6 minecraft:deepslate_tiles
setblock 266 63 -6 minecraft:deepslate_tiles
setblock 268 63 -6 minecraft:deepslate_tiles
setblock 272 63 -6 minecraft:deepslate_tiles
setblock 242 63 -6 minecraft:polished_basalt[axis=y]
setblock 270 63 -6 minecraft:polished_basalt[axis=y]
setblock 243 63 -6 minecraft:polished_deepslate
setblock 245 63 -6 minecraft:polished_deepslate
setblock 247 63 -6 minecraft:polished_deepslate
setblock 249 63 -6 minecraft:polished_deepslate
setblock 251 63 -6 minecraft:polished_deepslate
setblock 253 63 -6 minecraft:polished_deepslate
setblock 255 63 -6 minecraft:polished_deepslate
setblock 257 63 -6 minecraft:polished_deepslate
setblock 259 63 -6 minecraft:polished_deepslate
setblock 261 63 -6 minecraft:polished_deepslate
setblock 263 63 -6 minecraft:polished_deepslate
setblock 265 63 -6 minecraft:polished_deepslate
setblock 267 63 -6 minecraft:polished_deepslate
setblock 269 63 -6 minecraft:polished_deepslate
setblock 241 63 -6 minecraft:waxed_exposed_cut_copper
setblock 248 63 -6 minecraft:waxed_exposed_cut_copper
setblock 256 63 -6 minecraft:waxed_exposed_cut_copper
setblock 264 63 -6 minecraft:waxed_exposed_cut_copper
setblock 271 63 -6 minecraft:waxed_exposed_cut_copper
setblock 246 63 -5 minecraft:chiseled_deepslate
setblock 251 63 -5 minecraft:chiseled_deepslate
setblock 261 63 -5 minecraft:chiseled_deepslate
setblock 266 63 -5 minecraft:chiseled_deepslate
fill 254 63 -5 258 63 -5 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 -5 minecraft:deepslate_tiles
setblock 243 63 -5 minecraft:deepslate_tiles
setblock 245 63 -5 minecraft:deepslate_tiles
setblock 249 63 -5 minecraft:deepslate_tiles
setblock 253 63 -5 minecraft:deepslate_tiles
setblock 259 63 -5 minecraft:deepslate_tiles
setblock 263 63 -5 minecraft:deepslate_tiles
setblock 267 63 -5 minecraft:deepslate_tiles
setblock 269 63 -5 minecraft:deepslate_tiles
setblock 272 63 -5 minecraft:deepslate_tiles
setblock 242 63 -5 minecraft:polished_basalt[axis=y]
setblock 270 63 -5 minecraft:polished_basalt[axis=y]
setblock 244 63 -5 minecraft:polished_deepslate
setblock 248 63 -5 minecraft:polished_deepslate
setblock 250 63 -5 minecraft:polished_deepslate
setblock 252 63 -5 minecraft:polished_deepslate
setblock 260 63 -5 minecraft:polished_deepslate
setblock 262 63 -5 minecraft:polished_deepslate
setblock 264 63 -5 minecraft:polished_deepslate
setblock 268 63 -5 minecraft:polished_deepslate
setblock 241 63 -5 minecraft:waxed_exposed_cut_copper
setblock 247 63 -5 minecraft:waxed_exposed_cut_copper
setblock 265 63 -5 minecraft:waxed_exposed_cut_copper
setblock 271 63 -5 minecraft:waxed_exposed_cut_copper
setblock 253 63 -4 minecraft:cracked_polished_blackstone_bricks
setblock 259 63 -4 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 -4 minecraft:deepslate_tiles
setblock 244 63 -4 minecraft:deepslate_tiles
setblock 246 63 -4 minecraft:deepslate_tiles
setblock 248 63 -4 minecraft:deepslate_tiles
setblock 250 63 -4 minecraft:deepslate_tiles
setblock 252 63 -4 minecraft:deepslate_tiles
setblock 254 63 -4 minecraft:deepslate_tiles
setblock 258 63 -4 minecraft:deepslate_tiles
setblock 260 63 -4 minecraft:deepslate_tiles
setblock 262 63 -4 minecraft:deepslate_tiles
setblock 264 63 -4 minecraft:deepslate_tiles
setblock 266 63 -4 minecraft:deepslate_tiles
setblock 268 63 -4 minecraft:deepslate_tiles
setblock 272 63 -4 minecraft:deepslate_tiles
setblock 242 63 -4 minecraft:polished_basalt[axis=y]
setblock 270 63 -4 minecraft:polished_basalt[axis=y]
setblock 243 63 -4 minecraft:polished_deepslate
setblock 245 63 -4 minecraft:polished_deepslate
setblock 249 63 -4 minecraft:polished_deepslate
setblock 251 63 -4 minecraft:polished_deepslate
setblock 255 63 -4 minecraft:polished_deepslate
setblock 257 63 -4 minecraft:polished_deepslate
setblock 261 63 -4 minecraft:polished_deepslate
setblock 263 63 -4 minecraft:polished_deepslate
setblock 267 63 -4 minecraft:polished_deepslate
setblock 269 63 -4 minecraft:polished_deepslate
setblock 241 63 -4 minecraft:waxed_exposed_cut_copper
setblock 247 63 -4 minecraft:waxed_exposed_cut_copper
setblock 256 63 -4 minecraft:waxed_exposed_cut_copper
setblock 265 63 -4 minecraft:waxed_exposed_cut_copper
setblock 271 63 -4 minecraft:waxed_exposed_cut_copper
setblock 252 63 -3 minecraft:cracked_polished_blackstone_bricks
setblock 260 63 -3 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 -3 minecraft:deepslate_tiles
setblock 243 63 -3 minecraft:deepslate_tiles
setblock 245 63 -3 minecraft:deepslate_tiles
setblock 247 63 -3 minecraft:deepslate_tiles
setblock 249 63 -3 minecraft:deepslate_tiles
setblock 251 63 -3 minecraft:deepslate_tiles
setblock 253 63 -3 minecraft:deepslate_tiles
setblock 255 63 -3 minecraft:deepslate_tiles
setblock 257 63 -3 minecraft:deepslate_tiles
setblock 259 63 -3 minecraft:deepslate_tiles
setblock 261 63 -3 minecraft:deepslate_tiles
setblock 263 63 -3 minecraft:deepslate_tiles
setblock 265 63 -3 minecraft:deepslate_tiles
setblock 267 63 -3 minecraft:deepslate_tiles
setblock 269 63 -3 minecraft:deepslate_tiles
setblock 272 63 -3 minecraft:deepslate_tiles
setblock 242 63 -3 minecraft:polished_basalt[axis=y]
setblock 270 63 -3 minecraft:polished_basalt[axis=y]
setblock 244 63 -3 minecraft:polished_deepslate
setblock 248 63 -3 minecraft:polished_deepslate
setblock 250 63 -3 minecraft:polished_deepslate
setblock 254 63 -3 minecraft:polished_deepslate
setblock 256 63 -3 minecraft:polished_deepslate
setblock 258 63 -3 minecraft:polished_deepslate
setblock 262 63 -3 minecraft:polished_deepslate
setblock 264 63 -3 minecraft:polished_deepslate
setblock 268 63 -3 minecraft:polished_deepslate
setblock 241 63 -3 minecraft:waxed_exposed_cut_copper
setblock 246 63 -3 minecraft:waxed_exposed_cut_copper
setblock 266 63 -3 minecraft:waxed_exposed_cut_copper
setblock 271 63 -3 minecraft:waxed_exposed_cut_copper
setblock 251 63 -2 minecraft:cracked_polished_blackstone_bricks
setblock 261 63 -2 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 -2 minecraft:deepslate_tiles
setblock 244 63 -2 minecraft:deepslate_tiles
setblock 248 63 -2 minecraft:deepslate_tiles
setblock 250 63 -2 minecraft:deepslate_tiles
setblock 252 63 -2 minecraft:deepslate_tiles
setblock 254 63 -2 minecraft:deepslate_tiles
setblock 256 63 -2 minecraft:deepslate_tiles
setblock 258 63 -2 minecraft:deepslate_tiles
setblock 260 63 -2 minecraft:deepslate_tiles
setblock 262 63 -2 minecraft:deepslate_tiles
setblock 264 63 -2 minecraft:deepslate_tiles
setblock 268 63 -2 minecraft:deepslate_tiles
setblock 272 63 -2 minecraft:deepslate_tiles
setblock 242 63 -2 minecraft:polished_basalt[axis=y]
setblock 270 63 -2 minecraft:polished_basalt[axis=y]
setblock 243 63 -2 minecraft:polished_deepslate
setblock 245 63 -2 minecraft:polished_deepslate
setblock 247 63 -2 minecraft:polished_deepslate
setblock 249 63 -2 minecraft:polished_deepslate
setblock 253 63 -2 minecraft:polished_deepslate
setblock 255 63 -2 minecraft:polished_deepslate
setblock 257 63 -2 minecraft:polished_deepslate
setblock 259 63 -2 minecraft:polished_deepslate
setblock 263 63 -2 minecraft:polished_deepslate
setblock 265 63 -2 minecraft:polished_deepslate
setblock 267 63 -2 minecraft:polished_deepslate
setblock 269 63 -2 minecraft:polished_deepslate
setblock 241 63 -2 minecraft:waxed_exposed_cut_copper
setblock 246 63 -2 minecraft:waxed_exposed_cut_copper
setblock 266 63 -2 minecraft:waxed_exposed_cut_copper
setblock 271 63 -2 minecraft:waxed_exposed_cut_copper
setblock 251 63 -1 minecraft:cracked_polished_blackstone_bricks
setblock 261 63 -1 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 -1 minecraft:deepslate_tiles
setblock 243 63 -1 minecraft:deepslate_tiles
setblock 245 63 -1 minecraft:deepslate_tiles
setblock 247 63 -1 minecraft:deepslate_tiles
setblock 249 63 -1 minecraft:deepslate_tiles
setblock 253 63 -1 minecraft:deepslate_tiles
setblock 255 63 -1 minecraft:deepslate_tiles
setblock 257 63 -1 minecraft:deepslate_tiles
setblock 259 63 -1 minecraft:deepslate_tiles
setblock 263 63 -1 minecraft:deepslate_tiles
setblock 265 63 -1 minecraft:deepslate_tiles
setblock 267 63 -1 minecraft:deepslate_tiles
setblock 269 63 -1 minecraft:deepslate_tiles
setblock 272 63 -1 minecraft:deepslate_tiles
setblock 242 63 -1 minecraft:polished_basalt[axis=y]
setblock 270 63 -1 minecraft:polished_basalt[axis=y]
setblock 244 63 -1 minecraft:polished_deepslate
setblock 248 63 -1 minecraft:polished_deepslate
setblock 250 63 -1 minecraft:polished_deepslate
setblock 252 63 -1 minecraft:polished_deepslate
setblock 254 63 -1 minecraft:polished_deepslate
setblock 256 63 -1 minecraft:polished_deepslate
setblock 258 63 -1 minecraft:polished_deepslate
setblock 260 63 -1 minecraft:polished_deepslate
setblock 262 63 -1 minecraft:polished_deepslate
setblock 264 63 -1 minecraft:polished_deepslate
setblock 268 63 -1 minecraft:polished_deepslate
setblock 241 63 -1 minecraft:waxed_exposed_cut_copper
setblock 246 63 -1 minecraft:waxed_exposed_cut_copper
setblock 266 63 -1 minecraft:waxed_exposed_cut_copper
setblock 271 63 -1 minecraft:waxed_exposed_cut_copper
setblock 256 63 0 minecraft:chiseled_deepslate
setblock 251 63 0 minecraft:cracked_polished_blackstone_bricks
setblock 261 63 0 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 0 minecraft:deepslate_tiles
setblock 244 63 0 minecraft:deepslate_tiles
setblock 248 63 0 minecraft:deepslate_tiles
setblock 250 63 0 minecraft:deepslate_tiles
setblock 252 63 0 minecraft:deepslate_tiles
setblock 254 63 0 minecraft:deepslate_tiles
setblock 258 63 0 minecraft:deepslate_tiles
setblock 260 63 0 minecraft:deepslate_tiles
setblock 262 63 0 minecraft:deepslate_tiles
setblock 264 63 0 minecraft:deepslate_tiles
setblock 268 63 0 minecraft:deepslate_tiles
setblock 272 63 0 minecraft:deepslate_tiles
setblock 242 63 0 minecraft:polished_basalt[axis=y]
setblock 270 63 0 minecraft:polished_basalt[axis=y]
setblock 243 63 0 minecraft:polished_deepslate
setblock 245 63 0 minecraft:polished_deepslate
setblock 247 63 0 minecraft:polished_deepslate
setblock 249 63 0 minecraft:polished_deepslate
setblock 253 63 0 minecraft:polished_deepslate
setblock 255 63 0 minecraft:polished_deepslate
setblock 257 63 0 minecraft:polished_deepslate
setblock 259 63 0 minecraft:polished_deepslate
setblock 263 63 0 minecraft:polished_deepslate
setblock 265 63 0 minecraft:polished_deepslate
setblock 267 63 0 minecraft:polished_deepslate
setblock 269 63 0 minecraft:polished_deepslate
setblock 241 63 0 minecraft:waxed_exposed_cut_copper
setblock 246 63 0 minecraft:waxed_exposed_cut_copper
setblock 266 63 0 minecraft:waxed_exposed_cut_copper
setblock 271 63 0 minecraft:waxed_exposed_cut_copper
setblock 251 63 1 minecraft:cracked_polished_blackstone_bricks
setblock 261 63 1 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 1 minecraft:deepslate_tiles
setblock 243 63 1 minecraft:deepslate_tiles
setblock 245 63 1 minecraft:deepslate_tiles
setblock 247 63 1 minecraft:deepslate_tiles
setblock 249 63 1 minecraft:deepslate_tiles
setblock 253 63 1 minecraft:deepslate_tiles
setblock 255 63 1 minecraft:deepslate_tiles
setblock 257 63 1 minecraft:deepslate_tiles
setblock 259 63 1 minecraft:deepslate_tiles
setblock 263 63 1 minecraft:deepslate_tiles
setblock 265 63 1 minecraft:deepslate_tiles
setblock 267 63 1 minecraft:deepslate_tiles
setblock 269 63 1 minecraft:deepslate_tiles
setblock 272 63 1 minecraft:deepslate_tiles
setblock 242 63 1 minecraft:polished_basalt[axis=y]
setblock 270 63 1 minecraft:polished_basalt[axis=y]
setblock 244 63 1 minecraft:polished_deepslate
setblock 248 63 1 minecraft:polished_deepslate
setblock 250 63 1 minecraft:polished_deepslate
setblock 252 63 1 minecraft:polished_deepslate
setblock 254 63 1 minecraft:polished_deepslate
setblock 256 63 1 minecraft:polished_deepslate
setblock 258 63 1 minecraft:polished_deepslate
setblock 260 63 1 minecraft:polished_deepslate
setblock 262 63 1 minecraft:polished_deepslate
setblock 264 63 1 minecraft:polished_deepslate
setblock 268 63 1 minecraft:polished_deepslate
setblock 241 63 1 minecraft:waxed_exposed_cut_copper
setblock 246 63 1 minecraft:waxed_exposed_cut_copper
setblock 266 63 1 minecraft:waxed_exposed_cut_copper
setblock 271 63 1 minecraft:waxed_exposed_cut_copper
setblock 251 63 2 minecraft:cracked_polished_blackstone_bricks
setblock 261 63 2 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 2 minecraft:deepslate_tiles
setblock 244 63 2 minecraft:deepslate_tiles
setblock 248 63 2 minecraft:deepslate_tiles
setblock 250 63 2 minecraft:deepslate_tiles
setblock 252 63 2 minecraft:deepslate_tiles
setblock 254 63 2 minecraft:deepslate_tiles
setblock 256 63 2 minecraft:deepslate_tiles
setblock 258 63 2 minecraft:deepslate_tiles
setblock 260 63 2 minecraft:deepslate_tiles
setblock 262 63 2 minecraft:deepslate_tiles
setblock 264 63 2 minecraft:deepslate_tiles
setblock 268 63 2 minecraft:deepslate_tiles
setblock 272 63 2 minecraft:deepslate_tiles
setblock 242 63 2 minecraft:polished_basalt[axis=y]
setblock 270 63 2 minecraft:polished_basalt[axis=y]
setblock 243 63 2 minecraft:polished_deepslate
setblock 245 63 2 minecraft:polished_deepslate
setblock 247 63 2 minecraft:polished_deepslate
setblock 249 63 2 minecraft:polished_deepslate
setblock 253 63 2 minecraft:polished_deepslate
setblock 255 63 2 minecraft:polished_deepslate
setblock 257 63 2 minecraft:polished_deepslate
setblock 259 63 2 minecraft:polished_deepslate
setblock 263 63 2 minecraft:polished_deepslate
setblock 265 63 2 minecraft:polished_deepslate
setblock 267 63 2 minecraft:polished_deepslate
setblock 269 63 2 minecraft:polished_deepslate
setblock 241 63 2 minecraft:waxed_exposed_cut_copper
setblock 246 63 2 minecraft:waxed_exposed_cut_copper
setblock 266 63 2 minecraft:waxed_exposed_cut_copper
setblock 271 63 2 minecraft:waxed_exposed_cut_copper
setblock 252 63 3 minecraft:cracked_polished_blackstone_bricks
setblock 260 63 3 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 3 minecraft:deepslate_tiles
setblock 243 63 3 minecraft:deepslate_tiles
setblock 245 63 3 minecraft:deepslate_tiles
setblock 247 63 3 minecraft:deepslate_tiles
setblock 249 63 3 minecraft:deepslate_tiles
setblock 251 63 3 minecraft:deepslate_tiles
setblock 253 63 3 minecraft:deepslate_tiles
setblock 255 63 3 minecraft:deepslate_tiles
setblock 257 63 3 minecraft:deepslate_tiles
setblock 259 63 3 minecraft:deepslate_tiles
setblock 261 63 3 minecraft:deepslate_tiles
setblock 263 63 3 minecraft:deepslate_tiles
setblock 265 63 3 minecraft:deepslate_tiles
setblock 267 63 3 minecraft:deepslate_tiles
setblock 269 63 3 minecraft:deepslate_tiles
setblock 272 63 3 minecraft:deepslate_tiles
setblock 242 63 3 minecraft:polished_basalt[axis=y]
setblock 270 63 3 minecraft:polished_basalt[axis=y]
setblock 244 63 3 minecraft:polished_deepslate
setblock 248 63 3 minecraft:polished_deepslate
setblock 250 63 3 minecraft:polished_deepslate
setblock 254 63 3 minecraft:polished_deepslate
setblock 256 63 3 minecraft:polished_deepslate
setblock 258 63 3 minecraft:polished_deepslate
setblock 262 63 3 minecraft:polished_deepslate
setblock 264 63 3 minecraft:polished_deepslate
setblock 268 63 3 minecraft:polished_deepslate
setblock 241 63 3 minecraft:waxed_exposed_cut_copper
setblock 246 63 3 minecraft:waxed_exposed_cut_copper
setblock 266 63 3 minecraft:waxed_exposed_cut_copper
setblock 271 63 3 minecraft:waxed_exposed_cut_copper
setblock 253 63 4 minecraft:cracked_polished_blackstone_bricks
setblock 259 63 4 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 4 minecraft:deepslate_tiles
setblock 244 63 4 minecraft:deepslate_tiles
setblock 246 63 4 minecraft:deepslate_tiles
setblock 248 63 4 minecraft:deepslate_tiles
setblock 250 63 4 minecraft:deepslate_tiles
setblock 252 63 4 minecraft:deepslate_tiles
setblock 254 63 4 minecraft:deepslate_tiles
setblock 258 63 4 minecraft:deepslate_tiles
setblock 260 63 4 minecraft:deepslate_tiles
setblock 262 63 4 minecraft:deepslate_tiles
setblock 264 63 4 minecraft:deepslate_tiles
setblock 266 63 4 minecraft:deepslate_tiles
setblock 268 63 4 minecraft:deepslate_tiles
setblock 272 63 4 minecraft:deepslate_tiles
setblock 242 63 4 minecraft:polished_basalt[axis=y]
setblock 270 63 4 minecraft:polished_basalt[axis=y]
setblock 243 63 4 minecraft:polished_deepslate
setblock 245 63 4 minecraft:polished_deepslate
setblock 249 63 4 minecraft:polished_deepslate
setblock 251 63 4 minecraft:polished_deepslate
setblock 255 63 4 minecraft:polished_deepslate
setblock 257 63 4 minecraft:polished_deepslate
setblock 261 63 4 minecraft:polished_deepslate
setblock 263 63 4 minecraft:polished_deepslate
setblock 267 63 4 minecraft:polished_deepslate
setblock 269 63 4 minecraft:polished_deepslate
setblock 241 63 4 minecraft:waxed_exposed_cut_copper
setblock 247 63 4 minecraft:waxed_exposed_cut_copper
setblock 256 63 4 minecraft:waxed_exposed_cut_copper
setblock 265 63 4 minecraft:waxed_exposed_cut_copper
setblock 271 63 4 minecraft:waxed_exposed_cut_copper
setblock 246 63 5 minecraft:chiseled_deepslate
setblock 251 63 5 minecraft:chiseled_deepslate
setblock 261 63 5 minecraft:chiseled_deepslate
setblock 266 63 5 minecraft:chiseled_deepslate
fill 254 63 5 258 63 5 minecraft:cracked_polished_blackstone_bricks
setblock 240 63 5 minecraft:deepslate_tiles
setblock 243 63 5 minecraft:deepslate_tiles
setblock 245 63 5 minecraft:deepslate_tiles
setblock 249 63 5 minecraft:deepslate_tiles
setblock 253 63 5 minecraft:deepslate_tiles
setblock 259 63 5 minecraft:deepslate_tiles
setblock 263 63 5 minecraft:deepslate_tiles
setblock 267 63 5 minecraft:deepslate_tiles
setblock 269 63 5 minecraft:deepslate_tiles
setblock 272 63 5 minecraft:deepslate_tiles
setblock 242 63 5 minecraft:polished_basalt[axis=y]
setblock 270 63 5 minecraft:polished_basalt[axis=y]
setblock 244 63 5 minecraft:polished_deepslate
setblock 248 63 5 minecraft:polished_deepslate
setblock 250 63 5 minecraft:polished_deepslate
setblock 252 63 5 minecraft:polished_deepslate
setblock 260 63 5 minecraft:polished_deepslate
setblock 262 63 5 minecraft:polished_deepslate
setblock 264 63 5 minecraft:polished_deepslate
setblock 268 63 5 minecraft:polished_deepslate
setblock 241 63 5 minecraft:waxed_exposed_cut_copper
setblock 247 63 5 minecraft:waxed_exposed_cut_copper
setblock 265 63 5 minecraft:waxed_exposed_cut_copper
setblock 271 63 5 minecraft:waxed_exposed_cut_copper
setblock 240 63 6 minecraft:deepslate_tiles
setblock 244 63 6 minecraft:deepslate_tiles
setblock 246 63 6 minecraft:deepslate_tiles
setblock 250 63 6 minecraft:deepslate_tiles
setblock 252 63 6 minecraft:deepslate_tiles
setblock 254 63 6 minecraft:deepslate_tiles
setblock 258 63 6 minecraft:deepslate_tiles
setblock 260 63 6 minecraft:deepslate_tiles
setblock 262 63 6 minecraft:deepslate_tiles
setblock 266 63 6 minecraft:deepslate_tiles
setblock 268 63 6 minecraft:deepslate_tiles
setblock 272 63 6 minecraft:deepslate_tiles
setblock 242 63 6 minecraft:polished_basalt[axis=y]
setblock 270 63 6 minecraft:polished_basalt[axis=y]
setblock 243 63 6 minecraft:polished_deepslate
setblock 245 63 6 minecraft:polished_deepslate
setblock 247 63 6 minecraft:polished_deepslate
setblock 249 63 6 minecraft:polished_deepslate
setblock 251 63 6 minecraft:polished_deepslate
setblock 253 63 6 minecraft:polished_deepslate
setblock 255 63 6 minecraft:polished_deepslate
setblock 257 63 6 minecraft:polished_deepslate
setblock 259 63 6 minecraft:polished_deepslate
setblock 261 63 6 minecraft:polished_deepslate
setblock 263 63 6 minecraft:polished_deepslate
setblock 265 63 6 minecraft:polished_deepslate
setblock 267 63 6 minecraft:polished_deepslate
setblock 269 63 6 minecraft:polished_deepslate
setblock 241 63 6 minecraft:waxed_exposed_cut_copper
setblock 248 63 6 minecraft:waxed_exposed_cut_copper
setblock 256 63 6 minecraft:waxed_exposed_cut_copper
setblock 264 63 6 minecraft:waxed_exposed_cut_copper
setblock 271 63 6 minecraft:waxed_exposed_cut_copper
setblock 240 63 7 minecraft:deepslate_tiles
setblock 243 63 7 minecraft:deepslate_tiles
setblock 245 63 7 minecraft:deepslate_tiles
setblock 247 63 7 minecraft:deepslate_tiles
setblock 251 63 7 minecraft:deepslate_tiles
setblock 253 63 7 minecraft:deepslate_tiles
setblock 255 63 7 minecraft:deepslate_tiles
setblock 257 63 7 minecraft:deepslate_tiles
setblock 259 63 7 minecraft:deepslate_tiles
setblock 261 63 7 minecraft:deepslate_tiles
setblock 265 63 7 minecraft:deepslate_tiles
setblock 267 63 7 minecraft:deepslate_tiles
setblock 269 63 7 minecraft:deepslate_tiles
setblock 272 63 7 minecraft:deepslate_tiles
setblock 242 63 7 minecraft:polished_basalt[axis=y]
setblock 270 63 7 minecraft:polished_basalt[axis=y]
setblock 244 63 7 minecraft:polished_deepslate
setblock 246 63 7 minecraft:polished_deepslate
setblock 248 63 7 minecraft:polished_deepslate
setblock 250 63 7 minecraft:polished_deepslate
setblock 252 63 7 minecraft:polished_deepslate
setblock 254 63 7 minecraft:polished_deepslate
setblock 256 63 7 minecraft:polished_deepslate
setblock 258 63 7 minecraft:polished_deepslate
setblock 260 63 7 minecraft:polished_deepslate
setblock 262 63 7 minecraft:polished_deepslate
setblock 264 63 7 minecraft:polished_deepslate
setblock 266 63 7 minecraft:polished_deepslate
setblock 268 63 7 minecraft:polished_deepslate
setblock 241 63 7 minecraft:waxed_exposed_cut_copper
setblock 249 63 7 minecraft:waxed_exposed_cut_copper
setblock 263 63 7 minecraft:waxed_exposed_cut_copper
setblock 271 63 7 minecraft:waxed_exposed_cut_copper
setblock 268 63 8 minecraft:chiseled_quartz_block
setblock 240 63 8 minecraft:deepslate_tiles
setblock 244 63 8 minecraft:deepslate_tiles
setblock 246 63 8 minecraft:deepslate_tiles
setblock 248 63 8 minecraft:deepslate_tiles
setblock 252 63 8 minecraft:deepslate_tiles
setblock 254 63 8 minecraft:deepslate_tiles
setblock 256 63 8 minecraft:deepslate_tiles
setblock 258 63 8 minecraft:deepslate_tiles
setblock 260 63 8 minecraft:deepslate_tiles
setblock 264 63 8 minecraft:deepslate_tiles
setblock 266 63 8 minecraft:deepslate_tiles
setblock 272 63 8 minecraft:deepslate_tiles
setblock 242 63 8 minecraft:polished_basalt[axis=y]
setblock 270 63 8 minecraft:polished_basalt[axis=y]
setblock 243 63 8 minecraft:polished_deepslate
setblock 245 63 8 minecraft:polished_deepslate
setblock 247 63 8 minecraft:polished_deepslate
setblock 249 63 8 minecraft:polished_deepslate
setblock 251 63 8 minecraft:polished_deepslate
setblock 253 63 8 minecraft:polished_deepslate
setblock 255 63 8 minecraft:polished_deepslate
setblock 257 63 8 minecraft:polished_deepslate
setblock 259 63 8 minecraft:polished_deepslate
setblock 261 63 8 minecraft:polished_deepslate
setblock 263 63 8 minecraft:polished_deepslate
setblock 265 63 8 minecraft:polished_deepslate
setblock 267 63 8 minecraft:polished_deepslate
setblock 269 63 8 minecraft:polished_deepslate
setblock 241 63 8 minecraft:waxed_exposed_cut_copper
setblock 250 63 8 minecraft:waxed_exposed_cut_copper
setblock 262 63 8 minecraft:waxed_exposed_cut_copper
setblock 271 63 8 minecraft:waxed_exposed_cut_copper
setblock 240 63 9 minecraft:deepslate_tiles
setblock 243 63 9 minecraft:deepslate_tiles
setblock 245 63 9 minecraft:deepslate_tiles
setblock 247 63 9 minecraft:deepslate_tiles
setblock 249 63 9 minecraft:deepslate_tiles
setblock 253 63 9 minecraft:deepslate_tiles
setblock 255 63 9 minecraft:deepslate_tiles
setblock 257 63 9 minecraft:deepslate_tiles
setblock 259 63 9 minecraft:deepslate_tiles
setblock 263 63 9 minecraft:deepslate_tiles
setblock 265 63 9 minecraft:deepslate_tiles
setblock 267 63 9 minecraft:deepslate_tiles
setblock 269 63 9 minecraft:deepslate_tiles
setblock 272 63 9 minecraft:deepslate_tiles
setblock 242 63 9 minecraft:polished_basalt[axis=y]
setblock 270 63 9 minecraft:polished_basalt[axis=y]
setblock 244 63 9 minecraft:polished_deepslate
setblock 246 63 9 minecraft:polished_deepslate
setblock 248 63 9 minecraft:polished_deepslate
setblock 250 63 9 minecraft:polished_deepslate
setblock 254 63 9 minecraft:polished_deepslate
setblock 256 63 9 minecraft:polished_deepslate
setblock 258 63 9 minecraft:polished_deepslate
setblock 262 63 9 minecraft:polished_deepslate
setblock 264 63 9 minecraft:polished_deepslate
setblock 266 63 9 minecraft:polished_deepslate
setblock 268 63 9 minecraft:polished_deepslate
setblock 241 63 9 minecraft:waxed_exposed_cut_copper
fill 251 63 9 252 63 9 minecraft:waxed_exposed_cut_copper
fill 260 63 9 261 63 9 minecraft:waxed_exposed_cut_copper
setblock 271 63 9 minecraft:waxed_exposed_cut_copper
setblock 246 63 10 minecraft:chiseled_deepslate
setblock 251 63 10 minecraft:chiseled_deepslate
setblock 261 63 10 minecraft:chiseled_deepslate
setblock 266 63 10 minecraft:chiseled_deepslate
setblock 240 63 10 minecraft:deepslate_tiles
setblock 244 63 10 minecraft:deepslate_tiles
setblock 248 63 10 minecraft:deepslate_tiles
setblock 250 63 10 minecraft:deepslate_tiles
setblock 252 63 10 minecraft:deepslate_tiles
setblock 260 63 10 minecraft:deepslate_tiles
setblock 262 63 10 minecraft:deepslate_tiles
setblock 264 63 10 minecraft:deepslate_tiles
setblock 268 63 10 minecraft:deepslate_tiles
setblock 272 63 10 minecraft:deepslate_tiles
setblock 242 63 10 minecraft:polished_basalt[axis=y]
setblock 270 63 10 minecraft:polished_basalt[axis=y]
setblock 243 63 10 minecraft:polished_deepslate
setblock 247 63 10 minecraft:polished_deepslate
setblock 249 63 10 minecraft:polished_deepslate
setblock 263 63 10 minecraft:polished_deepslate
setblock 265 63 10 minecraft:polished_deepslate
setblock 269 63 10 minecraft:polished_deepslate
setblock 241 63 10 minecraft:waxed_exposed_cut_copper
setblock 245 63 10 minecraft:waxed_exposed_cut_copper
fill 253 63 10 259 63 10 minecraft:waxed_exposed_cut_copper
setblock 267 63 10 minecraft:waxed_exposed_cut_copper
setblock 271 63 10 minecraft:waxed_exposed_cut_copper
setblock 240 63 11 minecraft:deepslate_tiles
setblock 243 63 11 minecraft:deepslate_tiles
setblock 247 63 11 minecraft:deepslate_tiles
setblock 249 63 11 minecraft:deepslate_tiles
setblock 251 63 11 minecraft:deepslate_tiles
setblock 253 63 11 minecraft:deepslate_tiles
setblock 255 63 11 minecraft:deepslate_tiles
setblock 257 63 11 minecraft:deepslate_tiles
setblock 259 63 11 minecraft:deepslate_tiles
setblock 261 63 11 minecraft:deepslate_tiles
setblock 263 63 11 minecraft:deepslate_tiles
setblock 265 63 11 minecraft:deepslate_tiles
setblock 269 63 11 minecraft:deepslate_tiles
setblock 272 63 11 minecraft:deepslate_tiles
setblock 242 63 11 minecraft:polished_basalt[axis=y]
setblock 270 63 11 minecraft:polished_basalt[axis=y]
setblock 248 63 11 minecraft:polished_deepslate
setblock 250 63 11 minecraft:polished_deepslate
setblock 252 63 11 minecraft:polished_deepslate
setblock 254 63 11 minecraft:polished_deepslate
setblock 256 63 11 minecraft:polished_deepslate
setblock 258 63 11 minecraft:polished_deepslate
setblock 260 63 11 minecraft:polished_deepslate
setblock 262 63 11 minecraft:polished_deepslate
setblock 264 63 11 minecraft:polished_deepslate
setblock 245 63 11 minecraft:sea_lantern
setblock 267 63 11 minecraft:sea_lantern
setblock 241 63 11 minecraft:waxed_exposed_cut_copper
setblock 244 63 11 minecraft:waxed_exposed_cut_copper
setblock 246 63 11 minecraft:waxed_exposed_cut_copper
setblock 266 63 11 minecraft:waxed_exposed_cut_copper
setblock 268 63 11 minecraft:waxed_exposed_cut_copper
setblock 271 63 11 minecraft:waxed_exposed_cut_copper
setblock 240 63 12 minecraft:deepslate_tiles
setblock 244 63 12 minecraft:deepslate_tiles
setblock 246 63 12 minecraft:deepslate_tiles
setblock 248 63 12 minecraft:deepslate_tiles
setblock 250 63 12 minecraft:deepslate_tiles
setblock 252 63 12 minecraft:deepslate_tiles
setblock 254 63 12 minecraft:deepslate_tiles
setblock 258 63 12 minecraft:deepslate_tiles
setblock 260 63 12 minecraft:deepslate_tiles
setblock 262 63 12 minecraft:deepslate_tiles
setblock 264 63 12 minecraft:deepslate_tiles
setblock 266 63 12 minecraft:deepslate_tiles
setblock 268 63 12 minecraft:deepslate_tiles
setblock 272 63 12 minecraft:deepslate_tiles
setblock 242 63 12 minecraft:polished_basalt[axis=y]
setblock 270 63 12 minecraft:polished_basalt[axis=y]
setblock 243 63 12 minecraft:polished_deepslate
setblock 247 63 12 minecraft:polished_deepslate
setblock 249 63 12 minecraft:polished_deepslate
setblock 251 63 12 minecraft:polished_deepslate
setblock 253 63 12 minecraft:polished_deepslate
setblock 255 63 12 minecraft:polished_deepslate
setblock 259 63 12 minecraft:polished_deepslate
setblock 261 63 12 minecraft:polished_deepslate
setblock 263 63 12 minecraft:polished_deepslate
setblock 265 63 12 minecraft:polished_deepslate
setblock 269 63 12 minecraft:polished_deepslate
fill 256 63 12 257 63 12 minecraft:quartz_block
setblock 241 63 12 minecraft:waxed_exposed_cut_copper
setblock 245 63 12 minecraft:waxed_exposed_cut_copper
setblock 267 63 12 minecraft:waxed_exposed_cut_copper
setblock 271 63 12 minecraft:waxed_exposed_cut_copper
setblock 240 63 13 minecraft:deepslate_tiles
setblock 243 63 13 minecraft:deepslate_tiles
setblock 245 63 13 minecraft:deepslate_tiles
setblock 247 63 13 minecraft:deepslate_tiles
setblock 249 63 13 minecraft:deepslate_tiles
setblock 251 63 13 minecraft:deepslate_tiles
setblock 253 63 13 minecraft:deepslate_tiles
setblock 255 63 13 minecraft:deepslate_tiles
setblock 259 63 13 minecraft:deepslate_tiles
setblock 261 63 13 minecraft:deepslate_tiles
setblock 263 63 13 minecraft:deepslate_tiles
setblock 265 63 13 minecraft:deepslate_tiles
setblock 267 63 13 minecraft:deepslate_tiles
setblock 269 63 13 minecraft:deepslate_tiles
setblock 272 63 13 minecraft:deepslate_tiles
setblock 242 63 13 minecraft:polished_basalt[axis=y]
setblock 270 63 13 minecraft:polished_basalt[axis=y]
setblock 244 63 13 minecraft:polished_deepslate
setblock 246 63 13 minecraft:polished_deepslate
setblock 248 63 13 minecraft:polished_deepslate
setblock 250 63 13 minecraft:polished_deepslate
setblock 252 63 13 minecraft:polished_deepslate
setblock 254 63 13 minecraft:polished_deepslate
setblock 258 63 13 minecraft:polished_deepslate
setblock 260 63 13 minecraft:polished_deepslate
setblock 262 63 13 minecraft:polished_deepslate
setblock 264 63 13 minecraft:polished_deepslate
setblock 266 63 13 minecraft:polished_deepslate
setblock 268 63 13 minecraft:polished_deepslate
fill 256 63 13 257 63 13 minecraft:quartz_block
setblock 241 63 13 minecraft:waxed_exposed_cut_copper
setblock 271 63 13 minecraft:waxed_exposed_cut_copper
setblock 240 63 14 minecraft:deepslate_tiles
setblock 272 63 14 minecraft:deepslate_tiles
fill 242 63 14 270 63 14 minecraft:polished_basalt[axis=y]
setblock 241 63 14 minecraft:waxed_exposed_cut_copper
setblock 271 63 14 minecraft:waxed_exposed_cut_copper
setblock 240 63 15 minecraft:deepslate_tiles
setblock 272 63 15 minecraft:deepslate_tiles
fill 241 63 15 271 63 15 minecraft:waxed_exposed_cut_copper
fill 240 63 16 272 63 16 minecraft:deepslate_tiles
fill 240 64 -16 272 64 -16 minecraft:polished_blackstone_bricks
setblock 240 64 -15 minecraft:polished_blackstone_bricks
setblock 272 64 -15 minecraft:polished_blackstone_bricks
setblock 244 64 -15 minecraft:waxed_exposed_cut_copper
setblock 250 64 -15 minecraft:waxed_exposed_cut_copper
setblock 256 64 -15 minecraft:waxed_exposed_cut_copper
setblock 262 64 -15 minecraft:waxed_exposed_cut_copper
setblock 268 64 -15 minecraft:waxed_exposed_cut_copper
setblock 240 64 -14 minecraft:polished_blackstone_bricks
setblock 272 64 -14 minecraft:polished_blackstone_bricks
setblock 240 64 -13 minecraft:polished_blackstone_bricks
setblock 272 64 -13 minecraft:polished_blackstone_bricks
setblock 240 64 -12 minecraft:polished_blackstone_bricks
setblock 272 64 -12 minecraft:polished_blackstone_bricks
setblock 241 64 -12 minecraft:waxed_exposed_cut_copper
setblock 271 64 -12 minecraft:waxed_exposed_cut_copper
setblock 243 64 -11 minecraft:polished_basalt[axis=y]
setblock 269 64 -11 minecraft:polished_basalt[axis=y]
setblock 240 64 -11 minecraft:polished_blackstone_bricks
setblock 272 64 -11 minecraft:polished_blackstone_bricks
setblock 240 64 -10 minecraft:polished_blackstone_bricks
setblock 272 64 -10 minecraft:polished_blackstone_bricks
setblock 240 64 -9 minecraft:polished_blackstone_bricks
setblock 272 64 -9 minecraft:polished_blackstone_bricks
setblock 240 64 -8 minecraft:polished_blackstone_bricks
setblock 272 64 -8 minecraft:polished_blackstone_bricks
setblock 240 64 -7 minecraft:polished_blackstone_bricks
setblock 272 64 -7 minecraft:polished_blackstone_bricks
setblock 240 64 -6 minecraft:polished_blackstone_bricks
setblock 272 64 -6 minecraft:polished_blackstone_bricks
setblock 241 64 -6 minecraft:waxed_exposed_cut_copper
setblock 271 64 -6 minecraft:waxed_exposed_cut_copper
setblock 240 64 -5 minecraft:polished_blackstone_bricks
setblock 272 64 -5 minecraft:polished_blackstone_bricks
setblock 240 64 -4 minecraft:polished_blackstone_bricks
setblock 272 64 -4 minecraft:polished_blackstone_bricks
setblock 240 64 -3 minecraft:polished_blackstone_bricks
setblock 272 64 -3 minecraft:polished_blackstone_bricks
setblock 240 64 -2 minecraft:polished_blackstone_bricks
setblock 272 64 -2 minecraft:polished_blackstone_bricks
setblock 240 64 -1 minecraft:polished_blackstone_bricks
setblock 272 64 -1 minecraft:polished_blackstone_bricks
setblock 243 64 0 minecraft:polished_basalt[axis=y]
setblock 269 64 0 minecraft:polished_basalt[axis=y]
setblock 240 64 0 minecraft:polished_blackstone_bricks
setblock 272 64 0 minecraft:polished_blackstone_bricks
setblock 241 64 0 minecraft:waxed_exposed_cut_copper
setblock 271 64 0 minecraft:waxed_exposed_cut_copper
setblock 240 64 1 minecraft:polished_blackstone_bricks
setblock 272 64 1 minecraft:polished_blackstone_bricks
setblock 240 64 2 minecraft:polished_blackstone_bricks
setblock 272 64 2 minecraft:polished_blackstone_bricks
setblock 240 64 3 minecraft:polished_blackstone_bricks
setblock 272 64 3 minecraft:polished_blackstone_bricks
setblock 240 64 4 minecraft:polished_blackstone_bricks
setblock 272 64 4 minecraft:polished_blackstone_bricks
setblock 240 64 5 minecraft:polished_blackstone_bricks
setblock 272 64 5 minecraft:polished_blackstone_bricks
setblock 240 64 6 minecraft:polished_blackstone_bricks
setblock 272 64 6 minecraft:polished_blackstone_bricks
setblock 241 64 6 minecraft:waxed_exposed_cut_copper
setblock 271 64 6 minecraft:waxed_exposed_cut_copper
setblock 240 64 7 minecraft:polished_blackstone_bricks
setblock 270 64 7 minecraft:polished_blackstone_bricks
setblock 272 64 7 minecraft:polished_blackstone_bricks
setblock 240 64 8 minecraft:polished_blackstone_bricks
setblock 270 64 8 minecraft:polished_blackstone_bricks
setblock 272 64 8 minecraft:polished_blackstone_bricks
setblock 240 64 9 minecraft:polished_blackstone_bricks
setblock 270 64 9 minecraft:polished_blackstone_bricks
setblock 272 64 9 minecraft:polished_blackstone_bricks
setblock 240 64 10 minecraft:polished_blackstone_bricks
setblock 272 64 10 minecraft:polished_blackstone_bricks
setblock 243 64 11 minecraft:polished_basalt[axis=y]
setblock 269 64 11 minecraft:polished_basalt[axis=y]
setblock 240 64 11 minecraft:polished_blackstone_bricks
setblock 272 64 11 minecraft:polished_blackstone_bricks
setblock 240 64 12 minecraft:polished_blackstone_bricks
setblock 272 64 12 minecraft:polished_blackstone_bricks
setblock 241 64 12 minecraft:waxed_exposed_cut_copper
setblock 271 64 12 minecraft:waxed_exposed_cut_copper
setblock 240 64 13 minecraft:polished_blackstone_bricks
setblock 272 64 13 minecraft:polished_blackstone_bricks
setblock 240 64 14 minecraft:polished_blackstone_bricks
setblock 272 64 14 minecraft:polished_blackstone_bricks
setblock 240 64 15 minecraft:polished_blackstone_bricks
setblock 272 64 15 minecraft:polished_blackstone_bricks
setblock 244 64 15 minecraft:waxed_exposed_cut_copper
setblock 250 64 15 minecraft:waxed_exposed_cut_copper
setblock 256 64 15 minecraft:waxed_exposed_cut_copper
setblock 262 64 15 minecraft:waxed_exposed_cut_copper
setblock 268 64 15 minecraft:waxed_exposed_cut_copper
fill 240 64 16 272 64 16 minecraft:polished_blackstone_bricks
fill 240 65 -16 272 65 -16 minecraft:polished_blackstone_bricks
setblock 240 65 -15 minecraft:polished_blackstone_bricks
setblock 272 65 -15 minecraft:polished_blackstone_bricks
setblock 244 65 -15 minecraft:waxed_exposed_cut_copper
setblock 250 65 -15 minecraft:waxed_exposed_cut_copper
setblock 256 65 -15 minecraft:waxed_exposed_cut_copper
setblock 262 65 -15 minecraft:waxed_exposed_cut_copper
setblock 268 65 -15 minecraft:waxed_exposed_cut_copper
setblock 240 65 -14 minecraft:polished_blackstone_bricks
setblock 272 65 -14 minecraft:polished_blackstone_bricks
setblock 240 65 -13 minecraft:polished_blackstone_bricks
setblock 272 65 -13 minecraft:polished_blackstone_bricks
setblock 240 65 -12 minecraft:polished_blackstone_bricks
setblock 272 65 -12 minecraft:polished_blackstone_bricks
setblock 241 65 -12 minecraft:waxed_exposed_cut_copper
setblock 271 65 -12 minecraft:waxed_exposed_cut_copper
setblock 243 65 -11 minecraft:polished_basalt[axis=y]
setblock 269 65 -11 minecraft:polished_basalt[axis=y]
setblock 240 65 -11 minecraft:polished_blackstone_bricks
setblock 272 65 -11 minecraft:polished_blackstone_bricks
setblock 240 65 -10 minecraft:polished_blackstone_bricks
setblock 272 65 -10 minecraft:polished_blackstone_bricks
setblock 240 65 -9 minecraft:polished_blackstone_bricks
setblock 272 65 -9 minecraft:polished_blackstone_bricks
setblock 240 65 -8 minecraft:polished_blackstone_bricks
setblock 272 65 -8 minecraft:polished_blackstone_bricks
setblock 240 65 -7 minecraft:polished_blackstone_bricks
setblock 272 65 -7 minecraft:polished_blackstone_bricks
setblock 240 65 -6 minecraft:polished_blackstone_bricks
setblock 272 65 -6 minecraft:polished_blackstone_bricks
setblock 241 65 -6 minecraft:waxed_exposed_cut_copper
setblock 271 65 -6 minecraft:waxed_exposed_cut_copper
setblock 240 65 -5 minecraft:polished_blackstone_bricks
setblock 272 65 -5 minecraft:polished_blackstone_bricks
setblock 240 65 -4 minecraft:polished_blackstone_bricks
setblock 272 65 -4 minecraft:polished_blackstone_bricks
setblock 240 65 -3 minecraft:polished_blackstone_bricks
setblock 272 65 -3 minecraft:polished_blackstone_bricks
setblock 240 65 -2 minecraft:polished_blackstone_bricks
setblock 272 65 -2 minecraft:polished_blackstone_bricks
setblock 240 65 -1 minecraft:polished_blackstone_bricks
setblock 272 65 -1 minecraft:polished_blackstone_bricks
setblock 243 65 0 minecraft:polished_basalt[axis=y]
setblock 269 65 0 minecraft:polished_basalt[axis=y]
setblock 240 65 0 minecraft:polished_blackstone_bricks
setblock 272 65 0 minecraft:polished_blackstone_bricks
setblock 241 65 0 minecraft:waxed_exposed_cut_copper
setblock 271 65 0 minecraft:waxed_exposed_cut_copper
setblock 240 65 1 minecraft:polished_blackstone_bricks
setblock 272 65 1 minecraft:polished_blackstone_bricks
setblock 240 65 2 minecraft:polished_blackstone_bricks
setblock 272 65 2 minecraft:polished_blackstone_bricks
setblock 240 65 3 minecraft:polished_blackstone_bricks
setblock 272 65 3 minecraft:polished_blackstone_bricks
setblock 240 65 4 minecraft:polished_blackstone_bricks
setblock 272 65 4 minecraft:polished_blackstone_bricks
setblock 240 65 5 minecraft:polished_blackstone_bricks
setblock 272 65 5 minecraft:polished_blackstone_bricks
setblock 240 65 6 minecraft:polished_blackstone_bricks
setblock 272 65 6 minecraft:polished_blackstone_bricks
setblock 241 65 6 minecraft:waxed_exposed_cut_copper
setblock 271 65 6 minecraft:waxed_exposed_cut_copper
setblock 240 65 7 minecraft:polished_blackstone_bricks
setblock 270 65 7 minecraft:polished_blackstone_bricks
setblock 272 65 7 minecraft:polished_blackstone_bricks
setblock 240 65 8 minecraft:polished_blackstone_bricks
setblock 270 65 8 minecraft:polished_blackstone_bricks
setblock 272 65 8 minecraft:polished_blackstone_bricks
setblock 240 65 9 minecraft:polished_blackstone_bricks
setblock 270 65 9 minecraft:polished_blackstone_bricks
setblock 272 65 9 minecraft:polished_blackstone_bricks
setblock 240 65 10 minecraft:polished_blackstone_bricks
setblock 272 65 10 minecraft:polished_blackstone_bricks
setblock 243 65 11 minecraft:polished_basalt[axis=y]
setblock 269 65 11 minecraft:polished_basalt[axis=y]
setblock 240 65 11 minecraft:polished_blackstone_bricks
setblock 272 65 11 minecraft:polished_blackstone_bricks
setblock 240 65 12 minecraft:polished_blackstone_bricks
setblock 272 65 12 minecraft:polished_blackstone_bricks
setblock 241 65 12 minecraft:waxed_exposed_cut_copper
setblock 271 65 12 minecraft:waxed_exposed_cut_copper
setblock 240 65 13 minecraft:polished_blackstone_bricks
setblock 272 65 13 minecraft:polished_blackstone_bricks
setblock 240 65 14 minecraft:polished_blackstone_bricks
setblock 272 65 14 minecraft:polished_blackstone_bricks
setblock 240 65 15 minecraft:polished_blackstone_bricks
setblock 272 65 15 minecraft:polished_blackstone_bricks
setblock 244 65 15 minecraft:waxed_exposed_cut_copper
setblock 250 65 15 minecraft:waxed_exposed_cut_copper
setblock 256 65 15 minecraft:waxed_exposed_cut_copper
setblock 262 65 15 minecraft:waxed_exposed_cut_copper
setblock 268 65 15 minecraft:waxed_exposed_cut_copper
fill 240 65 16 272 65 16 minecraft:polished_blackstone_bricks
fill 240 66 -16 272 66 -16 minecraft:polished_blackstone_bricks
setblock 240 66 -15 minecraft:polished_blackstone_bricks
setblock 272 66 -15 minecraft:polished_blackstone_bricks
fill 241 66 -15 271 66 -15 minecraft:waxed_exposed_cut_copper
setblock 240 66 -14 minecraft:polished_blackstone_bricks
setblock 272 66 -14 minecraft:polished_blackstone_bricks
setblock 241 66 -14 minecraft:waxed_exposed_cut_copper
setblock 271 66 -14 minecraft:waxed_exposed_cut_copper
setblock 240 66 -13 minecraft:polished_blackstone_bricks
setblock 272 66 -13 minecraft:polished_blackstone_bricks
setblock 241 66 -13 minecraft:waxed_exposed_cut_copper
setblock 271 66 -13 minecraft:waxed_exposed_cut_copper
setblock 240 66 -12 minecraft:polished_blackstone_bricks
setblock 272 66 -12 minecraft:polished_blackstone_bricks
setblock 241 66 -12 minecraft:waxed_exposed_cut_copper
setblock 271 66 -12 minecraft:waxed_exposed_cut_copper
setblock 243 66 -11 minecraft:polished_basalt[axis=y]
setblock 269 66 -11 minecraft:polished_basalt[axis=y]
setblock 240 66 -11 minecraft:polished_blackstone_bricks
setblock 272 66 -11 minecraft:polished_blackstone_bricks
setblock 241 66 -11 minecraft:waxed_exposed_cut_copper
setblock 271 66 -11 minecraft:waxed_exposed_cut_copper
setblock 240 66 -10 minecraft:polished_blackstone_bricks
setblock 272 66 -10 minecraft:polished_blackstone_bricks
setblock 241 66 -10 minecraft:waxed_exposed_cut_copper
setblock 271 66 -10 minecraft:waxed_exposed_cut_copper
setblock 240 66 -9 minecraft:polished_blackstone_bricks
setblock 272 66 -9 minecraft:polished_blackstone_bricks
setblock 241 66 -9 minecraft:waxed_exposed_cut_copper
setblock 271 66 -9 minecraft:waxed_exposed_cut_copper
setblock 240 66 -8 minecraft:polished_blackstone_bricks
setblock 272 66 -8 minecraft:polished_blackstone_bricks
setblock 241 66 -8 minecraft:waxed_exposed_cut_copper
setblock 271 66 -8 minecraft:waxed_exposed_cut_copper
setblock 240 66 -7 minecraft:polished_blackstone_bricks
setblock 272 66 -7 minecraft:polished_blackstone_bricks
setblock 241 66 -7 minecraft:waxed_exposed_cut_copper
setblock 271 66 -7 minecraft:waxed_exposed_cut_copper
setblock 240 66 -6 minecraft:polished_blackstone_bricks
setblock 272 66 -6 minecraft:polished_blackstone_bricks
setblock 241 66 -6 minecraft:waxed_exposed_cut_copper
setblock 271 66 -6 minecraft:waxed_exposed_cut_copper
setblock 240 66 -5 minecraft:polished_blackstone_bricks
setblock 272 66 -5 minecraft:polished_blackstone_bricks
setblock 241 66 -5 minecraft:waxed_exposed_cut_copper
setblock 271 66 -5 minecraft:waxed_exposed_cut_copper
setblock 240 66 -4 minecraft:polished_blackstone_bricks
setblock 272 66 -4 minecraft:polished_blackstone_bricks
setblock 241 66 -4 minecraft:waxed_exposed_cut_copper
setblock 271 66 -4 minecraft:waxed_exposed_cut_copper
setblock 240 66 -3 minecraft:polished_blackstone_bricks
setblock 272 66 -3 minecraft:polished_blackstone_bricks
setblock 241 66 -3 minecraft:waxed_exposed_cut_copper
setblock 271 66 -3 minecraft:waxed_exposed_cut_copper
setblock 240 66 -2 minecraft:polished_blackstone_bricks
setblock 272 66 -2 minecraft:polished_blackstone_bricks
setblock 241 66 -2 minecraft:waxed_exposed_cut_copper
setblock 271 66 -2 minecraft:waxed_exposed_cut_copper
setblock 240 66 -1 minecraft:polished_blackstone_bricks
setblock 272 66 -1 minecraft:polished_blackstone_bricks
setblock 241 66 -1 minecraft:waxed_exposed_cut_copper
setblock 271 66 -1 minecraft:waxed_exposed_cut_copper
setblock 243 66 0 minecraft:polished_basalt[axis=y]
setblock 269 66 0 minecraft:polished_basalt[axis=y]
setblock 240 66 0 minecraft:polished_blackstone_bricks
setblock 272 66 0 minecraft:polished_blackstone_bricks
setblock 241 66 0 minecraft:waxed_exposed_cut_copper
setblock 271 66 0 minecraft:waxed_exposed_cut_copper
setblock 240 66 1 minecraft:polished_blackstone_bricks
setblock 272 66 1 minecraft:polished_blackstone_bricks
setblock 241 66 1 minecraft:waxed_exposed_cut_copper
setblock 271 66 1 minecraft:waxed_exposed_cut_copper
setblock 240 66 2 minecraft:polished_blackstone_bricks
setblock 272 66 2 minecraft:polished_blackstone_bricks
setblock 241 66 2 minecraft:waxed_exposed_cut_copper
setblock 271 66 2 minecraft:waxed_exposed_cut_copper
setblock 240 66 3 minecraft:polished_blackstone_bricks
setblock 272 66 3 minecraft:polished_blackstone_bricks
setblock 241 66 3 minecraft:waxed_exposed_cut_copper
setblock 271 66 3 minecraft:waxed_exposed_cut_copper
setblock 240 66 4 minecraft:polished_blackstone_bricks
setblock 272 66 4 minecraft:polished_blackstone_bricks
setblock 241 66 4 minecraft:waxed_exposed_cut_copper
setblock 271 66 4 minecraft:waxed_exposed_cut_copper
setblock 240 66 5 minecraft:polished_blackstone_bricks
setblock 272 66 5 minecraft:polished_blackstone_bricks
setblock 241 66 5 minecraft:waxed_exposed_cut_copper
setblock 271 66 5 minecraft:waxed_exposed_cut_copper
setblock 240 66 6 minecraft:polished_blackstone_bricks
setblock 272 66 6 minecraft:polished_blackstone_bricks
setblock 241 66 6 minecraft:waxed_exposed_cut_copper
setblock 271 66 6 minecraft:waxed_exposed_cut_copper
setblock 240 66 7 minecraft:polished_blackstone_bricks
setblock 270 66 7 minecraft:polished_blackstone_bricks
setblock 272 66 7 minecraft:polished_blackstone_bricks
setblock 241 66 7 minecraft:waxed_exposed_cut_copper
setblock 271 66 7 minecraft:waxed_exposed_cut_copper
setblock 269 66 8 minecraft:amethyst_block
setblock 240 66 8 minecraft:polished_blackstone_bricks
setblock 272 66 8 minecraft:polished_blackstone_bricks
setblock 270 66 8 minecraft:sea_lantern
setblock 241 66 8 minecraft:waxed_exposed_cut_copper
setblock 271 66 8 minecraft:waxed_exposed_cut_copper
setblock 240 66 9 minecraft:polished_blackstone_bricks
setblock 270 66 9 minecraft:polished_blackstone_bricks
setblock 272 66 9 minecraft:polished_blackstone_bricks
setblock 241 66 9 minecraft:waxed_exposed_cut_copper
setblock 271 66 9 minecraft:waxed_exposed_cut_copper
setblock 240 66 10 minecraft:polished_blackstone_bricks
setblock 272 66 10 minecraft:polished_blackstone_bricks
setblock 241 66 10 minecraft:waxed_exposed_cut_copper
setblock 271 66 10 minecraft:waxed_exposed_cut_copper
setblock 243 66 11 minecraft:polished_basalt[axis=y]
setblock 269 66 11 minecraft:polished_basalt[axis=y]
setblock 240 66 11 minecraft:polished_blackstone_bricks
setblock 272 66 11 minecraft:polished_blackstone_bricks
setblock 241 66 11 minecraft:waxed_exposed_cut_copper
setblock 271 66 11 minecraft:waxed_exposed_cut_copper
setblock 240 66 12 minecraft:polished_blackstone_bricks
setblock 272 66 12 minecraft:polished_blackstone_bricks
setblock 241 66 12 minecraft:waxed_exposed_cut_copper
setblock 271 66 12 minecraft:waxed_exposed_cut_copper
setblock 240 66 13 minecraft:polished_blackstone_bricks
setblock 272 66 13 minecraft:polished_blackstone_bricks
setblock 241 66 13 minecraft:waxed_exposed_cut_copper
setblock 271 66 13 minecraft:waxed_exposed_cut_copper
setblock 240 66 14 minecraft:polished_blackstone_bricks
setblock 272 66 14 minecraft:polished_blackstone_bricks
setblock 241 66 14 minecraft:waxed_exposed_cut_copper
setblock 271 66 14 minecraft:waxed_exposed_cut_copper
setblock 240 66 15 minecraft:polished_blackstone_bricks
setblock 272 66 15 minecraft:polished_blackstone_bricks
fill 241 66 15 271 66 15 minecraft:waxed_exposed_cut_copper
fill 240 66 16 272 66 16 minecraft:polished_blackstone_bricks
fill 240 67 -16 243 67 -16 minecraft:polished_blackstone_bricks
fill 245 67 -16 249 67 -16 minecraft:polished_blackstone_bricks
fill 251 67 -16 255 67 -16 minecraft:polished_blackstone_bricks
fill 257 67 -16 261 67 -16 minecraft:polished_blackstone_bricks
fill 263 67 -16 267 67 -16 minecraft:polished_blackstone_bricks
fill 269 67 -16 272 67 -16 minecraft:polished_blackstone_bricks
setblock 244 67 -16 minecraft:sea_lantern
setblock 250 67 -16 minecraft:sea_lantern
setblock 256 67 -16 minecraft:sea_lantern
setblock 262 67 -16 minecraft:sea_lantern
setblock 268 67 -16 minecraft:sea_lantern
setblock 240 67 -15 minecraft:polished_blackstone_bricks
setblock 272 67 -15 minecraft:polished_blackstone_bricks
setblock 244 67 -15 minecraft:red_stained_glass
setblock 250 67 -15 minecraft:red_stained_glass
setblock 256 67 -15 minecraft:red_stained_glass
setblock 262 67 -15 minecraft:red_stained_glass
setblock 268 67 -15 minecraft:red_stained_glass
setblock 240 67 -14 minecraft:polished_blackstone_bricks
setblock 272 67 -14 minecraft:polished_blackstone_bricks
setblock 240 67 -13 minecraft:polished_blackstone_bricks
setblock 272 67 -13 minecraft:polished_blackstone_bricks
setblock 241 67 -12 minecraft:red_stained_glass
setblock 271 67 -12 minecraft:red_stained_glass
setblock 240 67 -12 minecraft:sea_lantern
setblock 272 67 -12 minecraft:sea_lantern
setblock 243 67 -11 minecraft:polished_basalt[axis=y]
setblock 269 67 -11 minecraft:polished_basalt[axis=y]
setblock 240 67 -11 minecraft:polished_blackstone_bricks
setblock 272 67 -11 minecraft:polished_blackstone_bricks
setblock 240 67 -10 minecraft:polished_blackstone_bricks
setblock 272 67 -10 minecraft:polished_blackstone_bricks
setblock 240 67 -9 minecraft:polished_blackstone_bricks
setblock 272 67 -9 minecraft:polished_blackstone_bricks
setblock 240 67 -8 minecraft:polished_blackstone_bricks
setblock 272 67 -8 minecraft:polished_blackstone_bricks
setblock 240 67 -7 minecraft:polished_blackstone_bricks
setblock 272 67 -7 minecraft:polished_blackstone_bricks
setblock 241 67 -6 minecraft:red_stained_glass
setblock 271 67 -6 minecraft:red_stained_glass
setblock 240 67 -6 minecraft:sea_lantern
setblock 272 67 -6 minecraft:sea_lantern
setblock 240 67 -5 minecraft:polished_blackstone_bricks
setblock 272 67 -5 minecraft:polished_blackstone_bricks
setblock 240 67 -4 minecraft:polished_blackstone_bricks
setblock 272 67 -4 minecraft:polished_blackstone_bricks
setblock 240 67 -3 minecraft:polished_blackstone_bricks
setblock 272 67 -3 minecraft:polished_blackstone_bricks
setblock 240 67 -2 minecraft:polished_blackstone_bricks
setblock 272 67 -2 minecraft:polished_blackstone_bricks
setblock 240 67 -1 minecraft:polished_blackstone_bricks
setblock 272 67 -1 minecraft:polished_blackstone_bricks
setblock 243 67 0 minecraft:polished_basalt[axis=y]
setblock 269 67 0 minecraft:polished_basalt[axis=y]
setblock 241 67 0 minecraft:red_stained_glass
setblock 271 67 0 minecraft:red_stained_glass
setblock 240 67 0 minecraft:sea_lantern
setblock 272 67 0 minecraft:sea_lantern
setblock 240 67 1 minecraft:polished_blackstone_bricks
setblock 272 67 1 minecraft:polished_blackstone_bricks
setblock 240 67 2 minecraft:polished_blackstone_bricks
setblock 272 67 2 minecraft:polished_blackstone_bricks
setblock 240 67 3 minecraft:polished_blackstone_bricks
setblock 272 67 3 minecraft:polished_blackstone_bricks
setblock 240 67 4 minecraft:polished_blackstone_bricks
setblock 272 67 4 minecraft:polished_blackstone_bricks
setblock 240 67 5 minecraft:polished_blackstone_bricks
setblock 272 67 5 minecraft:polished_blackstone_bricks
setblock 241 67 6 minecraft:red_stained_glass
setblock 271 67 6 minecraft:red_stained_glass
setblock 240 67 6 minecraft:sea_lantern
setblock 272 67 6 minecraft:sea_lantern
setblock 240 67 7 minecraft:polished_blackstone_bricks
setblock 270 67 7 minecraft:polished_blackstone_bricks
setblock 272 67 7 minecraft:polished_blackstone_bricks
setblock 240 67 8 minecraft:polished_blackstone_bricks
setblock 270 67 8 minecraft:polished_blackstone_bricks
setblock 272 67 8 minecraft:polished_blackstone_bricks
setblock 269 67 8 minecraft:small_amethyst_bud[facing=up,waterlogged=false]
setblock 240 67 9 minecraft:polished_blackstone_bricks
setblock 270 67 9 minecraft:polished_blackstone_bricks
setblock 272 67 9 minecraft:polished_blackstone_bricks
setblock 240 67 10 minecraft:polished_blackstone_bricks
setblock 272 67 10 minecraft:polished_blackstone_bricks
setblock 243 67 11 minecraft:polished_basalt[axis=y]
setblock 269 67 11 minecraft:polished_basalt[axis=y]
setblock 240 67 11 minecraft:polished_blackstone_bricks
setblock 272 67 11 minecraft:polished_blackstone_bricks
setblock 241 67 12 minecraft:red_stained_glass
setblock 271 67 12 minecraft:red_stained_glass
setblock 240 67 12 minecraft:sea_lantern
setblock 272 67 12 minecraft:sea_lantern
setblock 240 67 13 minecraft:polished_blackstone_bricks
setblock 272 67 13 minecraft:polished_blackstone_bricks
setblock 240 67 14 minecraft:polished_blackstone_bricks
setblock 272 67 14 minecraft:polished_blackstone_bricks
setblock 240 67 15 minecraft:polished_blackstone_bricks
setblock 272 67 15 minecraft:polished_blackstone_bricks
setblock 244 67 15 minecraft:red_stained_glass
setblock 250 67 15 minecraft:red_stained_glass
setblock 256 67 15 minecraft:red_stained_glass
setblock 262 67 15 minecraft:red_stained_glass
setblock 268 67 15 minecraft:red_stained_glass
fill 240 67 16 243 67 16 minecraft:polished_blackstone_bricks
fill 245 67 16 249 67 16 minecraft:polished_blackstone_bricks
fill 251 67 16 255 67 16 minecraft:polished_blackstone_bricks
fill 257 67 16 261 67 16 minecraft:polished_blackstone_bricks
fill 263 67 16 267 67 16 minecraft:polished_blackstone_bricks
fill 269 67 16 272 67 16 minecraft:polished_blackstone_bricks
setblock 244 67 16 minecraft:sea_lantern
setblock 250 67 16 minecraft:sea_lantern
setblock 256 67 16 minecraft:sea_lantern
setblock 262 67 16 minecraft:sea_lantern
setblock 268 67 16 minecraft:sea_lantern
fill 240 68 -16 243 68 -16 minecraft:polished_blackstone_bricks
fill 245 68 -16 249 68 -16 minecraft:polished_blackstone_bricks
fill 251 68 -16 255 68 -16 minecraft:polished_blackstone_bricks
fill 257 68 -16 261 68 -16 minecraft:polished_blackstone_bricks
fill 263 68 -16 267 68 -16 minecraft:polished_blackstone_bricks
fill 269 68 -16 272 68 -16 minecraft:polished_blackstone_bricks
setblock 244 68 -16 minecraft:sea_lantern
setblock 250 68 -16 minecraft:sea_lantern
setblock 256 68 -16 minecraft:sea_lantern
setblock 262 68 -16 minecraft:sea_lantern
setblock 268 68 -16 minecraft:sea_lantern
setblock 240 68 -15 minecraft:polished_blackstone_bricks
setblock 272 68 -15 minecraft:polished_blackstone_bricks
setblock 244 68 -15 minecraft:red_stained_glass
setblock 250 68 -15 minecraft:red_stained_glass
setblock 256 68 -15 minecraft:red_stained_glass
setblock 262 68 -15 minecraft:red_stained_glass
setblock 268 68 -15 minecraft:red_stained_glass
setblock 240 68 -14 minecraft:polished_blackstone_bricks
setblock 272 68 -14 minecraft:polished_blackstone_bricks
setblock 240 68 -13 minecraft:polished_blackstone_bricks
setblock 272 68 -13 minecraft:polished_blackstone_bricks
setblock 241 68 -12 minecraft:red_stained_glass
setblock 271 68 -12 minecraft:red_stained_glass
setblock 240 68 -12 minecraft:sea_lantern
setblock 272 68 -12 minecraft:sea_lantern
setblock 243 68 -11 minecraft:polished_basalt[axis=y]
setblock 269 68 -11 minecraft:polished_basalt[axis=y]
setblock 240 68 -11 minecraft:polished_blackstone_bricks
setblock 272 68 -11 minecraft:polished_blackstone_bricks
setblock 240 68 -10 minecraft:polished_blackstone_bricks
setblock 272 68 -10 minecraft:polished_blackstone_bricks
setblock 240 68 -9 minecraft:polished_blackstone_bricks
setblock 272 68 -9 minecraft:polished_blackstone_bricks
setblock 240 68 -8 minecraft:polished_blackstone_bricks
setblock 272 68 -8 minecraft:polished_blackstone_bricks
setblock 240 68 -7 minecraft:polished_blackstone_bricks
setblock 272 68 -7 minecraft:polished_blackstone_bricks
setblock 241 68 -6 minecraft:red_stained_glass
setblock 271 68 -6 minecraft:red_stained_glass
setblock 240 68 -6 minecraft:sea_lantern
setblock 272 68 -6 minecraft:sea_lantern
setblock 240 68 -5 minecraft:polished_blackstone_bricks
setblock 272 68 -5 minecraft:polished_blackstone_bricks
setblock 240 68 -4 minecraft:polished_blackstone_bricks
setblock 272 68 -4 minecraft:polished_blackstone_bricks
setblock 240 68 -3 minecraft:polished_blackstone_bricks
setblock 272 68 -3 minecraft:polished_blackstone_bricks
setblock 240 68 -2 minecraft:polished_blackstone_bricks
setblock 272 68 -2 minecraft:polished_blackstone_bricks
setblock 240 68 -1 minecraft:polished_blackstone_bricks
setblock 272 68 -1 minecraft:polished_blackstone_bricks
setblock 243 68 0 minecraft:polished_basalt[axis=y]
setblock 269 68 0 minecraft:polished_basalt[axis=y]
setblock 241 68 0 minecraft:red_stained_glass
setblock 271 68 0 minecraft:red_stained_glass
setblock 240 68 0 minecraft:sea_lantern
setblock 272 68 0 minecraft:sea_lantern
setblock 240 68 1 minecraft:polished_blackstone_bricks
setblock 272 68 1 minecraft:polished_blackstone_bricks
setblock 240 68 2 minecraft:polished_blackstone_bricks
setblock 272 68 2 minecraft:polished_blackstone_bricks
setblock 240 68 3 minecraft:polished_blackstone_bricks
setblock 272 68 3 minecraft:polished_blackstone_bricks
setblock 240 68 4 minecraft:polished_blackstone_bricks
setblock 272 68 4 minecraft:polished_blackstone_bricks
setblock 240 68 5 minecraft:polished_blackstone_bricks
setblock 272 68 5 minecraft:polished_blackstone_bricks
setblock 241 68 6 minecraft:red_stained_glass
setblock 271 68 6 minecraft:red_stained_glass
setblock 240 68 6 minecraft:sea_lantern
setblock 272 68 6 minecraft:sea_lantern
setblock 240 68 7 minecraft:polished_blackstone_bricks
setblock 270 68 7 minecraft:polished_blackstone_bricks
setblock 272 68 7 minecraft:polished_blackstone_bricks
setblock 240 68 8 minecraft:polished_blackstone_bricks
setblock 270 68 8 minecraft:polished_blackstone_bricks
setblock 272 68 8 minecraft:polished_blackstone_bricks
setblock 240 68 9 minecraft:polished_blackstone_bricks
setblock 270 68 9 minecraft:polished_blackstone_bricks
setblock 272 68 9 minecraft:polished_blackstone_bricks
setblock 240 68 10 minecraft:polished_blackstone_bricks
setblock 272 68 10 minecraft:polished_blackstone_bricks
setblock 243 68 11 minecraft:polished_basalt[axis=y]
setblock 269 68 11 minecraft:polished_basalt[axis=y]
setblock 240 68 11 minecraft:polished_blackstone_bricks
setblock 272 68 11 minecraft:polished_blackstone_bricks
setblock 241 68 12 minecraft:red_stained_glass
setblock 271 68 12 minecraft:red_stained_glass
setblock 240 68 12 minecraft:sea_lantern
setblock 272 68 12 minecraft:sea_lantern
setblock 240 68 13 minecraft:polished_blackstone_bricks
setblock 272 68 13 minecraft:polished_blackstone_bricks
setblock 240 68 14 minecraft:polished_blackstone_bricks
setblock 272 68 14 minecraft:polished_blackstone_bricks
setblock 240 68 15 minecraft:polished_blackstone_bricks
setblock 272 68 15 minecraft:polished_blackstone_bricks
setblock 244 68 15 minecraft:red_stained_glass
setblock 250 68 15 minecraft:red_stained_glass
setblock 256 68 15 minecraft:red_stained_glass
setblock 262 68 15 minecraft:red_stained_glass
setblock 268 68 15 minecraft:red_stained_glass
fill 240 68 16 243 68 16 minecraft:polished_blackstone_bricks
fill 245 68 16 249 68 16 minecraft:polished_blackstone_bricks
fill 251 68 16 255 68 16 minecraft:polished_blackstone_bricks
fill 257 68 16 261 68 16 minecraft:polished_blackstone_bricks
fill 263 68 16 267 68 16 minecraft:polished_blackstone_bricks
fill 269 68 16 272 68 16 minecraft:polished_blackstone_bricks
setblock 244 68 16 minecraft:sea_lantern
setblock 250 68 16 minecraft:sea_lantern
setblock 256 68 16 minecraft:sea_lantern
setblock 262 68 16 minecraft:sea_lantern
setblock 268 68 16 minecraft:sea_lantern
fill 240 69 -16 243 69 -16 minecraft:polished_blackstone_bricks
fill 245 69 -16 249 69 -16 minecraft:polished_blackstone_bricks
fill 251 69 -16 255 69 -16 minecraft:polished_blackstone_bricks
fill 257 69 -16 261 69 -16 minecraft:polished_blackstone_bricks
fill 263 69 -16 267 69 -16 minecraft:polished_blackstone_bricks
fill 269 69 -16 272 69 -16 minecraft:polished_blackstone_bricks
setblock 244 69 -16 minecraft:sea_lantern
setblock 250 69 -16 minecraft:sea_lantern
setblock 256 69 -16 minecraft:sea_lantern
setblock 262 69 -16 minecraft:sea_lantern
setblock 268 69 -16 minecraft:sea_lantern
setblock 240 69 -15 minecraft:polished_blackstone_bricks
setblock 272 69 -15 minecraft:polished_blackstone_bricks
setblock 244 69 -15 minecraft:red_stained_glass
setblock 250 69 -15 minecraft:red_stained_glass
setblock 256 69 -15 minecraft:red_stained_glass
setblock 262 69 -15 minecraft:red_stained_glass
setblock 268 69 -15 minecraft:red_stained_glass
setblock 240 69 -14 minecraft:polished_blackstone_bricks
setblock 272 69 -14 minecraft:polished_blackstone_bricks
setblock 240 69 -13 minecraft:polished_blackstone_bricks
setblock 272 69 -13 minecraft:polished_blackstone_bricks
setblock 241 69 -12 minecraft:red_stained_glass
setblock 271 69 -12 minecraft:red_stained_glass
setblock 240 69 -12 minecraft:sea_lantern
setblock 272 69 -12 minecraft:sea_lantern
setblock 243 69 -11 minecraft:polished_basalt[axis=y]
setblock 269 69 -11 minecraft:polished_basalt[axis=y]
setblock 240 69 -11 minecraft:polished_blackstone_bricks
setblock 272 69 -11 minecraft:polished_blackstone_bricks
setblock 240 69 -10 minecraft:polished_blackstone_bricks
setblock 272 69 -10 minecraft:polished_blackstone_bricks
setblock 240 69 -9 minecraft:polished_blackstone_bricks
setblock 272 69 -9 minecraft:polished_blackstone_bricks
setblock 240 69 -8 minecraft:polished_blackstone_bricks
setblock 272 69 -8 minecraft:polished_blackstone_bricks
setblock 240 69 -7 minecraft:polished_blackstone_bricks
setblock 272 69 -7 minecraft:polished_blackstone_bricks
setblock 241 69 -6 minecraft:red_stained_glass
setblock 271 69 -6 minecraft:red_stained_glass
setblock 240 69 -6 minecraft:sea_lantern
setblock 272 69 -6 minecraft:sea_lantern
setblock 240 69 -5 minecraft:polished_blackstone_bricks
setblock 272 69 -5 minecraft:polished_blackstone_bricks
setblock 240 69 -4 minecraft:polished_blackstone_bricks
setblock 272 69 -4 minecraft:polished_blackstone_bricks
setblock 240 69 -3 minecraft:polished_blackstone_bricks
setblock 272 69 -3 minecraft:polished_blackstone_bricks
setblock 240 69 -2 minecraft:polished_blackstone_bricks
setblock 272 69 -2 minecraft:polished_blackstone_bricks
setblock 240 69 -1 minecraft:polished_blackstone_bricks
setblock 272 69 -1 minecraft:polished_blackstone_bricks
setblock 243 69 0 minecraft:polished_basalt[axis=y]
setblock 269 69 0 minecraft:polished_basalt[axis=y]
setblock 241 69 0 minecraft:red_stained_glass
setblock 271 69 0 minecraft:red_stained_glass
setblock 240 69 0 minecraft:sea_lantern
setblock 272 69 0 minecraft:sea_lantern
setblock 240 69 1 minecraft:polished_blackstone_bricks
setblock 272 69 1 minecraft:polished_blackstone_bricks
setblock 240 69 2 minecraft:polished_blackstone_bricks
setblock 272 69 2 minecraft:polished_blackstone_bricks
setblock 240 69 3 minecraft:polished_blackstone_bricks
setblock 272 69 3 minecraft:polished_blackstone_bricks
setblock 240 69 4 minecraft:polished_blackstone_bricks
setblock 272 69 4 minecraft:polished_blackstone_bricks
setblock 240 69 5 minecraft:polished_blackstone_bricks
setblock 272 69 5 minecraft:polished_blackstone_bricks
setblock 241 69 6 minecraft:red_stained_glass
setblock 271 69 6 minecraft:red_stained_glass
setblock 240 69 6 minecraft:sea_lantern
setblock 272 69 6 minecraft:sea_lantern
setblock 240 69 7 minecraft:polished_blackstone_bricks
setblock 272 69 7 minecraft:polished_blackstone_bricks
setblock 240 69 8 minecraft:polished_blackstone_bricks
setblock 272 69 8 minecraft:polished_blackstone_bricks
setblock 240 69 9 minecraft:polished_blackstone_bricks
setblock 272 69 9 minecraft:polished_blackstone_bricks
setblock 240 69 10 minecraft:polished_blackstone_bricks
setblock 272 69 10 minecraft:polished_blackstone_bricks
setblock 243 69 11 minecraft:polished_basalt[axis=y]
setblock 269 69 11 minecraft:polished_basalt[axis=y]
setblock 240 69 11 minecraft:polished_blackstone_bricks
setblock 272 69 11 minecraft:polished_blackstone_bricks
setblock 241 69 12 minecraft:red_stained_glass
setblock 271 69 12 minecraft:red_stained_glass
setblock 240 69 12 minecraft:sea_lantern
setblock 272 69 12 minecraft:sea_lantern
setblock 240 69 13 minecraft:polished_blackstone_bricks
setblock 272 69 13 minecraft:polished_blackstone_bricks
setblock 240 69 14 minecraft:polished_blackstone_bricks
setblock 272 69 14 minecraft:polished_blackstone_bricks
setblock 240 69 15 minecraft:polished_blackstone_bricks
setblock 272 69 15 minecraft:polished_blackstone_bricks
setblock 244 69 15 minecraft:red_stained_glass
setblock 250 69 15 minecraft:red_stained_glass
setblock 256 69 15 minecraft:red_stained_glass
setblock 262 69 15 minecraft:red_stained_glass
setblock 268 69 15 minecraft:red_stained_glass
fill 240 69 16 243 69 16 minecraft:polished_blackstone_bricks
fill 245 69 16 249 69 16 minecraft:polished_blackstone_bricks
fill 251 69 16 255 69 16 minecraft:polished_blackstone_bricks
fill 257 69 16 261 69 16 minecraft:polished_blackstone_bricks
fill 263 69 16 267 69 16 minecraft:polished_blackstone_bricks
fill 269 69 16 272 69 16 minecraft:polished_blackstone_bricks
setblock 244 69 16 minecraft:sea_lantern
setblock 250 69 16 minecraft:sea_lantern
setblock 256 69 16 minecraft:sea_lantern
setblock 262 69 16 minecraft:sea_lantern
setblock 268 69 16 minecraft:sea_lantern
fill 240 70 -16 243 70 -16 minecraft:polished_blackstone_bricks
fill 245 70 -16 249 70 -16 minecraft:polished_blackstone_bricks
fill 251 70 -16 255 70 -16 minecraft:polished_blackstone_bricks
fill 257 70 -16 261 70 -16 minecraft:polished_blackstone_bricks
fill 263 70 -16 267 70 -16 minecraft:polished_blackstone_bricks
fill 269 70 -16 272 70 -16 minecraft:polished_blackstone_bricks
setblock 244 70 -16 minecraft:sea_lantern
setblock 250 70 -16 minecraft:sea_lantern
setblock 256 70 -16 minecraft:sea_lantern
setblock 262 70 -16 minecraft:sea_lantern
setblock 268 70 -16 minecraft:sea_lantern
setblock 240 70 -15 minecraft:polished_blackstone_bricks
setblock 272 70 -15 minecraft:polished_blackstone_bricks
setblock 244 70 -15 minecraft:red_stained_glass
setblock 250 70 -15 minecraft:red_stained_glass
setblock 256 70 -15 minecraft:red_stained_glass
setblock 262 70 -15 minecraft:red_stained_glass
setblock 268 70 -15 minecraft:red_stained_glass
setblock 240 70 -14 minecraft:polished_blackstone_bricks
setblock 272 70 -14 minecraft:polished_blackstone_bricks
setblock 240 70 -13 minecraft:polished_blackstone_bricks
setblock 272 70 -13 minecraft:polished_blackstone_bricks
setblock 241 70 -12 minecraft:red_stained_glass
setblock 271 70 -12 minecraft:red_stained_glass
setblock 240 70 -12 minecraft:sea_lantern
setblock 272 70 -12 minecraft:sea_lantern
setblock 243 70 -11 minecraft:polished_basalt[axis=y]
setblock 269 70 -11 minecraft:polished_basalt[axis=y]
setblock 240 70 -11 minecraft:polished_blackstone_bricks
setblock 272 70 -11 minecraft:polished_blackstone_bricks
setblock 240 70 -10 minecraft:polished_blackstone_bricks
setblock 272 70 -10 minecraft:polished_blackstone_bricks
setblock 240 70 -9 minecraft:polished_blackstone_bricks
setblock 272 70 -9 minecraft:polished_blackstone_bricks
setblock 240 70 -8 minecraft:polished_blackstone_bricks
setblock 272 70 -8 minecraft:polished_blackstone_bricks
setblock 240 70 -7 minecraft:polished_blackstone_bricks
setblock 272 70 -7 minecraft:polished_blackstone_bricks
setblock 241 70 -6 minecraft:red_stained_glass
setblock 271 70 -6 minecraft:red_stained_glass
setblock 240 70 -6 minecraft:sea_lantern
setblock 272 70 -6 minecraft:sea_lantern
setblock 240 70 -5 minecraft:polished_blackstone_bricks
setblock 272 70 -5 minecraft:polished_blackstone_bricks
setblock 240 70 -4 minecraft:polished_blackstone_bricks
setblock 272 70 -4 minecraft:polished_blackstone_bricks
setblock 240 70 -3 minecraft:polished_blackstone_bricks
setblock 272 70 -3 minecraft:polished_blackstone_bricks
setblock 240 70 -2 minecraft:polished_blackstone_bricks
setblock 272 70 -2 minecraft:polished_blackstone_bricks
setblock 240 70 -1 minecraft:polished_blackstone_bricks
setblock 272 70 -1 minecraft:polished_blackstone_bricks
setblock 243 70 0 minecraft:polished_basalt[axis=y]
setblock 269 70 0 minecraft:polished_basalt[axis=y]
setblock 241 70 0 minecraft:red_stained_glass
setblock 271 70 0 minecraft:red_stained_glass
setblock 240 70 0 minecraft:sea_lantern
setblock 272 70 0 minecraft:sea_lantern
setblock 240 70 1 minecraft:polished_blackstone_bricks
setblock 272 70 1 minecraft:polished_blackstone_bricks
setblock 240 70 2 minecraft:polished_blackstone_bricks
setblock 272 70 2 minecraft:polished_blackstone_bricks
setblock 240 70 3 minecraft:polished_blackstone_bricks
setblock 272 70 3 minecraft:polished_blackstone_bricks
setblock 240 70 4 minecraft:polished_blackstone_bricks
setblock 272 70 4 minecraft:polished_blackstone_bricks
setblock 240 70 5 minecraft:polished_blackstone_bricks
setblock 272 70 5 minecraft:polished_blackstone_bricks
setblock 241 70 6 minecraft:red_stained_glass
setblock 271 70 6 minecraft:red_stained_glass
setblock 240 70 6 minecraft:sea_lantern
setblock 272 70 6 minecraft:sea_lantern
setblock 240 70 7 minecraft:polished_blackstone_bricks
setblock 272 70 7 minecraft:polished_blackstone_bricks
setblock 240 70 8 minecraft:polished_blackstone_bricks
setblock 272 70 8 minecraft:polished_blackstone_bricks
setblock 240 70 9 minecraft:polished_blackstone_bricks
setblock 272 70 9 minecraft:polished_blackstone_bricks
setblock 240 70 10 minecraft:polished_blackstone_bricks
setblock 272 70 10 minecraft:polished_blackstone_bricks
setblock 243 70 11 minecraft:polished_basalt[axis=y]
setblock 269 70 11 minecraft:polished_basalt[axis=y]
setblock 240 70 11 minecraft:polished_blackstone_bricks
setblock 272 70 11 minecraft:polished_blackstone_bricks
setblock 241 70 12 minecraft:red_stained_glass
setblock 271 70 12 minecraft:red_stained_glass
setblock 240 70 12 minecraft:sea_lantern
setblock 272 70 12 minecraft:sea_lantern
setblock 240 70 13 minecraft:polished_blackstone_bricks
setblock 272 70 13 minecraft:polished_blackstone_bricks
setblock 240 70 14 minecraft:polished_blackstone_bricks
setblock 272 70 14 minecraft:polished_blackstone_bricks
setblock 240 70 15 minecraft:polished_blackstone_bricks
setblock 272 70 15 minecraft:polished_blackstone_bricks
setblock 244 70 15 minecraft:red_stained_glass
setblock 250 70 15 minecraft:red_stained_glass
setblock 256 70 15 minecraft:red_stained_glass
setblock 262 70 15 minecraft:red_stained_glass
setblock 268 70 15 minecraft:red_stained_glass
fill 240 70 16 243 70 16 minecraft:polished_blackstone_bricks
fill 245 70 16 249 70 16 minecraft:polished_blackstone_bricks
fill 251 70 16 255 70 16 minecraft:polished_blackstone_bricks
fill 257 70 16 261 70 16 minecraft:polished_blackstone_bricks
fill 263 70 16 267 70 16 minecraft:polished_blackstone_bricks
fill 269 70 16 272 70 16 minecraft:polished_blackstone_bricks
setblock 244 70 16 minecraft:sea_lantern
setblock 250 70 16 minecraft:sea_lantern
setblock 256 70 16 minecraft:sea_lantern
setblock 262 70 16 minecraft:sea_lantern
setblock 268 70 16 minecraft:sea_lantern
fill 240 71 -16 243 71 -16 minecraft:polished_blackstone_bricks
fill 245 71 -16 249 71 -16 minecraft:polished_blackstone_bricks
fill 251 71 -16 255 71 -16 minecraft:polished_blackstone_bricks
fill 257 71 -16 261 71 -16 minecraft:polished_blackstone_bricks
fill 263 71 -16 267 71 -16 minecraft:polished_blackstone_bricks
fill 269 71 -16 272 71 -16 minecraft:polished_blackstone_bricks
setblock 244 71 -16 minecraft:sea_lantern
setblock 250 71 -16 minecraft:sea_lantern
setblock 256 71 -16 minecraft:sea_lantern
setblock 262 71 -16 minecraft:sea_lantern
setblock 268 71 -16 minecraft:sea_lantern
setblock 240 71 -15 minecraft:polished_blackstone_bricks
setblock 272 71 -15 minecraft:polished_blackstone_bricks
setblock 244 71 -15 minecraft:red_stained_glass
setblock 250 71 -15 minecraft:red_stained_glass
setblock 256 71 -15 minecraft:red_stained_glass
setblock 262 71 -15 minecraft:red_stained_glass
setblock 268 71 -15 minecraft:red_stained_glass
setblock 240 71 -14 minecraft:polished_blackstone_bricks
setblock 272 71 -14 minecraft:polished_blackstone_bricks
setblock 240 71 -13 minecraft:polished_blackstone_bricks
setblock 272 71 -13 minecraft:polished_blackstone_bricks
setblock 241 71 -12 minecraft:red_stained_glass
setblock 271 71 -12 minecraft:red_stained_glass
setblock 240 71 -12 minecraft:sea_lantern
setblock 272 71 -12 minecraft:sea_lantern
setblock 240 71 -11 minecraft:polished_blackstone_bricks
setblock 272 71 -11 minecraft:polished_blackstone_bricks
setblock 243 71 -11 minecraft:sea_lantern
setblock 269 71 -11 minecraft:sea_lantern
setblock 240 71 -10 minecraft:polished_blackstone_bricks
setblock 272 71 -10 minecraft:polished_blackstone_bricks
setblock 240 71 -9 minecraft:polished_blackstone_bricks
setblock 272 71 -9 minecraft:polished_blackstone_bricks
setblock 240 71 -8 minecraft:polished_blackstone_bricks
setblock 272 71 -8 minecraft:polished_blackstone_bricks
setblock 240 71 -7 minecraft:polished_blackstone_bricks
setblock 272 71 -7 minecraft:polished_blackstone_bricks
setblock 241 71 -6 minecraft:red_stained_glass
setblock 271 71 -6 minecraft:red_stained_glass
setblock 240 71 -6 minecraft:sea_lantern
setblock 272 71 -6 minecraft:sea_lantern
setblock 240 71 -5 minecraft:polished_blackstone_bricks
setblock 272 71 -5 minecraft:polished_blackstone_bricks
setblock 240 71 -4 minecraft:polished_blackstone_bricks
setblock 272 71 -4 minecraft:polished_blackstone_bricks
setblock 240 71 -3 minecraft:polished_blackstone_bricks
setblock 272 71 -3 minecraft:polished_blackstone_bricks
setblock 240 71 -2 minecraft:polished_blackstone_bricks
setblock 272 71 -2 minecraft:polished_blackstone_bricks
setblock 240 71 -1 minecraft:polished_blackstone_bricks
setblock 272 71 -1 minecraft:polished_blackstone_bricks
setblock 241 71 0 minecraft:red_stained_glass
setblock 271 71 0 minecraft:red_stained_glass
setblock 240 71 0 minecraft:sea_lantern
setblock 243 71 0 minecraft:sea_lantern
setblock 269 71 0 minecraft:sea_lantern
setblock 272 71 0 minecraft:sea_lantern
setblock 240 71 1 minecraft:polished_blackstone_bricks
setblock 272 71 1 minecraft:polished_blackstone_bricks
setblock 240 71 2 minecraft:polished_blackstone_bricks
setblock 272 71 2 minecraft:polished_blackstone_bricks
setblock 240 71 3 minecraft:polished_blackstone_bricks
setblock 272 71 3 minecraft:polished_blackstone_bricks
setblock 240 71 4 minecraft:polished_blackstone_bricks
setblock 272 71 4 minecraft:polished_blackstone_bricks
setblock 240 71 5 minecraft:polished_blackstone_bricks
setblock 272 71 5 minecraft:polished_blackstone_bricks
setblock 241 71 6 minecraft:red_stained_glass
setblock 271 71 6 minecraft:red_stained_glass
setblock 240 71 6 minecraft:sea_lantern
setblock 272 71 6 minecraft:sea_lantern
setblock 240 71 7 minecraft:polished_blackstone_bricks
setblock 272 71 7 minecraft:polished_blackstone_bricks
setblock 240 71 8 minecraft:polished_blackstone_bricks
setblock 272 71 8 minecraft:polished_blackstone_bricks
setblock 240 71 9 minecraft:polished_blackstone_bricks
setblock 272 71 9 minecraft:polished_blackstone_bricks
setblock 240 71 10 minecraft:polished_blackstone_bricks
setblock 272 71 10 minecraft:polished_blackstone_bricks
setblock 240 71 11 minecraft:polished_blackstone_bricks
setblock 272 71 11 minecraft:polished_blackstone_bricks
setblock 243 71 11 minecraft:sea_lantern
setblock 269 71 11 minecraft:sea_lantern
setblock 241 71 12 minecraft:red_stained_glass
setblock 271 71 12 minecraft:red_stained_glass
setblock 240 71 12 minecraft:sea_lantern
setblock 272 71 12 minecraft:sea_lantern
setblock 240 71 13 minecraft:polished_blackstone_bricks
setblock 272 71 13 minecraft:polished_blackstone_bricks
setblock 240 71 14 minecraft:polished_blackstone_bricks
setblock 272 71 14 minecraft:polished_blackstone_bricks
setblock 240 71 15 minecraft:polished_blackstone_bricks
setblock 272 71 15 minecraft:polished_blackstone_bricks
setblock 244 71 15 minecraft:red_stained_glass
setblock 250 71 15 minecraft:red_stained_glass
setblock 256 71 15 minecraft:red_stained_glass
setblock 262 71 15 minecraft:red_stained_glass
setblock 268 71 15 minecraft:red_stained_glass
fill 240 71 16 243 71 16 minecraft:polished_blackstone_bricks
fill 245 71 16 249 71 16 minecraft:polished_blackstone_bricks
fill 251 71 16 255 71 16 minecraft:polished_blackstone_bricks
fill 257 71 16 261 71 16 minecraft:polished_blackstone_bricks
fill 263 71 16 267 71 16 minecraft:polished_blackstone_bricks
fill 269 71 16 272 71 16 minecraft:polished_blackstone_bricks
setblock 244 71 16 minecraft:sea_lantern
setblock 250 71 16 minecraft:sea_lantern
setblock 256 71 16 minecraft:sea_lantern
setblock 262 71 16 minecraft:sea_lantern
setblock 268 71 16 minecraft:sea_lantern
fill 240 72 -16 243 72 -16 minecraft:polished_blackstone_bricks
fill 245 72 -16 249 72 -16 minecraft:polished_blackstone_bricks
fill 251 72 -16 255 72 -16 minecraft:polished_blackstone_bricks
fill 257 72 -16 261 72 -16 minecraft:polished_blackstone_bricks
fill 263 72 -16 267 72 -16 minecraft:polished_blackstone_bricks
fill 269 72 -16 272 72 -16 minecraft:polished_blackstone_bricks
setblock 244 72 -16 minecraft:sea_lantern
setblock 250 72 -16 minecraft:sea_lantern
setblock 256 72 -16 minecraft:sea_lantern
setblock 262 72 -16 minecraft:sea_lantern
setblock 268 72 -16 minecraft:sea_lantern
setblock 240 72 -15 minecraft:polished_blackstone_bricks
setblock 272 72 -15 minecraft:polished_blackstone_bricks
setblock 244 72 -15 minecraft:red_stained_glass
setblock 250 72 -15 minecraft:red_stained_glass
setblock 256 72 -15 minecraft:red_stained_glass
setblock 262 72 -15 minecraft:red_stained_glass
setblock 268 72 -15 minecraft:red_stained_glass
fill 252 72 -14 260 72 -14 minecraft:polished_blackstone
setblock 240 72 -14 minecraft:polished_blackstone_bricks
setblock 272 72 -14 minecraft:polished_blackstone_bricks
setblock 240 72 -13 minecraft:polished_blackstone_bricks
setblock 272 72 -13 minecraft:polished_blackstone_bricks
setblock 241 72 -12 minecraft:red_stained_glass
setblock 271 72 -12 minecraft:red_stained_glass
setblock 240 72 -12 minecraft:sea_lantern
setblock 272 72 -12 minecraft:sea_lantern
setblock 240 72 -11 minecraft:polished_blackstone_bricks
setblock 272 72 -11 minecraft:polished_blackstone_bricks
setblock 243 72 -11 minecraft:red_stained_glass
setblock 269 72 -11 minecraft:red_stained_glass
setblock 240 72 -10 minecraft:polished_blackstone_bricks
setblock 272 72 -10 minecraft:polished_blackstone_bricks
setblock 240 72 -9 minecraft:polished_blackstone_bricks
setblock 272 72 -9 minecraft:polished_blackstone_bricks
setblock 240 72 -8 minecraft:polished_blackstone_bricks
setblock 272 72 -8 minecraft:polished_blackstone_bricks
setblock 240 72 -7 minecraft:polished_blackstone_bricks
setblock 272 72 -7 minecraft:polished_blackstone_bricks
setblock 241 72 -6 minecraft:red_stained_glass
setblock 271 72 -6 minecraft:red_stained_glass
setblock 240 72 -6 minecraft:sea_lantern
setblock 272 72 -6 minecraft:sea_lantern
setblock 240 72 -5 minecraft:polished_blackstone_bricks
setblock 272 72 -5 minecraft:polished_blackstone_bricks
setblock 240 72 -4 minecraft:polished_blackstone_bricks
setblock 272 72 -4 minecraft:polished_blackstone_bricks
setblock 240 72 -3 minecraft:polished_blackstone_bricks
setblock 272 72 -3 minecraft:polished_blackstone_bricks
setblock 240 72 -2 minecraft:polished_blackstone_bricks
setblock 272 72 -2 minecraft:polished_blackstone_bricks
setblock 240 72 -1 minecraft:polished_blackstone_bricks
setblock 272 72 -1 minecraft:polished_blackstone_bricks
setblock 241 72 0 minecraft:red_stained_glass
setblock 243 72 0 minecraft:red_stained_glass
setblock 269 72 0 minecraft:red_stained_glass
setblock 271 72 0 minecraft:red_stained_glass
setblock 240 72 0 minecraft:sea_lantern
setblock 272 72 0 minecraft:sea_lantern
setblock 240 72 1 minecraft:polished_blackstone_bricks
setblock 272 72 1 minecraft:polished_blackstone_bricks
setblock 240 72 2 minecraft:polished_blackstone_bricks
setblock 272 72 2 minecraft:polished_blackstone_bricks
setblock 240 72 3 minecraft:polished_blackstone_bricks
setblock 272 72 3 minecraft:polished_blackstone_bricks
setblock 240 72 4 minecraft:polished_blackstone_bricks
setblock 272 72 4 minecraft:polished_blackstone_bricks
setblock 240 72 5 minecraft:polished_blackstone_bricks
setblock 272 72 5 minecraft:polished_blackstone_bricks
setblock 241 72 6 minecraft:red_stained_glass
setblock 271 72 6 minecraft:red_stained_glass
setblock 240 72 6 minecraft:sea_lantern
setblock 272 72 6 minecraft:sea_lantern
setblock 240 72 7 minecraft:polished_blackstone_bricks
setblock 272 72 7 minecraft:polished_blackstone_bricks
setblock 240 72 8 minecraft:polished_blackstone_bricks
setblock 272 72 8 minecraft:polished_blackstone_bricks
setblock 240 72 9 minecraft:polished_blackstone_bricks
setblock 272 72 9 minecraft:polished_blackstone_bricks
setblock 240 72 10 minecraft:polished_blackstone_bricks
setblock 272 72 10 minecraft:polished_blackstone_bricks
setblock 240 72 11 minecraft:polished_blackstone_bricks
setblock 272 72 11 minecraft:polished_blackstone_bricks
setblock 243 72 11 minecraft:red_stained_glass
setblock 269 72 11 minecraft:red_stained_glass
setblock 241 72 12 minecraft:red_stained_glass
setblock 271 72 12 minecraft:red_stained_glass
setblock 240 72 12 minecraft:sea_lantern
setblock 272 72 12 minecraft:sea_lantern
setblock 240 72 13 minecraft:polished_blackstone_bricks
setblock 272 72 13 minecraft:polished_blackstone_bricks
setblock 240 72 14 minecraft:polished_blackstone_bricks
setblock 272 72 14 minecraft:polished_blackstone_bricks
setblock 240 72 15 minecraft:polished_blackstone_bricks
setblock 272 72 15 minecraft:polished_blackstone_bricks
setblock 244 72 15 minecraft:red_stained_glass
setblock 250 72 15 minecraft:red_stained_glass
setblock 256 72 15 minecraft:red_stained_glass
setblock 262 72 15 minecraft:red_stained_glass
setblock 268 72 15 minecraft:red_stained_glass
fill 240 72 16 243 72 16 minecraft:polished_blackstone_bricks
fill 245 72 16 249 72 16 minecraft:polished_blackstone_bricks
fill 251 72 16 255 72 16 minecraft:polished_blackstone_bricks
fill 257 72 16 261 72 16 minecraft:polished_blackstone_bricks
fill 263 72 16 267 72 16 minecraft:polished_blackstone_bricks
fill 269 72 16 272 72 16 minecraft:polished_blackstone_bricks
setblock 244 72 16 minecraft:sea_lantern
setblock 250 72 16 minecraft:sea_lantern
setblock 256 72 16 minecraft:sea_lantern
setblock 262 72 16 minecraft:sea_lantern
setblock 268 72 16 minecraft:sea_lantern
fill 240 73 -16 243 73 -16 minecraft:polished_blackstone_bricks
fill 245 73 -16 249 73 -16 minecraft:polished_blackstone_bricks
fill 251 73 -16 255 73 -16 minecraft:polished_blackstone_bricks
fill 257 73 -16 261 73 -16 minecraft:polished_blackstone_bricks
fill 263 73 -16 267 73 -16 minecraft:polished_blackstone_bricks
fill 269 73 -16 272 73 -16 minecraft:polished_blackstone_bricks
setblock 244 73 -16 minecraft:sea_lantern
setblock 250 73 -16 minecraft:sea_lantern
setblock 256 73 -16 minecraft:sea_lantern
setblock 262 73 -16 minecraft:sea_lantern
setblock 268 73 -16 minecraft:sea_lantern
setblock 240 73 -15 minecraft:polished_blackstone_bricks
setblock 272 73 -15 minecraft:polished_blackstone_bricks
setblock 244 73 -15 minecraft:red_stained_glass
setblock 250 73 -15 minecraft:red_stained_glass
setblock 256 73 -15 minecraft:red_stained_glass
setblock 262 73 -15 minecraft:red_stained_glass
setblock 268 73 -15 minecraft:red_stained_glass
fill 252 73 -14 260 73 -14 minecraft:polished_blackstone
setblock 240 73 -14 minecraft:polished_blackstone_bricks
setblock 272 73 -14 minecraft:polished_blackstone_bricks
setblock 240 73 -13 minecraft:polished_blackstone_bricks
setblock 272 73 -13 minecraft:polished_blackstone_bricks
fill 255 73 -13 257 73 -13 minecraft:waxed_exposed_cut_copper
setblock 241 73 -12 minecraft:red_stained_glass
setblock 271 73 -12 minecraft:red_stained_glass
setblock 240 73 -12 minecraft:sea_lantern
setblock 272 73 -12 minecraft:sea_lantern
setblock 240 73 -11 minecraft:polished_blackstone_bricks
setblock 272 73 -11 minecraft:polished_blackstone_bricks
setblock 240 73 -10 minecraft:polished_blackstone_bricks
setblock 272 73 -10 minecraft:polished_blackstone_bricks
setblock 240 73 -9 minecraft:polished_blackstone_bricks
setblock 272 73 -9 minecraft:polished_blackstone_bricks
setblock 240 73 -8 minecraft:polished_blackstone_bricks
setblock 272 73 -8 minecraft:polished_blackstone_bricks
setblock 240 73 -7 minecraft:polished_blackstone_bricks
setblock 272 73 -7 minecraft:polished_blackstone_bricks
setblock 241 73 -6 minecraft:red_stained_glass
setblock 271 73 -6 minecraft:red_stained_glass
setblock 240 73 -6 minecraft:sea_lantern
setblock 272 73 -6 minecraft:sea_lantern
setblock 240 73 -5 minecraft:polished_blackstone_bricks
setblock 272 73 -5 minecraft:polished_blackstone_bricks
setblock 240 73 -4 minecraft:polished_blackstone_bricks
setblock 272 73 -4 minecraft:polished_blackstone_bricks
setblock 240 73 -3 minecraft:polished_blackstone_bricks
setblock 272 73 -3 minecraft:polished_blackstone_bricks
setblock 240 73 -2 minecraft:polished_blackstone_bricks
setblock 272 73 -2 minecraft:polished_blackstone_bricks
setblock 240 73 -1 minecraft:polished_blackstone_bricks
setblock 272 73 -1 minecraft:polished_blackstone_bricks
setblock 241 73 0 minecraft:red_stained_glass
setblock 271 73 0 minecraft:red_stained_glass
setblock 240 73 0 minecraft:sea_lantern
setblock 272 73 0 minecraft:sea_lantern
setblock 240 73 1 minecraft:polished_blackstone_bricks
setblock 272 73 1 minecraft:polished_blackstone_bricks
setblock 240 73 2 minecraft:polished_blackstone_bricks
setblock 272 73 2 minecraft:polished_blackstone_bricks
setblock 240 73 3 minecraft:polished_blackstone_bricks
setblock 272 73 3 minecraft:polished_blackstone_bricks
setblock 240 73 4 minecraft:polished_blackstone_bricks
setblock 272 73 4 minecraft:polished_blackstone_bricks
setblock 240 73 5 minecraft:polished_blackstone_bricks
setblock 272 73 5 minecraft:polished_blackstone_bricks
setblock 241 73 6 minecraft:red_stained_glass
setblock 271 73 6 minecraft:red_stained_glass
setblock 240 73 6 minecraft:sea_lantern
setblock 272 73 6 minecraft:sea_lantern
setblock 240 73 7 minecraft:polished_blackstone_bricks
setblock 272 73 7 minecraft:polished_blackstone_bricks
setblock 240 73 8 minecraft:polished_blackstone_bricks
setblock 272 73 8 minecraft:polished_blackstone_bricks
setblock 240 73 9 minecraft:polished_blackstone_bricks
setblock 272 73 9 minecraft:polished_blackstone_bricks
setblock 240 73 10 minecraft:polished_blackstone_bricks
setblock 272 73 10 minecraft:polished_blackstone_bricks
setblock 240 73 11 minecraft:polished_blackstone_bricks
setblock 272 73 11 minecraft:polished_blackstone_bricks
setblock 241 73 12 minecraft:red_stained_glass
setblock 271 73 12 minecraft:red_stained_glass
setblock 240 73 12 minecraft:sea_lantern
setblock 272 73 12 minecraft:sea_lantern
setblock 240 73 13 minecraft:polished_blackstone_bricks
setblock 272 73 13 minecraft:polished_blackstone_bricks
setblock 240 73 14 minecraft:polished_blackstone_bricks
setblock 272 73 14 minecraft:polished_blackstone_bricks
setblock 240 73 15 minecraft:polished_blackstone_bricks
setblock 272 73 15 minecraft:polished_blackstone_bricks
setblock 244 73 15 minecraft:red_stained_glass
setblock 250 73 15 minecraft:red_stained_glass
setblock 256 73 15 minecraft:red_stained_glass
setblock 262 73 15 minecraft:red_stained_glass
setblock 268 73 15 minecraft:red_stained_glass
fill 240 73 16 243 73 16 minecraft:polished_blackstone_bricks
fill 245 73 16 249 73 16 minecraft:polished_blackstone_bricks
fill 251 73 16 255 73 16 minecraft:polished_blackstone_bricks
fill 257 73 16 261 73 16 minecraft:polished_blackstone_bricks
fill 263 73 16 267 73 16 minecraft:polished_blackstone_bricks
fill 269 73 16 272 73 16 minecraft:polished_blackstone_bricks
setblock 244 73 16 minecraft:sea_lantern
setblock 250 73 16 minecraft:sea_lantern
setblock 256 73 16 minecraft:sea_lantern
setblock 262 73 16 minecraft:sea_lantern
setblock 268 73 16 minecraft:sea_lantern
fill 240 74 -16 243 74 -16 minecraft:polished_blackstone_bricks
fill 245 74 -16 249 74 -16 minecraft:polished_blackstone_bricks
fill 251 74 -16 255 74 -16 minecraft:polished_blackstone_bricks
fill 257 74 -16 261 74 -16 minecraft:polished_blackstone_bricks
fill 263 74 -16 267 74 -16 minecraft:polished_blackstone_bricks
fill 269 74 -16 272 74 -16 minecraft:polished_blackstone_bricks
setblock 244 74 -16 minecraft:sea_lantern
setblock 250 74 -16 minecraft:sea_lantern
setblock 256 74 -16 minecraft:sea_lantern
setblock 262 74 -16 minecraft:sea_lantern
setblock 268 74 -16 minecraft:sea_lantern
setblock 240 74 -15 minecraft:polished_blackstone_bricks
setblock 272 74 -15 minecraft:polished_blackstone_bricks
setblock 244 74 -15 minecraft:red_stained_glass
setblock 250 74 -15 minecraft:red_stained_glass
setblock 256 74 -15 minecraft:red_stained_glass
setblock 262 74 -15 minecraft:red_stained_glass
setblock 268 74 -15 minecraft:red_stained_glass
fill 252 74 -14 260 74 -14 minecraft:polished_blackstone
setblock 240 74 -14 minecraft:polished_blackstone_bricks
setblock 272 74 -14 minecraft:polished_blackstone_bricks
setblock 240 74 -13 minecraft:polished_blackstone_bricks
setblock 272 74 -13 minecraft:polished_blackstone_bricks
setblock 241 74 -12 minecraft:red_stained_glass
setblock 271 74 -12 minecraft:red_stained_glass
setblock 240 74 -12 minecraft:sea_lantern
setblock 272 74 -12 minecraft:sea_lantern
setblock 240 74 -11 minecraft:polished_blackstone_bricks
setblock 272 74 -11 minecraft:polished_blackstone_bricks
setblock 240 74 -10 minecraft:polished_blackstone_bricks
setblock 272 74 -10 minecraft:polished_blackstone_bricks
setblock 240 74 -9 minecraft:polished_blackstone_bricks
setblock 272 74 -9 minecraft:polished_blackstone_bricks
setblock 240 74 -8 minecraft:polished_blackstone_bricks
setblock 272 74 -8 minecraft:polished_blackstone_bricks
setblock 240 74 -7 minecraft:polished_blackstone_bricks
setblock 272 74 -7 minecraft:polished_blackstone_bricks
setblock 241 74 -6 minecraft:red_stained_glass
setblock 271 74 -6 minecraft:red_stained_glass
setblock 240 74 -6 minecraft:sea_lantern
setblock 272 74 -6 minecraft:sea_lantern
setblock 240 74 -5 minecraft:polished_blackstone_bricks
setblock 272 74 -5 minecraft:polished_blackstone_bricks
setblock 240 74 -4 minecraft:polished_blackstone_bricks
setblock 272 74 -4 minecraft:polished_blackstone_bricks
setblock 240 74 -3 minecraft:polished_blackstone_bricks
setblock 272 74 -3 minecraft:polished_blackstone_bricks
setblock 240 74 -2 minecraft:polished_blackstone_bricks
setblock 272 74 -2 minecraft:polished_blackstone_bricks
setblock 240 74 -1 minecraft:polished_blackstone_bricks
setblock 272 74 -1 minecraft:polished_blackstone_bricks
setblock 241 74 0 minecraft:red_stained_glass
setblock 271 74 0 minecraft:red_stained_glass
setblock 240 74 0 minecraft:sea_lantern
setblock 272 74 0 minecraft:sea_lantern
setblock 240 74 1 minecraft:polished_blackstone_bricks
setblock 272 74 1 minecraft:polished_blackstone_bricks
setblock 240 74 2 minecraft:polished_blackstone_bricks
setblock 272 74 2 minecraft:polished_blackstone_bricks
setblock 240 74 3 minecraft:polished_blackstone_bricks
setblock 272 74 3 minecraft:polished_blackstone_bricks
setblock 240 74 4 minecraft:polished_blackstone_bricks
setblock 272 74 4 minecraft:polished_blackstone_bricks
setblock 240 74 5 minecraft:polished_blackstone_bricks
setblock 272 74 5 minecraft:polished_blackstone_bricks
setblock 241 74 6 minecraft:red_stained_glass
setblock 271 74 6 minecraft:red_stained_glass
setblock 240 74 6 minecraft:sea_lantern
setblock 272 74 6 minecraft:sea_lantern
setblock 240 74 7 minecraft:polished_blackstone_bricks
setblock 272 74 7 minecraft:polished_blackstone_bricks
setblock 240 74 8 minecraft:polished_blackstone_bricks
setblock 272 74 8 minecraft:polished_blackstone_bricks
setblock 240 74 9 minecraft:polished_blackstone_bricks
setblock 272 74 9 minecraft:polished_blackstone_bricks
setblock 240 74 10 minecraft:polished_blackstone_bricks
setblock 272 74 10 minecraft:polished_blackstone_bricks
setblock 240 74 11 minecraft:polished_blackstone_bricks
setblock 272 74 11 minecraft:polished_blackstone_bricks
setblock 241 74 12 minecraft:red_stained_glass
setblock 271 74 12 minecraft:red_stained_glass
setblock 240 74 12 minecraft:sea_lantern
setblock 272 74 12 minecraft:sea_lantern
setblock 240 74 13 minecraft:polished_blackstone_bricks
setblock 272 74 13 minecraft:polished_blackstone_bricks
setblock 240 74 14 minecraft:polished_blackstone_bricks
setblock 272 74 14 minecraft:polished_blackstone_bricks
setblock 240 74 15 minecraft:polished_blackstone_bricks
setblock 272 74 15 minecraft:polished_blackstone_bricks
setblock 244 74 15 minecraft:red_stained_glass
setblock 250 74 15 minecraft:red_stained_glass
setblock 256 74 15 minecraft:red_stained_glass
setblock 262 74 15 minecraft:red_stained_glass
setblock 268 74 15 minecraft:red_stained_glass
fill 240 74 16 243 74 16 minecraft:polished_blackstone_bricks
fill 245 74 16 249 74 16 minecraft:polished_blackstone_bricks
fill 251 74 16 255 74 16 minecraft:polished_blackstone_bricks
fill 257 74 16 261 74 16 minecraft:polished_blackstone_bricks
fill 263 74 16 267 74 16 minecraft:polished_blackstone_bricks
fill 269 74 16 272 74 16 minecraft:polished_blackstone_bricks
setblock 244 74 16 minecraft:sea_lantern
setblock 250 74 16 minecraft:sea_lantern
setblock 256 74 16 minecraft:sea_lantern
setblock 262 74 16 minecraft:sea_lantern
setblock 268 74 16 minecraft:sea_lantern
fill 240 75 -16 243 75 -16 minecraft:polished_blackstone_bricks
fill 245 75 -16 249 75 -16 minecraft:polished_blackstone_bricks
fill 251 75 -16 255 75 -16 minecraft:polished_blackstone_bricks
fill 257 75 -16 261 75 -16 minecraft:polished_blackstone_bricks
fill 263 75 -16 267 75 -16 minecraft:polished_blackstone_bricks
fill 269 75 -16 272 75 -16 minecraft:polished_blackstone_bricks
setblock 244 75 -16 minecraft:sea_lantern
setblock 250 75 -16 minecraft:sea_lantern
setblock 256 75 -16 minecraft:sea_lantern
setblock 262 75 -16 minecraft:sea_lantern
setblock 268 75 -16 minecraft:sea_lantern
setblock 240 75 -15 minecraft:polished_blackstone_bricks
setblock 272 75 -15 minecraft:polished_blackstone_bricks
setblock 244 75 -15 minecraft:red_stained_glass
setblock 250 75 -15 minecraft:red_stained_glass
setblock 256 75 -15 minecraft:red_stained_glass
setblock 262 75 -15 minecraft:red_stained_glass
setblock 268 75 -15 minecraft:red_stained_glass
fill 252 75 -14 260 75 -14 minecraft:polished_blackstone
setblock 240 75 -14 minecraft:polished_blackstone_bricks
setblock 272 75 -14 minecraft:polished_blackstone_bricks
setblock 240 75 -13 minecraft:polished_blackstone_bricks
setblock 272 75 -13 minecraft:polished_blackstone_bricks
setblock 241 75 -12 minecraft:red_stained_glass
setblock 271 75 -12 minecraft:red_stained_glass
setblock 240 75 -12 minecraft:sea_lantern
setblock 272 75 -12 minecraft:sea_lantern
setblock 240 75 -11 minecraft:polished_blackstone_bricks
setblock 272 75 -11 minecraft:polished_blackstone_bricks
setblock 240 75 -10 minecraft:polished_blackstone_bricks
setblock 272 75 -10 minecraft:polished_blackstone_bricks
setblock 240 75 -9 minecraft:polished_blackstone_bricks
setblock 272 75 -9 minecraft:polished_blackstone_bricks
setblock 240 75 -8 minecraft:polished_blackstone_bricks
setblock 272 75 -8 minecraft:polished_blackstone_bricks
setblock 240 75 -7 minecraft:polished_blackstone_bricks
setblock 272 75 -7 minecraft:polished_blackstone_bricks
setblock 241 75 -6 minecraft:red_stained_glass
setblock 271 75 -6 minecraft:red_stained_glass
setblock 240 75 -6 minecraft:sea_lantern
setblock 272 75 -6 minecraft:sea_lantern
setblock 240 75 -5 minecraft:polished_blackstone_bricks
setblock 272 75 -5 minecraft:polished_blackstone_bricks
setblock 240 75 -4 minecraft:polished_blackstone_bricks
setblock 272 75 -4 minecraft:polished_blackstone_bricks
setblock 240 75 -3 minecraft:polished_blackstone_bricks
setblock 272 75 -3 minecraft:polished_blackstone_bricks
setblock 240 75 -2 minecraft:polished_blackstone_bricks
setblock 272 75 -2 minecraft:polished_blackstone_bricks
setblock 240 75 -1 minecraft:polished_blackstone_bricks
setblock 272 75 -1 minecraft:polished_blackstone_bricks
setblock 241 75 0 minecraft:red_stained_glass
setblock 271 75 0 minecraft:red_stained_glass
setblock 240 75 0 minecraft:sea_lantern
setblock 272 75 0 minecraft:sea_lantern
setblock 240 75 1 minecraft:polished_blackstone_bricks
setblock 272 75 1 minecraft:polished_blackstone_bricks
setblock 240 75 2 minecraft:polished_blackstone_bricks
setblock 272 75 2 minecraft:polished_blackstone_bricks
setblock 240 75 3 minecraft:polished_blackstone_bricks
setblock 272 75 3 minecraft:polished_blackstone_bricks
setblock 240 75 4 minecraft:polished_blackstone_bricks
setblock 272 75 4 minecraft:polished_blackstone_bricks
setblock 240 75 5 minecraft:polished_blackstone_bricks
setblock 272 75 5 minecraft:polished_blackstone_bricks
setblock 241 75 6 minecraft:red_stained_glass
setblock 271 75 6 minecraft:red_stained_glass
setblock 240 75 6 minecraft:sea_lantern
setblock 272 75 6 minecraft:sea_lantern
setblock 240 75 7 minecraft:polished_blackstone_bricks
setblock 272 75 7 minecraft:polished_blackstone_bricks
setblock 240 75 8 minecraft:polished_blackstone_bricks
setblock 272 75 8 minecraft:polished_blackstone_bricks
setblock 240 75 9 minecraft:polished_blackstone_bricks
setblock 272 75 9 minecraft:polished_blackstone_bricks
setblock 240 75 10 minecraft:polished_blackstone_bricks
setblock 272 75 10 minecraft:polished_blackstone_bricks
setblock 240 75 11 minecraft:polished_blackstone_bricks
setblock 272 75 11 minecraft:polished_blackstone_bricks
setblock 241 75 12 minecraft:red_stained_glass
setblock 271 75 12 minecraft:red_stained_glass
setblock 240 75 12 minecraft:sea_lantern
setblock 272 75 12 minecraft:sea_lantern
setblock 240 75 13 minecraft:polished_blackstone_bricks
setblock 272 75 13 minecraft:polished_blackstone_bricks
setblock 240 75 14 minecraft:polished_blackstone_bricks
setblock 272 75 14 minecraft:polished_blackstone_bricks
setblock 240 75 15 minecraft:polished_blackstone_bricks
setblock 272 75 15 minecraft:polished_blackstone_bricks
setblock 244 75 15 minecraft:red_stained_glass
setblock 250 75 15 minecraft:red_stained_glass
setblock 256 75 15 minecraft:red_stained_glass
setblock 262 75 15 minecraft:red_stained_glass
setblock 268 75 15 minecraft:red_stained_glass
fill 240 75 16 243 75 16 minecraft:polished_blackstone_bricks
fill 245 75 16 249 75 16 minecraft:polished_blackstone_bricks
fill 251 75 16 255 75 16 minecraft:polished_blackstone_bricks
fill 257 75 16 261 75 16 minecraft:polished_blackstone_bricks
fill 263 75 16 267 75 16 minecraft:polished_blackstone_bricks
fill 269 75 16 272 75 16 minecraft:polished_blackstone_bricks
setblock 244 75 16 minecraft:sea_lantern
setblock 250 75 16 minecraft:sea_lantern
setblock 256 75 16 minecraft:sea_lantern
setblock 262 75 16 minecraft:sea_lantern
setblock 268 75 16 minecraft:sea_lantern
fill 240 76 -16 243 76 -16 minecraft:polished_blackstone_bricks
fill 245 76 -16 249 76 -16 minecraft:polished_blackstone_bricks
fill 251 76 -16 255 76 -16 minecraft:polished_blackstone_bricks
fill 257 76 -16 261 76 -16 minecraft:polished_blackstone_bricks
fill 263 76 -16 267 76 -16 minecraft:polished_blackstone_bricks
fill 269 76 -16 272 76 -16 minecraft:polished_blackstone_bricks
setblock 244 76 -16 minecraft:sea_lantern
setblock 250 76 -16 minecraft:sea_lantern
setblock 256 76 -16 minecraft:sea_lantern
setblock 262 76 -16 minecraft:sea_lantern
setblock 268 76 -16 minecraft:sea_lantern
setblock 240 76 -15 minecraft:polished_blackstone_bricks
setblock 272 76 -15 minecraft:polished_blackstone_bricks
setblock 244 76 -15 minecraft:red_stained_glass
setblock 250 76 -15 minecraft:red_stained_glass
setblock 256 76 -15 minecraft:red_stained_glass
setblock 262 76 -15 minecraft:red_stained_glass
setblock 268 76 -15 minecraft:red_stained_glass
fill 252 76 -14 260 76 -14 minecraft:polished_blackstone
setblock 240 76 -14 minecraft:polished_blackstone_bricks
setblock 272 76 -14 minecraft:polished_blackstone_bricks
setblock 240 76 -13 minecraft:polished_blackstone_bricks
setblock 272 76 -13 minecraft:polished_blackstone_bricks
fill 253 76 -13 254 76 -13 minecraft:sea_lantern
fill 258 76 -13 259 76 -13 minecraft:sea_lantern
setblock 241 76 -12 minecraft:red_stained_glass
setblock 271 76 -12 minecraft:red_stained_glass
setblock 240 76 -12 minecraft:sea_lantern
setblock 272 76 -12 minecraft:sea_lantern
setblock 240 76 -11 minecraft:polished_blackstone_bricks
setblock 272 76 -11 minecraft:polished_blackstone_bricks
setblock 240 76 -10 minecraft:polished_blackstone_bricks
setblock 272 76 -10 minecraft:polished_blackstone_bricks
setblock 240 76 -9 minecraft:polished_blackstone_bricks
setblock 272 76 -9 minecraft:polished_blackstone_bricks
setblock 240 76 -8 minecraft:polished_blackstone_bricks
setblock 272 76 -8 minecraft:polished_blackstone_bricks
setblock 240 76 -7 minecraft:polished_blackstone_bricks
setblock 272 76 -7 minecraft:polished_blackstone_bricks
setblock 241 76 -6 minecraft:red_stained_glass
setblock 271 76 -6 minecraft:red_stained_glass
setblock 240 76 -6 minecraft:sea_lantern
setblock 272 76 -6 minecraft:sea_lantern
setblock 240 76 -5 minecraft:polished_blackstone_bricks
setblock 272 76 -5 minecraft:polished_blackstone_bricks
setblock 240 76 -4 minecraft:polished_blackstone_bricks
setblock 272 76 -4 minecraft:polished_blackstone_bricks
setblock 240 76 -3 minecraft:polished_blackstone_bricks
setblock 272 76 -3 minecraft:polished_blackstone_bricks
setblock 240 76 -2 minecraft:polished_blackstone_bricks
setblock 272 76 -2 minecraft:polished_blackstone_bricks
setblock 240 76 -1 minecraft:polished_blackstone_bricks
setblock 272 76 -1 minecraft:polished_blackstone_bricks
setblock 241 76 0 minecraft:red_stained_glass
setblock 271 76 0 minecraft:red_stained_glass
setblock 240 76 0 minecraft:sea_lantern
setblock 272 76 0 minecraft:sea_lantern
setblock 240 76 1 minecraft:polished_blackstone_bricks
setblock 272 76 1 minecraft:polished_blackstone_bricks
setblock 240 76 2 minecraft:polished_blackstone_bricks
setblock 272 76 2 minecraft:polished_blackstone_bricks
setblock 240 76 3 minecraft:polished_blackstone_bricks
setblock 272 76 3 minecraft:polished_blackstone_bricks
setblock 240 76 4 minecraft:polished_blackstone_bricks
setblock 272 76 4 minecraft:polished_blackstone_bricks
setblock 240 76 5 minecraft:polished_blackstone_bricks
setblock 272 76 5 minecraft:polished_blackstone_bricks
setblock 241 76 6 minecraft:red_stained_glass
setblock 271 76 6 minecraft:red_stained_glass
setblock 240 76 6 minecraft:sea_lantern
setblock 272 76 6 minecraft:sea_lantern
setblock 240 76 7 minecraft:polished_blackstone_bricks
setblock 272 76 7 minecraft:polished_blackstone_bricks
setblock 240 76 8 minecraft:polished_blackstone_bricks
setblock 272 76 8 minecraft:polished_blackstone_bricks
setblock 240 76 9 minecraft:polished_blackstone_bricks
setblock 272 76 9 minecraft:polished_blackstone_bricks
setblock 240 76 10 minecraft:polished_blackstone_bricks
setblock 272 76 10 minecraft:polished_blackstone_bricks
setblock 240 76 11 minecraft:polished_blackstone_bricks
setblock 272 76 11 minecraft:polished_blackstone_bricks
setblock 241 76 12 minecraft:red_stained_glass
setblock 271 76 12 minecraft:red_stained_glass
setblock 240 76 12 minecraft:sea_lantern
setblock 272 76 12 minecraft:sea_lantern
setblock 240 76 13 minecraft:polished_blackstone_bricks
setblock 272 76 13 minecraft:polished_blackstone_bricks
setblock 240 76 14 minecraft:polished_blackstone_bricks
setblock 272 76 14 minecraft:polished_blackstone_bricks
setblock 240 76 15 minecraft:polished_blackstone_bricks
setblock 272 76 15 minecraft:polished_blackstone_bricks
setblock 244 76 15 minecraft:red_stained_glass
setblock 250 76 15 minecraft:red_stained_glass
setblock 256 76 15 minecraft:red_stained_glass
setblock 262 76 15 minecraft:red_stained_glass
setblock 268 76 15 minecraft:red_stained_glass
fill 240 76 16 243 76 16 minecraft:polished_blackstone_bricks
fill 245 76 16 249 76 16 minecraft:polished_blackstone_bricks
fill 251 76 16 255 76 16 minecraft:polished_blackstone_bricks
fill 257 76 16 261 76 16 minecraft:polished_blackstone_bricks
fill 263 76 16 267 76 16 minecraft:polished_blackstone_bricks
fill 269 76 16 272 76 16 minecraft:polished_blackstone_bricks
setblock 244 76 16 minecraft:sea_lantern
setblock 250 76 16 minecraft:sea_lantern
setblock 256 76 16 minecraft:sea_lantern
setblock 262 76 16 minecraft:sea_lantern
setblock 268 76 16 minecraft:sea_lantern
fill 240 77 -16 243 77 -16 minecraft:polished_blackstone_bricks
fill 245 77 -16 249 77 -16 minecraft:polished_blackstone_bricks
fill 251 77 -16 255 77 -16 minecraft:polished_blackstone_bricks
fill 257 77 -16 261 77 -16 minecraft:polished_blackstone_bricks
fill 263 77 -16 267 77 -16 minecraft:polished_blackstone_bricks
fill 269 77 -16 272 77 -16 minecraft:polished_blackstone_bricks
setblock 244 77 -16 minecraft:sea_lantern
setblock 250 77 -16 minecraft:sea_lantern
setblock 256 77 -16 minecraft:sea_lantern
setblock 262 77 -16 minecraft:sea_lantern
setblock 268 77 -16 minecraft:sea_lantern
setblock 240 77 -15 minecraft:polished_blackstone_bricks
setblock 272 77 -15 minecraft:polished_blackstone_bricks
setblock 244 77 -15 minecraft:red_stained_glass
setblock 250 77 -15 minecraft:red_stained_glass
setblock 256 77 -15 minecraft:red_stained_glass
setblock 262 77 -15 minecraft:red_stained_glass
setblock 268 77 -15 minecraft:red_stained_glass
fill 252 77 -14 260 77 -14 minecraft:polished_blackstone
setblock 240 77 -14 minecraft:polished_blackstone_bricks
setblock 272 77 -14 minecraft:polished_blackstone_bricks
setblock 240 77 -13 minecraft:polished_blackstone_bricks
setblock 272 77 -13 minecraft:polished_blackstone_bricks
setblock 241 77 -12 minecraft:red_stained_glass
setblock 271 77 -12 minecraft:red_stained_glass
setblock 240 77 -12 minecraft:sea_lantern
setblock 272 77 -12 minecraft:sea_lantern
setblock 240 77 -11 minecraft:polished_blackstone_bricks
setblock 272 77 -11 minecraft:polished_blackstone_bricks
setblock 240 77 -10 minecraft:polished_blackstone_bricks
setblock 272 77 -10 minecraft:polished_blackstone_bricks
setblock 240 77 -9 minecraft:polished_blackstone_bricks
setblock 272 77 -9 minecraft:polished_blackstone_bricks
setblock 240 77 -8 minecraft:polished_blackstone_bricks
setblock 272 77 -8 minecraft:polished_blackstone_bricks
setblock 240 77 -7 minecraft:polished_blackstone_bricks
setblock 272 77 -7 minecraft:polished_blackstone_bricks
setblock 241 77 -6 minecraft:red_stained_glass
setblock 271 77 -6 minecraft:red_stained_glass
setblock 240 77 -6 minecraft:sea_lantern
setblock 272 77 -6 minecraft:sea_lantern
setblock 240 77 -5 minecraft:polished_blackstone_bricks
setblock 272 77 -5 minecraft:polished_blackstone_bricks
setblock 240 77 -4 minecraft:polished_blackstone_bricks
setblock 272 77 -4 minecraft:polished_blackstone_bricks
setblock 240 77 -3 minecraft:polished_blackstone_bricks
setblock 272 77 -3 minecraft:polished_blackstone_bricks
setblock 240 77 -2 minecraft:polished_blackstone_bricks
setblock 272 77 -2 minecraft:polished_blackstone_bricks
setblock 240 77 -1 minecraft:polished_blackstone_bricks
setblock 272 77 -1 minecraft:polished_blackstone_bricks
setblock 241 77 0 minecraft:red_stained_glass
setblock 271 77 0 minecraft:red_stained_glass
setblock 240 77 0 minecraft:sea_lantern
setblock 272 77 0 minecraft:sea_lantern
setblock 240 77 1 minecraft:polished_blackstone_bricks
setblock 272 77 1 minecraft:polished_blackstone_bricks
setblock 240 77 2 minecraft:polished_blackstone_bricks
setblock 272 77 2 minecraft:polished_blackstone_bricks
setblock 240 77 3 minecraft:polished_blackstone_bricks
setblock 272 77 3 minecraft:polished_blackstone_bricks
setblock 240 77 4 minecraft:polished_blackstone_bricks
setblock 272 77 4 minecraft:polished_blackstone_bricks
setblock 240 77 5 minecraft:polished_blackstone_bricks
setblock 272 77 5 minecraft:polished_blackstone_bricks
setblock 241 77 6 minecraft:red_stained_glass
setblock 271 77 6 minecraft:red_stained_glass
setblock 240 77 6 minecraft:sea_lantern
setblock 272 77 6 minecraft:sea_lantern
setblock 240 77 7 minecraft:polished_blackstone_bricks
setblock 272 77 7 minecraft:polished_blackstone_bricks
setblock 240 77 8 minecraft:polished_blackstone_bricks
setblock 272 77 8 minecraft:polished_blackstone_bricks
setblock 240 77 9 minecraft:polished_blackstone_bricks
setblock 272 77 9 minecraft:polished_blackstone_bricks
setblock 240 77 10 minecraft:polished_blackstone_bricks
setblock 272 77 10 minecraft:polished_blackstone_bricks
setblock 240 77 11 minecraft:polished_blackstone_bricks
setblock 272 77 11 minecraft:polished_blackstone_bricks
setblock 241 77 12 minecraft:red_stained_glass
setblock 271 77 12 minecraft:red_stained_glass
setblock 240 77 12 minecraft:sea_lantern
setblock 272 77 12 minecraft:sea_lantern
setblock 240 77 13 minecraft:polished_blackstone_bricks
setblock 272 77 13 minecraft:polished_blackstone_bricks
setblock 240 77 14 minecraft:polished_blackstone_bricks
setblock 272 77 14 minecraft:polished_blackstone_bricks
setblock 240 77 15 minecraft:polished_blackstone_bricks
setblock 272 77 15 minecraft:polished_blackstone_bricks
setblock 244 77 15 minecraft:red_stained_glass
setblock 250 77 15 minecraft:red_stained_glass
setblock 256 77 15 minecraft:red_stained_glass
setblock 262 77 15 minecraft:red_stained_glass
setblock 268 77 15 minecraft:red_stained_glass
fill 240 77 16 243 77 16 minecraft:polished_blackstone_bricks
fill 245 77 16 249 77 16 minecraft:polished_blackstone_bricks
fill 251 77 16 255 77 16 minecraft:polished_blackstone_bricks
fill 257 77 16 261 77 16 minecraft:polished_blackstone_bricks
fill 263 77 16 267 77 16 minecraft:polished_blackstone_bricks
fill 269 77 16 272 77 16 minecraft:polished_blackstone_bricks
setblock 244 77 16 minecraft:sea_lantern
setblock 250 77 16 minecraft:sea_lantern
setblock 256 77 16 minecraft:sea_lantern
setblock 262 77 16 minecraft:sea_lantern
setblock 268 77 16 minecraft:sea_lantern
fill 240 78 -16 243 78 -16 minecraft:polished_blackstone_bricks
fill 245 78 -16 249 78 -16 minecraft:polished_blackstone_bricks
fill 251 78 -16 255 78 -16 minecraft:polished_blackstone_bricks
fill 257 78 -16 261 78 -16 minecraft:polished_blackstone_bricks
fill 263 78 -16 267 78 -16 minecraft:polished_blackstone_bricks
fill 269 78 -16 272 78 -16 minecraft:polished_blackstone_bricks
setblock 244 78 -16 minecraft:sea_lantern
setblock 250 78 -16 minecraft:sea_lantern
setblock 256 78 -16 minecraft:sea_lantern
setblock 262 78 -16 minecraft:sea_lantern
setblock 268 78 -16 minecraft:sea_lantern
setblock 240 78 -15 minecraft:polished_blackstone_bricks
setblock 272 78 -15 minecraft:polished_blackstone_bricks
setblock 244 78 -15 minecraft:red_stained_glass
setblock 250 78 -15 minecraft:red_stained_glass
setblock 256 78 -15 minecraft:red_stained_glass
setblock 262 78 -15 minecraft:red_stained_glass
setblock 268 78 -15 minecraft:red_stained_glass
fill 252 78 -14 260 78 -14 minecraft:polished_blackstone
setblock 240 78 -14 minecraft:polished_blackstone_bricks
setblock 272 78 -14 minecraft:polished_blackstone_bricks
setblock 240 78 -13 minecraft:polished_blackstone_bricks
setblock 272 78 -13 minecraft:polished_blackstone_bricks
setblock 241 78 -12 minecraft:red_stained_glass
setblock 271 78 -12 minecraft:red_stained_glass
setblock 240 78 -12 minecraft:sea_lantern
setblock 272 78 -12 minecraft:sea_lantern
setblock 240 78 -11 minecraft:polished_blackstone_bricks
setblock 272 78 -11 minecraft:polished_blackstone_bricks
setblock 240 78 -10 minecraft:polished_blackstone_bricks
setblock 272 78 -10 minecraft:polished_blackstone_bricks
setblock 240 78 -9 minecraft:polished_blackstone_bricks
setblock 272 78 -9 minecraft:polished_blackstone_bricks
setblock 240 78 -8 minecraft:polished_blackstone_bricks
setblock 272 78 -8 minecraft:polished_blackstone_bricks
setblock 240 78 -7 minecraft:polished_blackstone_bricks
setblock 272 78 -7 minecraft:polished_blackstone_bricks
setblock 241 78 -6 minecraft:red_stained_glass
setblock 271 78 -6 minecraft:red_stained_glass
setblock 240 78 -6 minecraft:sea_lantern
setblock 272 78 -6 minecraft:sea_lantern
setblock 240 78 -5 minecraft:polished_blackstone_bricks
setblock 272 78 -5 minecraft:polished_blackstone_bricks
setblock 240 78 -4 minecraft:polished_blackstone_bricks
setblock 272 78 -4 minecraft:polished_blackstone_bricks
setblock 240 78 -3 minecraft:polished_blackstone_bricks
setblock 272 78 -3 minecraft:polished_blackstone_bricks
setblock 240 78 -2 minecraft:polished_blackstone_bricks
setblock 272 78 -2 minecraft:polished_blackstone_bricks
setblock 240 78 -1 minecraft:polished_blackstone_bricks
setblock 272 78 -1 minecraft:polished_blackstone_bricks
setblock 241 78 0 minecraft:red_stained_glass
setblock 271 78 0 minecraft:red_stained_glass
setblock 240 78 0 minecraft:sea_lantern
setblock 272 78 0 minecraft:sea_lantern
setblock 240 78 1 minecraft:polished_blackstone_bricks
setblock 272 78 1 minecraft:polished_blackstone_bricks
setblock 240 78 2 minecraft:polished_blackstone_bricks
setblock 272 78 2 minecraft:polished_blackstone_bricks
setblock 240 78 3 minecraft:polished_blackstone_bricks
setblock 272 78 3 minecraft:polished_blackstone_bricks
setblock 240 78 4 minecraft:polished_blackstone_bricks
setblock 272 78 4 minecraft:polished_blackstone_bricks
setblock 240 78 5 minecraft:polished_blackstone_bricks
setblock 272 78 5 minecraft:polished_blackstone_bricks
setblock 241 78 6 minecraft:red_stained_glass
setblock 271 78 6 minecraft:red_stained_glass
setblock 240 78 6 minecraft:sea_lantern
setblock 272 78 6 minecraft:sea_lantern
setblock 240 78 7 minecraft:polished_blackstone_bricks
setblock 272 78 7 minecraft:polished_blackstone_bricks
setblock 240 78 8 minecraft:polished_blackstone_bricks
setblock 272 78 8 minecraft:polished_blackstone_bricks
setblock 240 78 9 minecraft:polished_blackstone_bricks
setblock 272 78 9 minecraft:polished_blackstone_bricks
setblock 240 78 10 minecraft:polished_blackstone_bricks
setblock 272 78 10 minecraft:polished_blackstone_bricks
setblock 240 78 11 minecraft:polished_blackstone_bricks
setblock 272 78 11 minecraft:polished_blackstone_bricks
setblock 241 78 12 minecraft:red_stained_glass
setblock 271 78 12 minecraft:red_stained_glass
setblock 240 78 12 minecraft:sea_lantern
setblock 272 78 12 minecraft:sea_lantern
setblock 240 78 13 minecraft:polished_blackstone_bricks
setblock 272 78 13 minecraft:polished_blackstone_bricks
setblock 240 78 14 minecraft:polished_blackstone_bricks
setblock 272 78 14 minecraft:polished_blackstone_bricks
setblock 240 78 15 minecraft:polished_blackstone_bricks
setblock 272 78 15 minecraft:polished_blackstone_bricks
setblock 244 78 15 minecraft:red_stained_glass
setblock 250 78 15 minecraft:red_stained_glass
setblock 256 78 15 minecraft:red_stained_glass
setblock 262 78 15 minecraft:red_stained_glass
setblock 268 78 15 minecraft:red_stained_glass
fill 240 78 16 243 78 16 minecraft:polished_blackstone_bricks
fill 245 78 16 249 78 16 minecraft:polished_blackstone_bricks
fill 251 78 16 255 78 16 minecraft:polished_blackstone_bricks
fill 257 78 16 261 78 16 minecraft:polished_blackstone_bricks
fill 263 78 16 267 78 16 minecraft:polished_blackstone_bricks
fill 269 78 16 272 78 16 minecraft:polished_blackstone_bricks
setblock 244 78 16 minecraft:sea_lantern
setblock 250 78 16 minecraft:sea_lantern
setblock 256 78 16 minecraft:sea_lantern
setblock 262 78 16 minecraft:sea_lantern
setblock 268 78 16 minecraft:sea_lantern
fill 240 79 -16 272 79 -16 minecraft:polished_blackstone_bricks
setblock 244 79 -15 minecraft:polished_basalt[axis=y]
setblock 250 79 -15 minecraft:polished_basalt[axis=y]
setblock 256 79 -15 minecraft:polished_basalt[axis=y]
setblock 262 79 -15 minecraft:polished_basalt[axis=y]
setblock 268 79 -15 minecraft:polished_basalt[axis=y]
setblock 240 79 -15 minecraft:polished_blackstone_bricks
setblock 272 79 -15 minecraft:polished_blackstone_bricks
setblock 240 79 -14 minecraft:polished_blackstone_bricks
setblock 272 79 -14 minecraft:polished_blackstone_bricks
setblock 240 79 -13 minecraft:polished_blackstone_bricks
setblock 272 79 -13 minecraft:polished_blackstone_bricks
setblock 241 79 -12 minecraft:polished_basalt[axis=y]
setblock 271 79 -12 minecraft:polished_basalt[axis=y]
setblock 240 79 -12 minecraft:polished_blackstone_bricks
setblock 272 79 -12 minecraft:polished_blackstone_bricks
setblock 240 79 -11 minecraft:polished_blackstone_bricks
setblock 272 79 -11 minecraft:polished_blackstone_bricks
setblock 240 79 -10 minecraft:polished_blackstone_bricks
setblock 272 79 -10 minecraft:polished_blackstone_bricks
setblock 240 79 -9 minecraft:polished_blackstone_bricks
setblock 272 79 -9 minecraft:polished_blackstone_bricks
setblock 240 79 -8 minecraft:polished_blackstone_bricks
setblock 272 79 -8 minecraft:polished_blackstone_bricks
setblock 240 79 -7 minecraft:polished_blackstone_bricks
setblock 272 79 -7 minecraft:polished_blackstone_bricks
setblock 241 79 -6 minecraft:polished_basalt[axis=y]
setblock 271 79 -6 minecraft:polished_basalt[axis=y]
setblock 240 79 -6 minecraft:polished_blackstone_bricks
setblock 272 79 -6 minecraft:polished_blackstone_bricks
setblock 240 79 -5 minecraft:polished_blackstone_bricks
setblock 272 79 -5 minecraft:polished_blackstone_bricks
setblock 240 79 -4 minecraft:polished_blackstone_bricks
setblock 272 79 -4 minecraft:polished_blackstone_bricks
setblock 240 79 -3 minecraft:polished_blackstone_bricks
setblock 272 79 -3 minecraft:polished_blackstone_bricks
setblock 240 79 -2 minecraft:polished_blackstone_bricks
setblock 272 79 -2 minecraft:polished_blackstone_bricks
setblock 240 79 -1 minecraft:polished_blackstone_bricks
setblock 272 79 -1 minecraft:polished_blackstone_bricks
setblock 241 79 0 minecraft:polished_basalt[axis=y]
setblock 271 79 0 minecraft:polished_basalt[axis=y]
setblock 240 79 0 minecraft:polished_blackstone_bricks
setblock 272 79 0 minecraft:polished_blackstone_bricks
setblock 240 79 1 minecraft:polished_blackstone_bricks
setblock 272 79 1 minecraft:polished_blackstone_bricks
setblock 240 79 2 minecraft:polished_blackstone_bricks
setblock 272 79 2 minecraft:polished_blackstone_bricks
setblock 240 79 3 minecraft:polished_blackstone_bricks
setblock 272 79 3 minecraft:polished_blackstone_bricks
setblock 240 79 4 minecraft:polished_blackstone_bricks
setblock 272 79 4 minecraft:polished_blackstone_bricks
setblock 240 79 5 minecraft:polished_blackstone_bricks
setblock 272 79 5 minecraft:polished_blackstone_bricks
setblock 241 79 6 minecraft:polished_basalt[axis=y]
setblock 271 79 6 minecraft:polished_basalt[axis=y]
setblock 240 79 6 minecraft:polished_blackstone_bricks
setblock 272 79 6 minecraft:polished_blackstone_bricks
setblock 240 79 7 minecraft:polished_blackstone_bricks
setblock 272 79 7 minecraft:polished_blackstone_bricks
setblock 240 79 8 minecraft:polished_blackstone_bricks
setblock 272 79 8 minecraft:polished_blackstone_bricks
setblock 240 79 9 minecraft:polished_blackstone_bricks
setblock 272 79 9 minecraft:polished_blackstone_bricks
setblock 240 79 10 minecraft:polished_blackstone_bricks
setblock 272 79 10 minecraft:polished_blackstone_bricks
setblock 240 79 11 minecraft:polished_blackstone_bricks
setblock 272 79 11 minecraft:polished_blackstone_bricks
setblock 241 79 12 minecraft:polished_basalt[axis=y]
setblock 271 79 12 minecraft:polished_basalt[axis=y]
setblock 240 79 12 minecraft:polished_blackstone_bricks
setblock 272 79 12 minecraft:polished_blackstone_bricks
setblock 240 79 13 minecraft:polished_blackstone_bricks
setblock 272 79 13 minecraft:polished_blackstone_bricks
setblock 240 79 14 minecraft:polished_blackstone_bricks
setblock 272 79 14 minecraft:polished_blackstone_bricks
setblock 244 79 15 minecraft:polished_basalt[axis=y]
setblock 250 79 15 minecraft:polished_basalt[axis=y]
setblock 256 79 15 minecraft:polished_basalt[axis=y]
setblock 262 79 15 minecraft:polished_basalt[axis=y]
setblock 268 79 15 minecraft:polished_basalt[axis=y]
setblock 240 79 15 minecraft:polished_blackstone_bricks
setblock 272 79 15 minecraft:polished_blackstone_bricks
fill 240 79 16 272 79 16 minecraft:polished_blackstone_bricks
fill 240 80 -16 272 80 -16 minecraft:polished_blackstone_bricks
setblock 240 80 -15 minecraft:polished_blackstone_bricks
setblock 272 80 -15 minecraft:polished_blackstone_bricks
fill 241 80 -15 271 80 -15 minecraft:waxed_exposed_cut_copper
setblock 240 80 -14 minecraft:polished_blackstone_bricks
setblock 272 80 -14 minecraft:polished_blackstone_bricks
setblock 241 80 -14 minecraft:waxed_exposed_cut_copper
setblock 271 80 -14 minecraft:waxed_exposed_cut_copper
setblock 240 80 -13 minecraft:polished_blackstone_bricks
setblock 272 80 -13 minecraft:polished_blackstone_bricks
setblock 241 80 -13 minecraft:waxed_exposed_cut_copper
setblock 271 80 -13 minecraft:waxed_exposed_cut_copper
setblock 240 80 -12 minecraft:polished_blackstone_bricks
setblock 272 80 -12 minecraft:polished_blackstone_bricks
setblock 244 80 -12 minecraft:sea_lantern
setblock 268 80 -12 minecraft:sea_lantern
fill 241 80 -12 242 80 -12 minecraft:waxed_exposed_cut_copper
fill 270 80 -12 271 80 -12 minecraft:waxed_exposed_cut_copper
setblock 240 80 -11 minecraft:polished_blackstone_bricks
setblock 272 80 -11 minecraft:polished_blackstone_bricks
setblock 241 80 -11 minecraft:waxed_exposed_cut_copper
setblock 271 80 -11 minecraft:waxed_exposed_cut_copper
setblock 240 80 -10 minecraft:polished_blackstone_bricks
setblock 272 80 -10 minecraft:polished_blackstone_bricks
setblock 241 80 -10 minecraft:waxed_exposed_cut_copper
setblock 271 80 -10 minecraft:waxed_exposed_cut_copper
setblock 240 80 -9 minecraft:polished_blackstone_bricks
setblock 272 80 -9 minecraft:polished_blackstone_bricks
setblock 241 80 -9 minecraft:waxed_exposed_cut_copper
setblock 271 80 -9 minecraft:waxed_exposed_cut_copper
setblock 240 80 -8 minecraft:polished_blackstone_bricks
setblock 272 80 -8 minecraft:polished_blackstone_bricks
setblock 241 80 -8 minecraft:waxed_exposed_cut_copper
setblock 271 80 -8 minecraft:waxed_exposed_cut_copper
setblock 240 80 -7 minecraft:polished_blackstone_bricks
setblock 272 80 -7 minecraft:polished_blackstone_bricks
setblock 241 80 -7 minecraft:waxed_exposed_cut_copper
setblock 271 80 -7 minecraft:waxed_exposed_cut_copper
setblock 240 80 -6 minecraft:polished_blackstone_bricks
setblock 272 80 -6 minecraft:polished_blackstone_bricks
setblock 241 80 -6 minecraft:waxed_exposed_cut_copper
setblock 271 80 -6 minecraft:waxed_exposed_cut_copper
setblock 240 80 -5 minecraft:polished_blackstone_bricks
setblock 272 80 -5 minecraft:polished_blackstone_bricks
setblock 241 80 -5 minecraft:waxed_exposed_cut_copper
setblock 271 80 -5 minecraft:waxed_exposed_cut_copper
setblock 240 80 -4 minecraft:polished_blackstone_bricks
setblock 272 80 -4 minecraft:polished_blackstone_bricks
setblock 241 80 -4 minecraft:waxed_exposed_cut_copper
setblock 271 80 -4 minecraft:waxed_exposed_cut_copper
setblock 240 80 -3 minecraft:polished_blackstone_bricks
setblock 272 80 -3 minecraft:polished_blackstone_bricks
setblock 241 80 -3 minecraft:waxed_exposed_cut_copper
setblock 271 80 -3 minecraft:waxed_exposed_cut_copper
setblock 240 80 -2 minecraft:polished_blackstone_bricks
setblock 272 80 -2 minecraft:polished_blackstone_bricks
setblock 241 80 -2 minecraft:waxed_exposed_cut_copper
setblock 271 80 -2 minecraft:waxed_exposed_cut_copper
setblock 240 80 -1 minecraft:polished_blackstone_bricks
setblock 272 80 -1 minecraft:polished_blackstone_bricks
setblock 241 80 -1 minecraft:waxed_exposed_cut_copper
setblock 271 80 -1 minecraft:waxed_exposed_cut_copper
setblock 240 80 0 minecraft:polished_blackstone_bricks
setblock 272 80 0 minecraft:polished_blackstone_bricks
setblock 244 80 0 minecraft:sea_lantern
setblock 268 80 0 minecraft:sea_lantern
fill 241 80 0 242 80 0 minecraft:waxed_exposed_cut_copper
fill 270 80 0 271 80 0 minecraft:waxed_exposed_cut_copper
setblock 240 80 1 minecraft:polished_blackstone_bricks
setblock 272 80 1 minecraft:polished_blackstone_bricks
setblock 241 80 1 minecraft:waxed_exposed_cut_copper
setblock 271 80 1 minecraft:waxed_exposed_cut_copper
setblock 240 80 2 minecraft:polished_blackstone_bricks
setblock 272 80 2 minecraft:polished_blackstone_bricks
setblock 241 80 2 minecraft:waxed_exposed_cut_copper
setblock 271 80 2 minecraft:waxed_exposed_cut_copper
setblock 240 80 3 minecraft:polished_blackstone_bricks
setblock 272 80 3 minecraft:polished_blackstone_bricks
setblock 241 80 3 minecraft:waxed_exposed_cut_copper
setblock 271 80 3 minecraft:waxed_exposed_cut_copper
setblock 240 80 4 minecraft:polished_blackstone_bricks
setblock 272 80 4 minecraft:polished_blackstone_bricks
setblock 241 80 4 minecraft:waxed_exposed_cut_copper
setblock 271 80 4 minecraft:waxed_exposed_cut_copper
setblock 240 80 5 minecraft:polished_blackstone_bricks
setblock 272 80 5 minecraft:polished_blackstone_bricks
setblock 241 80 5 minecraft:waxed_exposed_cut_copper
setblock 271 80 5 minecraft:waxed_exposed_cut_copper
setblock 240 80 6 minecraft:polished_blackstone_bricks
setblock 272 80 6 minecraft:polished_blackstone_bricks
setblock 241 80 6 minecraft:waxed_exposed_cut_copper
setblock 271 80 6 minecraft:waxed_exposed_cut_copper
setblock 240 80 7 minecraft:polished_blackstone_bricks
setblock 272 80 7 minecraft:polished_blackstone_bricks
setblock 241 80 7 minecraft:waxed_exposed_cut_copper
setblock 271 80 7 minecraft:waxed_exposed_cut_copper
setblock 240 80 8 minecraft:polished_blackstone_bricks
setblock 272 80 8 minecraft:polished_blackstone_bricks
setblock 241 80 8 minecraft:waxed_exposed_cut_copper
setblock 271 80 8 minecraft:waxed_exposed_cut_copper
setblock 240 80 9 minecraft:polished_blackstone_bricks
setblock 272 80 9 minecraft:polished_blackstone_bricks
setblock 241 80 9 minecraft:waxed_exposed_cut_copper
setblock 271 80 9 minecraft:waxed_exposed_cut_copper
setblock 240 80 10 minecraft:polished_blackstone_bricks
setblock 272 80 10 minecraft:polished_blackstone_bricks
setblock 241 80 10 minecraft:waxed_exposed_cut_copper
setblock 271 80 10 minecraft:waxed_exposed_cut_copper
setblock 240 80 11 minecraft:polished_blackstone_bricks
setblock 272 80 11 minecraft:polished_blackstone_bricks
setblock 241 80 11 minecraft:waxed_exposed_cut_copper
setblock 271 80 11 minecraft:waxed_exposed_cut_copper
setblock 240 80 12 minecraft:polished_blackstone_bricks
setblock 272 80 12 minecraft:polished_blackstone_bricks
setblock 244 80 12 minecraft:sea_lantern
setblock 268 80 12 minecraft:sea_lantern
fill 241 80 12 242 80 12 minecraft:waxed_exposed_cut_copper
fill 270 80 12 271 80 12 minecraft:waxed_exposed_cut_copper
setblock 240 80 13 minecraft:polished_blackstone_bricks
setblock 272 80 13 minecraft:polished_blackstone_bricks
setblock 241 80 13 minecraft:waxed_exposed_cut_copper
setblock 271 80 13 minecraft:waxed_exposed_cut_copper
setblock 240 80 14 minecraft:polished_blackstone_bricks
setblock 272 80 14 minecraft:polished_blackstone_bricks
setblock 241 80 14 minecraft:waxed_exposed_cut_copper
setblock 271 80 14 minecraft:waxed_exposed_cut_copper
setblock 240 80 15 minecraft:polished_blackstone_bricks
setblock 272 80 15 minecraft:polished_blackstone_bricks
fill 241 80 15 271 80 15 minecraft:waxed_exposed_cut_copper
fill 240 80 16 272 80 16 minecraft:polished_blackstone_bricks
fill 240 81 -16 272 81 -16 minecraft:polished_blackstone_bricks
setblock 240 81 -15 minecraft:polished_blackstone_bricks
setblock 272 81 -15 minecraft:polished_blackstone_bricks
setblock 244 81 -15 minecraft:waxed_exposed_cut_copper
setblock 250 81 -15 minecraft:waxed_exposed_cut_copper
setblock 256 81 -15 minecraft:waxed_exposed_cut_copper
setblock 262 81 -15 minecraft:waxed_exposed_cut_copper
setblock 268 81 -15 minecraft:waxed_exposed_cut_copper
setblock 240 81 -14 minecraft:polished_blackstone_bricks
setblock 272 81 -14 minecraft:polished_blackstone_bricks
setblock 240 81 -13 minecraft:polished_blackstone_bricks
setblock 272 81 -13 minecraft:polished_blackstone_bricks
setblock 240 81 -12 minecraft:polished_blackstone_bricks
setblock 272 81 -12 minecraft:polished_blackstone_bricks
setblock 250 81 -12 minecraft:sea_lantern
setblock 256 81 -12 minecraft:sea_lantern
setblock 262 81 -12 minecraft:sea_lantern
setblock 241 81 -12 minecraft:waxed_exposed_cut_copper
fill 243 81 -12 245 81 -12 minecraft:waxed_exposed_cut_copper
fill 267 81 -12 269 81 -12 minecraft:waxed_exposed_cut_copper
setblock 271 81 -12 minecraft:waxed_exposed_cut_copper
setblock 240 81 -11 minecraft:polished_blackstone_bricks
setblock 272 81 -11 minecraft:polished_blackstone_bricks
setblock 240 81 -10 minecraft:polished_blackstone_bricks
setblock 272 81 -10 minecraft:polished_blackstone_bricks
setblock 240 81 -9 minecraft:polished_blackstone_bricks
setblock 272 81 -9 minecraft:polished_blackstone_bricks
setblock 240 81 -8 minecraft:polished_blackstone_bricks
setblock 272 81 -8 minecraft:polished_blackstone_bricks
setblock 240 81 -7 minecraft:polished_blackstone_bricks
setblock 272 81 -7 minecraft:polished_blackstone_bricks
setblock 240 81 -6 minecraft:polished_blackstone_bricks
setblock 272 81 -6 minecraft:polished_blackstone_bricks
setblock 241 81 -6 minecraft:waxed_exposed_cut_copper
setblock 271 81 -6 minecraft:waxed_exposed_cut_copper
setblock 240 81 -5 minecraft:polished_blackstone_bricks
setblock 272 81 -5 minecraft:polished_blackstone_bricks
setblock 240 81 -4 minecraft:polished_blackstone_bricks
setblock 272 81 -4 minecraft:polished_blackstone_bricks
setblock 240 81 -3 minecraft:polished_blackstone_bricks
setblock 272 81 -3 minecraft:polished_blackstone_bricks
setblock 240 81 -2 minecraft:polished_blackstone_bricks
setblock 272 81 -2 minecraft:polished_blackstone_bricks
setblock 240 81 -1 minecraft:polished_blackstone_bricks
setblock 272 81 -1 minecraft:polished_blackstone_bricks
setblock 240 81 0 minecraft:polished_blackstone_bricks
setblock 272 81 0 minecraft:polished_blackstone_bricks
setblock 250 81 0 minecraft:sea_lantern
setblock 256 81 0 minecraft:sea_lantern
setblock 262 81 0 minecraft:sea_lantern
setblock 241 81 0 minecraft:waxed_exposed_cut_copper
fill 243 81 0 245 81 0 minecraft:waxed_exposed_cut_copper
fill 267 81 0 269 81 0 minecraft:waxed_exposed_cut_copper
setblock 271 81 0 minecraft:waxed_exposed_cut_copper
setblock 240 81 1 minecraft:polished_blackstone_bricks
setblock 272 81 1 minecraft:polished_blackstone_bricks
setblock 240 81 2 minecraft:polished_blackstone_bricks
setblock 272 81 2 minecraft:polished_blackstone_bricks
setblock 240 81 3 minecraft:polished_blackstone_bricks
setblock 272 81 3 minecraft:polished_blackstone_bricks
setblock 240 81 4 minecraft:polished_blackstone_bricks
setblock 272 81 4 minecraft:polished_blackstone_bricks
setblock 240 81 5 minecraft:polished_blackstone_bricks
setblock 272 81 5 minecraft:polished_blackstone_bricks
setblock 240 81 6 minecraft:polished_blackstone_bricks
setblock 272 81 6 minecraft:polished_blackstone_bricks
setblock 241 81 6 minecraft:waxed_exposed_cut_copper
setblock 271 81 6 minecraft:waxed_exposed_cut_copper
setblock 240 81 7 minecraft:polished_blackstone_bricks
setblock 272 81 7 minecraft:polished_blackstone_bricks
setblock 240 81 8 minecraft:polished_blackstone_bricks
setblock 272 81 8 minecraft:polished_blackstone_bricks
setblock 240 81 9 minecraft:polished_blackstone_bricks
setblock 272 81 9 minecraft:polished_blackstone_bricks
setblock 240 81 10 minecraft:polished_blackstone_bricks
setblock 272 81 10 minecraft:polished_blackstone_bricks
setblock 240 81 11 minecraft:polished_blackstone_bricks
setblock 272 81 11 minecraft:polished_blackstone_bricks
setblock 240 81 12 minecraft:polished_blackstone_bricks
setblock 272 81 12 minecraft:polished_blackstone_bricks
setblock 250 81 12 minecraft:sea_lantern
setblock 256 81 12 minecraft:sea_lantern
setblock 262 81 12 minecraft:sea_lantern
setblock 241 81 12 minecraft:waxed_exposed_cut_copper
fill 243 81 12 245 81 12 minecraft:waxed_exposed_cut_copper
fill 267 81 12 269 81 12 minecraft:waxed_exposed_cut_copper
setblock 271 81 12 minecraft:waxed_exposed_cut_copper
setblock 240 81 13 minecraft:polished_blackstone_bricks
setblock 272 81 13 minecraft:polished_blackstone_bricks
setblock 240 81 14 minecraft:polished_blackstone_bricks
setblock 272 81 14 minecraft:polished_blackstone_bricks
setblock 240 81 15 minecraft:polished_blackstone_bricks
setblock 272 81 15 minecraft:polished_blackstone_bricks
setblock 244 81 15 minecraft:waxed_exposed_cut_copper
setblock 250 81 15 minecraft:waxed_exposed_cut_copper
setblock 256 81 15 minecraft:waxed_exposed_cut_copper
setblock 262 81 15 minecraft:waxed_exposed_cut_copper
setblock 268 81 15 minecraft:waxed_exposed_cut_copper
fill 240 81 16 272 81 16 minecraft:polished_blackstone_bricks
fill 240 82 -16 272 82 -16 minecraft:polished_blackstone_bricks
setblock 240 82 -15 minecraft:polished_blackstone_bricks
setblock 272 82 -15 minecraft:polished_blackstone_bricks
setblock 244 82 -15 minecraft:waxed_exposed_cut_copper
setblock 250 82 -15 minecraft:waxed_exposed_cut_copper
setblock 256 82 -15 minecraft:waxed_exposed_cut_copper
setblock 262 82 -15 minecraft:waxed_exposed_cut_copper
setblock 268 82 -15 minecraft:waxed_exposed_cut_copper
setblock 240 82 -14 minecraft:polished_blackstone_bricks
setblock 272 82 -14 minecraft:polished_blackstone_bricks
setblock 240 82 -13 minecraft:polished_blackstone_bricks
setblock 272 82 -13 minecraft:polished_blackstone_bricks
setblock 240 82 -12 minecraft:polished_blackstone_bricks
setblock 272 82 -12 minecraft:polished_blackstone_bricks
setblock 241 82 -12 minecraft:waxed_exposed_cut_copper
fill 246 82 -12 266 82 -12 minecraft:waxed_exposed_cut_copper
setblock 271 82 -12 minecraft:waxed_exposed_cut_copper
setblock 240 82 -11 minecraft:polished_blackstone_bricks
setblock 272 82 -11 minecraft:polished_blackstone_bricks
setblock 240 82 -10 minecraft:polished_blackstone_bricks
setblock 272 82 -10 minecraft:polished_blackstone_bricks
setblock 240 82 -9 minecraft:polished_blackstone_bricks
setblock 272 82 -9 minecraft:polished_blackstone_bricks
setblock 240 82 -8 minecraft:polished_blackstone_bricks
setblock 272 82 -8 minecraft:polished_blackstone_bricks
setblock 240 82 -7 minecraft:polished_blackstone_bricks
setblock 272 82 -7 minecraft:polished_blackstone_bricks
setblock 240 82 -6 minecraft:polished_blackstone_bricks
setblock 272 82 -6 minecraft:polished_blackstone_bricks
setblock 241 82 -6 minecraft:waxed_exposed_cut_copper
setblock 271 82 -6 minecraft:waxed_exposed_cut_copper
setblock 240 82 -5 minecraft:polished_blackstone_bricks
setblock 272 82 -5 minecraft:polished_blackstone_bricks
setblock 240 82 -4 minecraft:polished_blackstone_bricks
setblock 272 82 -4 minecraft:polished_blackstone_bricks
setblock 240 82 -3 minecraft:polished_blackstone_bricks
setblock 272 82 -3 minecraft:polished_blackstone_bricks
setblock 240 82 -2 minecraft:polished_blackstone_bricks
setblock 272 82 -2 minecraft:polished_blackstone_bricks
setblock 240 82 -1 minecraft:polished_blackstone_bricks
setblock 272 82 -1 minecraft:polished_blackstone_bricks
setblock 240 82 0 minecraft:polished_blackstone_bricks
setblock 272 82 0 minecraft:polished_blackstone_bricks
setblock 241 82 0 minecraft:waxed_exposed_cut_copper
fill 246 82 0 266 82 0 minecraft:waxed_exposed_cut_copper
setblock 271 82 0 minecraft:waxed_exposed_cut_copper
setblock 240 82 1 minecraft:polished_blackstone_bricks
setblock 272 82 1 minecraft:polished_blackstone_bricks
setblock 240 82 2 minecraft:polished_blackstone_bricks
setblock 272 82 2 minecraft:polished_blackstone_bricks
setblock 240 82 3 minecraft:polished_blackstone_bricks
setblock 272 82 3 minecraft:polished_blackstone_bricks
setblock 240 82 4 minecraft:polished_blackstone_bricks
setblock 272 82 4 minecraft:polished_blackstone_bricks
setblock 240 82 5 minecraft:polished_blackstone_bricks
setblock 272 82 5 minecraft:polished_blackstone_bricks
setblock 240 82 6 minecraft:polished_blackstone_bricks
setblock 272 82 6 minecraft:polished_blackstone_bricks
setblock 241 82 6 minecraft:waxed_exposed_cut_copper
setblock 271 82 6 minecraft:waxed_exposed_cut_copper
setblock 240 82 7 minecraft:polished_blackstone_bricks
setblock 272 82 7 minecraft:polished_blackstone_bricks
setblock 240 82 8 minecraft:polished_blackstone_bricks
setblock 272 82 8 minecraft:polished_blackstone_bricks
setblock 240 82 9 minecraft:polished_blackstone_bricks
setblock 272 82 9 minecraft:polished_blackstone_bricks
setblock 240 82 10 minecraft:polished_blackstone_bricks
setblock 272 82 10 minecraft:polished_blackstone_bricks
setblock 240 82 11 minecraft:polished_blackstone_bricks
setblock 272 82 11 minecraft:polished_blackstone_bricks
setblock 240 82 12 minecraft:polished_blackstone_bricks
setblock 272 82 12 minecraft:polished_blackstone_bricks
setblock 241 82 12 minecraft:waxed_exposed_cut_copper
fill 246 82 12 266 82 12 minecraft:waxed_exposed_cut_copper
setblock 271 82 12 minecraft:waxed_exposed_cut_copper
setblock 240 82 13 minecraft:polished_blackstone_bricks
setblock 272 82 13 minecraft:polished_blackstone_bricks
setblock 240 82 14 minecraft:polished_blackstone_bricks
setblock 272 82 14 minecraft:polished_blackstone_bricks
setblock 240 82 15 minecraft:polished_blackstone_bricks
setblock 272 82 15 minecraft:polished_blackstone_bricks
setblock 244 82 15 minecraft:waxed_exposed_cut_copper
setblock 250 82 15 minecraft:waxed_exposed_cut_copper
setblock 256 82 15 minecraft:waxed_exposed_cut_copper
setblock 262 82 15 minecraft:waxed_exposed_cut_copper
setblock 268 82 15 minecraft:waxed_exposed_cut_copper
fill 240 82 16 272 82 16 minecraft:polished_blackstone_bricks
fill 240 83 -16 272 83 -16 minecraft:polished_blackstone_bricks
setblock 240 83 -15 minecraft:polished_blackstone_bricks
setblock 272 83 -15 minecraft:polished_blackstone_bricks
fill 241 83 -15 271 83 -15 minecraft:waxed_exposed_cut_copper
setblock 240 83 -14 minecraft:polished_blackstone_bricks
setblock 272 83 -14 minecraft:polished_blackstone_bricks
setblock 241 83 -14 minecraft:waxed_exposed_cut_copper
setblock 271 83 -14 minecraft:waxed_exposed_cut_copper
setblock 240 83 -13 minecraft:polished_blackstone_bricks
setblock 272 83 -13 minecraft:polished_blackstone_bricks
setblock 241 83 -13 minecraft:waxed_exposed_cut_copper
setblock 271 83 -13 minecraft:waxed_exposed_cut_copper
setblock 240 83 -12 minecraft:polished_blackstone_bricks
setblock 272 83 -12 minecraft:polished_blackstone_bricks
setblock 241 83 -12 minecraft:waxed_exposed_cut_copper
setblock 271 83 -12 minecraft:waxed_exposed_cut_copper
setblock 240 83 -11 minecraft:polished_blackstone_bricks
setblock 272 83 -11 minecraft:polished_blackstone_bricks
setblock 241 83 -11 minecraft:waxed_exposed_cut_copper
setblock 271 83 -11 minecraft:waxed_exposed_cut_copper
setblock 240 83 -10 minecraft:polished_blackstone_bricks
setblock 272 83 -10 minecraft:polished_blackstone_bricks
setblock 241 83 -10 minecraft:waxed_exposed_cut_copper
setblock 271 83 -10 minecraft:waxed_exposed_cut_copper
setblock 246 83 -9 minecraft:light_blue_stained_glass
setblock 263 83 -9 minecraft:light_blue_stained_glass
setblock 240 83 -9 minecraft:polished_blackstone_bricks
setblock 272 83 -9 minecraft:polished_blackstone_bricks
setblock 241 83 -9 minecraft:waxed_exposed_cut_copper
setblock 271 83 -9 minecraft:waxed_exposed_cut_copper
setblock 253 83 -8 minecraft:light_blue_stained_glass
setblock 240 83 -8 minecraft:polished_blackstone_bricks
setblock 272 83 -8 minecraft:polished_blackstone_bricks
setblock 241 83 -8 minecraft:waxed_exposed_cut_copper
setblock 271 83 -8 minecraft:waxed_exposed_cut_copper
setblock 240 83 -7 minecraft:polished_blackstone_bricks
setblock 272 83 -7 minecraft:polished_blackstone_bricks
setblock 241 83 -7 minecraft:waxed_exposed_cut_copper
setblock 271 83 -7 minecraft:waxed_exposed_cut_copper
setblock 240 83 -6 minecraft:polished_blackstone_bricks
setblock 272 83 -6 minecraft:polished_blackstone_bricks
setblock 241 83 -6 minecraft:waxed_exposed_cut_copper
setblock 271 83 -6 minecraft:waxed_exposed_cut_copper
setblock 240 83 -5 minecraft:polished_blackstone_bricks
setblock 272 83 -5 minecraft:polished_blackstone_bricks
setblock 241 83 -5 minecraft:waxed_exposed_cut_copper
setblock 271 83 -5 minecraft:waxed_exposed_cut_copper
setblock 266 83 -4 minecraft:light_blue_stained_glass
setblock 240 83 -4 minecraft:polished_blackstone_bricks
setblock 272 83 -4 minecraft:polished_blackstone_bricks
setblock 241 83 -4 minecraft:waxed_exposed_cut_copper
setblock 271 83 -4 minecraft:waxed_exposed_cut_copper
setblock 240 83 -3 minecraft:polished_blackstone_bricks
setblock 272 83 -3 minecraft:polished_blackstone_bricks
setblock 241 83 -3 minecraft:waxed_exposed_cut_copper
setblock 271 83 -3 minecraft:waxed_exposed_cut_copper
setblock 240 83 -2 minecraft:polished_blackstone_bricks
setblock 272 83 -2 minecraft:polished_blackstone_bricks
setblock 241 83 -2 minecraft:waxed_exposed_cut_copper
setblock 271 83 -2 minecraft:waxed_exposed_cut_copper
setblock 240 83 -1 minecraft:polished_blackstone_bricks
setblock 272 83 -1 minecraft:polished_blackstone_bricks
setblock 241 83 -1 minecraft:waxed_exposed_cut_copper
setblock 271 83 -1 minecraft:waxed_exposed_cut_copper
setblock 240 83 0 minecraft:polished_blackstone_bricks
setblock 272 83 0 minecraft:polished_blackstone_bricks
setblock 241 83 0 minecraft:waxed_exposed_cut_copper
setblock 271 83 0 minecraft:waxed_exposed_cut_copper
setblock 240 83 1 minecraft:polished_blackstone_bricks
setblock 272 83 1 minecraft:polished_blackstone_bricks
setblock 241 83 1 minecraft:waxed_exposed_cut_copper
setblock 271 83 1 minecraft:waxed_exposed_cut_copper
setblock 240 83 2 minecraft:polished_blackstone_bricks
setblock 272 83 2 minecraft:polished_blackstone_bricks
setblock 241 83 2 minecraft:waxed_exposed_cut_copper
setblock 271 83 2 minecraft:waxed_exposed_cut_copper
setblock 240 83 3 minecraft:polished_blackstone_bricks
setblock 272 83 3 minecraft:polished_blackstone_bricks
setblock 241 83 3 minecraft:waxed_exposed_cut_copper
setblock 271 83 3 minecraft:waxed_exposed_cut_copper
setblock 259 83 4 minecraft:light_blue_stained_glass
setblock 240 83 4 minecraft:polished_blackstone_bricks
setblock 272 83 4 minecraft:polished_blackstone_bricks
setblock 241 83 4 minecraft:waxed_exposed_cut_copper
setblock 271 83 4 minecraft:waxed_exposed_cut_copper
setblock 245 83 5 minecraft:light_blue_stained_glass
setblock 240 83 5 minecraft:polished_blackstone_bricks
setblock 272 83 5 minecraft:polished_blackstone_bricks
setblock 241 83 5 minecraft:waxed_exposed_cut_copper
setblock 271 83 5 minecraft:waxed_exposed_cut_copper
setblock 240 83 6 minecraft:polished_blackstone_bricks
setblock 272 83 6 minecraft:polished_blackstone_bricks
setblock 241 83 6 minecraft:waxed_exposed_cut_copper
setblock 271 83 6 minecraft:waxed_exposed_cut_copper
setblock 251 83 7 minecraft:light_blue_stained_glass
setblock 240 83 7 minecraft:polished_blackstone_bricks
setblock 272 83 7 minecraft:polished_blackstone_bricks
setblock 241 83 7 minecraft:waxed_exposed_cut_copper
setblock 271 83 7 minecraft:waxed_exposed_cut_copper
setblock 240 83 8 minecraft:polished_blackstone_bricks
setblock 272 83 8 minecraft:polished_blackstone_bricks
setblock 241 83 8 minecraft:waxed_exposed_cut_copper
setblock 271 83 8 minecraft:waxed_exposed_cut_copper
setblock 240 83 9 minecraft:polished_blackstone_bricks
setblock 272 83 9 minecraft:polished_blackstone_bricks
setblock 241 83 9 minecraft:waxed_exposed_cut_copper
setblock 271 83 9 minecraft:waxed_exposed_cut_copper
setblock 265 83 10 minecraft:light_blue_stained_glass
setblock 240 83 10 minecraft:polished_blackstone_bricks
setblock 272 83 10 minecraft:polished_blackstone_bricks
setblock 241 83 10 minecraft:waxed_exposed_cut_copper
setblock 271 83 10 minecraft:waxed_exposed_cut_copper
setblock 240 83 11 minecraft:polished_blackstone_bricks
setblock 272 83 11 minecraft:polished_blackstone_bricks
setblock 241 83 11 minecraft:waxed_exposed_cut_copper
setblock 271 83 11 minecraft:waxed_exposed_cut_copper
setblock 240 83 12 minecraft:polished_blackstone_bricks
setblock 272 83 12 minecraft:polished_blackstone_bricks
setblock 241 83 12 minecraft:waxed_exposed_cut_copper
setblock 271 83 12 minecraft:waxed_exposed_cut_copper
setblock 240 83 13 minecraft:polished_blackstone_bricks
setblock 272 83 13 minecraft:polished_blackstone_bricks
setblock 241 83 13 minecraft:waxed_exposed_cut_copper
setblock 271 83 13 minecraft:waxed_exposed_cut_copper
setblock 240 83 14 minecraft:polished_blackstone_bricks
setblock 272 83 14 minecraft:polished_blackstone_bricks
setblock 241 83 14 minecraft:waxed_exposed_cut_copper
setblock 271 83 14 minecraft:waxed_exposed_cut_copper
setblock 240 83 15 minecraft:polished_blackstone_bricks
setblock 272 83 15 minecraft:polished_blackstone_bricks
fill 241 83 15 271 83 15 minecraft:waxed_exposed_cut_copper
fill 240 83 16 272 83 16 minecraft:polished_blackstone_bricks
fill 240 84 -16 272 84 -16 minecraft:black_concrete
fill 240 84 -15 272 84 -15 minecraft:black_concrete
fill 240 84 -14 272 84 -14 minecraft:black_concrete
fill 240 84 -13 272 84 -13 minecraft:black_concrete
fill 240 84 -12 272 84 -12 minecraft:black_concrete
fill 240 84 -11 272 84 -11 minecraft:black_concrete
fill 240 84 -10 272 84 -10 minecraft:black_concrete
fill 240 84 -9 245 84 -9 minecraft:black_concrete
fill 247 84 -9 262 84 -9 minecraft:black_concrete
fill 264 84 -9 272 84 -9 minecraft:black_concrete
setblock 246 84 -9 minecraft:sea_lantern
setblock 263 84 -9 minecraft:sea_lantern
fill 240 84 -8 252 84 -8 minecraft:black_concrete
fill 254 84 -8 272 84 -8 minecraft:black_concrete
setblock 253 84 -8 minecraft:sea_lantern
fill 240 84 -7 272 84 -7 minecraft:black_concrete
fill 240 84 -6 272 84 -6 minecraft:black_concrete
fill 240 84 -5 272 84 -5 minecraft:black_concrete
fill 240 84 -4 265 84 -4 minecraft:black_concrete
fill 267 84 -4 272 84 -4 minecraft:black_concrete
setblock 266 84 -4 minecraft:sea_lantern
fill 240 84 -3 272 84 -3 minecraft:black_concrete
fill 240 84 -2 272 84 -2 minecraft:black_concrete
fill 240 84 -1 272 84 -1 minecraft:black_concrete
fill 240 84 0 272 84 0 minecraft:black_concrete
fill 240 84 1 272 84 1 minecraft:black_concrete
fill 240 84 2 272 84 2 minecraft:black_concrete
fill 240 84 3 272 84 3 minecraft:black_concrete
fill 240 84 4 258 84 4 minecraft:black_concrete
fill 260 84 4 272 84 4 minecraft:black_concrete
setblock 259 84 4 minecraft:sea_lantern
fill 240 84 5 244 84 5 minecraft:black_concrete
fill 246 84 5 272 84 5 minecraft:black_concrete
setblock 245 84 5 minecraft:sea_lantern
fill 240 84 6 272 84 6 minecraft:black_concrete
fill 240 84 7 250 84 7 minecraft:black_concrete
fill 252 84 7 272 84 7 minecraft:black_concrete
setblock 251 84 7 minecraft:sea_lantern
fill 240 84 8 272 84 8 minecraft:black_concrete
fill 240 84 9 272 84 9 minecraft:black_concrete
fill 240 84 10 264 84 10 minecraft:black_concrete
fill 266 84 10 272 84 10 minecraft:black_concrete
setblock 265 84 10 minecraft:sea_lantern
fill 240 84 11 272 84 11 minecraft:black_concrete
fill 240 84 12 272 84 12 minecraft:black_concrete
fill 240 84 13 272 84 13 minecraft:black_concrete
fill 240 84 14 272 84 14 minecraft:black_concrete
fill 240 84 15 272 84 15 minecraft:black_concrete
fill 240 84 16 272 84 16 minecraft:black_concrete
schedule function signal:world/build_5 1t replace
