fill 176 55 -16 208 84 16 minecraft:air
fill 176 61 -16 208 61 -16 minecraft:bedrock
fill 176 61 -15 208 61 -15 minecraft:bedrock
fill 176 61 -14 208 61 -14 minecraft:bedrock
fill 176 61 -13 208 61 -13 minecraft:bedrock
fill 176 61 -12 208 61 -12 minecraft:bedrock
fill 176 61 -11 208 61 -11 minecraft:bedrock
fill 176 61 -10 208 61 -10 minecraft:bedrock
fill 176 61 -9 208 61 -9 minecraft:bedrock
fill 176 61 -8 208 61 -8 minecraft:bedrock
fill 176 61 -7 208 61 -7 minecraft:bedrock
fill 176 61 -6 208 61 -6 minecraft:bedrock
fill 176 61 -5 208 61 -5 minecraft:bedrock
fill 176 61 -4 208 61 -4 minecraft:bedrock
fill 176 61 -3 208 61 -3 minecraft:bedrock
fill 176 61 -2 208 61 -2 minecraft:bedrock
fill 176 61 -1 208 61 -1 minecraft:bedrock
fill 176 61 0 208 61 0 minecraft:bedrock
fill 176 61 1 208 61 1 minecraft:bedrock
fill 176 61 2 208 61 2 minecraft:bedrock
fill 176 61 3 208 61 3 minecraft:bedrock
fill 176 61 4 208 61 4 minecraft:bedrock
fill 176 61 5 208 61 5 minecraft:bedrock
fill 176 61 6 208 61 6 minecraft:bedrock
fill 176 61 7 208 61 7 minecraft:bedrock
fill 176 61 8 208 61 8 minecraft:bedrock
fill 176 61 9 208 61 9 minecraft:bedrock
fill 176 61 10 208 61 10 minecraft:bedrock
fill 176 61 11 208 61 11 minecraft:bedrock
fill 176 61 12 208 61 12 minecraft:bedrock
fill 176 61 13 208 61 13 minecraft:bedrock
fill 176 61 14 208 61 14 minecraft:bedrock
fill 176 61 15 208 61 15 minecraft:bedrock
fill 176 61 16 208 61 16 minecraft:bedrock
fill 176 62 -16 208 62 -16 minecraft:bedrock
fill 176 62 -15 208 62 -15 minecraft:bedrock
fill 176 62 -14 208 62 -14 minecraft:bedrock
fill 176 62 -13 208 62 -13 minecraft:bedrock
fill 176 62 -12 208 62 -12 minecraft:bedrock
fill 176 62 -11 208 62 -11 minecraft:bedrock
fill 176 62 -10 208 62 -10 minecraft:bedrock
fill 176 62 -9 208 62 -9 minecraft:bedrock
fill 176 62 -8 208 62 -8 minecraft:bedrock
fill 176 62 -7 208 62 -7 minecraft:bedrock
fill 176 62 -6 208 62 -6 minecraft:bedrock
fill 176 62 -5 208 62 -5 minecraft:bedrock
fill 176 62 -4 208 62 -4 minecraft:bedrock
fill 176 62 -3 208 62 -3 minecraft:bedrock
fill 176 62 -2 208 62 -2 minecraft:bedrock
fill 176 62 -1 208 62 -1 minecraft:bedrock
fill 176 62 0 208 62 0 minecraft:bedrock
fill 176 62 1 208 62 1 minecraft:bedrock
fill 176 62 2 208 62 2 minecraft:bedrock
fill 176 62 3 208 62 3 minecraft:bedrock
fill 176 62 4 208 62 4 minecraft:bedrock
fill 176 62 5 208 62 5 minecraft:bedrock
fill 176 62 6 208 62 6 minecraft:bedrock
fill 176 62 7 208 62 7 minecraft:bedrock
fill 176 62 8 208 62 8 minecraft:bedrock
fill 176 62 9 208 62 9 minecraft:bedrock
fill 176 62 10 208 62 10 minecraft:bedrock
fill 176 62 11 208 62 11 minecraft:bedrock
fill 176 62 12 208 62 12 minecraft:bedrock
fill 176 62 13 208 62 13 minecraft:bedrock
fill 176 62 14 208 62 14 minecraft:bedrock
fill 176 62 15 208 62 15 minecraft:bedrock
fill 176 62 16 208 62 16 minecraft:bedrock
fill 176 63 -16 208 63 -16 minecraft:deepslate_tiles
setblock 176 63 -15 minecraft:deepslate_tiles
setblock 208 63 -15 minecraft:deepslate_tiles
fill 177 63 -15 207 63 -15 minecraft:waxed_cut_copper
setblock 176 63 -14 minecraft:deepslate_tiles
setblock 208 63 -14 minecraft:deepslate_tiles
fill 178 63 -14 206 63 -14 minecraft:polished_blackstone
setblock 177 63 -14 minecraft:waxed_cut_copper
setblock 207 63 -14 minecraft:waxed_cut_copper
setblock 176 63 -13 minecraft:deepslate_tiles
setblock 179 63 -13 minecraft:deepslate_tiles
setblock 181 63 -13 minecraft:deepslate_tiles
setblock 183 63 -13 minecraft:deepslate_tiles
setblock 185 63 -13 minecraft:deepslate_tiles
setblock 187 63 -13 minecraft:deepslate_tiles
setblock 189 63 -13 minecraft:deepslate_tiles
setblock 191 63 -13 minecraft:deepslate_tiles
setblock 193 63 -13 minecraft:deepslate_tiles
setblock 195 63 -13 minecraft:deepslate_tiles
setblock 197 63 -13 minecraft:deepslate_tiles
setblock 199 63 -13 minecraft:deepslate_tiles
setblock 201 63 -13 minecraft:deepslate_tiles
setblock 203 63 -13 minecraft:deepslate_tiles
setblock 205 63 -13 minecraft:deepslate_tiles
setblock 208 63 -13 minecraft:deepslate_tiles
setblock 178 63 -13 minecraft:polished_blackstone
setblock 206 63 -13 minecraft:polished_blackstone
setblock 180 63 -13 minecraft:polished_deepslate
setblock 182 63 -13 minecraft:polished_deepslate
setblock 184 63 -13 minecraft:polished_deepslate
setblock 186 63 -13 minecraft:polished_deepslate
setblock 188 63 -13 minecraft:polished_deepslate
setblock 190 63 -13 minecraft:polished_deepslate
setblock 192 63 -13 minecraft:polished_deepslate
setblock 194 63 -13 minecraft:polished_deepslate
setblock 196 63 -13 minecraft:polished_deepslate
setblock 198 63 -13 minecraft:polished_deepslate
setblock 200 63 -13 minecraft:polished_deepslate
setblock 202 63 -13 minecraft:polished_deepslate
setblock 204 63 -13 minecraft:polished_deepslate
setblock 177 63 -13 minecraft:waxed_cut_copper
setblock 207 63 -13 minecraft:waxed_cut_copper
setblock 176 63 -12 minecraft:deepslate_tiles
setblock 180 63 -12 minecraft:deepslate_tiles
setblock 182 63 -12 minecraft:deepslate_tiles
setblock 184 63 -12 minecraft:deepslate_tiles
setblock 186 63 -12 minecraft:deepslate_tiles
setblock 188 63 -12 minecraft:deepslate_tiles
setblock 190 63 -12 minecraft:deepslate_tiles
setblock 192 63 -12 minecraft:deepslate_tiles
setblock 194 63 -12 minecraft:deepslate_tiles
setblock 196 63 -12 minecraft:deepslate_tiles
setblock 198 63 -12 minecraft:deepslate_tiles
setblock 200 63 -12 minecraft:deepslate_tiles
setblock 202 63 -12 minecraft:deepslate_tiles
setblock 204 63 -12 minecraft:deepslate_tiles
setblock 208 63 -12 minecraft:deepslate_tiles
setblock 178 63 -12 minecraft:polished_blackstone
setblock 206 63 -12 minecraft:polished_blackstone
setblock 179 63 -12 minecraft:polished_deepslate
setblock 183 63 -12 minecraft:polished_deepslate
setblock 185 63 -12 minecraft:polished_deepslate
setblock 187 63 -12 minecraft:polished_deepslate
setblock 189 63 -12 minecraft:polished_deepslate
setblock 191 63 -12 minecraft:polished_deepslate
setblock 193 63 -12 minecraft:polished_deepslate
setblock 195 63 -12 minecraft:polished_deepslate
setblock 197 63 -12 minecraft:polished_deepslate
setblock 199 63 -12 minecraft:polished_deepslate
setblock 201 63 -12 minecraft:polished_deepslate
setblock 205 63 -12 minecraft:polished_deepslate
setblock 177 63 -12 minecraft:waxed_cut_copper
setblock 181 63 -12 minecraft:waxed_cut_copper
setblock 203 63 -12 minecraft:waxed_cut_copper
setblock 207 63 -12 minecraft:waxed_cut_copper
setblock 176 63 -11 minecraft:deepslate_tiles
setblock 179 63 -11 minecraft:deepslate_tiles
setblock 183 63 -11 minecraft:deepslate_tiles
setblock 185 63 -11 minecraft:deepslate_tiles
setblock 187 63 -11 minecraft:deepslate_tiles
setblock 189 63 -11 minecraft:deepslate_tiles
setblock 191 63 -11 minecraft:deepslate_tiles
setblock 193 63 -11 minecraft:deepslate_tiles
setblock 195 63 -11 minecraft:deepslate_tiles
setblock 197 63 -11 minecraft:deepslate_tiles
setblock 199 63 -11 minecraft:deepslate_tiles
setblock 201 63 -11 minecraft:deepslate_tiles
setblock 205 63 -11 minecraft:deepslate_tiles
setblock 208 63 -11 minecraft:deepslate_tiles
setblock 178 63 -11 minecraft:polished_blackstone
setblock 206 63 -11 minecraft:polished_blackstone
setblock 184 63 -11 minecraft:polished_deepslate
setblock 186 63 -11 minecraft:polished_deepslate
setblock 188 63 -11 minecraft:polished_deepslate
setblock 190 63 -11 minecraft:polished_deepslate
setblock 192 63 -11 minecraft:polished_deepslate
setblock 194 63 -11 minecraft:polished_deepslate
setblock 196 63 -11 minecraft:polished_deepslate
setblock 198 63 -11 minecraft:polished_deepslate
setblock 200 63 -11 minecraft:polished_deepslate
setblock 181 63 -11 minecraft:sea_lantern
setblock 203 63 -11 minecraft:sea_lantern
setblock 177 63 -11 minecraft:waxed_cut_copper
setblock 180 63 -11 minecraft:waxed_cut_copper
setblock 182 63 -11 minecraft:waxed_cut_copper
setblock 202 63 -11 minecraft:waxed_cut_copper
setblock 204 63 -11 minecraft:waxed_cut_copper
setblock 207 63 -11 minecraft:waxed_cut_copper
setblock 182 63 -10 minecraft:chiseled_deepslate
setblock 187 63 -10 minecraft:chiseled_deepslate
setblock 192 63 -10 minecraft:chiseled_deepslate
setblock 197 63 -10 minecraft:chiseled_deepslate
setblock 202 63 -10 minecraft:chiseled_deepslate
setblock 176 63 -10 minecraft:deepslate_tiles
setblock 180 63 -10 minecraft:deepslate_tiles
setblock 184 63 -10 minecraft:deepslate_tiles
setblock 186 63 -10 minecraft:deepslate_tiles
setblock 188 63 -10 minecraft:deepslate_tiles
setblock 190 63 -10 minecraft:deepslate_tiles
setblock 194 63 -10 minecraft:deepslate_tiles
setblock 196 63 -10 minecraft:deepslate_tiles
setblock 198 63 -10 minecraft:deepslate_tiles
setblock 200 63 -10 minecraft:deepslate_tiles
setblock 204 63 -10 minecraft:deepslate_tiles
setblock 208 63 -10 minecraft:deepslate_tiles
setblock 178 63 -10 minecraft:polished_blackstone
setblock 206 63 -10 minecraft:polished_blackstone
setblock 179 63 -10 minecraft:polished_deepslate
setblock 183 63 -10 minecraft:polished_deepslate
setblock 185 63 -10 minecraft:polished_deepslate
setblock 189 63 -10 minecraft:polished_deepslate
setblock 191 63 -10 minecraft:polished_deepslate
setblock 193 63 -10 minecraft:polished_deepslate
setblock 195 63 -10 minecraft:polished_deepslate
setblock 199 63 -10 minecraft:polished_deepslate
setblock 201 63 -10 minecraft:polished_deepslate
setblock 205 63 -10 minecraft:polished_deepslate
setblock 177 63 -10 minecraft:waxed_cut_copper
setblock 181 63 -10 minecraft:waxed_cut_copper
setblock 203 63 -10 minecraft:waxed_cut_copper
setblock 207 63 -10 minecraft:waxed_cut_copper
setblock 176 63 -9 minecraft:deepslate_tiles
setblock 179 63 -9 minecraft:deepslate_tiles
setblock 181 63 -9 minecraft:deepslate_tiles
setblock 183 63 -9 minecraft:deepslate_tiles
setblock 185 63 -9 minecraft:deepslate_tiles
setblock 187 63 -9 minecraft:deepslate_tiles
setblock 189 63 -9 minecraft:deepslate_tiles
setblock 191 63 -9 minecraft:deepslate_tiles
setblock 193 63 -9 minecraft:deepslate_tiles
setblock 195 63 -9 minecraft:deepslate_tiles
setblock 197 63 -9 minecraft:deepslate_tiles
setblock 199 63 -9 minecraft:deepslate_tiles
setblock 201 63 -9 minecraft:deepslate_tiles
setblock 203 63 -9 minecraft:deepslate_tiles
setblock 205 63 -9 minecraft:deepslate_tiles
setblock 208 63 -9 minecraft:deepslate_tiles
setblock 178 63 -9 minecraft:polished_blackstone
setblock 206 63 -9 minecraft:polished_blackstone
setblock 180 63 -9 minecraft:polished_deepslate
setblock 182 63 -9 minecraft:polished_deepslate
setblock 186 63 -9 minecraft:polished_deepslate
setblock 188 63 -9 minecraft:polished_deepslate
setblock 190 63 -9 minecraft:polished_deepslate
setblock 194 63 -9 minecraft:polished_deepslate
setblock 196 63 -9 minecraft:polished_deepslate
setblock 198 63 -9 minecraft:polished_deepslate
setblock 202 63 -9 minecraft:polished_deepslate
setblock 204 63 -9 minecraft:polished_deepslate
setblock 177 63 -9 minecraft:waxed_cut_copper
setblock 184 63 -9 minecraft:waxed_cut_copper
setblock 192 63 -9 minecraft:waxed_cut_copper
setblock 200 63 -9 minecraft:waxed_cut_copper
setblock 207 63 -9 minecraft:waxed_cut_copper
setblock 176 63 -8 minecraft:deepslate_tiles
setblock 180 63 -8 minecraft:deepslate_tiles
setblock 182 63 -8 minecraft:deepslate_tiles
setblock 186 63 -8 minecraft:deepslate_tiles
setblock 188 63 -8 minecraft:deepslate_tiles
setblock 190 63 -8 minecraft:deepslate_tiles
setblock 194 63 -8 minecraft:deepslate_tiles
setblock 196 63 -8 minecraft:deepslate_tiles
setblock 198 63 -8 minecraft:deepslate_tiles
setblock 202 63 -8 minecraft:deepslate_tiles
setblock 204 63 -8 minecraft:deepslate_tiles
setblock 208 63 -8 minecraft:deepslate_tiles
setblock 178 63 -8 minecraft:polished_blackstone
setblock 206 63 -8 minecraft:polished_blackstone
setblock 179 63 -8 minecraft:polished_deepslate
setblock 181 63 -8 minecraft:polished_deepslate
setblock 183 63 -8 minecraft:polished_deepslate
setblock 185 63 -8 minecraft:polished_deepslate
setblock 187 63 -8 minecraft:polished_deepslate
setblock 189 63 -8 minecraft:polished_deepslate
setblock 191 63 -8 minecraft:polished_deepslate
setblock 193 63 -8 minecraft:polished_deepslate
setblock 195 63 -8 minecraft:polished_deepslate
setblock 197 63 -8 minecraft:polished_deepslate
setblock 199 63 -8 minecraft:polished_deepslate
setblock 201 63 -8 minecraft:polished_deepslate
setblock 203 63 -8 minecraft:polished_deepslate
setblock 205 63 -8 minecraft:polished_deepslate
setblock 177 63 -8 minecraft:waxed_cut_copper
setblock 184 63 -8 minecraft:waxed_cut_copper
setblock 192 63 -8 minecraft:waxed_cut_copper
setblock 200 63 -8 minecraft:waxed_cut_copper
setblock 207 63 -8 minecraft:waxed_cut_copper
setblock 176 63 -7 minecraft:deepslate_tiles
setblock 179 63 -7 minecraft:deepslate_tiles
setblock 181 63 -7 minecraft:deepslate_tiles
setblock 183 63 -7 minecraft:deepslate_tiles
setblock 185 63 -7 minecraft:deepslate_tiles
setblock 187 63 -7 minecraft:deepslate_tiles
setblock 189 63 -7 minecraft:deepslate_tiles
setblock 191 63 -7 minecraft:deepslate_tiles
setblock 193 63 -7 minecraft:deepslate_tiles
setblock 195 63 -7 minecraft:deepslate_tiles
setblock 197 63 -7 minecraft:deepslate_tiles
setblock 199 63 -7 minecraft:deepslate_tiles
setblock 201 63 -7 minecraft:deepslate_tiles
setblock 203 63 -7 minecraft:deepslate_tiles
setblock 205 63 -7 minecraft:deepslate_tiles
setblock 208 63 -7 minecraft:deepslate_tiles
setblock 178 63 -7 minecraft:polished_blackstone
setblock 206 63 -7 minecraft:polished_blackstone
setblock 180 63 -7 minecraft:polished_deepslate
setblock 182 63 -7 minecraft:polished_deepslate
setblock 186 63 -7 minecraft:polished_deepslate
setblock 188 63 -7 minecraft:polished_deepslate
setblock 190 63 -7 minecraft:polished_deepslate
setblock 194 63 -7 minecraft:polished_deepslate
setblock 196 63 -7 minecraft:polished_deepslate
setblock 198 63 -7 minecraft:polished_deepslate
setblock 202 63 -7 minecraft:polished_deepslate
setblock 204 63 -7 minecraft:polished_deepslate
setblock 177 63 -7 minecraft:waxed_cut_copper
setblock 184 63 -7 minecraft:waxed_cut_copper
setblock 192 63 -7 minecraft:waxed_cut_copper
setblock 200 63 -7 minecraft:waxed_cut_copper
setblock 207 63 -7 minecraft:waxed_cut_copper
setblock 176 63 -6 minecraft:deepslate_tiles
setblock 180 63 -6 minecraft:deepslate_tiles
setblock 182 63 -6 minecraft:deepslate_tiles
setblock 186 63 -6 minecraft:deepslate_tiles
setblock 188 63 -6 minecraft:deepslate_tiles
setblock 190 63 -6 minecraft:deepslate_tiles
setblock 194 63 -6 minecraft:deepslate_tiles
setblock 196 63 -6 minecraft:deepslate_tiles
setblock 198 63 -6 minecraft:deepslate_tiles
setblock 202 63 -6 minecraft:deepslate_tiles
setblock 204 63 -6 minecraft:deepslate_tiles
setblock 208 63 -6 minecraft:deepslate_tiles
setblock 178 63 -6 minecraft:polished_blackstone
setblock 206 63 -6 minecraft:polished_blackstone
setblock 179 63 -6 minecraft:polished_deepslate
setblock 181 63 -6 minecraft:polished_deepslate
setblock 183 63 -6 minecraft:polished_deepslate
setblock 185 63 -6 minecraft:polished_deepslate
setblock 187 63 -6 minecraft:polished_deepslate
setblock 189 63 -6 minecraft:polished_deepslate
setblock 191 63 -6 minecraft:polished_deepslate
setblock 193 63 -6 minecraft:polished_deepslate
setblock 195 63 -6 minecraft:polished_deepslate
setblock 197 63 -6 minecraft:polished_deepslate
setblock 199 63 -6 minecraft:polished_deepslate
setblock 201 63 -6 minecraft:polished_deepslate
setblock 203 63 -6 minecraft:polished_deepslate
setblock 205 63 -6 minecraft:polished_deepslate
setblock 177 63 -6 minecraft:waxed_cut_copper
setblock 184 63 -6 minecraft:waxed_cut_copper
setblock 192 63 -6 minecraft:waxed_cut_copper
setblock 200 63 -6 minecraft:waxed_cut_copper
setblock 207 63 -6 minecraft:waxed_cut_copper
setblock 182 63 -5 minecraft:chiseled_deepslate
setblock 187 63 -5 minecraft:chiseled_deepslate
setblock 197 63 -5 minecraft:chiseled_deepslate
setblock 202 63 -5 minecraft:chiseled_deepslate
setblock 176 63 -5 minecraft:deepslate_tiles
setblock 179 63 -5 minecraft:deepslate_tiles
setblock 181 63 -5 minecraft:deepslate_tiles
setblock 183 63 -5 minecraft:deepslate_tiles
setblock 185 63 -5 minecraft:deepslate_tiles
setblock 189 63 -5 minecraft:deepslate_tiles
setblock 195 63 -5 minecraft:deepslate_tiles
setblock 199 63 -5 minecraft:deepslate_tiles
setblock 201 63 -5 minecraft:deepslate_tiles
setblock 203 63 -5 minecraft:deepslate_tiles
setblock 205 63 -5 minecraft:deepslate_tiles
setblock 208 63 -5 minecraft:deepslate_tiles
setblock 178 63 -5 minecraft:polished_blackstone
setblock 206 63 -5 minecraft:polished_blackstone
setblock 180 63 -5 minecraft:polished_deepslate
setblock 186 63 -5 minecraft:polished_deepslate
setblock 188 63 -5 minecraft:polished_deepslate
setblock 190 63 -5 minecraft:polished_deepslate
setblock 194 63 -5 minecraft:polished_deepslate
setblock 196 63 -5 minecraft:polished_deepslate
setblock 198 63 -5 minecraft:polished_deepslate
setblock 204 63 -5 minecraft:polished_deepslate
setblock 177 63 -5 minecraft:waxed_cut_copper
setblock 184 63 -5 minecraft:waxed_cut_copper
fill 191 63 -5 193 63 -5 minecraft:waxed_cut_copper
setblock 200 63 -5 minecraft:waxed_cut_copper
setblock 207 63 -5 minecraft:waxed_cut_copper
setblock 176 63 -4 minecraft:deepslate_tiles
setblock 180 63 -4 minecraft:deepslate_tiles
setblock 182 63 -4 minecraft:deepslate_tiles
setblock 186 63 -4 minecraft:deepslate_tiles
setblock 188 63 -4 minecraft:deepslate_tiles
setblock 190 63 -4 minecraft:deepslate_tiles
setblock 194 63 -4 minecraft:deepslate_tiles
setblock 196 63 -4 minecraft:deepslate_tiles
setblock 198 63 -4 minecraft:deepslate_tiles
setblock 202 63 -4 minecraft:deepslate_tiles
setblock 204 63 -4 minecraft:deepslate_tiles
setblock 208 63 -4 minecraft:deepslate_tiles
setblock 178 63 -4 minecraft:polished_blackstone
setblock 206 63 -4 minecraft:polished_blackstone
setblock 179 63 -4 minecraft:polished_deepslate
setblock 181 63 -4 minecraft:polished_deepslate
setblock 183 63 -4 minecraft:polished_deepslate
setblock 185 63 -4 minecraft:polished_deepslate
setblock 187 63 -4 minecraft:polished_deepslate
setblock 189 63 -4 minecraft:polished_deepslate
setblock 191 63 -4 minecraft:polished_deepslate
setblock 193 63 -4 minecraft:polished_deepslate
setblock 195 63 -4 minecraft:polished_deepslate
setblock 197 63 -4 minecraft:polished_deepslate
setblock 199 63 -4 minecraft:polished_deepslate
setblock 201 63 -4 minecraft:polished_deepslate
setblock 203 63 -4 minecraft:polished_deepslate
setblock 205 63 -4 minecraft:polished_deepslate
setblock 177 63 -4 minecraft:waxed_cut_copper
setblock 184 63 -4 minecraft:waxed_cut_copper
setblock 192 63 -4 minecraft:waxed_cut_copper
setblock 200 63 -4 minecraft:waxed_cut_copper
setblock 207 63 -4 minecraft:waxed_cut_copper
setblock 176 63 -3 minecraft:deepslate_tiles
setblock 179 63 -3 minecraft:deepslate_tiles
setblock 181 63 -3 minecraft:deepslate_tiles
setblock 183 63 -3 minecraft:deepslate_tiles
setblock 185 63 -3 minecraft:deepslate_tiles
setblock 187 63 -3 minecraft:deepslate_tiles
setblock 189 63 -3 minecraft:deepslate_tiles
setblock 191 63 -3 minecraft:deepslate_tiles
setblock 193 63 -3 minecraft:deepslate_tiles
setblock 195 63 -3 minecraft:deepslate_tiles
setblock 197 63 -3 minecraft:deepslate_tiles
setblock 199 63 -3 minecraft:deepslate_tiles
setblock 201 63 -3 minecraft:deepslate_tiles
setblock 203 63 -3 minecraft:deepslate_tiles
setblock 205 63 -3 minecraft:deepslate_tiles
setblock 208 63 -3 minecraft:deepslate_tiles
setblock 178 63 -3 minecraft:polished_blackstone
setblock 206 63 -3 minecraft:polished_blackstone
setblock 180 63 -3 minecraft:polished_deepslate
setblock 182 63 -3 minecraft:polished_deepslate
setblock 186 63 -3 minecraft:polished_deepslate
setblock 188 63 -3 minecraft:polished_deepslate
setblock 190 63 -3 minecraft:polished_deepslate
setblock 194 63 -3 minecraft:polished_deepslate
setblock 196 63 -3 minecraft:polished_deepslate
setblock 198 63 -3 minecraft:polished_deepslate
setblock 202 63 -3 minecraft:polished_deepslate
setblock 204 63 -3 minecraft:polished_deepslate
setblock 177 63 -3 minecraft:waxed_cut_copper
setblock 184 63 -3 minecraft:waxed_cut_copper
setblock 192 63 -3 minecraft:waxed_cut_copper
setblock 200 63 -3 minecraft:waxed_cut_copper
setblock 207 63 -3 minecraft:waxed_cut_copper
fill 184 63 -2 185 63 -2 minecraft:copper_block
fill 192 63 -2 193 63 -2 minecraft:copper_block
fill 200 63 -2 201 63 -2 minecraft:copper_block
setblock 176 63 -2 minecraft:deepslate_tiles
setblock 180 63 -2 minecraft:deepslate_tiles
setblock 182 63 -2 minecraft:deepslate_tiles
setblock 186 63 -2 minecraft:deepslate_tiles
setblock 188 63 -2 minecraft:deepslate_tiles
setblock 190 63 -2 minecraft:deepslate_tiles
setblock 194 63 -2 minecraft:deepslate_tiles
setblock 196 63 -2 minecraft:deepslate_tiles
setblock 198 63 -2 minecraft:deepslate_tiles
setblock 202 63 -2 minecraft:deepslate_tiles
setblock 204 63 -2 minecraft:deepslate_tiles
setblock 208 63 -2 minecraft:deepslate_tiles
setblock 178 63 -2 minecraft:polished_blackstone
setblock 206 63 -2 minecraft:polished_blackstone
setblock 179 63 -2 minecraft:polished_deepslate
setblock 181 63 -2 minecraft:polished_deepslate
setblock 183 63 -2 minecraft:polished_deepslate
setblock 187 63 -2 minecraft:polished_deepslate
setblock 189 63 -2 minecraft:polished_deepslate
setblock 191 63 -2 minecraft:polished_deepslate
setblock 195 63 -2 minecraft:polished_deepslate
setblock 197 63 -2 minecraft:polished_deepslate
setblock 199 63 -2 minecraft:polished_deepslate
setblock 203 63 -2 minecraft:polished_deepslate
setblock 205 63 -2 minecraft:polished_deepslate
setblock 177 63 -2 minecraft:waxed_cut_copper
setblock 207 63 -2 minecraft:waxed_cut_copper
fill 184 63 -1 185 63 -1 minecraft:copper_block
fill 192 63 -1 193 63 -1 minecraft:copper_block
fill 200 63 -1 201 63 -1 minecraft:copper_block
setblock 176 63 -1 minecraft:deepslate_tiles
setblock 179 63 -1 minecraft:deepslate_tiles
setblock 181 63 -1 minecraft:deepslate_tiles
setblock 183 63 -1 minecraft:deepslate_tiles
setblock 187 63 -1 minecraft:deepslate_tiles
setblock 189 63 -1 minecraft:deepslate_tiles
setblock 191 63 -1 minecraft:deepslate_tiles
setblock 195 63 -1 minecraft:deepslate_tiles
setblock 197 63 -1 minecraft:deepslate_tiles
setblock 199 63 -1 minecraft:deepslate_tiles
setblock 203 63 -1 minecraft:deepslate_tiles
setblock 205 63 -1 minecraft:deepslate_tiles
setblock 208 63 -1 minecraft:deepslate_tiles
setblock 178 63 -1 minecraft:polished_blackstone
setblock 206 63 -1 minecraft:polished_blackstone
setblock 180 63 -1 minecraft:polished_deepslate
setblock 182 63 -1 minecraft:polished_deepslate
setblock 186 63 -1 minecraft:polished_deepslate
setblock 188 63 -1 minecraft:polished_deepslate
setblock 190 63 -1 minecraft:polished_deepslate
setblock 194 63 -1 minecraft:polished_deepslate
setblock 196 63 -1 minecraft:polished_deepslate
setblock 198 63 -1 minecraft:polished_deepslate
setblock 202 63 -1 minecraft:polished_deepslate
setblock 204 63 -1 minecraft:polished_deepslate
setblock 177 63 -1 minecraft:waxed_cut_copper
setblock 207 63 -1 minecraft:waxed_cut_copper
setblock 182 63 0 minecraft:chiseled_deepslate
setblock 187 63 0 minecraft:chiseled_deepslate
setblock 197 63 0 minecraft:chiseled_deepslate
setblock 202 63 0 minecraft:chiseled_deepslate
setblock 176 63 0 minecraft:deepslate_tiles
setblock 180 63 0 minecraft:deepslate_tiles
setblock 186 63 0 minecraft:deepslate_tiles
setblock 188 63 0 minecraft:deepslate_tiles
setblock 190 63 0 minecraft:deepslate_tiles
setblock 194 63 0 minecraft:deepslate_tiles
setblock 196 63 0 minecraft:deepslate_tiles
setblock 198 63 0 minecraft:deepslate_tiles
setblock 204 63 0 minecraft:deepslate_tiles
setblock 208 63 0 minecraft:deepslate_tiles
setblock 178 63 0 minecraft:polished_blackstone
setblock 206 63 0 minecraft:polished_blackstone
setblock 179 63 0 minecraft:polished_deepslate
setblock 181 63 0 minecraft:polished_deepslate
setblock 183 63 0 minecraft:polished_deepslate
setblock 185 63 0 minecraft:polished_deepslate
setblock 189 63 0 minecraft:polished_deepslate
setblock 191 63 0 minecraft:polished_deepslate
setblock 193 63 0 minecraft:polished_deepslate
setblock 195 63 0 minecraft:polished_deepslate
setblock 199 63 0 minecraft:polished_deepslate
setblock 201 63 0 minecraft:polished_deepslate
setblock 203 63 0 minecraft:polished_deepslate
setblock 205 63 0 minecraft:polished_deepslate
setblock 177 63 0 minecraft:waxed_cut_copper
setblock 184 63 0 minecraft:waxed_cut_copper
setblock 192 63 0 minecraft:waxed_cut_copper
setblock 200 63 0 minecraft:waxed_cut_copper
setblock 207 63 0 minecraft:waxed_cut_copper
setblock 176 63 1 minecraft:deepslate_tiles
setblock 179 63 1 minecraft:deepslate_tiles
setblock 181 63 1 minecraft:deepslate_tiles
setblock 183 63 1 minecraft:deepslate_tiles
setblock 185 63 1 minecraft:deepslate_tiles
setblock 187 63 1 minecraft:deepslate_tiles
setblock 189 63 1 minecraft:deepslate_tiles
setblock 191 63 1 minecraft:deepslate_tiles
setblock 193 63 1 minecraft:deepslate_tiles
setblock 195 63 1 minecraft:deepslate_tiles
setblock 197 63 1 minecraft:deepslate_tiles
setblock 199 63 1 minecraft:deepslate_tiles
setblock 201 63 1 minecraft:deepslate_tiles
setblock 203 63 1 minecraft:deepslate_tiles
setblock 205 63 1 minecraft:deepslate_tiles
setblock 208 63 1 minecraft:deepslate_tiles
setblock 178 63 1 minecraft:polished_blackstone
setblock 206 63 1 minecraft:polished_blackstone
setblock 180 63 1 minecraft:polished_deepslate
setblock 182 63 1 minecraft:polished_deepslate
setblock 186 63 1 minecraft:polished_deepslate
setblock 188 63 1 minecraft:polished_deepslate
setblock 190 63 1 minecraft:polished_deepslate
setblock 194 63 1 minecraft:polished_deepslate
setblock 196 63 1 minecraft:polished_deepslate
setblock 198 63 1 minecraft:polished_deepslate
setblock 202 63 1 minecraft:polished_deepslate
setblock 204 63 1 minecraft:polished_deepslate
setblock 177 63 1 minecraft:waxed_cut_copper
setblock 184 63 1 minecraft:waxed_cut_copper
setblock 192 63 1 minecraft:waxed_cut_copper
setblock 200 63 1 minecraft:waxed_cut_copper
setblock 207 63 1 minecraft:waxed_cut_copper
setblock 176 63 2 minecraft:deepslate_tiles
setblock 180 63 2 minecraft:deepslate_tiles
setblock 182 63 2 minecraft:deepslate_tiles
setblock 186 63 2 minecraft:deepslate_tiles
setblock 188 63 2 minecraft:deepslate_tiles
setblock 190 63 2 minecraft:deepslate_tiles
setblock 194 63 2 minecraft:deepslate_tiles
setblock 196 63 2 minecraft:deepslate_tiles
setblock 198 63 2 minecraft:deepslate_tiles
setblock 202 63 2 minecraft:deepslate_tiles
setblock 204 63 2 minecraft:deepslate_tiles
setblock 208 63 2 minecraft:deepslate_tiles
setblock 178 63 2 minecraft:polished_blackstone
setblock 206 63 2 minecraft:polished_blackstone
setblock 179 63 2 minecraft:polished_deepslate
setblock 181 63 2 minecraft:polished_deepslate
setblock 183 63 2 minecraft:polished_deepslate
setblock 185 63 2 minecraft:polished_deepslate
setblock 187 63 2 minecraft:polished_deepslate
setblock 189 63 2 minecraft:polished_deepslate
setblock 191 63 2 minecraft:polished_deepslate
setblock 193 63 2 minecraft:polished_deepslate
setblock 195 63 2 minecraft:polished_deepslate
setblock 197 63 2 minecraft:polished_deepslate
setblock 199 63 2 minecraft:polished_deepslate
setblock 201 63 2 minecraft:polished_deepslate
setblock 203 63 2 minecraft:polished_deepslate
setblock 205 63 2 minecraft:polished_deepslate
setblock 177 63 2 minecraft:waxed_cut_copper
setblock 184 63 2 minecraft:waxed_cut_copper
setblock 192 63 2 minecraft:waxed_cut_copper
setblock 200 63 2 minecraft:waxed_cut_copper
setblock 207 63 2 minecraft:waxed_cut_copper
setblock 176 63 3 minecraft:deepslate_tiles
setblock 179 63 3 minecraft:deepslate_tiles
setblock 205 63 3 minecraft:deepslate_tiles
setblock 208 63 3 minecraft:deepslate_tiles
setblock 178 63 3 minecraft:polished_blackstone
setblock 206 63 3 minecraft:polished_blackstone
setblock 177 63 3 minecraft:waxed_cut_copper
fill 180 63 3 204 63 3 minecraft:waxed_cut_copper
setblock 207 63 3 minecraft:waxed_cut_copper
setblock 176 63 4 minecraft:deepslate_tiles
setblock 180 63 4 minecraft:deepslate_tiles
setblock 182 63 4 minecraft:deepslate_tiles
setblock 186 63 4 minecraft:deepslate_tiles
setblock 188 63 4 minecraft:deepslate_tiles
setblock 190 63 4 minecraft:deepslate_tiles
setblock 194 63 4 minecraft:deepslate_tiles
setblock 196 63 4 minecraft:deepslate_tiles
setblock 198 63 4 minecraft:deepslate_tiles
setblock 202 63 4 minecraft:deepslate_tiles
setblock 204 63 4 minecraft:deepslate_tiles
setblock 208 63 4 minecraft:deepslate_tiles
setblock 178 63 4 minecraft:polished_blackstone
setblock 206 63 4 minecraft:polished_blackstone
setblock 179 63 4 minecraft:polished_deepslate
setblock 181 63 4 minecraft:polished_deepslate
setblock 183 63 4 minecraft:polished_deepslate
setblock 185 63 4 minecraft:polished_deepslate
setblock 187 63 4 minecraft:polished_deepslate
setblock 189 63 4 minecraft:polished_deepslate
setblock 191 63 4 minecraft:polished_deepslate
setblock 193 63 4 minecraft:polished_deepslate
setblock 195 63 4 minecraft:polished_deepslate
setblock 197 63 4 minecraft:polished_deepslate
setblock 199 63 4 minecraft:polished_deepslate
setblock 201 63 4 minecraft:polished_deepslate
setblock 203 63 4 minecraft:polished_deepslate
setblock 205 63 4 minecraft:polished_deepslate
setblock 177 63 4 minecraft:waxed_cut_copper
setblock 184 63 4 minecraft:waxed_cut_copper
setblock 192 63 4 minecraft:waxed_cut_copper
setblock 200 63 4 minecraft:waxed_cut_copper
setblock 207 63 4 minecraft:waxed_cut_copper
setblock 182 63 5 minecraft:chiseled_deepslate
setblock 187 63 5 minecraft:chiseled_deepslate
setblock 197 63 5 minecraft:chiseled_deepslate
setblock 202 63 5 minecraft:chiseled_deepslate
setblock 176 63 5 minecraft:deepslate_tiles
setblock 179 63 5 minecraft:deepslate_tiles
setblock 181 63 5 minecraft:deepslate_tiles
setblock 183 63 5 minecraft:deepslate_tiles
setblock 185 63 5 minecraft:deepslate_tiles
setblock 189 63 5 minecraft:deepslate_tiles
setblock 195 63 5 minecraft:deepslate_tiles
setblock 199 63 5 minecraft:deepslate_tiles
setblock 201 63 5 minecraft:deepslate_tiles
setblock 203 63 5 minecraft:deepslate_tiles
setblock 205 63 5 minecraft:deepslate_tiles
setblock 208 63 5 minecraft:deepslate_tiles
setblock 178 63 5 minecraft:polished_blackstone
setblock 206 63 5 minecraft:polished_blackstone
setblock 180 63 5 minecraft:polished_deepslate
setblock 186 63 5 minecraft:polished_deepslate
setblock 188 63 5 minecraft:polished_deepslate
setblock 190 63 5 minecraft:polished_deepslate
setblock 194 63 5 minecraft:polished_deepslate
setblock 196 63 5 minecraft:polished_deepslate
setblock 198 63 5 minecraft:polished_deepslate
setblock 204 63 5 minecraft:polished_deepslate
setblock 177 63 5 minecraft:waxed_cut_copper
setblock 184 63 5 minecraft:waxed_cut_copper
fill 191 63 5 193 63 5 minecraft:waxed_cut_copper
setblock 200 63 5 minecraft:waxed_cut_copper
setblock 207 63 5 minecraft:waxed_cut_copper
setblock 176 63 6 minecraft:deepslate_tiles
setblock 180 63 6 minecraft:deepslate_tiles
setblock 182 63 6 minecraft:deepslate_tiles
setblock 186 63 6 minecraft:deepslate_tiles
setblock 188 63 6 minecraft:deepslate_tiles
setblock 190 63 6 minecraft:deepslate_tiles
setblock 194 63 6 minecraft:deepslate_tiles
setblock 196 63 6 minecraft:deepslate_tiles
setblock 198 63 6 minecraft:deepslate_tiles
setblock 202 63 6 minecraft:deepslate_tiles
setblock 204 63 6 minecraft:deepslate_tiles
setblock 208 63 6 minecraft:deepslate_tiles
setblock 178 63 6 minecraft:polished_blackstone
setblock 206 63 6 minecraft:polished_blackstone
setblock 179 63 6 minecraft:polished_deepslate
setblock 181 63 6 minecraft:polished_deepslate
setblock 183 63 6 minecraft:polished_deepslate
setblock 185 63 6 minecraft:polished_deepslate
setblock 187 63 6 minecraft:polished_deepslate
setblock 189 63 6 minecraft:polished_deepslate
setblock 191 63 6 minecraft:polished_deepslate
setblock 193 63 6 minecraft:polished_deepslate
setblock 195 63 6 minecraft:polished_deepslate
setblock 197 63 6 minecraft:polished_deepslate
setblock 199 63 6 minecraft:polished_deepslate
setblock 201 63 6 minecraft:polished_deepslate
setblock 203 63 6 minecraft:polished_deepslate
setblock 205 63 6 minecraft:polished_deepslate
setblock 177 63 6 minecraft:waxed_cut_copper
setblock 184 63 6 minecraft:waxed_cut_copper
setblock 192 63 6 minecraft:waxed_cut_copper
setblock 200 63 6 minecraft:waxed_cut_copper
setblock 207 63 6 minecraft:waxed_cut_copper
setblock 176 63 7 minecraft:deepslate_tiles
setblock 179 63 7 minecraft:deepslate_tiles
setblock 181 63 7 minecraft:deepslate_tiles
setblock 183 63 7 minecraft:deepslate_tiles
setblock 185 63 7 minecraft:deepslate_tiles
setblock 187 63 7 minecraft:deepslate_tiles
setblock 189 63 7 minecraft:deepslate_tiles
setblock 191 63 7 minecraft:deepslate_tiles
setblock 193 63 7 minecraft:deepslate_tiles
setblock 195 63 7 minecraft:deepslate_tiles
setblock 197 63 7 minecraft:deepslate_tiles
setblock 199 63 7 minecraft:deepslate_tiles
setblock 201 63 7 minecraft:deepslate_tiles
setblock 203 63 7 minecraft:deepslate_tiles
setblock 205 63 7 minecraft:deepslate_tiles
setblock 208 63 7 minecraft:deepslate_tiles
setblock 178 63 7 minecraft:polished_blackstone
setblock 206 63 7 minecraft:polished_blackstone
setblock 180 63 7 minecraft:polished_deepslate
setblock 182 63 7 minecraft:polished_deepslate
setblock 186 63 7 minecraft:polished_deepslate
setblock 188 63 7 minecraft:polished_deepslate
setblock 190 63 7 minecraft:polished_deepslate
setblock 194 63 7 minecraft:polished_deepslate
setblock 196 63 7 minecraft:polished_deepslate
setblock 198 63 7 minecraft:polished_deepslate
setblock 202 63 7 minecraft:polished_deepslate
setblock 204 63 7 minecraft:polished_deepslate
setblock 177 63 7 minecraft:waxed_cut_copper
setblock 184 63 7 minecraft:waxed_cut_copper
setblock 192 63 7 minecraft:waxed_cut_copper
setblock 200 63 7 minecraft:waxed_cut_copper
setblock 207 63 7 minecraft:waxed_cut_copper
setblock 204 63 8 minecraft:chiseled_quartz_block
setblock 176 63 8 minecraft:deepslate_tiles
setblock 180 63 8 minecraft:deepslate_tiles
setblock 182 63 8 minecraft:deepslate_tiles
setblock 184 63 8 minecraft:deepslate_tiles
setblock 186 63 8 minecraft:deepslate_tiles
setblock 188 63 8 minecraft:deepslate_tiles
setblock 190 63 8 minecraft:deepslate_tiles
setblock 192 63 8 minecraft:deepslate_tiles
setblock 194 63 8 minecraft:deepslate_tiles
setblock 196 63 8 minecraft:deepslate_tiles
setblock 198 63 8 minecraft:deepslate_tiles
setblock 200 63 8 minecraft:deepslate_tiles
setblock 202 63 8 minecraft:deepslate_tiles
setblock 208 63 8 minecraft:deepslate_tiles
setblock 178 63 8 minecraft:polished_blackstone
setblock 206 63 8 minecraft:polished_blackstone
setblock 179 63 8 minecraft:polished_deepslate
setblock 181 63 8 minecraft:polished_deepslate
setblock 183 63 8 minecraft:polished_deepslate
setblock 185 63 8 minecraft:polished_deepslate
setblock 187 63 8 minecraft:polished_deepslate
setblock 189 63 8 minecraft:polished_deepslate
setblock 191 63 8 minecraft:polished_deepslate
setblock 193 63 8 minecraft:polished_deepslate
setblock 195 63 8 minecraft:polished_deepslate
setblock 197 63 8 minecraft:polished_deepslate
setblock 199 63 8 minecraft:polished_deepslate
setblock 201 63 8 minecraft:polished_deepslate
setblock 203 63 8 minecraft:polished_deepslate
setblock 205 63 8 minecraft:polished_deepslate
setblock 177 63 8 minecraft:waxed_cut_copper
setblock 207 63 8 minecraft:waxed_cut_copper
setblock 176 63 9 minecraft:deepslate_tiles
setblock 179 63 9 minecraft:deepslate_tiles
setblock 181 63 9 minecraft:deepslate_tiles
setblock 183 63 9 minecraft:deepslate_tiles
setblock 185 63 9 minecraft:deepslate_tiles
setblock 187 63 9 minecraft:deepslate_tiles
setblock 189 63 9 minecraft:deepslate_tiles
setblock 191 63 9 minecraft:deepslate_tiles
setblock 193 63 9 minecraft:deepslate_tiles
setblock 195 63 9 minecraft:deepslate_tiles
setblock 197 63 9 minecraft:deepslate_tiles
setblock 199 63 9 minecraft:deepslate_tiles
setblock 201 63 9 minecraft:deepslate_tiles
setblock 203 63 9 minecraft:deepslate_tiles
setblock 205 63 9 minecraft:deepslate_tiles
setblock 208 63 9 minecraft:deepslate_tiles
setblock 178 63 9 minecraft:polished_blackstone
setblock 206 63 9 minecraft:polished_blackstone
setblock 180 63 9 minecraft:polished_deepslate
setblock 182 63 9 minecraft:polished_deepslate
setblock 184 63 9 minecraft:polished_deepslate
setblock 186 63 9 minecraft:polished_deepslate
setblock 188 63 9 minecraft:polished_deepslate
setblock 190 63 9 minecraft:polished_deepslate
setblock 192 63 9 minecraft:polished_deepslate
setblock 194 63 9 minecraft:polished_deepslate
setblock 196 63 9 minecraft:polished_deepslate
setblock 198 63 9 minecraft:polished_deepslate
setblock 200 63 9 minecraft:polished_deepslate
setblock 202 63 9 minecraft:polished_deepslate
setblock 204 63 9 minecraft:polished_deepslate
setblock 177 63 9 minecraft:waxed_cut_copper
setblock 207 63 9 minecraft:waxed_cut_copper
setblock 182 63 10 minecraft:chiseled_deepslate
setblock 187 63 10 minecraft:chiseled_deepslate
setblock 192 63 10 minecraft:chiseled_deepslate
setblock 197 63 10 minecraft:chiseled_deepslate
setblock 202 63 10 minecraft:chiseled_deepslate
setblock 176 63 10 minecraft:deepslate_tiles
setblock 180 63 10 minecraft:deepslate_tiles
setblock 184 63 10 minecraft:deepslate_tiles
setblock 186 63 10 minecraft:deepslate_tiles
setblock 188 63 10 minecraft:deepslate_tiles
setblock 190 63 10 minecraft:deepslate_tiles
setblock 194 63 10 minecraft:deepslate_tiles
setblock 196 63 10 minecraft:deepslate_tiles
setblock 198 63 10 minecraft:deepslate_tiles
setblock 200 63 10 minecraft:deepslate_tiles
setblock 204 63 10 minecraft:deepslate_tiles
setblock 208 63 10 minecraft:deepslate_tiles
setblock 178 63 10 minecraft:polished_blackstone
setblock 206 63 10 minecraft:polished_blackstone
setblock 179 63 10 minecraft:polished_deepslate
setblock 183 63 10 minecraft:polished_deepslate
setblock 185 63 10 minecraft:polished_deepslate
setblock 189 63 10 minecraft:polished_deepslate
setblock 191 63 10 minecraft:polished_deepslate
setblock 193 63 10 minecraft:polished_deepslate
setblock 195 63 10 minecraft:polished_deepslate
setblock 199 63 10 minecraft:polished_deepslate
setblock 201 63 10 minecraft:polished_deepslate
setblock 205 63 10 minecraft:polished_deepslate
setblock 177 63 10 minecraft:waxed_cut_copper
setblock 181 63 10 minecraft:waxed_cut_copper
setblock 203 63 10 minecraft:waxed_cut_copper
setblock 207 63 10 minecraft:waxed_cut_copper
setblock 176 63 11 minecraft:deepslate_tiles
setblock 179 63 11 minecraft:deepslate_tiles
setblock 183 63 11 minecraft:deepslate_tiles
setblock 185 63 11 minecraft:deepslate_tiles
setblock 187 63 11 minecraft:deepslate_tiles
setblock 189 63 11 minecraft:deepslate_tiles
setblock 191 63 11 minecraft:deepslate_tiles
setblock 193 63 11 minecraft:deepslate_tiles
setblock 195 63 11 minecraft:deepslate_tiles
setblock 197 63 11 minecraft:deepslate_tiles
setblock 199 63 11 minecraft:deepslate_tiles
setblock 201 63 11 minecraft:deepslate_tiles
setblock 205 63 11 minecraft:deepslate_tiles
setblock 208 63 11 minecraft:deepslate_tiles
setblock 178 63 11 minecraft:polished_blackstone
setblock 206 63 11 minecraft:polished_blackstone
setblock 184 63 11 minecraft:polished_deepslate
setblock 186 63 11 minecraft:polished_deepslate
setblock 188 63 11 minecraft:polished_deepslate
setblock 190 63 11 minecraft:polished_deepslate
setblock 192 63 11 minecraft:polished_deepslate
setblock 194 63 11 minecraft:polished_deepslate
setblock 196 63 11 minecraft:polished_deepslate
setblock 198 63 11 minecraft:polished_deepslate
setblock 200 63 11 minecraft:polished_deepslate
setblock 181 63 11 minecraft:sea_lantern
setblock 203 63 11 minecraft:sea_lantern
setblock 177 63 11 minecraft:waxed_cut_copper
setblock 180 63 11 minecraft:waxed_cut_copper
setblock 182 63 11 minecraft:waxed_cut_copper
setblock 202 63 11 minecraft:waxed_cut_copper
setblock 204 63 11 minecraft:waxed_cut_copper
setblock 207 63 11 minecraft:waxed_cut_copper
setblock 176 63 12 minecraft:deepslate_tiles
setblock 180 63 12 minecraft:deepslate_tiles
setblock 182 63 12 minecraft:deepslate_tiles
setblock 184 63 12 minecraft:deepslate_tiles
setblock 186 63 12 minecraft:deepslate_tiles
setblock 188 63 12 minecraft:deepslate_tiles
setblock 190 63 12 minecraft:deepslate_tiles
setblock 194 63 12 minecraft:deepslate_tiles
setblock 196 63 12 minecraft:deepslate_tiles
setblock 198 63 12 minecraft:deepslate_tiles
setblock 200 63 12 minecraft:deepslate_tiles
setblock 202 63 12 minecraft:deepslate_tiles
setblock 204 63 12 minecraft:deepslate_tiles
setblock 208 63 12 minecraft:deepslate_tiles
setblock 178 63 12 minecraft:polished_blackstone
setblock 206 63 12 minecraft:polished_blackstone
setblock 179 63 12 minecraft:polished_deepslate
setblock 183 63 12 minecraft:polished_deepslate
setblock 185 63 12 minecraft:polished_deepslate
setblock 187 63 12 minecraft:polished_deepslate
setblock 189 63 12 minecraft:polished_deepslate
setblock 191 63 12 minecraft:polished_deepslate
setblock 195 63 12 minecraft:polished_deepslate
setblock 197 63 12 minecraft:polished_deepslate
setblock 199 63 12 minecraft:polished_deepslate
setblock 201 63 12 minecraft:polished_deepslate
setblock 205 63 12 minecraft:polished_deepslate
fill 192 63 12 193 63 12 minecraft:quartz_block
setblock 177 63 12 minecraft:waxed_cut_copper
setblock 181 63 12 minecraft:waxed_cut_copper
setblock 203 63 12 minecraft:waxed_cut_copper
setblock 207 63 12 minecraft:waxed_cut_copper
setblock 176 63 13 minecraft:deepslate_tiles
setblock 179 63 13 minecraft:deepslate_tiles
setblock 181 63 13 minecraft:deepslate_tiles
setblock 183 63 13 minecraft:deepslate_tiles
setblock 185 63 13 minecraft:deepslate_tiles
setblock 187 63 13 minecraft:deepslate_tiles
setblock 189 63 13 minecraft:deepslate_tiles
setblock 191 63 13 minecraft:deepslate_tiles
setblock 195 63 13 minecraft:deepslate_tiles
setblock 197 63 13 minecraft:deepslate_tiles
setblock 199 63 13 minecraft:deepslate_tiles
setblock 201 63 13 minecraft:deepslate_tiles
setblock 203 63 13 minecraft:deepslate_tiles
setblock 205 63 13 minecraft:deepslate_tiles
setblock 208 63 13 minecraft:deepslate_tiles
setblock 178 63 13 minecraft:polished_blackstone
setblock 206 63 13 minecraft:polished_blackstone
setblock 180 63 13 minecraft:polished_deepslate
setblock 182 63 13 minecraft:polished_deepslate
setblock 184 63 13 minecraft:polished_deepslate
setblock 186 63 13 minecraft:polished_deepslate
setblock 188 63 13 minecraft:polished_deepslate
setblock 190 63 13 minecraft:polished_deepslate
setblock 194 63 13 minecraft:polished_deepslate
setblock 196 63 13 minecraft:polished_deepslate
setblock 198 63 13 minecraft:polished_deepslate
setblock 200 63 13 minecraft:polished_deepslate
setblock 202 63 13 minecraft:polished_deepslate
setblock 204 63 13 minecraft:polished_deepslate
fill 192 63 13 193 63 13 minecraft:quartz_block
setblock 177 63 13 minecraft:waxed_cut_copper
setblock 207 63 13 minecraft:waxed_cut_copper
setblock 176 63 14 minecraft:deepslate_tiles
setblock 208 63 14 minecraft:deepslate_tiles
fill 178 63 14 206 63 14 minecraft:polished_blackstone
setblock 177 63 14 minecraft:waxed_cut_copper
setblock 207 63 14 minecraft:waxed_cut_copper
setblock 176 63 15 minecraft:deepslate_tiles
setblock 208 63 15 minecraft:deepslate_tiles
fill 177 63 15 207 63 15 minecraft:waxed_cut_copper
fill 176 63 16 208 63 16 minecraft:deepslate_tiles
fill 176 64 -16 208 64 -16 minecraft:deepslate_tiles
setblock 176 64 -15 minecraft:deepslate_tiles
setblock 208 64 -15 minecraft:deepslate_tiles
setblock 180 64 -15 minecraft:waxed_cut_copper
setblock 186 64 -15 minecraft:waxed_cut_copper
setblock 192 64 -15 minecraft:waxed_cut_copper
setblock 198 64 -15 minecraft:waxed_cut_copper
setblock 204 64 -15 minecraft:waxed_cut_copper
setblock 176 64 -14 minecraft:deepslate_tiles
setblock 208 64 -14 minecraft:deepslate_tiles
setblock 176 64 -13 minecraft:deepslate_tiles
setblock 208 64 -13 minecraft:deepslate_tiles
setblock 176 64 -12 minecraft:deepslate_tiles
setblock 208 64 -12 minecraft:deepslate_tiles
setblock 177 64 -12 minecraft:waxed_cut_copper
setblock 207 64 -12 minecraft:waxed_cut_copper
setblock 176 64 -11 minecraft:deepslate_tiles
setblock 208 64 -11 minecraft:deepslate_tiles
setblock 188 64 -10 minecraft:dark_prismarine
setblock 200 64 -10 minecraft:dark_prismarine
setblock 176 64 -10 minecraft:deepslate_tiles
setblock 208 64 -10 minecraft:deepslate_tiles
setblock 179 64 -10 minecraft:polished_blackstone_bricks
setblock 205 64 -10 minecraft:polished_blackstone_bricks
setblock 184 64 -10 minecraft:sea_lantern
setblock 192 64 -10 minecraft:sea_lantern
setblock 196 64 -10 minecraft:sea_lantern
setblock 176 64 -9 minecraft:deepslate_tiles
setblock 208 64 -9 minecraft:deepslate_tiles
setblock 179 64 -9 minecraft:polished_blackstone_bricks
setblock 205 64 -9 minecraft:polished_blackstone_bricks
setblock 176 64 -8 minecraft:deepslate_tiles
setblock 208 64 -8 minecraft:deepslate_tiles
setblock 179 64 -8 minecraft:polished_blackstone_bricks
setblock 205 64 -8 minecraft:polished_blackstone_bricks
setblock 176 64 -7 minecraft:deepslate_tiles
setblock 208 64 -7 minecraft:deepslate_tiles
setblock 176 64 -6 minecraft:deepslate_tiles
setblock 208 64 -6 minecraft:deepslate_tiles
setblock 177 64 -6 minecraft:waxed_cut_copper
setblock 207 64 -6 minecraft:waxed_cut_copper
setblock 176 64 -5 minecraft:deepslate_tiles
setblock 208 64 -5 minecraft:deepslate_tiles
setblock 176 64 -4 minecraft:deepslate_tiles
setblock 208 64 -4 minecraft:deepslate_tiles
setblock 179 64 -4 minecraft:polished_blackstone_bricks
setblock 205 64 -4 minecraft:polished_blackstone_bricks
setblock 176 64 -3 minecraft:deepslate_tiles
setblock 208 64 -3 minecraft:deepslate_tiles
setblock 179 64 -3 minecraft:polished_blackstone_bricks
setblock 205 64 -3 minecraft:polished_blackstone_bricks
setblock 176 64 -2 minecraft:deepslate_tiles
setblock 208 64 -2 minecraft:deepslate_tiles
setblock 179 64 -2 minecraft:polished_blackstone_bricks
setblock 205 64 -2 minecraft:polished_blackstone_bricks
setblock 176 64 -1 minecraft:deepslate_tiles
setblock 208 64 -1 minecraft:deepslate_tiles
setblock 176 64 0 minecraft:deepslate_tiles
setblock 208 64 0 minecraft:deepslate_tiles
setblock 177 64 0 minecraft:waxed_cut_copper
setblock 207 64 0 minecraft:waxed_cut_copper
setblock 176 64 1 minecraft:deepslate_tiles
setblock 208 64 1 minecraft:deepslate_tiles
setblock 176 64 2 minecraft:deepslate_tiles
setblock 208 64 2 minecraft:deepslate_tiles
setblock 179 64 2 minecraft:polished_blackstone_bricks
setblock 205 64 2 minecraft:polished_blackstone_bricks
setblock 176 64 3 minecraft:deepslate_tiles
setblock 208 64 3 minecraft:deepslate_tiles
setblock 179 64 3 minecraft:polished_blackstone_bricks
setblock 205 64 3 minecraft:polished_blackstone_bricks
setblock 176 64 4 minecraft:deepslate_tiles
setblock 208 64 4 minecraft:deepslate_tiles
setblock 179 64 4 minecraft:polished_blackstone_bricks
setblock 205 64 4 minecraft:polished_blackstone_bricks
setblock 176 64 5 minecraft:deepslate_tiles
setblock 208 64 5 minecraft:deepslate_tiles
setblock 176 64 6 minecraft:deepslate_tiles
setblock 208 64 6 minecraft:deepslate_tiles
setblock 177 64 6 minecraft:waxed_cut_copper
setblock 207 64 6 minecraft:waxed_cut_copper
setblock 176 64 7 minecraft:deepslate_tiles
setblock 208 64 7 minecraft:deepslate_tiles
setblock 206 64 7 minecraft:polished_blackstone_bricks
setblock 176 64 8 minecraft:deepslate_tiles
setblock 208 64 8 minecraft:deepslate_tiles
setblock 206 64 8 minecraft:polished_blackstone_bricks
setblock 176 64 9 minecraft:deepslate_tiles
setblock 208 64 9 minecraft:deepslate_tiles
setblock 206 64 9 minecraft:polished_blackstone_bricks
setblock 176 64 10 minecraft:deepslate_tiles
setblock 208 64 10 minecraft:deepslate_tiles
setblock 176 64 11 minecraft:deepslate_tiles
setblock 208 64 11 minecraft:deepslate_tiles
setblock 176 64 12 minecraft:deepslate_tiles
setblock 208 64 12 minecraft:deepslate_tiles
setblock 177 64 12 minecraft:waxed_cut_copper
setblock 207 64 12 minecraft:waxed_cut_copper
setblock 176 64 13 minecraft:deepslate_tiles
setblock 208 64 13 minecraft:deepslate_tiles
setblock 176 64 14 minecraft:deepslate_tiles
setblock 208 64 14 minecraft:deepslate_tiles
setblock 176 64 15 minecraft:deepslate_tiles
setblock 208 64 15 minecraft:deepslate_tiles
setblock 180 64 15 minecraft:waxed_cut_copper
setblock 186 64 15 minecraft:waxed_cut_copper
setblock 192 64 15 minecraft:waxed_cut_copper
setblock 198 64 15 minecraft:waxed_cut_copper
setblock 204 64 15 minecraft:waxed_cut_copper
fill 176 64 16 208 64 16 minecraft:deepslate_tiles
fill 176 65 -16 208 65 -16 minecraft:deepslate_tiles
setblock 176 65 -15 minecraft:deepslate_tiles
setblock 208 65 -15 minecraft:deepslate_tiles
setblock 180 65 -15 minecraft:waxed_cut_copper
setblock 186 65 -15 minecraft:waxed_cut_copper
setblock 192 65 -15 minecraft:waxed_cut_copper
setblock 198 65 -15 minecraft:waxed_cut_copper
setblock 204 65 -15 minecraft:waxed_cut_copper
setblock 176 65 -14 minecraft:deepslate_tiles
setblock 208 65 -14 minecraft:deepslate_tiles
setblock 176 65 -13 minecraft:deepslate_tiles
setblock 208 65 -13 minecraft:deepslate_tiles
setblock 176 65 -12 minecraft:deepslate_tiles
setblock 208 65 -12 minecraft:deepslate_tiles
setblock 177 65 -12 minecraft:waxed_cut_copper
setblock 207 65 -12 minecraft:waxed_cut_copper
setblock 176 65 -11 minecraft:deepslate_tiles
setblock 208 65 -11 minecraft:deepslate_tiles
setblock 176 65 -10 minecraft:deepslate_tiles
setblock 208 65 -10 minecraft:deepslate_tiles
setblock 184 65 -10 minecraft:polished_blackstone
setblock 188 65 -10 minecraft:polished_blackstone
setblock 192 65 -10 minecraft:polished_blackstone
setblock 196 65 -10 minecraft:polished_blackstone
setblock 200 65 -10 minecraft:polished_blackstone
setblock 179 65 -10 minecraft:polished_blackstone_bricks
setblock 205 65 -10 minecraft:polished_blackstone_bricks
setblock 176 65 -9 minecraft:deepslate_tiles
setblock 208 65 -9 minecraft:deepslate_tiles
setblock 179 65 -9 minecraft:polished_blackstone_bricks
setblock 205 65 -9 minecraft:polished_blackstone_bricks
setblock 180 65 -9 minecraft:sea_lantern
setblock 204 65 -9 minecraft:sea_lantern
setblock 176 65 -8 minecraft:deepslate_tiles
setblock 208 65 -8 minecraft:deepslate_tiles
setblock 179 65 -8 minecraft:polished_blackstone_bricks
setblock 205 65 -8 minecraft:polished_blackstone_bricks
setblock 176 65 -7 minecraft:deepslate_tiles
setblock 208 65 -7 minecraft:deepslate_tiles
setblock 176 65 -6 minecraft:deepslate_tiles
setblock 208 65 -6 minecraft:deepslate_tiles
setblock 177 65 -6 minecraft:waxed_cut_copper
setblock 207 65 -6 minecraft:waxed_cut_copper
setblock 176 65 -5 minecraft:deepslate_tiles
setblock 208 65 -5 minecraft:deepslate_tiles
setblock 176 65 -4 minecraft:deepslate_tiles
setblock 208 65 -4 minecraft:deepslate_tiles
setblock 179 65 -4 minecraft:polished_blackstone_bricks
setblock 205 65 -4 minecraft:polished_blackstone_bricks
setblock 176 65 -3 minecraft:deepslate_tiles
setblock 208 65 -3 minecraft:deepslate_tiles
setblock 179 65 -3 minecraft:polished_blackstone_bricks
setblock 205 65 -3 minecraft:polished_blackstone_bricks
setblock 180 65 -3 minecraft:sea_lantern
setblock 204 65 -3 minecraft:sea_lantern
setblock 176 65 -2 minecraft:deepslate_tiles
setblock 208 65 -2 minecraft:deepslate_tiles
setblock 179 65 -2 minecraft:polished_blackstone_bricks
setblock 205 65 -2 minecraft:polished_blackstone_bricks
setblock 176 65 -1 minecraft:deepslate_tiles
setblock 208 65 -1 minecraft:deepslate_tiles
setblock 176 65 0 minecraft:deepslate_tiles
setblock 208 65 0 minecraft:deepslate_tiles
setblock 177 65 0 minecraft:waxed_cut_copper
setblock 207 65 0 minecraft:waxed_cut_copper
setblock 176 65 1 minecraft:deepslate_tiles
setblock 208 65 1 minecraft:deepslate_tiles
setblock 176 65 2 minecraft:deepslate_tiles
setblock 208 65 2 minecraft:deepslate_tiles
setblock 179 65 2 minecraft:polished_blackstone_bricks
setblock 205 65 2 minecraft:polished_blackstone_bricks
setblock 176 65 3 minecraft:deepslate_tiles
setblock 208 65 3 minecraft:deepslate_tiles
setblock 179 65 3 minecraft:polished_blackstone_bricks
setblock 205 65 3 minecraft:polished_blackstone_bricks
setblock 180 65 3 minecraft:sea_lantern
setblock 204 65 3 minecraft:sea_lantern
setblock 176 65 4 minecraft:deepslate_tiles
setblock 208 65 4 minecraft:deepslate_tiles
setblock 179 65 4 minecraft:polished_blackstone_bricks
setblock 205 65 4 minecraft:polished_blackstone_bricks
setblock 176 65 5 minecraft:deepslate_tiles
setblock 208 65 5 minecraft:deepslate_tiles
setblock 176 65 6 minecraft:deepslate_tiles
setblock 208 65 6 minecraft:deepslate_tiles
setblock 177 65 6 minecraft:waxed_cut_copper
setblock 207 65 6 minecraft:waxed_cut_copper
setblock 176 65 7 minecraft:deepslate_tiles
setblock 208 65 7 minecraft:deepslate_tiles
setblock 206 65 7 minecraft:polished_blackstone_bricks
setblock 176 65 8 minecraft:deepslate_tiles
setblock 208 65 8 minecraft:deepslate_tiles
setblock 206 65 8 minecraft:polished_blackstone_bricks
setblock 176 65 9 minecraft:deepslate_tiles
setblock 208 65 9 minecraft:deepslate_tiles
setblock 206 65 9 minecraft:polished_blackstone_bricks
setblock 176 65 10 minecraft:deepslate_tiles
setblock 208 65 10 minecraft:deepslate_tiles
setblock 176 65 11 minecraft:deepslate_tiles
setblock 208 65 11 minecraft:deepslate_tiles
setblock 176 65 12 minecraft:deepslate_tiles
setblock 208 65 12 minecraft:deepslate_tiles
setblock 177 65 12 minecraft:waxed_cut_copper
setblock 207 65 12 minecraft:waxed_cut_copper
setblock 176 65 13 minecraft:deepslate_tiles
setblock 208 65 13 minecraft:deepslate_tiles
setblock 176 65 14 minecraft:deepslate_tiles
setblock 208 65 14 minecraft:deepslate_tiles
setblock 176 65 15 minecraft:deepslate_tiles
setblock 208 65 15 minecraft:deepslate_tiles
setblock 180 65 15 minecraft:waxed_cut_copper
setblock 186 65 15 minecraft:waxed_cut_copper
setblock 192 65 15 minecraft:waxed_cut_copper
setblock 198 65 15 minecraft:waxed_cut_copper
setblock 204 65 15 minecraft:waxed_cut_copper
fill 176 65 16 208 65 16 minecraft:deepslate_tiles
fill 176 66 -16 208 66 -16 minecraft:deepslate_tiles
setblock 176 66 -15 minecraft:deepslate_tiles
setblock 208 66 -15 minecraft:deepslate_tiles
fill 177 66 -15 207 66 -15 minecraft:waxed_cut_copper
setblock 176 66 -14 minecraft:deepslate_tiles
setblock 208 66 -14 minecraft:deepslate_tiles
setblock 177 66 -14 minecraft:waxed_cut_copper
setblock 207 66 -14 minecraft:waxed_cut_copper
setblock 176 66 -13 minecraft:deepslate_tiles
setblock 208 66 -13 minecraft:deepslate_tiles
setblock 177 66 -13 minecraft:waxed_cut_copper
setblock 207 66 -13 minecraft:waxed_cut_copper
setblock 176 66 -12 minecraft:deepslate_tiles
setblock 208 66 -12 minecraft:deepslate_tiles
setblock 177 66 -12 minecraft:waxed_cut_copper
setblock 207 66 -12 minecraft:waxed_cut_copper
setblock 176 66 -11 minecraft:deepslate_tiles
setblock 208 66 -11 minecraft:deepslate_tiles
setblock 177 66 -11 minecraft:waxed_cut_copper
setblock 207 66 -11 minecraft:waxed_cut_copper
setblock 184 66 -10 minecraft:dark_prismarine
setblock 188 66 -10 minecraft:dark_prismarine
setblock 192 66 -10 minecraft:dark_prismarine
setblock 196 66 -10 minecraft:dark_prismarine
setblock 200 66 -10 minecraft:dark_prismarine
setblock 176 66 -10 minecraft:deepslate_tiles
setblock 208 66 -10 minecraft:deepslate_tiles
setblock 179 66 -10 minecraft:polished_blackstone_bricks
setblock 205 66 -10 minecraft:polished_blackstone_bricks
setblock 177 66 -10 minecraft:waxed_cut_copper
setblock 207 66 -10 minecraft:waxed_cut_copper
setblock 176 66 -9 minecraft:deepslate_tiles
setblock 208 66 -9 minecraft:deepslate_tiles
setblock 179 66 -9 minecraft:polished_blackstone_bricks
setblock 205 66 -9 minecraft:polished_blackstone_bricks
setblock 177 66 -9 minecraft:waxed_cut_copper
setblock 207 66 -9 minecraft:waxed_cut_copper
setblock 176 66 -8 minecraft:deepslate_tiles
setblock 208 66 -8 minecraft:deepslate_tiles
setblock 179 66 -8 minecraft:polished_blackstone_bricks
setblock 205 66 -8 minecraft:polished_blackstone_bricks
setblock 177 66 -8 minecraft:waxed_cut_copper
setblock 207 66 -8 minecraft:waxed_cut_copper
setblock 176 66 -7 minecraft:deepslate_tiles
setblock 208 66 -7 minecraft:deepslate_tiles
setblock 177 66 -7 minecraft:waxed_cut_copper
setblock 207 66 -7 minecraft:waxed_cut_copper
setblock 176 66 -6 minecraft:deepslate_tiles
setblock 208 66 -6 minecraft:deepslate_tiles
setblock 177 66 -6 minecraft:waxed_cut_copper
setblock 207 66 -6 minecraft:waxed_cut_copper
setblock 176 66 -5 minecraft:deepslate_tiles
setblock 208 66 -5 minecraft:deepslate_tiles
setblock 177 66 -5 minecraft:waxed_cut_copper
setblock 207 66 -5 minecraft:waxed_cut_copper
setblock 176 66 -4 minecraft:deepslate_tiles
setblock 208 66 -4 minecraft:deepslate_tiles
setblock 179 66 -4 minecraft:polished_blackstone_bricks
setblock 205 66 -4 minecraft:polished_blackstone_bricks
setblock 177 66 -4 minecraft:waxed_cut_copper
setblock 207 66 -4 minecraft:waxed_cut_copper
setblock 176 66 -3 minecraft:deepslate_tiles
setblock 208 66 -3 minecraft:deepslate_tiles
setblock 179 66 -3 minecraft:polished_blackstone_bricks
setblock 205 66 -3 minecraft:polished_blackstone_bricks
setblock 177 66 -3 minecraft:waxed_cut_copper
setblock 207 66 -3 minecraft:waxed_cut_copper
setblock 176 66 -2 minecraft:deepslate_tiles
setblock 208 66 -2 minecraft:deepslate_tiles
setblock 179 66 -2 minecraft:polished_blackstone_bricks
setblock 205 66 -2 minecraft:polished_blackstone_bricks
setblock 177 66 -2 minecraft:waxed_cut_copper
setblock 207 66 -2 minecraft:waxed_cut_copper
setblock 176 66 -1 minecraft:deepslate_tiles
setblock 208 66 -1 minecraft:deepslate_tiles
setblock 177 66 -1 minecraft:waxed_cut_copper
setblock 207 66 -1 minecraft:waxed_cut_copper
setblock 176 66 0 minecraft:deepslate_tiles
setblock 208 66 0 minecraft:deepslate_tiles
setblock 177 66 0 minecraft:waxed_cut_copper
setblock 207 66 0 minecraft:waxed_cut_copper
setblock 176 66 1 minecraft:deepslate_tiles
setblock 208 66 1 minecraft:deepslate_tiles
setblock 177 66 1 minecraft:waxed_cut_copper
setblock 207 66 1 minecraft:waxed_cut_copper
setblock 176 66 2 minecraft:deepslate_tiles
setblock 208 66 2 minecraft:deepslate_tiles
setblock 179 66 2 minecraft:polished_blackstone_bricks
setblock 205 66 2 minecraft:polished_blackstone_bricks
setblock 177 66 2 minecraft:waxed_cut_copper
setblock 207 66 2 minecraft:waxed_cut_copper
setblock 176 66 3 minecraft:deepslate_tiles
setblock 208 66 3 minecraft:deepslate_tiles
setblock 179 66 3 minecraft:polished_blackstone_bricks
setblock 205 66 3 minecraft:polished_blackstone_bricks
setblock 177 66 3 minecraft:waxed_cut_copper
setblock 207 66 3 minecraft:waxed_cut_copper
setblock 176 66 4 minecraft:deepslate_tiles
setblock 208 66 4 minecraft:deepslate_tiles
setblock 179 66 4 minecraft:polished_blackstone_bricks
setblock 205 66 4 minecraft:polished_blackstone_bricks
setblock 177 66 4 minecraft:waxed_cut_copper
setblock 207 66 4 minecraft:waxed_cut_copper
setblock 176 66 5 minecraft:deepslate_tiles
setblock 208 66 5 minecraft:deepslate_tiles
setblock 177 66 5 minecraft:waxed_cut_copper
setblock 207 66 5 minecraft:waxed_cut_copper
setblock 176 66 6 minecraft:deepslate_tiles
setblock 208 66 6 minecraft:deepslate_tiles
setblock 177 66 6 minecraft:waxed_cut_copper
setblock 207 66 6 minecraft:waxed_cut_copper
setblock 176 66 7 minecraft:deepslate_tiles
setblock 208 66 7 minecraft:deepslate_tiles
setblock 206 66 7 minecraft:polished_blackstone_bricks
setblock 177 66 7 minecraft:waxed_cut_copper
setblock 207 66 7 minecraft:waxed_cut_copper
setblock 205 66 8 minecraft:amethyst_block
setblock 176 66 8 minecraft:deepslate_tiles
setblock 208 66 8 minecraft:deepslate_tiles
setblock 206 66 8 minecraft:sea_lantern
setblock 177 66 8 minecraft:waxed_cut_copper
setblock 207 66 8 minecraft:waxed_cut_copper
setblock 176 66 9 minecraft:deepslate_tiles
setblock 208 66 9 minecraft:deepslate_tiles
setblock 206 66 9 minecraft:polished_blackstone_bricks
setblock 177 66 9 minecraft:waxed_cut_copper
setblock 207 66 9 minecraft:waxed_cut_copper
setblock 176 66 10 minecraft:deepslate_tiles
setblock 208 66 10 minecraft:deepslate_tiles
setblock 177 66 10 minecraft:waxed_cut_copper
setblock 207 66 10 minecraft:waxed_cut_copper
setblock 176 66 11 minecraft:deepslate_tiles
setblock 208 66 11 minecraft:deepslate_tiles
setblock 177 66 11 minecraft:waxed_cut_copper
setblock 207 66 11 minecraft:waxed_cut_copper
setblock 176 66 12 minecraft:deepslate_tiles
setblock 208 66 12 minecraft:deepslate_tiles
setblock 177 66 12 minecraft:waxed_cut_copper
setblock 207 66 12 minecraft:waxed_cut_copper
setblock 176 66 13 minecraft:deepslate_tiles
setblock 208 66 13 minecraft:deepslate_tiles
setblock 177 66 13 minecraft:waxed_cut_copper
setblock 207 66 13 minecraft:waxed_cut_copper
setblock 176 66 14 minecraft:deepslate_tiles
setblock 208 66 14 minecraft:deepslate_tiles
setblock 177 66 14 minecraft:waxed_cut_copper
setblock 207 66 14 minecraft:waxed_cut_copper
setblock 176 66 15 minecraft:deepslate_tiles
setblock 208 66 15 minecraft:deepslate_tiles
fill 177 66 15 207 66 15 minecraft:waxed_cut_copper
fill 176 66 16 208 66 16 minecraft:deepslate_tiles
fill 176 67 -16 179 67 -16 minecraft:deepslate_tiles
fill 181 67 -16 185 67 -16 minecraft:deepslate_tiles
fill 187 67 -16 191 67 -16 minecraft:deepslate_tiles
fill 193 67 -16 197 67 -16 minecraft:deepslate_tiles
fill 199 67 -16 203 67 -16 minecraft:deepslate_tiles
fill 205 67 -16 208 67 -16 minecraft:deepslate_tiles
setblock 180 67 -16 minecraft:sea_lantern
setblock 186 67 -16 minecraft:sea_lantern
setblock 192 67 -16 minecraft:sea_lantern
setblock 198 67 -16 minecraft:sea_lantern
setblock 204 67 -16 minecraft:sea_lantern
setblock 176 67 -15 minecraft:deepslate_tiles
setblock 208 67 -15 minecraft:deepslate_tiles
setblock 180 67 -15 minecraft:orange_stained_glass
setblock 186 67 -15 minecraft:orange_stained_glass
setblock 192 67 -15 minecraft:orange_stained_glass
setblock 198 67 -15 minecraft:orange_stained_glass
setblock 204 67 -15 minecraft:orange_stained_glass
setblock 176 67 -14 minecraft:deepslate_tiles
setblock 208 67 -14 minecraft:deepslate_tiles
setblock 176 67 -13 minecraft:deepslate_tiles
setblock 208 67 -13 minecraft:deepslate_tiles
setblock 177 67 -12 minecraft:orange_stained_glass
setblock 207 67 -12 minecraft:orange_stained_glass
setblock 176 67 -12 minecraft:sea_lantern
setblock 208 67 -12 minecraft:sea_lantern
setblock 176 67 -11 minecraft:deepslate_tiles
setblock 208 67 -11 minecraft:deepslate_tiles
setblock 176 67 -10 minecraft:deepslate_tiles
setblock 208 67 -10 minecraft:deepslate_tiles
setblock 179 67 -10 minecraft:polished_blackstone_bricks
setblock 205 67 -10 minecraft:polished_blackstone_bricks
setblock 176 67 -9 minecraft:deepslate_tiles
setblock 208 67 -9 minecraft:deepslate_tiles
setblock 179 67 -9 minecraft:polished_blackstone_bricks
setblock 205 67 -9 minecraft:polished_blackstone_bricks
setblock 180 67 -9 minecraft:sea_lantern
setblock 204 67 -9 minecraft:sea_lantern
setblock 176 67 -8 minecraft:deepslate_tiles
setblock 208 67 -8 minecraft:deepslate_tiles
setblock 179 67 -8 minecraft:polished_blackstone_bricks
setblock 205 67 -8 minecraft:polished_blackstone_bricks
setblock 176 67 -7 minecraft:deepslate_tiles
setblock 208 67 -7 minecraft:deepslate_tiles
setblock 177 67 -6 minecraft:orange_stained_glass
setblock 207 67 -6 minecraft:orange_stained_glass
setblock 176 67 -6 minecraft:sea_lantern
setblock 208 67 -6 minecraft:sea_lantern
setblock 176 67 -5 minecraft:deepslate_tiles
setblock 208 67 -5 minecraft:deepslate_tiles
setblock 176 67 -4 minecraft:deepslate_tiles
setblock 208 67 -4 minecraft:deepslate_tiles
setblock 179 67 -4 minecraft:polished_blackstone_bricks
setblock 205 67 -4 minecraft:polished_blackstone_bricks
setblock 176 67 -3 minecraft:deepslate_tiles
setblock 208 67 -3 minecraft:deepslate_tiles
setblock 179 67 -3 minecraft:polished_blackstone_bricks
setblock 205 67 -3 minecraft:polished_blackstone_bricks
setblock 180 67 -3 minecraft:sea_lantern
setblock 204 67 -3 minecraft:sea_lantern
setblock 176 67 -2 minecraft:deepslate_tiles
setblock 208 67 -2 minecraft:deepslate_tiles
setblock 179 67 -2 minecraft:polished_blackstone_bricks
setblock 205 67 -2 minecraft:polished_blackstone_bricks
setblock 176 67 -1 minecraft:deepslate_tiles
setblock 208 67 -1 minecraft:deepslate_tiles
setblock 177 67 0 minecraft:orange_stained_glass
setblock 207 67 0 minecraft:orange_stained_glass
setblock 176 67 0 minecraft:sea_lantern
setblock 208 67 0 minecraft:sea_lantern
setblock 176 67 1 minecraft:deepslate_tiles
setblock 208 67 1 minecraft:deepslate_tiles
setblock 176 67 2 minecraft:deepslate_tiles
setblock 208 67 2 minecraft:deepslate_tiles
setblock 179 67 2 minecraft:polished_blackstone_bricks
setblock 205 67 2 minecraft:polished_blackstone_bricks
setblock 176 67 3 minecraft:deepslate_tiles
setblock 208 67 3 minecraft:deepslate_tiles
setblock 179 67 3 minecraft:polished_blackstone_bricks
setblock 205 67 3 minecraft:polished_blackstone_bricks
setblock 180 67 3 minecraft:sea_lantern
setblock 204 67 3 minecraft:sea_lantern
setblock 176 67 4 minecraft:deepslate_tiles
setblock 208 67 4 minecraft:deepslate_tiles
setblock 179 67 4 minecraft:polished_blackstone_bricks
setblock 205 67 4 minecraft:polished_blackstone_bricks
setblock 176 67 5 minecraft:deepslate_tiles
setblock 208 67 5 minecraft:deepslate_tiles
setblock 177 67 6 minecraft:orange_stained_glass
setblock 207 67 6 minecraft:orange_stained_glass
setblock 176 67 6 minecraft:sea_lantern
setblock 208 67 6 minecraft:sea_lantern
setblock 176 67 7 minecraft:deepslate_tiles
setblock 208 67 7 minecraft:deepslate_tiles
setblock 206 67 7 minecraft:polished_blackstone_bricks
setblock 176 67 8 minecraft:deepslate_tiles
setblock 208 67 8 minecraft:deepslate_tiles
setblock 206 67 8 minecraft:polished_blackstone_bricks
setblock 205 67 8 minecraft:small_amethyst_bud[facing=up,waterlogged=false]
setblock 176 67 9 minecraft:deepslate_tiles
setblock 208 67 9 minecraft:deepslate_tiles
setblock 206 67 9 minecraft:polished_blackstone_bricks
setblock 176 67 10 minecraft:deepslate_tiles
setblock 208 67 10 minecraft:deepslate_tiles
setblock 176 67 11 minecraft:deepslate_tiles
setblock 208 67 11 minecraft:deepslate_tiles
setblock 177 67 12 minecraft:orange_stained_glass
setblock 207 67 12 minecraft:orange_stained_glass
setblock 176 67 12 minecraft:sea_lantern
setblock 208 67 12 minecraft:sea_lantern
setblock 176 67 13 minecraft:deepslate_tiles
setblock 208 67 13 minecraft:deepslate_tiles
setblock 176 67 14 minecraft:deepslate_tiles
setblock 208 67 14 minecraft:deepslate_tiles
setblock 176 67 15 minecraft:deepslate_tiles
setblock 208 67 15 minecraft:deepslate_tiles
setblock 180 67 15 minecraft:orange_stained_glass
setblock 186 67 15 minecraft:orange_stained_glass
setblock 192 67 15 minecraft:orange_stained_glass
setblock 198 67 15 minecraft:orange_stained_glass
setblock 204 67 15 minecraft:orange_stained_glass
fill 176 67 16 179 67 16 minecraft:deepslate_tiles
fill 181 67 16 185 67 16 minecraft:deepslate_tiles
fill 187 67 16 191 67 16 minecraft:deepslate_tiles
fill 193 67 16 197 67 16 minecraft:deepslate_tiles
fill 199 67 16 203 67 16 minecraft:deepslate_tiles
fill 205 67 16 208 67 16 minecraft:deepslate_tiles
setblock 180 67 16 minecraft:sea_lantern
setblock 186 67 16 minecraft:sea_lantern
setblock 192 67 16 minecraft:sea_lantern
setblock 198 67 16 minecraft:sea_lantern
setblock 204 67 16 minecraft:sea_lantern
fill 176 68 -16 179 68 -16 minecraft:deepslate_tiles
fill 181 68 -16 185 68 -16 minecraft:deepslate_tiles
fill 187 68 -16 191 68 -16 minecraft:deepslate_tiles
fill 193 68 -16 197 68 -16 minecraft:deepslate_tiles
fill 199 68 -16 203 68 -16 minecraft:deepslate_tiles
fill 205 68 -16 208 68 -16 minecraft:deepslate_tiles
setblock 180 68 -16 minecraft:sea_lantern
setblock 186 68 -16 minecraft:sea_lantern
setblock 192 68 -16 minecraft:sea_lantern
setblock 198 68 -16 minecraft:sea_lantern
setblock 204 68 -16 minecraft:sea_lantern
setblock 176 68 -15 minecraft:deepslate_tiles
setblock 208 68 -15 minecraft:deepslate_tiles
setblock 180 68 -15 minecraft:orange_stained_glass
setblock 186 68 -15 minecraft:orange_stained_glass
setblock 192 68 -15 minecraft:orange_stained_glass
setblock 198 68 -15 minecraft:orange_stained_glass
setblock 204 68 -15 minecraft:orange_stained_glass
setblock 176 68 -14 minecraft:deepslate_tiles
setblock 208 68 -14 minecraft:deepslate_tiles
setblock 176 68 -13 minecraft:deepslate_tiles
setblock 208 68 -13 minecraft:deepslate_tiles
setblock 177 68 -12 minecraft:orange_stained_glass
setblock 207 68 -12 minecraft:orange_stained_glass
setblock 176 68 -12 minecraft:sea_lantern
setblock 208 68 -12 minecraft:sea_lantern
setblock 176 68 -11 minecraft:deepslate_tiles
setblock 208 68 -11 minecraft:deepslate_tiles
setblock 176 68 -10 minecraft:deepslate_tiles
setblock 208 68 -10 minecraft:deepslate_tiles
setblock 179 68 -10 minecraft:polished_blackstone_bricks
setblock 205 68 -10 minecraft:polished_blackstone_bricks
setblock 176 68 -9 minecraft:deepslate_tiles
setblock 208 68 -9 minecraft:deepslate_tiles
setblock 179 68 -9 minecraft:polished_blackstone_bricks
setblock 205 68 -9 minecraft:polished_blackstone_bricks
setblock 176 68 -8 minecraft:deepslate_tiles
setblock 208 68 -8 minecraft:deepslate_tiles
setblock 179 68 -8 minecraft:polished_blackstone_bricks
setblock 205 68 -8 minecraft:polished_blackstone_bricks
setblock 176 68 -7 minecraft:deepslate_tiles
setblock 208 68 -7 minecraft:deepslate_tiles
setblock 177 68 -6 minecraft:orange_stained_glass
setblock 207 68 -6 minecraft:orange_stained_glass
setblock 176 68 -6 minecraft:sea_lantern
setblock 208 68 -6 minecraft:sea_lantern
setblock 176 68 -5 minecraft:deepslate_tiles
setblock 208 68 -5 minecraft:deepslate_tiles
setblock 176 68 -4 minecraft:deepslate_tiles
setblock 208 68 -4 minecraft:deepslate_tiles
setblock 179 68 -4 minecraft:polished_blackstone_bricks
setblock 205 68 -4 minecraft:polished_blackstone_bricks
setblock 176 68 -3 minecraft:deepslate_tiles
setblock 208 68 -3 minecraft:deepslate_tiles
setblock 179 68 -3 minecraft:polished_blackstone_bricks
setblock 205 68 -3 minecraft:polished_blackstone_bricks
setblock 176 68 -2 minecraft:deepslate_tiles
setblock 208 68 -2 minecraft:deepslate_tiles
setblock 179 68 -2 minecraft:polished_blackstone_bricks
setblock 205 68 -2 minecraft:polished_blackstone_bricks
setblock 176 68 -1 minecraft:deepslate_tiles
setblock 208 68 -1 minecraft:deepslate_tiles
setblock 177 68 0 minecraft:orange_stained_glass
setblock 207 68 0 minecraft:orange_stained_glass
setblock 176 68 0 minecraft:sea_lantern
setblock 208 68 0 minecraft:sea_lantern
setblock 176 68 1 minecraft:deepslate_tiles
setblock 208 68 1 minecraft:deepslate_tiles
setblock 176 68 2 minecraft:deepslate_tiles
setblock 208 68 2 minecraft:deepslate_tiles
setblock 179 68 2 minecraft:polished_blackstone_bricks
setblock 205 68 2 minecraft:polished_blackstone_bricks
setblock 176 68 3 minecraft:deepslate_tiles
setblock 208 68 3 minecraft:deepslate_tiles
setblock 179 68 3 minecraft:polished_blackstone_bricks
setblock 205 68 3 minecraft:polished_blackstone_bricks
setblock 176 68 4 minecraft:deepslate_tiles
setblock 208 68 4 minecraft:deepslate_tiles
setblock 179 68 4 minecraft:polished_blackstone_bricks
setblock 205 68 4 minecraft:polished_blackstone_bricks
setblock 176 68 5 minecraft:deepslate_tiles
setblock 208 68 5 minecraft:deepslate_tiles
setblock 177 68 6 minecraft:orange_stained_glass
setblock 207 68 6 minecraft:orange_stained_glass
setblock 176 68 6 minecraft:sea_lantern
setblock 208 68 6 minecraft:sea_lantern
setblock 176 68 7 minecraft:deepslate_tiles
setblock 208 68 7 minecraft:deepslate_tiles
setblock 206 68 7 minecraft:polished_blackstone_bricks
setblock 176 68 8 minecraft:deepslate_tiles
setblock 208 68 8 minecraft:deepslate_tiles
setblock 206 68 8 minecraft:polished_blackstone_bricks
setblock 176 68 9 minecraft:deepslate_tiles
setblock 208 68 9 minecraft:deepslate_tiles
setblock 206 68 9 minecraft:polished_blackstone_bricks
setblock 176 68 10 minecraft:deepslate_tiles
setblock 208 68 10 minecraft:deepslate_tiles
setblock 176 68 11 minecraft:deepslate_tiles
setblock 208 68 11 minecraft:deepslate_tiles
setblock 177 68 12 minecraft:orange_stained_glass
setblock 207 68 12 minecraft:orange_stained_glass
setblock 176 68 12 minecraft:sea_lantern
setblock 208 68 12 minecraft:sea_lantern
setblock 176 68 13 minecraft:deepslate_tiles
setblock 208 68 13 minecraft:deepslate_tiles
setblock 176 68 14 minecraft:deepslate_tiles
setblock 208 68 14 minecraft:deepslate_tiles
setblock 176 68 15 minecraft:deepslate_tiles
setblock 208 68 15 minecraft:deepslate_tiles
setblock 180 68 15 minecraft:orange_stained_glass
setblock 186 68 15 minecraft:orange_stained_glass
setblock 192 68 15 minecraft:orange_stained_glass
setblock 198 68 15 minecraft:orange_stained_glass
setblock 204 68 15 minecraft:orange_stained_glass
fill 176 68 16 179 68 16 minecraft:deepslate_tiles
fill 181 68 16 185 68 16 minecraft:deepslate_tiles
fill 187 68 16 191 68 16 minecraft:deepslate_tiles
fill 193 68 16 197 68 16 minecraft:deepslate_tiles
fill 199 68 16 203 68 16 minecraft:deepslate_tiles
fill 205 68 16 208 68 16 minecraft:deepslate_tiles
setblock 180 68 16 minecraft:sea_lantern
setblock 186 68 16 minecraft:sea_lantern
setblock 192 68 16 minecraft:sea_lantern
setblock 198 68 16 minecraft:sea_lantern
setblock 204 68 16 minecraft:sea_lantern
fill 176 69 -16 179 69 -16 minecraft:deepslate_tiles
fill 181 69 -16 185 69 -16 minecraft:deepslate_tiles
fill 187 69 -16 191 69 -16 minecraft:deepslate_tiles
fill 193 69 -16 197 69 -16 minecraft:deepslate_tiles
fill 199 69 -16 203 69 -16 minecraft:deepslate_tiles
fill 205 69 -16 208 69 -16 minecraft:deepslate_tiles
setblock 180 69 -16 minecraft:sea_lantern
setblock 186 69 -16 minecraft:sea_lantern
setblock 192 69 -16 minecraft:sea_lantern
setblock 198 69 -16 minecraft:sea_lantern
setblock 204 69 -16 minecraft:sea_lantern
setblock 176 69 -15 minecraft:deepslate_tiles
setblock 208 69 -15 minecraft:deepslate_tiles
setblock 180 69 -15 minecraft:orange_stained_glass
setblock 186 69 -15 minecraft:orange_stained_glass
setblock 192 69 -15 minecraft:orange_stained_glass
setblock 198 69 -15 minecraft:orange_stained_glass
setblock 204 69 -15 minecraft:orange_stained_glass
setblock 176 69 -14 minecraft:deepslate_tiles
setblock 208 69 -14 minecraft:deepslate_tiles
setblock 176 69 -13 minecraft:deepslate_tiles
setblock 208 69 -13 minecraft:deepslate_tiles
fill 182 69 -13 186 69 -13 minecraft:polished_blackstone
fill 190 69 -13 194 69 -13 minecraft:polished_blackstone
fill 198 69 -13 202 69 -13 minecraft:polished_blackstone
setblock 177 69 -12 minecraft:orange_stained_glass
setblock 207 69 -12 minecraft:orange_stained_glass
fill 182 69 -12 186 69 -12 minecraft:polished_blackstone
fill 190 69 -12 194 69 -12 minecraft:polished_blackstone
fill 198 69 -12 202 69 -12 minecraft:polished_blackstone
setblock 176 69 -12 minecraft:sea_lantern
setblock 208 69 -12 minecraft:sea_lantern
setblock 176 69 -11 minecraft:deepslate_tiles
setblock 208 69 -11 minecraft:deepslate_tiles
setblock 176 69 -10 minecraft:deepslate_tiles
setblock 208 69 -10 minecraft:deepslate_tiles
setblock 179 69 -10 minecraft:polished_blackstone_bricks
setblock 205 69 -10 minecraft:polished_blackstone_bricks
setblock 176 69 -9 minecraft:deepslate_tiles
setblock 208 69 -9 minecraft:deepslate_tiles
setblock 179 69 -9 minecraft:polished_blackstone_bricks
setblock 205 69 -9 minecraft:polished_blackstone_bricks
setblock 180 69 -9 minecraft:sea_lantern
setblock 204 69 -9 minecraft:sea_lantern
setblock 176 69 -8 minecraft:deepslate_tiles
setblock 208 69 -8 minecraft:deepslate_tiles
setblock 179 69 -8 minecraft:polished_blackstone_bricks
setblock 205 69 -8 minecraft:polished_blackstone_bricks
setblock 176 69 -7 minecraft:deepslate_tiles
setblock 208 69 -7 minecraft:deepslate_tiles
setblock 177 69 -6 minecraft:orange_stained_glass
setblock 207 69 -6 minecraft:orange_stained_glass
setblock 176 69 -6 minecraft:sea_lantern
setblock 208 69 -6 minecraft:sea_lantern
setblock 176 69 -5 minecraft:deepslate_tiles
setblock 208 69 -5 minecraft:deepslate_tiles
setblock 176 69 -4 minecraft:deepslate_tiles
setblock 208 69 -4 minecraft:deepslate_tiles
setblock 179 69 -4 minecraft:polished_blackstone_bricks
setblock 205 69 -4 minecraft:polished_blackstone_bricks
setblock 176 69 -3 minecraft:deepslate_tiles
setblock 208 69 -3 minecraft:deepslate_tiles
setblock 179 69 -3 minecraft:polished_blackstone_bricks
setblock 205 69 -3 minecraft:polished_blackstone_bricks
setblock 180 69 -3 minecraft:sea_lantern
setblock 204 69 -3 minecraft:sea_lantern
setblock 176 69 -2 minecraft:deepslate_tiles
setblock 208 69 -2 minecraft:deepslate_tiles
setblock 179 69 -2 minecraft:polished_blackstone_bricks
setblock 205 69 -2 minecraft:polished_blackstone_bricks
setblock 176 69 -1 minecraft:deepslate_tiles
setblock 208 69 -1 minecraft:deepslate_tiles
setblock 177 69 0 minecraft:orange_stained_glass
setblock 207 69 0 minecraft:orange_stained_glass
setblock 176 69 0 minecraft:sea_lantern
setblock 208 69 0 minecraft:sea_lantern
setblock 176 69 1 minecraft:deepslate_tiles
setblock 208 69 1 minecraft:deepslate_tiles
setblock 176 69 2 minecraft:deepslate_tiles
setblock 208 69 2 minecraft:deepslate_tiles
setblock 179 69 2 minecraft:polished_blackstone_bricks
setblock 205 69 2 minecraft:polished_blackstone_bricks
setblock 176 69 3 minecraft:deepslate_tiles
setblock 208 69 3 minecraft:deepslate_tiles
setblock 179 69 3 minecraft:polished_blackstone_bricks
setblock 205 69 3 minecraft:polished_blackstone_bricks
setblock 180 69 3 minecraft:sea_lantern
setblock 204 69 3 minecraft:sea_lantern
setblock 176 69 4 minecraft:deepslate_tiles
setblock 208 69 4 minecraft:deepslate_tiles
setblock 179 69 4 minecraft:polished_blackstone_bricks
setblock 205 69 4 minecraft:polished_blackstone_bricks
setblock 176 69 5 minecraft:deepslate_tiles
setblock 208 69 5 minecraft:deepslate_tiles
setblock 177 69 6 minecraft:orange_stained_glass
setblock 207 69 6 minecraft:orange_stained_glass
setblock 176 69 6 minecraft:sea_lantern
setblock 208 69 6 minecraft:sea_lantern
setblock 176 69 7 minecraft:deepslate_tiles
setblock 208 69 7 minecraft:deepslate_tiles
setblock 176 69 8 minecraft:deepslate_tiles
setblock 208 69 8 minecraft:deepslate_tiles
setblock 176 69 9 minecraft:deepslate_tiles
setblock 208 69 9 minecraft:deepslate_tiles
setblock 176 69 10 minecraft:deepslate_tiles
setblock 208 69 10 minecraft:deepslate_tiles
setblock 176 69 11 minecraft:deepslate_tiles
setblock 208 69 11 minecraft:deepslate_tiles
setblock 177 69 12 minecraft:orange_stained_glass
setblock 207 69 12 minecraft:orange_stained_glass
setblock 176 69 12 minecraft:sea_lantern
setblock 208 69 12 minecraft:sea_lantern
setblock 176 69 13 minecraft:deepslate_tiles
setblock 208 69 13 minecraft:deepslate_tiles
setblock 176 69 14 minecraft:deepslate_tiles
setblock 208 69 14 minecraft:deepslate_tiles
setblock 176 69 15 minecraft:deepslate_tiles
setblock 208 69 15 minecraft:deepslate_tiles
setblock 180 69 15 minecraft:orange_stained_glass
setblock 186 69 15 minecraft:orange_stained_glass
setblock 192 69 15 minecraft:orange_stained_glass
setblock 198 69 15 minecraft:orange_stained_glass
setblock 204 69 15 minecraft:orange_stained_glass
fill 176 69 16 179 69 16 minecraft:deepslate_tiles
fill 181 69 16 185 69 16 minecraft:deepslate_tiles
fill 187 69 16 191 69 16 minecraft:deepslate_tiles
fill 193 69 16 197 69 16 minecraft:deepslate_tiles
fill 199 69 16 203 69 16 minecraft:deepslate_tiles
fill 205 69 16 208 69 16 minecraft:deepslate_tiles
setblock 180 69 16 minecraft:sea_lantern
setblock 186 69 16 minecraft:sea_lantern
setblock 192 69 16 minecraft:sea_lantern
setblock 198 69 16 minecraft:sea_lantern
setblock 204 69 16 minecraft:sea_lantern
fill 176 70 -16 179 70 -16 minecraft:deepslate_tiles
fill 181 70 -16 185 70 -16 minecraft:deepslate_tiles
fill 187 70 -16 191 70 -16 minecraft:deepslate_tiles
fill 193 70 -16 197 70 -16 minecraft:deepslate_tiles
fill 199 70 -16 203 70 -16 minecraft:deepslate_tiles
fill 205 70 -16 208 70 -16 minecraft:deepslate_tiles
setblock 180 70 -16 minecraft:sea_lantern
setblock 186 70 -16 minecraft:sea_lantern
setblock 192 70 -16 minecraft:sea_lantern
setblock 198 70 -16 minecraft:sea_lantern
setblock 204 70 -16 minecraft:sea_lantern
setblock 176 70 -15 minecraft:deepslate_tiles
setblock 208 70 -15 minecraft:deepslate_tiles
setblock 180 70 -15 minecraft:orange_stained_glass
setblock 186 70 -15 minecraft:orange_stained_glass
setblock 192 70 -15 minecraft:orange_stained_glass
setblock 198 70 -15 minecraft:orange_stained_glass
setblock 204 70 -15 minecraft:orange_stained_glass
setblock 176 70 -14 minecraft:deepslate_tiles
setblock 208 70 -14 minecraft:deepslate_tiles
setblock 176 70 -13 minecraft:deepslate_tiles
setblock 208 70 -13 minecraft:deepslate_tiles
fill 182 70 -13 186 70 -13 minecraft:polished_blackstone
fill 190 70 -13 194 70 -13 minecraft:polished_blackstone
fill 198 70 -13 202 70 -13 minecraft:polished_blackstone
setblock 177 70 -12 minecraft:orange_stained_glass
setblock 207 70 -12 minecraft:orange_stained_glass
setblock 182 70 -12 minecraft:polished_blackstone
setblock 186 70 -12 minecraft:polished_blackstone
setblock 190 70 -12 minecraft:polished_blackstone
setblock 194 70 -12 minecraft:polished_blackstone
setblock 198 70 -12 minecraft:polished_blackstone
setblock 202 70 -12 minecraft:polished_blackstone
setblock 176 70 -12 minecraft:sea_lantern
fill 183 70 -12 185 70 -12 minecraft:sea_lantern
fill 191 70 -12 193 70 -12 minecraft:sea_lantern
fill 199 70 -12 201 70 -12 minecraft:sea_lantern
setblock 208 70 -12 minecraft:sea_lantern
setblock 176 70 -11 minecraft:deepslate_tiles
setblock 208 70 -11 minecraft:deepslate_tiles
fill 183 70 -11 185 70 -11 minecraft:orange_stained_glass
fill 191 70 -11 193 70 -11 minecraft:orange_stained_glass
fill 199 70 -11 201 70 -11 minecraft:orange_stained_glass
setblock 176 70 -10 minecraft:deepslate_tiles
setblock 208 70 -10 minecraft:deepslate_tiles
setblock 179 70 -10 minecraft:polished_blackstone_bricks
setblock 205 70 -10 minecraft:polished_blackstone_bricks
setblock 176 70 -9 minecraft:deepslate_tiles
setblock 208 70 -9 minecraft:deepslate_tiles
setblock 179 70 -9 minecraft:polished_blackstone_bricks
setblock 205 70 -9 minecraft:polished_blackstone_bricks
setblock 176 70 -8 minecraft:deepslate_tiles
setblock 208 70 -8 minecraft:deepslate_tiles
setblock 179 70 -8 minecraft:polished_blackstone_bricks
setblock 205 70 -8 minecraft:polished_blackstone_bricks
setblock 176 70 -7 minecraft:deepslate_tiles
setblock 208 70 -7 minecraft:deepslate_tiles
setblock 177 70 -6 minecraft:orange_stained_glass
setblock 207 70 -6 minecraft:orange_stained_glass
setblock 176 70 -6 minecraft:sea_lantern
setblock 208 70 -6 minecraft:sea_lantern
setblock 176 70 -5 minecraft:deepslate_tiles
setblock 208 70 -5 minecraft:deepslate_tiles
setblock 176 70 -4 minecraft:deepslate_tiles
setblock 208 70 -4 minecraft:deepslate_tiles
setblock 179 70 -4 minecraft:polished_blackstone_bricks
setblock 205 70 -4 minecraft:polished_blackstone_bricks
setblock 176 70 -3 minecraft:deepslate_tiles
setblock 208 70 -3 minecraft:deepslate_tiles
setblock 179 70 -3 minecraft:polished_blackstone_bricks
setblock 205 70 -3 minecraft:polished_blackstone_bricks
setblock 176 70 -2 minecraft:deepslate_tiles
setblock 208 70 -2 minecraft:deepslate_tiles
setblock 179 70 -2 minecraft:polished_blackstone_bricks
setblock 205 70 -2 minecraft:polished_blackstone_bricks
setblock 176 70 -1 minecraft:deepslate_tiles
setblock 208 70 -1 minecraft:deepslate_tiles
setblock 177 70 0 minecraft:orange_stained_glass
setblock 207 70 0 minecraft:orange_stained_glass
setblock 176 70 0 minecraft:sea_lantern
setblock 208 70 0 minecraft:sea_lantern
setblock 176 70 1 minecraft:deepslate_tiles
setblock 208 70 1 minecraft:deepslate_tiles
setblock 176 70 2 minecraft:deepslate_tiles
setblock 208 70 2 minecraft:deepslate_tiles
setblock 179 70 2 minecraft:polished_blackstone_bricks
setblock 205 70 2 minecraft:polished_blackstone_bricks
setblock 176 70 3 minecraft:deepslate_tiles
setblock 208 70 3 minecraft:deepslate_tiles
setblock 179 70 3 minecraft:polished_blackstone_bricks
setblock 205 70 3 minecraft:polished_blackstone_bricks
setblock 176 70 4 minecraft:deepslate_tiles
setblock 208 70 4 minecraft:deepslate_tiles
setblock 179 70 4 minecraft:polished_blackstone_bricks
setblock 205 70 4 minecraft:polished_blackstone_bricks
setblock 176 70 5 minecraft:deepslate_tiles
setblock 208 70 5 minecraft:deepslate_tiles
setblock 177 70 6 minecraft:orange_stained_glass
setblock 207 70 6 minecraft:orange_stained_glass
setblock 176 70 6 minecraft:sea_lantern
setblock 208 70 6 minecraft:sea_lantern
setblock 176 70 7 minecraft:deepslate_tiles
setblock 208 70 7 minecraft:deepslate_tiles
setblock 176 70 8 minecraft:deepslate_tiles
setblock 208 70 8 minecraft:deepslate_tiles
setblock 176 70 9 minecraft:deepslate_tiles
setblock 208 70 9 minecraft:deepslate_tiles
setblock 176 70 10 minecraft:deepslate_tiles
setblock 208 70 10 minecraft:deepslate_tiles
setblock 176 70 11 minecraft:deepslate_tiles
setblock 208 70 11 minecraft:deepslate_tiles
setblock 177 70 12 minecraft:orange_stained_glass
setblock 207 70 12 minecraft:orange_stained_glass
setblock 176 70 12 minecraft:sea_lantern
setblock 208 70 12 minecraft:sea_lantern
setblock 176 70 13 minecraft:deepslate_tiles
setblock 208 70 13 minecraft:deepslate_tiles
setblock 176 70 14 minecraft:deepslate_tiles
setblock 208 70 14 minecraft:deepslate_tiles
setblock 176 70 15 minecraft:deepslate_tiles
setblock 208 70 15 minecraft:deepslate_tiles
setblock 180 70 15 minecraft:orange_stained_glass
setblock 186 70 15 minecraft:orange_stained_glass
setblock 192 70 15 minecraft:orange_stained_glass
setblock 198 70 15 minecraft:orange_stained_glass
setblock 204 70 15 minecraft:orange_stained_glass
fill 176 70 16 179 70 16 minecraft:deepslate_tiles
fill 181 70 16 185 70 16 minecraft:deepslate_tiles
fill 187 70 16 191 70 16 minecraft:deepslate_tiles
fill 193 70 16 197 70 16 minecraft:deepslate_tiles
fill 199 70 16 203 70 16 minecraft:deepslate_tiles
fill 205 70 16 208 70 16 minecraft:deepslate_tiles
setblock 180 70 16 minecraft:sea_lantern
setblock 186 70 16 minecraft:sea_lantern
setblock 192 70 16 minecraft:sea_lantern
setblock 198 70 16 minecraft:sea_lantern
setblock 204 70 16 minecraft:sea_lantern
fill 176 71 -16 179 71 -16 minecraft:deepslate_tiles
fill 181 71 -16 185 71 -16 minecraft:deepslate_tiles
fill 187 71 -16 191 71 -16 minecraft:deepslate_tiles
fill 193 71 -16 197 71 -16 minecraft:deepslate_tiles
fill 199 71 -16 203 71 -16 minecraft:deepslate_tiles
fill 205 71 -16 208 71 -16 minecraft:deepslate_tiles
setblock 180 71 -16 minecraft:sea_lantern
setblock 186 71 -16 minecraft:sea_lantern
setblock 192 71 -16 minecraft:sea_lantern
setblock 198 71 -16 minecraft:sea_lantern
setblock 204 71 -16 minecraft:sea_lantern
setblock 176 71 -15 minecraft:deepslate_tiles
setblock 208 71 -15 minecraft:deepslate_tiles
setblock 180 71 -15 minecraft:orange_stained_glass
setblock 186 71 -15 minecraft:orange_stained_glass
setblock 192 71 -15 minecraft:orange_stained_glass
setblock 198 71 -15 minecraft:orange_stained_glass
setblock 204 71 -15 minecraft:orange_stained_glass
setblock 176 71 -14 minecraft:deepslate_tiles
setblock 208 71 -14 minecraft:deepslate_tiles
setblock 176 71 -13 minecraft:deepslate_tiles
setblock 208 71 -13 minecraft:deepslate_tiles
fill 182 71 -13 186 71 -13 minecraft:polished_blackstone
fill 190 71 -13 194 71 -13 minecraft:polished_blackstone
fill 198 71 -13 202 71 -13 minecraft:polished_blackstone
setblock 177 71 -12 minecraft:orange_stained_glass
setblock 207 71 -12 minecraft:orange_stained_glass
setblock 182 71 -12 minecraft:polished_blackstone
setblock 186 71 -12 minecraft:polished_blackstone
setblock 190 71 -12 minecraft:polished_blackstone
setblock 194 71 -12 minecraft:polished_blackstone
setblock 198 71 -12 minecraft:polished_blackstone
setblock 202 71 -12 minecraft:polished_blackstone
setblock 176 71 -12 minecraft:sea_lantern
fill 183 71 -12 185 71 -12 minecraft:sea_lantern
fill 191 71 -12 193 71 -12 minecraft:sea_lantern
fill 199 71 -12 201 71 -12 minecraft:sea_lantern
setblock 208 71 -12 minecraft:sea_lantern
setblock 176 71 -11 minecraft:deepslate_tiles
setblock 208 71 -11 minecraft:deepslate_tiles
fill 183 71 -11 185 71 -11 minecraft:orange_stained_glass
fill 191 71 -11 193 71 -11 minecraft:orange_stained_glass
fill 199 71 -11 201 71 -11 minecraft:orange_stained_glass
setblock 176 71 -10 minecraft:deepslate_tiles
setblock 208 71 -10 minecraft:deepslate_tiles
setblock 176 71 -9 minecraft:deepslate_tiles
setblock 208 71 -9 minecraft:deepslate_tiles
setblock 176 71 -8 minecraft:deepslate_tiles
setblock 208 71 -8 minecraft:deepslate_tiles
setblock 176 71 -7 minecraft:deepslate_tiles
setblock 208 71 -7 minecraft:deepslate_tiles
setblock 177 71 -6 minecraft:orange_stained_glass
setblock 207 71 -6 minecraft:orange_stained_glass
setblock 176 71 -6 minecraft:sea_lantern
setblock 208 71 -6 minecraft:sea_lantern
setblock 176 71 -5 minecraft:deepslate_tiles
setblock 208 71 -5 minecraft:deepslate_tiles
setblock 176 71 -4 minecraft:deepslate_tiles
setblock 208 71 -4 minecraft:deepslate_tiles
setblock 176 71 -3 minecraft:deepslate_tiles
setblock 208 71 -3 minecraft:deepslate_tiles
setblock 176 71 -2 minecraft:deepslate_tiles
setblock 208 71 -2 minecraft:deepslate_tiles
setblock 176 71 -1 minecraft:deepslate_tiles
setblock 208 71 -1 minecraft:deepslate_tiles
setblock 177 71 0 minecraft:orange_stained_glass
setblock 207 71 0 minecraft:orange_stained_glass
setblock 176 71 0 minecraft:sea_lantern
setblock 208 71 0 minecraft:sea_lantern
setblock 176 71 1 minecraft:deepslate_tiles
setblock 208 71 1 minecraft:deepslate_tiles
setblock 176 71 2 minecraft:deepslate_tiles
setblock 208 71 2 minecraft:deepslate_tiles
setblock 176 71 3 minecraft:deepslate_tiles
setblock 208 71 3 minecraft:deepslate_tiles
setblock 176 71 4 minecraft:deepslate_tiles
setblock 208 71 4 minecraft:deepslate_tiles
setblock 176 71 5 minecraft:deepslate_tiles
setblock 208 71 5 minecraft:deepslate_tiles
setblock 177 71 6 minecraft:orange_stained_glass
setblock 207 71 6 minecraft:orange_stained_glass
setblock 176 71 6 minecraft:sea_lantern
setblock 208 71 6 minecraft:sea_lantern
setblock 176 71 7 minecraft:deepslate_tiles
setblock 208 71 7 minecraft:deepslate_tiles
setblock 176 71 8 minecraft:deepslate_tiles
setblock 208 71 8 minecraft:deepslate_tiles
setblock 176 71 9 minecraft:deepslate_tiles
setblock 208 71 9 minecraft:deepslate_tiles
setblock 176 71 10 minecraft:deepslate_tiles
setblock 208 71 10 minecraft:deepslate_tiles
setblock 176 71 11 minecraft:deepslate_tiles
setblock 208 71 11 minecraft:deepslate_tiles
setblock 177 71 12 minecraft:orange_stained_glass
setblock 207 71 12 minecraft:orange_stained_glass
setblock 176 71 12 minecraft:sea_lantern
setblock 208 71 12 minecraft:sea_lantern
setblock 176 71 13 minecraft:deepslate_tiles
setblock 208 71 13 minecraft:deepslate_tiles
setblock 176 71 14 minecraft:deepslate_tiles
setblock 208 71 14 minecraft:deepslate_tiles
setblock 176 71 15 minecraft:deepslate_tiles
setblock 208 71 15 minecraft:deepslate_tiles
setblock 180 71 15 minecraft:orange_stained_glass
setblock 186 71 15 minecraft:orange_stained_glass
setblock 192 71 15 minecraft:orange_stained_glass
setblock 198 71 15 minecraft:orange_stained_glass
setblock 204 71 15 minecraft:orange_stained_glass
fill 176 71 16 179 71 16 minecraft:deepslate_tiles
fill 181 71 16 185 71 16 minecraft:deepslate_tiles
fill 187 71 16 191 71 16 minecraft:deepslate_tiles
fill 193 71 16 197 71 16 minecraft:deepslate_tiles
fill 199 71 16 203 71 16 minecraft:deepslate_tiles
fill 205 71 16 208 71 16 minecraft:deepslate_tiles
setblock 180 71 16 minecraft:sea_lantern
setblock 186 71 16 minecraft:sea_lantern
setblock 192 71 16 minecraft:sea_lantern
setblock 198 71 16 minecraft:sea_lantern
setblock 204 71 16 minecraft:sea_lantern
fill 176 72 -16 179 72 -16 minecraft:deepslate_tiles
fill 181 72 -16 185 72 -16 minecraft:deepslate_tiles
fill 187 72 -16 191 72 -16 minecraft:deepslate_tiles
fill 193 72 -16 197 72 -16 minecraft:deepslate_tiles
fill 199 72 -16 203 72 -16 minecraft:deepslate_tiles
fill 205 72 -16 208 72 -16 minecraft:deepslate_tiles
setblock 180 72 -16 minecraft:sea_lantern
setblock 186 72 -16 minecraft:sea_lantern
setblock 192 72 -16 minecraft:sea_lantern
setblock 198 72 -16 minecraft:sea_lantern
setblock 204 72 -16 minecraft:sea_lantern
setblock 176 72 -15 minecraft:deepslate_tiles
setblock 208 72 -15 minecraft:deepslate_tiles
setblock 180 72 -15 minecraft:orange_stained_glass
setblock 186 72 -15 minecraft:orange_stained_glass
setblock 192 72 -15 minecraft:orange_stained_glass
setblock 198 72 -15 minecraft:orange_stained_glass
setblock 204 72 -15 minecraft:orange_stained_glass
setblock 176 72 -14 minecraft:deepslate_tiles
setblock 208 72 -14 minecraft:deepslate_tiles
setblock 176 72 -13 minecraft:deepslate_tiles
setblock 208 72 -13 minecraft:deepslate_tiles
fill 182 72 -13 186 72 -13 minecraft:polished_blackstone
fill 190 72 -13 194 72 -13 minecraft:polished_blackstone
fill 198 72 -13 202 72 -13 minecraft:polished_blackstone
setblock 177 72 -12 minecraft:orange_stained_glass
setblock 207 72 -12 minecraft:orange_stained_glass
fill 182 72 -12 186 72 -12 minecraft:polished_blackstone
fill 190 72 -12 194 72 -12 minecraft:polished_blackstone
fill 198 72 -12 202 72 -12 minecraft:polished_blackstone
setblock 176 72 -12 minecraft:sea_lantern
setblock 208 72 -12 minecraft:sea_lantern
setblock 176 72 -11 minecraft:deepslate_tiles
setblock 208 72 -11 minecraft:deepslate_tiles
setblock 176 72 -10 minecraft:deepslate_tiles
setblock 208 72 -10 minecraft:deepslate_tiles
setblock 176 72 -9 minecraft:deepslate_tiles
setblock 208 72 -9 minecraft:deepslate_tiles
setblock 176 72 -8 minecraft:deepslate_tiles
setblock 208 72 -8 minecraft:deepslate_tiles
setblock 176 72 -7 minecraft:deepslate_tiles
setblock 208 72 -7 minecraft:deepslate_tiles
setblock 177 72 -6 minecraft:orange_stained_glass
setblock 207 72 -6 minecraft:orange_stained_glass
setblock 176 72 -6 minecraft:sea_lantern
setblock 208 72 -6 minecraft:sea_lantern
setblock 176 72 -5 minecraft:deepslate_tiles
setblock 208 72 -5 minecraft:deepslate_tiles
setblock 176 72 -4 minecraft:deepslate_tiles
setblock 208 72 -4 minecraft:deepslate_tiles
setblock 176 72 -3 minecraft:deepslate_tiles
setblock 208 72 -3 minecraft:deepslate_tiles
setblock 176 72 -2 minecraft:deepslate_tiles
setblock 208 72 -2 minecraft:deepslate_tiles
setblock 176 72 -1 minecraft:deepslate_tiles
setblock 208 72 -1 minecraft:deepslate_tiles
setblock 177 72 0 minecraft:orange_stained_glass
setblock 207 72 0 minecraft:orange_stained_glass
setblock 176 72 0 minecraft:sea_lantern
setblock 208 72 0 minecraft:sea_lantern
setblock 176 72 1 minecraft:deepslate_tiles
setblock 208 72 1 minecraft:deepslate_tiles
setblock 176 72 2 minecraft:deepslate_tiles
setblock 208 72 2 minecraft:deepslate_tiles
setblock 176 72 3 minecraft:deepslate_tiles
setblock 208 72 3 minecraft:deepslate_tiles
setblock 176 72 4 minecraft:deepslate_tiles
setblock 208 72 4 minecraft:deepslate_tiles
setblock 176 72 5 minecraft:deepslate_tiles
setblock 208 72 5 minecraft:deepslate_tiles
setblock 177 72 6 minecraft:orange_stained_glass
setblock 207 72 6 minecraft:orange_stained_glass
setblock 176 72 6 minecraft:sea_lantern
setblock 208 72 6 minecraft:sea_lantern
setblock 176 72 7 minecraft:deepslate_tiles
setblock 208 72 7 minecraft:deepslate_tiles
setblock 176 72 8 minecraft:deepslate_tiles
setblock 208 72 8 minecraft:deepslate_tiles
setblock 176 72 9 minecraft:deepslate_tiles
setblock 208 72 9 minecraft:deepslate_tiles
setblock 176 72 10 minecraft:deepslate_tiles
setblock 208 72 10 minecraft:deepslate_tiles
setblock 176 72 11 minecraft:deepslate_tiles
setblock 208 72 11 minecraft:deepslate_tiles
setblock 177 72 12 minecraft:orange_stained_glass
setblock 207 72 12 minecraft:orange_stained_glass
setblock 176 72 12 minecraft:sea_lantern
setblock 208 72 12 minecraft:sea_lantern
setblock 176 72 13 minecraft:deepslate_tiles
setblock 208 72 13 minecraft:deepslate_tiles
setblock 176 72 14 minecraft:deepslate_tiles
setblock 208 72 14 minecraft:deepslate_tiles
setblock 176 72 15 minecraft:deepslate_tiles
setblock 208 72 15 minecraft:deepslate_tiles
setblock 180 72 15 minecraft:orange_stained_glass
setblock 186 72 15 minecraft:orange_stained_glass
setblock 192 72 15 minecraft:orange_stained_glass
setblock 198 72 15 minecraft:orange_stained_glass
setblock 204 72 15 minecraft:orange_stained_glass
fill 176 72 16 179 72 16 minecraft:deepslate_tiles
fill 181 72 16 185 72 16 minecraft:deepslate_tiles
fill 187 72 16 191 72 16 minecraft:deepslate_tiles
fill 193 72 16 197 72 16 minecraft:deepslate_tiles
fill 199 72 16 203 72 16 minecraft:deepslate_tiles
fill 205 72 16 208 72 16 minecraft:deepslate_tiles
setblock 180 72 16 minecraft:sea_lantern
setblock 186 72 16 minecraft:sea_lantern
setblock 192 72 16 minecraft:sea_lantern
setblock 198 72 16 minecraft:sea_lantern
setblock 204 72 16 minecraft:sea_lantern
fill 176 73 -16 179 73 -16 minecraft:deepslate_tiles
fill 181 73 -16 185 73 -16 minecraft:deepslate_tiles
fill 187 73 -16 191 73 -16 minecraft:deepslate_tiles
fill 193 73 -16 197 73 -16 minecraft:deepslate_tiles
fill 199 73 -16 203 73 -16 minecraft:deepslate_tiles
fill 205 73 -16 208 73 -16 minecraft:deepslate_tiles
setblock 180 73 -16 minecraft:sea_lantern
setblock 186 73 -16 minecraft:sea_lantern
setblock 192 73 -16 minecraft:sea_lantern
setblock 198 73 -16 minecraft:sea_lantern
setblock 204 73 -16 minecraft:sea_lantern
setblock 176 73 -15 minecraft:deepslate_tiles
setblock 208 73 -15 minecraft:deepslate_tiles
setblock 180 73 -15 minecraft:orange_stained_glass
setblock 186 73 -15 minecraft:orange_stained_glass
setblock 192 73 -15 minecraft:orange_stained_glass
setblock 198 73 -15 minecraft:orange_stained_glass
setblock 204 73 -15 minecraft:orange_stained_glass
setblock 176 73 -14 minecraft:deepslate_tiles
setblock 208 73 -14 minecraft:deepslate_tiles
setblock 176 73 -13 minecraft:deepslate_tiles
setblock 208 73 -13 minecraft:deepslate_tiles
setblock 177 73 -12 minecraft:orange_stained_glass
setblock 207 73 -12 minecraft:orange_stained_glass
setblock 176 73 -12 minecraft:sea_lantern
setblock 208 73 -12 minecraft:sea_lantern
setblock 184 73 -12 minecraft:waxed_chiseled_copper
setblock 192 73 -12 minecraft:waxed_chiseled_copper
setblock 200 73 -12 minecraft:waxed_chiseled_copper
setblock 176 73 -11 minecraft:deepslate_tiles
setblock 208 73 -11 minecraft:deepslate_tiles
setblock 176 73 -10 minecraft:deepslate_tiles
setblock 208 73 -10 minecraft:deepslate_tiles
setblock 176 73 -9 minecraft:deepslate_tiles
setblock 208 73 -9 minecraft:deepslate_tiles
setblock 176 73 -8 minecraft:deepslate_tiles
setblock 208 73 -8 minecraft:deepslate_tiles
setblock 176 73 -7 minecraft:deepslate_tiles
setblock 208 73 -7 minecraft:deepslate_tiles
setblock 177 73 -6 minecraft:orange_stained_glass
setblock 207 73 -6 minecraft:orange_stained_glass
setblock 176 73 -6 minecraft:sea_lantern
setblock 208 73 -6 minecraft:sea_lantern
setblock 176 73 -5 minecraft:deepslate_tiles
setblock 208 73 -5 minecraft:deepslate_tiles
setblock 176 73 -4 minecraft:deepslate_tiles
setblock 208 73 -4 minecraft:deepslate_tiles
setblock 176 73 -3 minecraft:deepslate_tiles
setblock 208 73 -3 minecraft:deepslate_tiles
setblock 176 73 -2 minecraft:deepslate_tiles
setblock 208 73 -2 minecraft:deepslate_tiles
setblock 176 73 -1 minecraft:deepslate_tiles
setblock 208 73 -1 minecraft:deepslate_tiles
setblock 177 73 0 minecraft:orange_stained_glass
setblock 207 73 0 minecraft:orange_stained_glass
setblock 176 73 0 minecraft:sea_lantern
setblock 208 73 0 minecraft:sea_lantern
setblock 176 73 1 minecraft:deepslate_tiles
setblock 208 73 1 minecraft:deepslate_tiles
setblock 176 73 2 minecraft:deepslate_tiles
setblock 208 73 2 minecraft:deepslate_tiles
setblock 176 73 3 minecraft:deepslate_tiles
setblock 208 73 3 minecraft:deepslate_tiles
setblock 176 73 4 minecraft:deepslate_tiles
setblock 208 73 4 minecraft:deepslate_tiles
setblock 176 73 5 minecraft:deepslate_tiles
setblock 208 73 5 minecraft:deepslate_tiles
setblock 177 73 6 minecraft:orange_stained_glass
setblock 207 73 6 minecraft:orange_stained_glass
setblock 176 73 6 minecraft:sea_lantern
setblock 208 73 6 minecraft:sea_lantern
setblock 176 73 7 minecraft:deepslate_tiles
setblock 208 73 7 minecraft:deepslate_tiles
setblock 176 73 8 minecraft:deepslate_tiles
setblock 208 73 8 minecraft:deepslate_tiles
setblock 176 73 9 minecraft:deepslate_tiles
setblock 208 73 9 minecraft:deepslate_tiles
setblock 176 73 10 minecraft:deepslate_tiles
setblock 208 73 10 minecraft:deepslate_tiles
setblock 176 73 11 minecraft:deepslate_tiles
setblock 208 73 11 minecraft:deepslate_tiles
setblock 177 73 12 minecraft:orange_stained_glass
setblock 207 73 12 minecraft:orange_stained_glass
setblock 176 73 12 minecraft:sea_lantern
setblock 208 73 12 minecraft:sea_lantern
setblock 176 73 13 minecraft:deepslate_tiles
setblock 208 73 13 minecraft:deepslate_tiles
setblock 176 73 14 minecraft:deepslate_tiles
setblock 208 73 14 minecraft:deepslate_tiles
setblock 176 73 15 minecraft:deepslate_tiles
setblock 208 73 15 minecraft:deepslate_tiles
setblock 180 73 15 minecraft:orange_stained_glass
setblock 186 73 15 minecraft:orange_stained_glass
setblock 192 73 15 minecraft:orange_stained_glass
setblock 198 73 15 minecraft:orange_stained_glass
setblock 204 73 15 minecraft:orange_stained_glass
fill 176 73 16 179 73 16 minecraft:deepslate_tiles
fill 181 73 16 185 73 16 minecraft:deepslate_tiles
fill 187 73 16 191 73 16 minecraft:deepslate_tiles
fill 193 73 16 197 73 16 minecraft:deepslate_tiles
fill 199 73 16 203 73 16 minecraft:deepslate_tiles
fill 205 73 16 208 73 16 minecraft:deepslate_tiles
setblock 180 73 16 minecraft:sea_lantern
setblock 186 73 16 minecraft:sea_lantern
setblock 192 73 16 minecraft:sea_lantern
setblock 198 73 16 minecraft:sea_lantern
setblock 204 73 16 minecraft:sea_lantern
fill 176 74 -16 179 74 -16 minecraft:deepslate_tiles
fill 181 74 -16 185 74 -16 minecraft:deepslate_tiles
fill 187 74 -16 191 74 -16 minecraft:deepslate_tiles
fill 193 74 -16 197 74 -16 minecraft:deepslate_tiles
fill 199 74 -16 203 74 -16 minecraft:deepslate_tiles
fill 205 74 -16 208 74 -16 minecraft:deepslate_tiles
setblock 180 74 -16 minecraft:sea_lantern
setblock 186 74 -16 minecraft:sea_lantern
setblock 192 74 -16 minecraft:sea_lantern
setblock 198 74 -16 minecraft:sea_lantern
setblock 204 74 -16 minecraft:sea_lantern
setblock 176 74 -15 minecraft:deepslate_tiles
setblock 208 74 -15 minecraft:deepslate_tiles
setblock 180 74 -15 minecraft:orange_stained_glass
setblock 186 74 -15 minecraft:orange_stained_glass
setblock 192 74 -15 minecraft:orange_stained_glass
setblock 198 74 -15 minecraft:orange_stained_glass
setblock 204 74 -15 minecraft:orange_stained_glass
setblock 176 74 -14 minecraft:deepslate_tiles
setblock 208 74 -14 minecraft:deepslate_tiles
setblock 176 74 -13 minecraft:deepslate_tiles
setblock 208 74 -13 minecraft:deepslate_tiles
setblock 177 74 -12 minecraft:orange_stained_glass
setblock 207 74 -12 minecraft:orange_stained_glass
setblock 176 74 -12 minecraft:sea_lantern
setblock 208 74 -12 minecraft:sea_lantern
setblock 176 74 -11 minecraft:deepslate_tiles
setblock 208 74 -11 minecraft:deepslate_tiles
setblock 176 74 -10 minecraft:deepslate_tiles
setblock 208 74 -10 minecraft:deepslate_tiles
setblock 176 74 -9 minecraft:deepslate_tiles
setblock 208 74 -9 minecraft:deepslate_tiles
setblock 176 74 -8 minecraft:deepslate_tiles
setblock 208 74 -8 minecraft:deepslate_tiles
setblock 176 74 -7 minecraft:deepslate_tiles
setblock 208 74 -7 minecraft:deepslate_tiles
setblock 177 74 -6 minecraft:orange_stained_glass
setblock 207 74 -6 minecraft:orange_stained_glass
setblock 176 74 -6 minecraft:sea_lantern
setblock 208 74 -6 minecraft:sea_lantern
setblock 176 74 -5 minecraft:deepslate_tiles
setblock 208 74 -5 minecraft:deepslate_tiles
setblock 176 74 -4 minecraft:deepslate_tiles
setblock 208 74 -4 minecraft:deepslate_tiles
setblock 176 74 -3 minecraft:deepslate_tiles
setblock 208 74 -3 minecraft:deepslate_tiles
setblock 176 74 -2 minecraft:deepslate_tiles
setblock 208 74 -2 minecraft:deepslate_tiles
setblock 176 74 -1 minecraft:deepslate_tiles
setblock 208 74 -1 minecraft:deepslate_tiles
setblock 177 74 0 minecraft:orange_stained_glass
setblock 207 74 0 minecraft:orange_stained_glass
setblock 176 74 0 minecraft:sea_lantern
setblock 208 74 0 minecraft:sea_lantern
setblock 176 74 1 minecraft:deepslate_tiles
setblock 208 74 1 minecraft:deepslate_tiles
setblock 176 74 2 minecraft:deepslate_tiles
setblock 208 74 2 minecraft:deepslate_tiles
setblock 176 74 3 minecraft:deepslate_tiles
setblock 208 74 3 minecraft:deepslate_tiles
setblock 176 74 4 minecraft:deepslate_tiles
setblock 208 74 4 minecraft:deepslate_tiles
setblock 176 74 5 minecraft:deepslate_tiles
setblock 208 74 5 minecraft:deepslate_tiles
setblock 177 74 6 minecraft:orange_stained_glass
setblock 207 74 6 minecraft:orange_stained_glass
setblock 176 74 6 minecraft:sea_lantern
setblock 208 74 6 minecraft:sea_lantern
setblock 176 74 7 minecraft:deepslate_tiles
setblock 208 74 7 minecraft:deepslate_tiles
setblock 176 74 8 minecraft:deepslate_tiles
setblock 208 74 8 minecraft:deepslate_tiles
setblock 176 74 9 minecraft:deepslate_tiles
setblock 208 74 9 minecraft:deepslate_tiles
setblock 176 74 10 minecraft:deepslate_tiles
setblock 208 74 10 minecraft:deepslate_tiles
setblock 176 74 11 minecraft:deepslate_tiles
setblock 208 74 11 minecraft:deepslate_tiles
setblock 177 74 12 minecraft:orange_stained_glass
setblock 207 74 12 minecraft:orange_stained_glass
setblock 176 74 12 minecraft:sea_lantern
setblock 208 74 12 minecraft:sea_lantern
setblock 176 74 13 minecraft:deepslate_tiles
setblock 208 74 13 minecraft:deepslate_tiles
setblock 176 74 14 minecraft:deepslate_tiles
setblock 208 74 14 minecraft:deepslate_tiles
setblock 176 74 15 minecraft:deepslate_tiles
setblock 208 74 15 minecraft:deepslate_tiles
setblock 180 74 15 minecraft:orange_stained_glass
setblock 186 74 15 minecraft:orange_stained_glass
setblock 192 74 15 minecraft:orange_stained_glass
setblock 198 74 15 minecraft:orange_stained_glass
setblock 204 74 15 minecraft:orange_stained_glass
fill 176 74 16 179 74 16 minecraft:deepslate_tiles
fill 181 74 16 185 74 16 minecraft:deepslate_tiles
fill 187 74 16 191 74 16 minecraft:deepslate_tiles
fill 193 74 16 197 74 16 minecraft:deepslate_tiles
fill 199 74 16 203 74 16 minecraft:deepslate_tiles
fill 205 74 16 208 74 16 minecraft:deepslate_tiles
setblock 180 74 16 minecraft:sea_lantern
setblock 186 74 16 minecraft:sea_lantern
setblock 192 74 16 minecraft:sea_lantern
setblock 198 74 16 minecraft:sea_lantern
setblock 204 74 16 minecraft:sea_lantern
fill 176 75 -16 179 75 -16 minecraft:deepslate_tiles
fill 181 75 -16 185 75 -16 minecraft:deepslate_tiles
fill 187 75 -16 191 75 -16 minecraft:deepslate_tiles
fill 193 75 -16 197 75 -16 minecraft:deepslate_tiles
fill 199 75 -16 203 75 -16 minecraft:deepslate_tiles
fill 205 75 -16 208 75 -16 minecraft:deepslate_tiles
setblock 180 75 -16 minecraft:sea_lantern
setblock 186 75 -16 minecraft:sea_lantern
setblock 192 75 -16 minecraft:sea_lantern
setblock 198 75 -16 minecraft:sea_lantern
setblock 204 75 -16 minecraft:sea_lantern
setblock 176 75 -15 minecraft:deepslate_tiles
setblock 208 75 -15 minecraft:deepslate_tiles
setblock 180 75 -15 minecraft:orange_stained_glass
setblock 186 75 -15 minecraft:orange_stained_glass
setblock 192 75 -15 minecraft:orange_stained_glass
setblock 198 75 -15 minecraft:orange_stained_glass
setblock 204 75 -15 minecraft:orange_stained_glass
setblock 176 75 -14 minecraft:deepslate_tiles
setblock 208 75 -14 minecraft:deepslate_tiles
setblock 176 75 -13 minecraft:deepslate_tiles
setblock 208 75 -13 minecraft:deepslate_tiles
setblock 177 75 -12 minecraft:orange_stained_glass
setblock 207 75 -12 minecraft:orange_stained_glass
setblock 176 75 -12 minecraft:sea_lantern
setblock 208 75 -12 minecraft:sea_lantern
setblock 176 75 -11 minecraft:deepslate_tiles
setblock 208 75 -11 minecraft:deepslate_tiles
setblock 176 75 -10 minecraft:deepslate_tiles
setblock 208 75 -10 minecraft:deepslate_tiles
setblock 176 75 -9 minecraft:deepslate_tiles
setblock 208 75 -9 minecraft:deepslate_tiles
setblock 176 75 -8 minecraft:deepslate_tiles
setblock 208 75 -8 minecraft:deepslate_tiles
setblock 176 75 -7 minecraft:deepslate_tiles
setblock 208 75 -7 minecraft:deepslate_tiles
setblock 177 75 -6 minecraft:orange_stained_glass
setblock 207 75 -6 minecraft:orange_stained_glass
setblock 176 75 -6 minecraft:sea_lantern
setblock 208 75 -6 minecraft:sea_lantern
setblock 176 75 -5 minecraft:deepslate_tiles
setblock 208 75 -5 minecraft:deepslate_tiles
setblock 176 75 -4 minecraft:deepslate_tiles
setblock 208 75 -4 minecraft:deepslate_tiles
setblock 176 75 -3 minecraft:deepslate_tiles
setblock 208 75 -3 minecraft:deepslate_tiles
setblock 176 75 -2 minecraft:deepslate_tiles
setblock 208 75 -2 minecraft:deepslate_tiles
setblock 176 75 -1 minecraft:deepslate_tiles
setblock 208 75 -1 minecraft:deepslate_tiles
setblock 177 75 0 minecraft:orange_stained_glass
setblock 207 75 0 minecraft:orange_stained_glass
setblock 176 75 0 minecraft:sea_lantern
setblock 208 75 0 minecraft:sea_lantern
setblock 176 75 1 minecraft:deepslate_tiles
setblock 208 75 1 minecraft:deepslate_tiles
setblock 176 75 2 minecraft:deepslate_tiles
setblock 208 75 2 minecraft:deepslate_tiles
setblock 176 75 3 minecraft:deepslate_tiles
setblock 208 75 3 minecraft:deepslate_tiles
setblock 176 75 4 minecraft:deepslate_tiles
setblock 208 75 4 minecraft:deepslate_tiles
setblock 176 75 5 minecraft:deepslate_tiles
setblock 208 75 5 minecraft:deepslate_tiles
setblock 177 75 6 minecraft:orange_stained_glass
setblock 207 75 6 minecraft:orange_stained_glass
setblock 176 75 6 minecraft:sea_lantern
setblock 208 75 6 minecraft:sea_lantern
setblock 176 75 7 minecraft:deepslate_tiles
setblock 208 75 7 minecraft:deepslate_tiles
setblock 176 75 8 minecraft:deepslate_tiles
setblock 208 75 8 minecraft:deepslate_tiles
setblock 176 75 9 minecraft:deepslate_tiles
setblock 208 75 9 minecraft:deepslate_tiles
setblock 176 75 10 minecraft:deepslate_tiles
setblock 208 75 10 minecraft:deepslate_tiles
setblock 176 75 11 minecraft:deepslate_tiles
setblock 208 75 11 minecraft:deepslate_tiles
setblock 177 75 12 minecraft:orange_stained_glass
setblock 207 75 12 minecraft:orange_stained_glass
setblock 176 75 12 minecraft:sea_lantern
setblock 208 75 12 minecraft:sea_lantern
setblock 176 75 13 minecraft:deepslate_tiles
setblock 208 75 13 minecraft:deepslate_tiles
setblock 176 75 14 minecraft:deepslate_tiles
setblock 208 75 14 minecraft:deepslate_tiles
setblock 176 75 15 minecraft:deepslate_tiles
setblock 208 75 15 minecraft:deepslate_tiles
setblock 180 75 15 minecraft:orange_stained_glass
setblock 186 75 15 minecraft:orange_stained_glass
setblock 192 75 15 minecraft:orange_stained_glass
setblock 198 75 15 minecraft:orange_stained_glass
setblock 204 75 15 minecraft:orange_stained_glass
fill 176 75 16 179 75 16 minecraft:deepslate_tiles
fill 181 75 16 185 75 16 minecraft:deepslate_tiles
fill 187 75 16 191 75 16 minecraft:deepslate_tiles
fill 193 75 16 197 75 16 minecraft:deepslate_tiles
fill 199 75 16 203 75 16 minecraft:deepslate_tiles
fill 205 75 16 208 75 16 minecraft:deepslate_tiles
setblock 180 75 16 minecraft:sea_lantern
setblock 186 75 16 minecraft:sea_lantern
setblock 192 75 16 minecraft:sea_lantern
setblock 198 75 16 minecraft:sea_lantern
setblock 204 75 16 minecraft:sea_lantern
fill 176 76 -16 179 76 -16 minecraft:deepslate_tiles
fill 181 76 -16 185 76 -16 minecraft:deepslate_tiles
fill 187 76 -16 191 76 -16 minecraft:deepslate_tiles
fill 193 76 -16 197 76 -16 minecraft:deepslate_tiles
fill 199 76 -16 203 76 -16 minecraft:deepslate_tiles
fill 205 76 -16 208 76 -16 minecraft:deepslate_tiles
setblock 180 76 -16 minecraft:sea_lantern
setblock 186 76 -16 minecraft:sea_lantern
setblock 192 76 -16 minecraft:sea_lantern
setblock 198 76 -16 minecraft:sea_lantern
setblock 204 76 -16 minecraft:sea_lantern
setblock 176 76 -15 minecraft:deepslate_tiles
setblock 208 76 -15 minecraft:deepslate_tiles
setblock 180 76 -15 minecraft:orange_stained_glass
setblock 186 76 -15 minecraft:orange_stained_glass
setblock 192 76 -15 minecraft:orange_stained_glass
setblock 198 76 -15 minecraft:orange_stained_glass
setblock 204 76 -15 minecraft:orange_stained_glass
setblock 176 76 -14 minecraft:deepslate_tiles
setblock 208 76 -14 minecraft:deepslate_tiles
setblock 176 76 -13 minecraft:deepslate_tiles
setblock 208 76 -13 minecraft:deepslate_tiles
setblock 177 76 -12 minecraft:orange_stained_glass
setblock 207 76 -12 minecraft:orange_stained_glass
setblock 176 76 -12 minecraft:sea_lantern
setblock 208 76 -12 minecraft:sea_lantern
setblock 176 76 -11 minecraft:deepslate_tiles
setblock 208 76 -11 minecraft:deepslate_tiles
setblock 176 76 -10 minecraft:deepslate_tiles
setblock 208 76 -10 minecraft:deepslate_tiles
setblock 176 76 -9 minecraft:deepslate_tiles
setblock 208 76 -9 minecraft:deepslate_tiles
setblock 176 76 -8 minecraft:deepslate_tiles
setblock 208 76 -8 minecraft:deepslate_tiles
setblock 176 76 -7 minecraft:deepslate_tiles
setblock 208 76 -7 minecraft:deepslate_tiles
setblock 177 76 -6 minecraft:orange_stained_glass
setblock 207 76 -6 minecraft:orange_stained_glass
setblock 176 76 -6 minecraft:sea_lantern
setblock 208 76 -6 minecraft:sea_lantern
setblock 176 76 -5 minecraft:deepslate_tiles
setblock 208 76 -5 minecraft:deepslate_tiles
setblock 176 76 -4 minecraft:deepslate_tiles
setblock 208 76 -4 minecraft:deepslate_tiles
setblock 176 76 -3 minecraft:deepslate_tiles
setblock 208 76 -3 minecraft:deepslate_tiles
setblock 176 76 -2 minecraft:deepslate_tiles
setblock 208 76 -2 minecraft:deepslate_tiles
setblock 176 76 -1 minecraft:deepslate_tiles
setblock 208 76 -1 minecraft:deepslate_tiles
setblock 177 76 0 minecraft:orange_stained_glass
setblock 207 76 0 minecraft:orange_stained_glass
setblock 176 76 0 minecraft:sea_lantern
setblock 208 76 0 minecraft:sea_lantern
setblock 176 76 1 minecraft:deepslate_tiles
setblock 208 76 1 minecraft:deepslate_tiles
setblock 176 76 2 minecraft:deepslate_tiles
setblock 208 76 2 minecraft:deepslate_tiles
setblock 176 76 3 minecraft:deepslate_tiles
setblock 208 76 3 minecraft:deepslate_tiles
setblock 176 76 4 minecraft:deepslate_tiles
setblock 208 76 4 minecraft:deepslate_tiles
setblock 176 76 5 minecraft:deepslate_tiles
setblock 208 76 5 minecraft:deepslate_tiles
setblock 177 76 6 minecraft:orange_stained_glass
setblock 207 76 6 minecraft:orange_stained_glass
setblock 176 76 6 minecraft:sea_lantern
setblock 208 76 6 minecraft:sea_lantern
setblock 176 76 7 minecraft:deepslate_tiles
setblock 208 76 7 minecraft:deepslate_tiles
setblock 176 76 8 minecraft:deepslate_tiles
setblock 208 76 8 minecraft:deepslate_tiles
setblock 176 76 9 minecraft:deepslate_tiles
setblock 208 76 9 minecraft:deepslate_tiles
setblock 176 76 10 minecraft:deepslate_tiles
setblock 208 76 10 minecraft:deepslate_tiles
setblock 176 76 11 minecraft:deepslate_tiles
setblock 208 76 11 minecraft:deepslate_tiles
setblock 177 76 12 minecraft:orange_stained_glass
setblock 207 76 12 minecraft:orange_stained_glass
setblock 176 76 12 minecraft:sea_lantern
setblock 208 76 12 minecraft:sea_lantern
setblock 176 76 13 minecraft:deepslate_tiles
setblock 208 76 13 minecraft:deepslate_tiles
setblock 176 76 14 minecraft:deepslate_tiles
setblock 208 76 14 minecraft:deepslate_tiles
setblock 176 76 15 minecraft:deepslate_tiles
setblock 208 76 15 minecraft:deepslate_tiles
setblock 180 76 15 minecraft:orange_stained_glass
setblock 186 76 15 minecraft:orange_stained_glass
setblock 192 76 15 minecraft:orange_stained_glass
setblock 198 76 15 minecraft:orange_stained_glass
setblock 204 76 15 minecraft:orange_stained_glass
fill 176 76 16 179 76 16 minecraft:deepslate_tiles
fill 181 76 16 185 76 16 minecraft:deepslate_tiles
fill 187 76 16 191 76 16 minecraft:deepslate_tiles
fill 193 76 16 197 76 16 minecraft:deepslate_tiles
fill 199 76 16 203 76 16 minecraft:deepslate_tiles
fill 205 76 16 208 76 16 minecraft:deepslate_tiles
setblock 180 76 16 minecraft:sea_lantern
setblock 186 76 16 minecraft:sea_lantern
setblock 192 76 16 minecraft:sea_lantern
setblock 198 76 16 minecraft:sea_lantern
setblock 204 76 16 minecraft:sea_lantern
fill 176 77 -16 179 77 -16 minecraft:deepslate_tiles
fill 181 77 -16 185 77 -16 minecraft:deepslate_tiles
fill 187 77 -16 191 77 -16 minecraft:deepslate_tiles
fill 193 77 -16 197 77 -16 minecraft:deepslate_tiles
fill 199 77 -16 203 77 -16 minecraft:deepslate_tiles
fill 205 77 -16 208 77 -16 minecraft:deepslate_tiles
setblock 180 77 -16 minecraft:sea_lantern
setblock 186 77 -16 minecraft:sea_lantern
setblock 192 77 -16 minecraft:sea_lantern
setblock 198 77 -16 minecraft:sea_lantern
setblock 204 77 -16 minecraft:sea_lantern
setblock 176 77 -15 minecraft:deepslate_tiles
setblock 208 77 -15 minecraft:deepslate_tiles
setblock 180 77 -15 minecraft:orange_stained_glass
setblock 186 77 -15 minecraft:orange_stained_glass
setblock 192 77 -15 minecraft:orange_stained_glass
setblock 198 77 -15 minecraft:orange_stained_glass
setblock 204 77 -15 minecraft:orange_stained_glass
setblock 176 77 -14 minecraft:deepslate_tiles
setblock 208 77 -14 minecraft:deepslate_tiles
setblock 176 77 -13 minecraft:deepslate_tiles
setblock 208 77 -13 minecraft:deepslate_tiles
setblock 177 77 -12 minecraft:orange_stained_glass
setblock 207 77 -12 minecraft:orange_stained_glass
setblock 176 77 -12 minecraft:sea_lantern
setblock 208 77 -12 minecraft:sea_lantern
setblock 176 77 -11 minecraft:deepslate_tiles
setblock 208 77 -11 minecraft:deepslate_tiles
setblock 176 77 -10 minecraft:deepslate_tiles
setblock 208 77 -10 minecraft:deepslate_tiles
setblock 176 77 -9 minecraft:deepslate_tiles
setblock 208 77 -9 minecraft:deepslate_tiles
setblock 176 77 -8 minecraft:deepslate_tiles
setblock 208 77 -8 minecraft:deepslate_tiles
setblock 176 77 -7 minecraft:deepslate_tiles
setblock 208 77 -7 minecraft:deepslate_tiles
setblock 177 77 -6 minecraft:orange_stained_glass
setblock 207 77 -6 minecraft:orange_stained_glass
setblock 176 77 -6 minecraft:sea_lantern
setblock 208 77 -6 minecraft:sea_lantern
setblock 176 77 -5 minecraft:deepslate_tiles
setblock 208 77 -5 minecraft:deepslate_tiles
setblock 176 77 -4 minecraft:deepslate_tiles
setblock 208 77 -4 minecraft:deepslate_tiles
setblock 176 77 -3 minecraft:deepslate_tiles
setblock 208 77 -3 minecraft:deepslate_tiles
setblock 176 77 -2 minecraft:deepslate_tiles
setblock 208 77 -2 minecraft:deepslate_tiles
setblock 176 77 -1 minecraft:deepslate_tiles
setblock 208 77 -1 minecraft:deepslate_tiles
setblock 177 77 0 minecraft:orange_stained_glass
setblock 207 77 0 minecraft:orange_stained_glass
setblock 176 77 0 minecraft:sea_lantern
setblock 208 77 0 minecraft:sea_lantern
setblock 176 77 1 minecraft:deepslate_tiles
setblock 208 77 1 minecraft:deepslate_tiles
setblock 176 77 2 minecraft:deepslate_tiles
setblock 208 77 2 minecraft:deepslate_tiles
setblock 176 77 3 minecraft:deepslate_tiles
setblock 208 77 3 minecraft:deepslate_tiles
setblock 176 77 4 minecraft:deepslate_tiles
setblock 208 77 4 minecraft:deepslate_tiles
setblock 176 77 5 minecraft:deepslate_tiles
setblock 208 77 5 minecraft:deepslate_tiles
setblock 177 77 6 minecraft:orange_stained_glass
setblock 207 77 6 minecraft:orange_stained_glass
setblock 176 77 6 minecraft:sea_lantern
setblock 208 77 6 minecraft:sea_lantern
setblock 176 77 7 minecraft:deepslate_tiles
setblock 208 77 7 minecraft:deepslate_tiles
setblock 176 77 8 minecraft:deepslate_tiles
setblock 208 77 8 minecraft:deepslate_tiles
setblock 176 77 9 minecraft:deepslate_tiles
setblock 208 77 9 minecraft:deepslate_tiles
setblock 176 77 10 minecraft:deepslate_tiles
setblock 208 77 10 minecraft:deepslate_tiles
setblock 176 77 11 minecraft:deepslate_tiles
setblock 208 77 11 minecraft:deepslate_tiles
setblock 177 77 12 minecraft:orange_stained_glass
setblock 207 77 12 minecraft:orange_stained_glass
setblock 176 77 12 minecraft:sea_lantern
setblock 208 77 12 minecraft:sea_lantern
setblock 176 77 13 minecraft:deepslate_tiles
setblock 208 77 13 minecraft:deepslate_tiles
setblock 176 77 14 minecraft:deepslate_tiles
setblock 208 77 14 minecraft:deepslate_tiles
setblock 176 77 15 minecraft:deepslate_tiles
setblock 208 77 15 minecraft:deepslate_tiles
setblock 180 77 15 minecraft:orange_stained_glass
setblock 186 77 15 minecraft:orange_stained_glass
setblock 192 77 15 minecraft:orange_stained_glass
setblock 198 77 15 minecraft:orange_stained_glass
setblock 204 77 15 minecraft:orange_stained_glass
fill 176 77 16 179 77 16 minecraft:deepslate_tiles
fill 181 77 16 185 77 16 minecraft:deepslate_tiles
fill 187 77 16 191 77 16 minecraft:deepslate_tiles
fill 193 77 16 197 77 16 minecraft:deepslate_tiles
fill 199 77 16 203 77 16 minecraft:deepslate_tiles
fill 205 77 16 208 77 16 minecraft:deepslate_tiles
setblock 180 77 16 minecraft:sea_lantern
setblock 186 77 16 minecraft:sea_lantern
setblock 192 77 16 minecraft:sea_lantern
setblock 198 77 16 minecraft:sea_lantern
setblock 204 77 16 minecraft:sea_lantern
fill 176 78 -16 179 78 -16 minecraft:deepslate_tiles
fill 181 78 -16 185 78 -16 minecraft:deepslate_tiles
fill 187 78 -16 191 78 -16 minecraft:deepslate_tiles
fill 193 78 -16 197 78 -16 minecraft:deepslate_tiles
fill 199 78 -16 203 78 -16 minecraft:deepslate_tiles
fill 205 78 -16 208 78 -16 minecraft:deepslate_tiles
setblock 180 78 -16 minecraft:sea_lantern
setblock 186 78 -16 minecraft:sea_lantern
setblock 192 78 -16 minecraft:sea_lantern
setblock 198 78 -16 minecraft:sea_lantern
setblock 204 78 -16 minecraft:sea_lantern
setblock 176 78 -15 minecraft:deepslate_tiles
setblock 208 78 -15 minecraft:deepslate_tiles
setblock 180 78 -15 minecraft:orange_stained_glass
setblock 186 78 -15 minecraft:orange_stained_glass
setblock 192 78 -15 minecraft:orange_stained_glass
setblock 198 78 -15 minecraft:orange_stained_glass
setblock 204 78 -15 minecraft:orange_stained_glass
setblock 176 78 -14 minecraft:deepslate_tiles
setblock 208 78 -14 minecraft:deepslate_tiles
setblock 176 78 -13 minecraft:deepslate_tiles
setblock 208 78 -13 minecraft:deepslate_tiles
setblock 177 78 -12 minecraft:orange_stained_glass
setblock 207 78 -12 minecraft:orange_stained_glass
setblock 176 78 -12 minecraft:sea_lantern
setblock 208 78 -12 minecraft:sea_lantern
setblock 176 78 -11 minecraft:deepslate_tiles
setblock 208 78 -11 minecraft:deepslate_tiles
setblock 176 78 -10 minecraft:deepslate_tiles
setblock 208 78 -10 minecraft:deepslate_tiles
setblock 176 78 -9 minecraft:deepslate_tiles
setblock 208 78 -9 minecraft:deepslate_tiles
setblock 176 78 -8 minecraft:deepslate_tiles
setblock 208 78 -8 minecraft:deepslate_tiles
setblock 176 78 -7 minecraft:deepslate_tiles
setblock 208 78 -7 minecraft:deepslate_tiles
setblock 177 78 -6 minecraft:orange_stained_glass
setblock 207 78 -6 minecraft:orange_stained_glass
setblock 176 78 -6 minecraft:sea_lantern
setblock 208 78 -6 minecraft:sea_lantern
setblock 176 78 -5 minecraft:deepslate_tiles
setblock 208 78 -5 minecraft:deepslate_tiles
setblock 176 78 -4 minecraft:deepslate_tiles
setblock 208 78 -4 minecraft:deepslate_tiles
setblock 176 78 -3 minecraft:deepslate_tiles
setblock 208 78 -3 minecraft:deepslate_tiles
setblock 176 78 -2 minecraft:deepslate_tiles
setblock 208 78 -2 minecraft:deepslate_tiles
setblock 176 78 -1 minecraft:deepslate_tiles
setblock 208 78 -1 minecraft:deepslate_tiles
setblock 177 78 0 minecraft:orange_stained_glass
setblock 207 78 0 minecraft:orange_stained_glass
setblock 176 78 0 minecraft:sea_lantern
setblock 208 78 0 minecraft:sea_lantern
setblock 176 78 1 minecraft:deepslate_tiles
setblock 208 78 1 minecraft:deepslate_tiles
setblock 176 78 2 minecraft:deepslate_tiles
setblock 208 78 2 minecraft:deepslate_tiles
setblock 176 78 3 minecraft:deepslate_tiles
setblock 208 78 3 minecraft:deepslate_tiles
setblock 176 78 4 minecraft:deepslate_tiles
setblock 208 78 4 minecraft:deepslate_tiles
setblock 176 78 5 minecraft:deepslate_tiles
setblock 208 78 5 minecraft:deepslate_tiles
setblock 177 78 6 minecraft:orange_stained_glass
setblock 207 78 6 minecraft:orange_stained_glass
setblock 176 78 6 minecraft:sea_lantern
setblock 208 78 6 minecraft:sea_lantern
setblock 176 78 7 minecraft:deepslate_tiles
setblock 208 78 7 minecraft:deepslate_tiles
setblock 176 78 8 minecraft:deepslate_tiles
setblock 208 78 8 minecraft:deepslate_tiles
setblock 176 78 9 minecraft:deepslate_tiles
setblock 208 78 9 minecraft:deepslate_tiles
setblock 176 78 10 minecraft:deepslate_tiles
setblock 208 78 10 minecraft:deepslate_tiles
setblock 176 78 11 minecraft:deepslate_tiles
setblock 208 78 11 minecraft:deepslate_tiles
setblock 177 78 12 minecraft:orange_stained_glass
setblock 207 78 12 minecraft:orange_stained_glass
setblock 176 78 12 minecraft:sea_lantern
setblock 208 78 12 minecraft:sea_lantern
setblock 176 78 13 minecraft:deepslate_tiles
setblock 208 78 13 minecraft:deepslate_tiles
setblock 176 78 14 minecraft:deepslate_tiles
setblock 208 78 14 minecraft:deepslate_tiles
setblock 176 78 15 minecraft:deepslate_tiles
setblock 208 78 15 minecraft:deepslate_tiles
setblock 180 78 15 minecraft:orange_stained_glass
setblock 186 78 15 minecraft:orange_stained_glass
setblock 192 78 15 minecraft:orange_stained_glass
setblock 198 78 15 minecraft:orange_stained_glass
setblock 204 78 15 minecraft:orange_stained_glass
fill 176 78 16 179 78 16 minecraft:deepslate_tiles
fill 181 78 16 185 78 16 minecraft:deepslate_tiles
fill 187 78 16 191 78 16 minecraft:deepslate_tiles
fill 193 78 16 197 78 16 minecraft:deepslate_tiles
fill 199 78 16 203 78 16 minecraft:deepslate_tiles
fill 205 78 16 208 78 16 minecraft:deepslate_tiles
setblock 180 78 16 minecraft:sea_lantern
setblock 186 78 16 minecraft:sea_lantern
setblock 192 78 16 minecraft:sea_lantern
setblock 198 78 16 minecraft:sea_lantern
setblock 204 78 16 minecraft:sea_lantern
fill 176 79 -16 208 79 -16 minecraft:deepslate_tiles
setblock 176 79 -15 minecraft:deepslate_tiles
setblock 208 79 -15 minecraft:deepslate_tiles
setblock 180 79 -15 minecraft:polished_blackstone
setblock 186 79 -15 minecraft:polished_blackstone
setblock 192 79 -15 minecraft:polished_blackstone
setblock 198 79 -15 minecraft:polished_blackstone
setblock 204 79 -15 minecraft:polished_blackstone
setblock 176 79 -14 minecraft:deepslate_tiles
setblock 208 79 -14 minecraft:deepslate_tiles
setblock 176 79 -13 minecraft:deepslate_tiles
setblock 208 79 -13 minecraft:deepslate_tiles
setblock 176 79 -12 minecraft:deepslate_tiles
setblock 208 79 -12 minecraft:deepslate_tiles
setblock 177 79 -12 minecraft:polished_blackstone
setblock 207 79 -12 minecraft:polished_blackstone
setblock 176 79 -11 minecraft:deepslate_tiles
setblock 208 79 -11 minecraft:deepslate_tiles
setblock 176 79 -10 minecraft:deepslate_tiles
setblock 208 79 -10 minecraft:deepslate_tiles
setblock 176 79 -9 minecraft:deepslate_tiles
setblock 208 79 -9 minecraft:deepslate_tiles
setblock 176 79 -8 minecraft:deepslate_tiles
setblock 208 79 -8 minecraft:deepslate_tiles
setblock 176 79 -7 minecraft:deepslate_tiles
setblock 208 79 -7 minecraft:deepslate_tiles
setblock 176 79 -6 minecraft:deepslate_tiles
setblock 208 79 -6 minecraft:deepslate_tiles
setblock 177 79 -6 minecraft:polished_blackstone
setblock 207 79 -6 minecraft:polished_blackstone
setblock 176 79 -5 minecraft:deepslate_tiles
setblock 208 79 -5 minecraft:deepslate_tiles
setblock 176 79 -4 minecraft:deepslate_tiles
setblock 208 79 -4 minecraft:deepslate_tiles
setblock 176 79 -3 minecraft:deepslate_tiles
setblock 208 79 -3 minecraft:deepslate_tiles
setblock 176 79 -2 minecraft:deepslate_tiles
setblock 208 79 -2 minecraft:deepslate_tiles
setblock 176 79 -1 minecraft:deepslate_tiles
setblock 208 79 -1 minecraft:deepslate_tiles
setblock 176 79 0 minecraft:deepslate_tiles
setblock 208 79 0 minecraft:deepslate_tiles
setblock 177 79 0 minecraft:polished_blackstone
setblock 207 79 0 minecraft:polished_blackstone
setblock 176 79 1 minecraft:deepslate_tiles
setblock 208 79 1 minecraft:deepslate_tiles
setblock 176 79 2 minecraft:deepslate_tiles
setblock 208 79 2 minecraft:deepslate_tiles
setblock 176 79 3 minecraft:deepslate_tiles
setblock 208 79 3 minecraft:deepslate_tiles
setblock 176 79 4 minecraft:deepslate_tiles
setblock 208 79 4 minecraft:deepslate_tiles
setblock 176 79 5 minecraft:deepslate_tiles
setblock 208 79 5 minecraft:deepslate_tiles
setblock 176 79 6 minecraft:deepslate_tiles
setblock 208 79 6 minecraft:deepslate_tiles
setblock 177 79 6 minecraft:polished_blackstone
setblock 207 79 6 minecraft:polished_blackstone
setblock 176 79 7 minecraft:deepslate_tiles
setblock 208 79 7 minecraft:deepslate_tiles
setblock 176 79 8 minecraft:deepslate_tiles
setblock 208 79 8 minecraft:deepslate_tiles
setblock 176 79 9 minecraft:deepslate_tiles
setblock 208 79 9 minecraft:deepslate_tiles
setblock 176 79 10 minecraft:deepslate_tiles
setblock 208 79 10 minecraft:deepslate_tiles
setblock 176 79 11 minecraft:deepslate_tiles
setblock 208 79 11 minecraft:deepslate_tiles
setblock 176 79 12 minecraft:deepslate_tiles
setblock 208 79 12 minecraft:deepslate_tiles
setblock 177 79 12 minecraft:polished_blackstone
setblock 207 79 12 minecraft:polished_blackstone
setblock 176 79 13 minecraft:deepslate_tiles
setblock 208 79 13 minecraft:deepslate_tiles
setblock 176 79 14 minecraft:deepslate_tiles
setblock 208 79 14 minecraft:deepslate_tiles
setblock 176 79 15 minecraft:deepslate_tiles
setblock 208 79 15 minecraft:deepslate_tiles
setblock 180 79 15 minecraft:polished_blackstone
setblock 186 79 15 minecraft:polished_blackstone
setblock 192 79 15 minecraft:polished_blackstone
setblock 198 79 15 minecraft:polished_blackstone
setblock 204 79 15 minecraft:polished_blackstone
fill 176 79 16 208 79 16 minecraft:deepslate_tiles
fill 176 80 -16 208 80 -16 minecraft:deepslate_tiles
setblock 176 80 -15 minecraft:deepslate_tiles
setblock 208 80 -15 minecraft:deepslate_tiles
fill 177 80 -15 207 80 -15 minecraft:waxed_cut_copper
setblock 176 80 -14 minecraft:deepslate_tiles
setblock 208 80 -14 minecraft:deepslate_tiles
setblock 177 80 -14 minecraft:waxed_cut_copper
setblock 207 80 -14 minecraft:waxed_cut_copper
setblock 176 80 -13 minecraft:deepslate_tiles
setblock 208 80 -13 minecraft:deepslate_tiles
setblock 177 80 -13 minecraft:waxed_cut_copper
setblock 207 80 -13 minecraft:waxed_cut_copper
setblock 176 80 -12 minecraft:deepslate_tiles
setblock 208 80 -12 minecraft:deepslate_tiles
setblock 180 80 -12 minecraft:sea_lantern
setblock 204 80 -12 minecraft:sea_lantern
fill 177 80 -12 178 80 -12 minecraft:waxed_cut_copper
fill 206 80 -12 207 80 -12 minecraft:waxed_cut_copper
setblock 176 80 -11 minecraft:deepslate_tiles
setblock 208 80 -11 minecraft:deepslate_tiles
setblock 177 80 -11 minecraft:waxed_cut_copper
setblock 207 80 -11 minecraft:waxed_cut_copper
setblock 176 80 -10 minecraft:deepslate_tiles
setblock 208 80 -10 minecraft:deepslate_tiles
setblock 177 80 -10 minecraft:waxed_cut_copper
setblock 207 80 -10 minecraft:waxed_cut_copper
setblock 176 80 -9 minecraft:deepslate_tiles
setblock 208 80 -9 minecraft:deepslate_tiles
setblock 177 80 -9 minecraft:waxed_cut_copper
setblock 207 80 -9 minecraft:waxed_cut_copper
setblock 176 80 -8 minecraft:deepslate_tiles
setblock 208 80 -8 minecraft:deepslate_tiles
setblock 177 80 -8 minecraft:waxed_cut_copper
setblock 207 80 -8 minecraft:waxed_cut_copper
setblock 176 80 -7 minecraft:deepslate_tiles
setblock 208 80 -7 minecraft:deepslate_tiles
setblock 177 80 -7 minecraft:waxed_cut_copper
setblock 207 80 -7 minecraft:waxed_cut_copper
setblock 176 80 -6 minecraft:deepslate_tiles
setblock 208 80 -6 minecraft:deepslate_tiles
setblock 177 80 -6 minecraft:waxed_cut_copper
setblock 207 80 -6 minecraft:waxed_cut_copper
setblock 176 80 -5 minecraft:deepslate_tiles
setblock 208 80 -5 minecraft:deepslate_tiles
setblock 177 80 -5 minecraft:waxed_cut_copper
setblock 207 80 -5 minecraft:waxed_cut_copper
setblock 176 80 -4 minecraft:deepslate_tiles
setblock 208 80 -4 minecraft:deepslate_tiles
setblock 177 80 -4 minecraft:waxed_cut_copper
setblock 207 80 -4 minecraft:waxed_cut_copper
setblock 176 80 -3 minecraft:deepslate_tiles
setblock 208 80 -3 minecraft:deepslate_tiles
setblock 177 80 -3 minecraft:waxed_cut_copper
setblock 207 80 -3 minecraft:waxed_cut_copper
setblock 176 80 -2 minecraft:deepslate_tiles
setblock 208 80 -2 minecraft:deepslate_tiles
setblock 177 80 -2 minecraft:waxed_cut_copper
setblock 207 80 -2 minecraft:waxed_cut_copper
setblock 176 80 -1 minecraft:deepslate_tiles
setblock 208 80 -1 minecraft:deepslate_tiles
setblock 177 80 -1 minecraft:waxed_cut_copper
setblock 207 80 -1 minecraft:waxed_cut_copper
setblock 176 80 0 minecraft:deepslate_tiles
setblock 208 80 0 minecraft:deepslate_tiles
setblock 180 80 0 minecraft:sea_lantern
setblock 204 80 0 minecraft:sea_lantern
fill 177 80 0 178 80 0 minecraft:waxed_cut_copper
fill 206 80 0 207 80 0 minecraft:waxed_cut_copper
setblock 176 80 1 minecraft:deepslate_tiles
setblock 208 80 1 minecraft:deepslate_tiles
setblock 177 80 1 minecraft:waxed_cut_copper
setblock 207 80 1 minecraft:waxed_cut_copper
setblock 176 80 2 minecraft:deepslate_tiles
setblock 208 80 2 minecraft:deepslate_tiles
setblock 177 80 2 minecraft:waxed_cut_copper
setblock 207 80 2 minecraft:waxed_cut_copper
setblock 176 80 3 minecraft:deepslate_tiles
setblock 208 80 3 minecraft:deepslate_tiles
setblock 177 80 3 minecraft:waxed_cut_copper
setblock 207 80 3 minecraft:waxed_cut_copper
setblock 176 80 4 minecraft:deepslate_tiles
setblock 208 80 4 minecraft:deepslate_tiles
setblock 177 80 4 minecraft:waxed_cut_copper
setblock 207 80 4 minecraft:waxed_cut_copper
setblock 176 80 5 minecraft:deepslate_tiles
setblock 208 80 5 minecraft:deepslate_tiles
setblock 177 80 5 minecraft:waxed_cut_copper
setblock 207 80 5 minecraft:waxed_cut_copper
setblock 176 80 6 minecraft:deepslate_tiles
setblock 208 80 6 minecraft:deepslate_tiles
setblock 177 80 6 minecraft:waxed_cut_copper
setblock 207 80 6 minecraft:waxed_cut_copper
setblock 176 80 7 minecraft:deepslate_tiles
setblock 208 80 7 minecraft:deepslate_tiles
setblock 177 80 7 minecraft:waxed_cut_copper
setblock 207 80 7 minecraft:waxed_cut_copper
setblock 176 80 8 minecraft:deepslate_tiles
setblock 208 80 8 minecraft:deepslate_tiles
setblock 177 80 8 minecraft:waxed_cut_copper
setblock 207 80 8 minecraft:waxed_cut_copper
setblock 176 80 9 minecraft:deepslate_tiles
setblock 208 80 9 minecraft:deepslate_tiles
setblock 177 80 9 minecraft:waxed_cut_copper
setblock 207 80 9 minecraft:waxed_cut_copper
setblock 176 80 10 minecraft:deepslate_tiles
setblock 208 80 10 minecraft:deepslate_tiles
setblock 177 80 10 minecraft:waxed_cut_copper
setblock 207 80 10 minecraft:waxed_cut_copper
setblock 176 80 11 minecraft:deepslate_tiles
setblock 208 80 11 minecraft:deepslate_tiles
setblock 177 80 11 minecraft:waxed_cut_copper
setblock 207 80 11 minecraft:waxed_cut_copper
setblock 176 80 12 minecraft:deepslate_tiles
setblock 208 80 12 minecraft:deepslate_tiles
setblock 180 80 12 minecraft:sea_lantern
setblock 204 80 12 minecraft:sea_lantern
fill 177 80 12 178 80 12 minecraft:waxed_cut_copper
fill 206 80 12 207 80 12 minecraft:waxed_cut_copper
setblock 176 80 13 minecraft:deepslate_tiles
setblock 208 80 13 minecraft:deepslate_tiles
setblock 177 80 13 minecraft:waxed_cut_copper
setblock 207 80 13 minecraft:waxed_cut_copper
setblock 176 80 14 minecraft:deepslate_tiles
setblock 208 80 14 minecraft:deepslate_tiles
setblock 177 80 14 minecraft:waxed_cut_copper
setblock 207 80 14 minecraft:waxed_cut_copper
setblock 176 80 15 minecraft:deepslate_tiles
setblock 208 80 15 minecraft:deepslate_tiles
fill 177 80 15 207 80 15 minecraft:waxed_cut_copper
fill 176 80 16 208 80 16 minecraft:deepslate_tiles
fill 176 81 -16 208 81 -16 minecraft:deepslate_tiles
setblock 176 81 -15 minecraft:deepslate_tiles
setblock 208 81 -15 minecraft:deepslate_tiles
setblock 180 81 -15 minecraft:waxed_cut_copper
setblock 186 81 -15 minecraft:waxed_cut_copper
setblock 192 81 -15 minecraft:waxed_cut_copper
setblock 198 81 -15 minecraft:waxed_cut_copper
setblock 204 81 -15 minecraft:waxed_cut_copper
setblock 176 81 -14 minecraft:deepslate_tiles
setblock 208 81 -14 minecraft:deepslate_tiles
setblock 176 81 -13 minecraft:deepslate_tiles
setblock 208 81 -13 minecraft:deepslate_tiles
setblock 176 81 -12 minecraft:deepslate_tiles
setblock 208 81 -12 minecraft:deepslate_tiles
setblock 186 81 -12 minecraft:sea_lantern
setblock 192 81 -12 minecraft:sea_lantern
setblock 198 81 -12 minecraft:sea_lantern
setblock 177 81 -12 minecraft:waxed_cut_copper
fill 179 81 -12 181 81 -12 minecraft:waxed_cut_copper
fill 203 81 -12 205 81 -12 minecraft:waxed_cut_copper
setblock 207 81 -12 minecraft:waxed_cut_copper
setblock 176 81 -11 minecraft:deepslate_tiles
setblock 208 81 -11 minecraft:deepslate_tiles
setblock 176 81 -10 minecraft:deepslate_tiles
setblock 208 81 -10 minecraft:deepslate_tiles
setblock 176 81 -9 minecraft:deepslate_tiles
setblock 208 81 -9 minecraft:deepslate_tiles
setblock 176 81 -8 minecraft:deepslate_tiles
setblock 208 81 -8 minecraft:deepslate_tiles
setblock 176 81 -7 minecraft:deepslate_tiles
setblock 208 81 -7 minecraft:deepslate_tiles
setblock 176 81 -6 minecraft:deepslate_tiles
setblock 208 81 -6 minecraft:deepslate_tiles
setblock 177 81 -6 minecraft:waxed_cut_copper
setblock 207 81 -6 minecraft:waxed_cut_copper
setblock 176 81 -5 minecraft:deepslate_tiles
setblock 208 81 -5 minecraft:deepslate_tiles
setblock 176 81 -4 minecraft:deepslate_tiles
setblock 208 81 -4 minecraft:deepslate_tiles
setblock 176 81 -3 minecraft:deepslate_tiles
setblock 208 81 -3 minecraft:deepslate_tiles
setblock 176 81 -2 minecraft:deepslate_tiles
setblock 208 81 -2 minecraft:deepslate_tiles
setblock 176 81 -1 minecraft:deepslate_tiles
setblock 208 81 -1 minecraft:deepslate_tiles
setblock 176 81 0 minecraft:deepslate_tiles
setblock 208 81 0 minecraft:deepslate_tiles
setblock 186 81 0 minecraft:sea_lantern
setblock 192 81 0 minecraft:sea_lantern
setblock 198 81 0 minecraft:sea_lantern
setblock 177 81 0 minecraft:waxed_cut_copper
fill 179 81 0 181 81 0 minecraft:waxed_cut_copper
fill 203 81 0 205 81 0 minecraft:waxed_cut_copper
setblock 207 81 0 minecraft:waxed_cut_copper
setblock 176 81 1 minecraft:deepslate_tiles
setblock 208 81 1 minecraft:deepslate_tiles
setblock 176 81 2 minecraft:deepslate_tiles
setblock 208 81 2 minecraft:deepslate_tiles
setblock 176 81 3 minecraft:deepslate_tiles
setblock 208 81 3 minecraft:deepslate_tiles
setblock 176 81 4 minecraft:deepslate_tiles
setblock 208 81 4 minecraft:deepslate_tiles
setblock 176 81 5 minecraft:deepslate_tiles
setblock 208 81 5 minecraft:deepslate_tiles
setblock 176 81 6 minecraft:deepslate_tiles
setblock 208 81 6 minecraft:deepslate_tiles
setblock 177 81 6 minecraft:waxed_cut_copper
setblock 207 81 6 minecraft:waxed_cut_copper
setblock 176 81 7 minecraft:deepslate_tiles
setblock 208 81 7 minecraft:deepslate_tiles
setblock 176 81 8 minecraft:deepslate_tiles
setblock 208 81 8 minecraft:deepslate_tiles
setblock 176 81 9 minecraft:deepslate_tiles
setblock 208 81 9 minecraft:deepslate_tiles
setblock 176 81 10 minecraft:deepslate_tiles
setblock 208 81 10 minecraft:deepslate_tiles
setblock 176 81 11 minecraft:deepslate_tiles
setblock 208 81 11 minecraft:deepslate_tiles
setblock 176 81 12 minecraft:deepslate_tiles
setblock 208 81 12 minecraft:deepslate_tiles
setblock 186 81 12 minecraft:sea_lantern
setblock 192 81 12 minecraft:sea_lantern
setblock 198 81 12 minecraft:sea_lantern
setblock 177 81 12 minecraft:waxed_cut_copper
fill 179 81 12 181 81 12 minecraft:waxed_cut_copper
fill 203 81 12 205 81 12 minecraft:waxed_cut_copper
setblock 207 81 12 minecraft:waxed_cut_copper
setblock 176 81 13 minecraft:deepslate_tiles
setblock 208 81 13 minecraft:deepslate_tiles
setblock 176 81 14 minecraft:deepslate_tiles
setblock 208 81 14 minecraft:deepslate_tiles
setblock 176 81 15 minecraft:deepslate_tiles
setblock 208 81 15 minecraft:deepslate_tiles
setblock 180 81 15 minecraft:waxed_cut_copper
setblock 186 81 15 minecraft:waxed_cut_copper
setblock 192 81 15 minecraft:waxed_cut_copper
setblock 198 81 15 minecraft:waxed_cut_copper
setblock 204 81 15 minecraft:waxed_cut_copper
fill 176 81 16 208 81 16 minecraft:deepslate_tiles
fill 176 82 -16 208 82 -16 minecraft:deepslate_tiles
setblock 176 82 -15 minecraft:deepslate_tiles
setblock 208 82 -15 minecraft:deepslate_tiles
setblock 180 82 -15 minecraft:waxed_cut_copper
setblock 186 82 -15 minecraft:waxed_cut_copper
setblock 192 82 -15 minecraft:waxed_cut_copper
setblock 198 82 -15 minecraft:waxed_cut_copper
setblock 204 82 -15 minecraft:waxed_cut_copper
setblock 176 82 -14 minecraft:deepslate_tiles
setblock 208 82 -14 minecraft:deepslate_tiles
setblock 176 82 -13 minecraft:deepslate_tiles
setblock 208 82 -13 minecraft:deepslate_tiles
setblock 176 82 -12 minecraft:deepslate_tiles
setblock 208 82 -12 minecraft:deepslate_tiles
setblock 177 82 -12 minecraft:waxed_cut_copper
fill 182 82 -12 202 82 -12 minecraft:waxed_cut_copper
setblock 207 82 -12 minecraft:waxed_cut_copper
setblock 176 82 -11 minecraft:deepslate_tiles
setblock 208 82 -11 minecraft:deepslate_tiles
setblock 176 82 -10 minecraft:deepslate_tiles
setblock 208 82 -10 minecraft:deepslate_tiles
setblock 176 82 -9 minecraft:deepslate_tiles
setblock 208 82 -9 minecraft:deepslate_tiles
setblock 176 82 -8 minecraft:deepslate_tiles
setblock 208 82 -8 minecraft:deepslate_tiles
setblock 176 82 -7 minecraft:deepslate_tiles
setblock 208 82 -7 minecraft:deepslate_tiles
setblock 176 82 -6 minecraft:deepslate_tiles
setblock 208 82 -6 minecraft:deepslate_tiles
setblock 177 82 -6 minecraft:waxed_cut_copper
setblock 207 82 -6 minecraft:waxed_cut_copper
setblock 176 82 -5 minecraft:deepslate_tiles
setblock 208 82 -5 minecraft:deepslate_tiles
setblock 176 82 -4 minecraft:deepslate_tiles
setblock 208 82 -4 minecraft:deepslate_tiles
setblock 176 82 -3 minecraft:deepslate_tiles
setblock 208 82 -3 minecraft:deepslate_tiles
setblock 176 82 -2 minecraft:deepslate_tiles
setblock 208 82 -2 minecraft:deepslate_tiles
setblock 176 82 -1 minecraft:deepslate_tiles
setblock 208 82 -1 minecraft:deepslate_tiles
setblock 176 82 0 minecraft:deepslate_tiles
setblock 208 82 0 minecraft:deepslate_tiles
setblock 177 82 0 minecraft:waxed_cut_copper
fill 182 82 0 202 82 0 minecraft:waxed_cut_copper
setblock 207 82 0 minecraft:waxed_cut_copper
setblock 176 82 1 minecraft:deepslate_tiles
setblock 208 82 1 minecraft:deepslate_tiles
setblock 176 82 2 minecraft:deepslate_tiles
setblock 208 82 2 minecraft:deepslate_tiles
setblock 176 82 3 minecraft:deepslate_tiles
setblock 208 82 3 minecraft:deepslate_tiles
setblock 176 82 4 minecraft:deepslate_tiles
setblock 208 82 4 minecraft:deepslate_tiles
setblock 176 82 5 minecraft:deepslate_tiles
setblock 208 82 5 minecraft:deepslate_tiles
setblock 176 82 6 minecraft:deepslate_tiles
setblock 208 82 6 minecraft:deepslate_tiles
setblock 177 82 6 minecraft:waxed_cut_copper
setblock 207 82 6 minecraft:waxed_cut_copper
setblock 176 82 7 minecraft:deepslate_tiles
setblock 208 82 7 minecraft:deepslate_tiles
setblock 176 82 8 minecraft:deepslate_tiles
setblock 208 82 8 minecraft:deepslate_tiles
setblock 176 82 9 minecraft:deepslate_tiles
setblock 208 82 9 minecraft:deepslate_tiles
setblock 176 82 10 minecraft:deepslate_tiles
setblock 208 82 10 minecraft:deepslate_tiles
setblock 176 82 11 minecraft:deepslate_tiles
setblock 208 82 11 minecraft:deepslate_tiles
setblock 176 82 12 minecraft:deepslate_tiles
setblock 208 82 12 minecraft:deepslate_tiles
setblock 177 82 12 minecraft:waxed_cut_copper
fill 182 82 12 202 82 12 minecraft:waxed_cut_copper
setblock 207 82 12 minecraft:waxed_cut_copper
setblock 176 82 13 minecraft:deepslate_tiles
setblock 208 82 13 minecraft:deepslate_tiles
setblock 176 82 14 minecraft:deepslate_tiles
setblock 208 82 14 minecraft:deepslate_tiles
setblock 176 82 15 minecraft:deepslate_tiles
setblock 208 82 15 minecraft:deepslate_tiles
setblock 180 82 15 minecraft:waxed_cut_copper
setblock 186 82 15 minecraft:waxed_cut_copper
setblock 192 82 15 minecraft:waxed_cut_copper
setblock 198 82 15 minecraft:waxed_cut_copper
setblock 204 82 15 minecraft:waxed_cut_copper
fill 176 82 16 208 82 16 minecraft:deepslate_tiles
fill 176 83 -16 208 83 -16 minecraft:deepslate_tiles
setblock 176 83 -15 minecraft:deepslate_tiles
setblock 208 83 -15 minecraft:deepslate_tiles
fill 177 83 -15 207 83 -15 minecraft:waxed_cut_copper
setblock 176 83 -14 minecraft:deepslate_tiles
setblock 208 83 -14 minecraft:deepslate_tiles
setblock 177 83 -14 minecraft:waxed_cut_copper
setblock 207 83 -14 minecraft:waxed_cut_copper
setblock 176 83 -13 minecraft:deepslate_tiles
setblock 208 83 -13 minecraft:deepslate_tiles
setblock 177 83 -13 minecraft:waxed_cut_copper
setblock 207 83 -13 minecraft:waxed_cut_copper
setblock 176 83 -12 minecraft:deepslate_tiles
setblock 208 83 -12 minecraft:deepslate_tiles
setblock 177 83 -12 minecraft:waxed_cut_copper
setblock 207 83 -12 minecraft:waxed_cut_copper
setblock 176 83 -11 minecraft:deepslate_tiles
setblock 208 83 -11 minecraft:deepslate_tiles
setblock 177 83 -11 minecraft:waxed_cut_copper
setblock 207 83 -11 minecraft:waxed_cut_copper
setblock 176 83 -10 minecraft:deepslate_tiles
setblock 208 83 -10 minecraft:deepslate_tiles
setblock 177 83 -10 minecraft:waxed_cut_copper
setblock 207 83 -10 minecraft:waxed_cut_copper
setblock 176 83 -9 minecraft:deepslate_tiles
setblock 208 83 -9 minecraft:deepslate_tiles
setblock 182 83 -9 minecraft:light_blue_stained_glass
setblock 199 83 -9 minecraft:light_blue_stained_glass
setblock 177 83 -9 minecraft:waxed_cut_copper
setblock 207 83 -9 minecraft:waxed_cut_copper
setblock 176 83 -8 minecraft:deepslate_tiles
setblock 208 83 -8 minecraft:deepslate_tiles
setblock 189 83 -8 minecraft:light_blue_stained_glass
setblock 177 83 -8 minecraft:waxed_cut_copper
setblock 207 83 -8 minecraft:waxed_cut_copper
setblock 176 83 -7 minecraft:deepslate_tiles
setblock 208 83 -7 minecraft:deepslate_tiles
setblock 177 83 -7 minecraft:waxed_cut_copper
setblock 207 83 -7 minecraft:waxed_cut_copper
setblock 176 83 -6 minecraft:deepslate_tiles
setblock 208 83 -6 minecraft:deepslate_tiles
setblock 177 83 -6 minecraft:waxed_cut_copper
setblock 207 83 -6 minecraft:waxed_cut_copper
setblock 176 83 -5 minecraft:deepslate_tiles
setblock 208 83 -5 minecraft:deepslate_tiles
setblock 177 83 -5 minecraft:waxed_cut_copper
setblock 207 83 -5 minecraft:waxed_cut_copper
setblock 176 83 -4 minecraft:deepslate_tiles
setblock 208 83 -4 minecraft:deepslate_tiles
setblock 202 83 -4 minecraft:light_blue_stained_glass
setblock 177 83 -4 minecraft:waxed_cut_copper
setblock 207 83 -4 minecraft:waxed_cut_copper
setblock 176 83 -3 minecraft:deepslate_tiles
setblock 208 83 -3 minecraft:deepslate_tiles
setblock 177 83 -3 minecraft:waxed_cut_copper
setblock 207 83 -3 minecraft:waxed_cut_copper
setblock 176 83 -2 minecraft:deepslate_tiles
setblock 208 83 -2 minecraft:deepslate_tiles
setblock 177 83 -2 minecraft:waxed_cut_copper
setblock 207 83 -2 minecraft:waxed_cut_copper
setblock 176 83 -1 minecraft:deepslate_tiles
setblock 208 83 -1 minecraft:deepslate_tiles
setblock 177 83 -1 minecraft:waxed_cut_copper
setblock 207 83 -1 minecraft:waxed_cut_copper
setblock 176 83 0 minecraft:deepslate_tiles
setblock 208 83 0 minecraft:deepslate_tiles
setblock 177 83 0 minecraft:waxed_cut_copper
setblock 207 83 0 minecraft:waxed_cut_copper
setblock 176 83 1 minecraft:deepslate_tiles
setblock 208 83 1 minecraft:deepslate_tiles
setblock 177 83 1 minecraft:waxed_cut_copper
setblock 207 83 1 minecraft:waxed_cut_copper
setblock 176 83 2 minecraft:deepslate_tiles
setblock 208 83 2 minecraft:deepslate_tiles
setblock 177 83 2 minecraft:waxed_cut_copper
setblock 207 83 2 minecraft:waxed_cut_copper
setblock 176 83 3 minecraft:deepslate_tiles
setblock 208 83 3 minecraft:deepslate_tiles
setblock 177 83 3 minecraft:waxed_cut_copper
setblock 207 83 3 minecraft:waxed_cut_copper
setblock 176 83 4 minecraft:deepslate_tiles
setblock 208 83 4 minecraft:deepslate_tiles
setblock 195 83 4 minecraft:light_blue_stained_glass
setblock 177 83 4 minecraft:waxed_cut_copper
setblock 207 83 4 minecraft:waxed_cut_copper
setblock 176 83 5 minecraft:deepslate_tiles
setblock 208 83 5 minecraft:deepslate_tiles
setblock 181 83 5 minecraft:light_blue_stained_glass
setblock 177 83 5 minecraft:waxed_cut_copper
setblock 207 83 5 minecraft:waxed_cut_copper
setblock 176 83 6 minecraft:deepslate_tiles
setblock 208 83 6 minecraft:deepslate_tiles
setblock 177 83 6 minecraft:waxed_cut_copper
setblock 207 83 6 minecraft:waxed_cut_copper
setblock 176 83 7 minecraft:deepslate_tiles
setblock 208 83 7 minecraft:deepslate_tiles
setblock 187 83 7 minecraft:light_blue_stained_glass
setblock 177 83 7 minecraft:waxed_cut_copper
setblock 207 83 7 minecraft:waxed_cut_copper
setblock 176 83 8 minecraft:deepslate_tiles
setblock 208 83 8 minecraft:deepslate_tiles
setblock 177 83 8 minecraft:waxed_cut_copper
setblock 207 83 8 minecraft:waxed_cut_copper
setblock 176 83 9 minecraft:deepslate_tiles
setblock 208 83 9 minecraft:deepslate_tiles
setblock 177 83 9 minecraft:waxed_cut_copper
setblock 207 83 9 minecraft:waxed_cut_copper
setblock 176 83 10 minecraft:deepslate_tiles
setblock 208 83 10 minecraft:deepslate_tiles
setblock 201 83 10 minecraft:light_blue_stained_glass
setblock 177 83 10 minecraft:waxed_cut_copper
setblock 207 83 10 minecraft:waxed_cut_copper
setblock 176 83 11 minecraft:deepslate_tiles
setblock 208 83 11 minecraft:deepslate_tiles
setblock 177 83 11 minecraft:waxed_cut_copper
setblock 207 83 11 minecraft:waxed_cut_copper
setblock 176 83 12 minecraft:deepslate_tiles
setblock 208 83 12 minecraft:deepslate_tiles
setblock 177 83 12 minecraft:waxed_cut_copper
setblock 207 83 12 minecraft:waxed_cut_copper
setblock 176 83 13 minecraft:deepslate_tiles
setblock 208 83 13 minecraft:deepslate_tiles
setblock 177 83 13 minecraft:waxed_cut_copper
setblock 207 83 13 minecraft:waxed_cut_copper
setblock 176 83 14 minecraft:deepslate_tiles
setblock 208 83 14 minecraft:deepslate_tiles
setblock 177 83 14 minecraft:waxed_cut_copper
setblock 207 83 14 minecraft:waxed_cut_copper
setblock 176 83 15 minecraft:deepslate_tiles
setblock 208 83 15 minecraft:deepslate_tiles
fill 177 83 15 207 83 15 minecraft:waxed_cut_copper
fill 176 83 16 208 83 16 minecraft:deepslate_tiles
fill 176 84 -16 208 84 -16 minecraft:black_concrete
fill 176 84 -15 208 84 -15 minecraft:black_concrete
fill 176 84 -14 208 84 -14 minecraft:black_concrete
fill 176 84 -13 208 84 -13 minecraft:black_concrete
fill 176 84 -12 208 84 -12 minecraft:black_concrete
fill 176 84 -11 208 84 -11 minecraft:black_concrete
fill 176 84 -10 208 84 -10 minecraft:black_concrete
fill 176 84 -9 181 84 -9 minecraft:black_concrete
fill 183 84 -9 198 84 -9 minecraft:black_concrete
fill 200 84 -9 208 84 -9 minecraft:black_concrete
setblock 182 84 -9 minecraft:sea_lantern
setblock 199 84 -9 minecraft:sea_lantern
fill 176 84 -8 188 84 -8 minecraft:black_concrete
fill 190 84 -8 208 84 -8 minecraft:black_concrete
setblock 189 84 -8 minecraft:sea_lantern
fill 176 84 -7 208 84 -7 minecraft:black_concrete
fill 176 84 -6 208 84 -6 minecraft:black_concrete
fill 176 84 -5 208 84 -5 minecraft:black_concrete
fill 176 84 -4 201 84 -4 minecraft:black_concrete
fill 203 84 -4 208 84 -4 minecraft:black_concrete
setblock 202 84 -4 minecraft:sea_lantern
fill 176 84 -3 208 84 -3 minecraft:black_concrete
fill 176 84 -2 208 84 -2 minecraft:black_concrete
fill 176 84 -1 208 84 -1 minecraft:black_concrete
fill 176 84 0 208 84 0 minecraft:black_concrete
fill 176 84 1 208 84 1 minecraft:black_concrete
fill 176 84 2 208 84 2 minecraft:black_concrete
fill 176 84 3 208 84 3 minecraft:black_concrete
fill 176 84 4 194 84 4 minecraft:black_concrete
fill 196 84 4 208 84 4 minecraft:black_concrete
setblock 195 84 4 minecraft:sea_lantern
fill 176 84 5 180 84 5 minecraft:black_concrete
fill 182 84 5 208 84 5 minecraft:black_concrete
setblock 181 84 5 minecraft:sea_lantern
fill 176 84 6 208 84 6 minecraft:black_concrete
fill 176 84 7 186 84 7 minecraft:black_concrete
fill 188 84 7 208 84 7 minecraft:black_concrete
setblock 187 84 7 minecraft:sea_lantern
fill 176 84 8 208 84 8 minecraft:black_concrete
fill 176 84 9 208 84 9 minecraft:black_concrete
fill 176 84 10 200 84 10 minecraft:black_concrete
fill 202 84 10 208 84 10 minecraft:black_concrete
setblock 201 84 10 minecraft:sea_lantern
fill 176 84 11 208 84 11 minecraft:black_concrete
fill 176 84 12 208 84 12 minecraft:black_concrete
fill 176 84 13 208 84 13 minecraft:black_concrete
fill 176 84 14 208 84 14 minecraft:black_concrete
fill 176 84 15 208 84 15 minecraft:black_concrete
fill 176 84 16 208 84 16 minecraft:black_concrete
schedule function signal:world/build_4 1t replace
