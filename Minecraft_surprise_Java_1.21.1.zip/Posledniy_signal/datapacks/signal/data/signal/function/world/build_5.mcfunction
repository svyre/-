fill 304 55 -16 336 84 16 minecraft:air
fill 304 61 -16 336 61 -16 minecraft:bedrock
fill 304 61 -15 336 61 -15 minecraft:bedrock
fill 304 61 -14 336 61 -14 minecraft:bedrock
fill 304 61 -13 336 61 -13 minecraft:bedrock
fill 304 61 -12 336 61 -12 minecraft:bedrock
fill 304 61 -11 336 61 -11 minecraft:bedrock
fill 304 61 -10 336 61 -10 minecraft:bedrock
fill 304 61 -9 336 61 -9 minecraft:bedrock
fill 304 61 -8 336 61 -8 minecraft:bedrock
fill 304 61 -7 336 61 -7 minecraft:bedrock
fill 304 61 -6 336 61 -6 minecraft:bedrock
fill 304 61 -5 336 61 -5 minecraft:bedrock
fill 304 61 -4 336 61 -4 minecraft:bedrock
fill 304 61 -3 336 61 -3 minecraft:bedrock
fill 304 61 -2 336 61 -2 minecraft:bedrock
fill 304 61 -1 336 61 -1 minecraft:bedrock
fill 304 61 0 336 61 0 minecraft:bedrock
fill 304 61 1 336 61 1 minecraft:bedrock
fill 304 61 2 336 61 2 minecraft:bedrock
fill 304 61 3 336 61 3 minecraft:bedrock
fill 304 61 4 336 61 4 minecraft:bedrock
fill 304 61 5 336 61 5 minecraft:bedrock
fill 304 61 6 336 61 6 minecraft:bedrock
fill 304 61 7 336 61 7 minecraft:bedrock
fill 304 61 8 336 61 8 minecraft:bedrock
fill 304 61 9 336 61 9 minecraft:bedrock
fill 304 61 10 336 61 10 minecraft:bedrock
fill 304 61 11 336 61 11 minecraft:bedrock
fill 304 61 12 336 61 12 minecraft:bedrock
fill 304 61 13 336 61 13 minecraft:bedrock
fill 304 61 14 336 61 14 minecraft:bedrock
fill 304 61 15 336 61 15 minecraft:bedrock
fill 304 61 16 336 61 16 minecraft:bedrock
fill 304 62 -16 336 62 -16 minecraft:bedrock
fill 304 62 -15 336 62 -15 minecraft:bedrock
fill 304 62 -14 336 62 -14 minecraft:bedrock
fill 304 62 -13 336 62 -13 minecraft:bedrock
fill 304 62 -12 336 62 -12 minecraft:bedrock
fill 304 62 -11 336 62 -11 minecraft:bedrock
fill 304 62 -10 336 62 -10 minecraft:bedrock
fill 304 62 -9 336 62 -9 minecraft:bedrock
fill 304 62 -8 336 62 -8 minecraft:bedrock
fill 304 62 -7 336 62 -7 minecraft:bedrock
fill 304 62 -6 336 62 -6 minecraft:bedrock
fill 304 62 -5 336 62 -5 minecraft:bedrock
fill 304 62 -4 336 62 -4 minecraft:bedrock
fill 304 62 -3 336 62 -3 minecraft:bedrock
fill 304 62 -2 336 62 -2 minecraft:bedrock
fill 304 62 -1 336 62 -1 minecraft:bedrock
fill 304 62 0 336 62 0 minecraft:bedrock
fill 304 62 1 336 62 1 minecraft:bedrock
fill 304 62 2 336 62 2 minecraft:bedrock
fill 304 62 3 336 62 3 minecraft:bedrock
fill 304 62 4 336 62 4 minecraft:bedrock
fill 304 62 5 336 62 5 minecraft:bedrock
fill 304 62 6 336 62 6 minecraft:bedrock
fill 304 62 7 336 62 7 minecraft:bedrock
fill 304 62 8 336 62 8 minecraft:bedrock
fill 304 62 9 336 62 9 minecraft:bedrock
fill 304 62 10 336 62 10 minecraft:bedrock
fill 304 62 11 336 62 11 minecraft:bedrock
fill 304 62 12 336 62 12 minecraft:bedrock
fill 304 62 13 336 62 13 minecraft:bedrock
fill 304 62 14 336 62 14 minecraft:bedrock
fill 304 62 15 336 62 15 minecraft:bedrock
fill 304 62 16 336 62 16 minecraft:bedrock
fill 304 63 -16 336 63 -16 minecraft:deepslate_tiles
setblock 304 63 -15 minecraft:deepslate_tiles
setblock 336 63 -15 minecraft:deepslate_tiles
fill 305 63 -15 335 63 -15 minecraft:quartz_block
setblock 304 63 -14 minecraft:deepslate_tiles
setblock 336 63 -14 minecraft:deepslate_tiles
fill 306 63 -14 334 63 -14 minecraft:polished_deepslate
setblock 305 63 -14 minecraft:quartz_block
setblock 335 63 -14 minecraft:quartz_block
setblock 304 63 -13 minecraft:deepslate_tiles
setblock 307 63 -13 minecraft:deepslate_tiles
setblock 309 63 -13 minecraft:deepslate_tiles
setblock 311 63 -13 minecraft:deepslate_tiles
setblock 313 63 -13 minecraft:deepslate_tiles
setblock 315 63 -13 minecraft:deepslate_tiles
setblock 317 63 -13 minecraft:deepslate_tiles
setblock 319 63 -13 minecraft:deepslate_tiles
setblock 321 63 -13 minecraft:deepslate_tiles
setblock 323 63 -13 minecraft:deepslate_tiles
setblock 325 63 -13 minecraft:deepslate_tiles
setblock 327 63 -13 minecraft:deepslate_tiles
setblock 329 63 -13 minecraft:deepslate_tiles
setblock 331 63 -13 minecraft:deepslate_tiles
setblock 333 63 -13 minecraft:deepslate_tiles
setblock 336 63 -13 minecraft:deepslate_tiles
setblock 306 63 -13 minecraft:polished_deepslate
setblock 308 63 -13 minecraft:polished_deepslate
setblock 310 63 -13 minecraft:polished_deepslate
setblock 312 63 -13 minecraft:polished_deepslate
setblock 314 63 -13 minecraft:polished_deepslate
setblock 316 63 -13 minecraft:polished_deepslate
setblock 318 63 -13 minecraft:polished_deepslate
setblock 320 63 -13 minecraft:polished_deepslate
setblock 322 63 -13 minecraft:polished_deepslate
setblock 324 63 -13 minecraft:polished_deepslate
setblock 326 63 -13 minecraft:polished_deepslate
setblock 328 63 -13 minecraft:polished_deepslate
setblock 330 63 -13 minecraft:polished_deepslate
setblock 332 63 -13 minecraft:polished_deepslate
setblock 334 63 -13 minecraft:polished_deepslate
setblock 305 63 -13 minecraft:quartz_block
setblock 335 63 -13 minecraft:quartz_block
setblock 304 63 -12 minecraft:deepslate_tiles
setblock 308 63 -12 minecraft:deepslate_tiles
setblock 310 63 -12 minecraft:deepslate_tiles
setblock 312 63 -12 minecraft:deepslate_tiles
setblock 314 63 -12 minecraft:deepslate_tiles
setblock 316 63 -12 minecraft:deepslate_tiles
setblock 318 63 -12 minecraft:deepslate_tiles
setblock 322 63 -12 minecraft:deepslate_tiles
setblock 324 63 -12 minecraft:deepslate_tiles
setblock 326 63 -12 minecraft:deepslate_tiles
setblock 328 63 -12 minecraft:deepslate_tiles
setblock 330 63 -12 minecraft:deepslate_tiles
setblock 332 63 -12 minecraft:deepslate_tiles
setblock 336 63 -12 minecraft:deepslate_tiles
fill 306 63 -12 307 63 -12 minecraft:polished_deepslate
setblock 311 63 -12 minecraft:polished_deepslate
setblock 313 63 -12 minecraft:polished_deepslate
setblock 315 63 -12 minecraft:polished_deepslate
setblock 317 63 -12 minecraft:polished_deepslate
setblock 323 63 -12 minecraft:polished_deepslate
setblock 325 63 -12 minecraft:polished_deepslate
setblock 327 63 -12 minecraft:polished_deepslate
setblock 329 63 -12 minecraft:polished_deepslate
fill 333 63 -12 334 63 -12 minecraft:polished_deepslate
setblock 305 63 -12 minecraft:quartz_block
setblock 309 63 -12 minecraft:quartz_block
setblock 331 63 -12 minecraft:quartz_block
setblock 335 63 -12 minecraft:quartz_block
fill 319 63 -12 321 63 -12 minecraft:waxed_oxidized_cut_copper
setblock 304 63 -11 minecraft:deepslate_tiles
setblock 307 63 -11 minecraft:deepslate_tiles
setblock 311 63 -11 minecraft:deepslate_tiles
setblock 313 63 -11 minecraft:deepslate_tiles
setblock 315 63 -11 minecraft:deepslate_tiles
setblock 325 63 -11 minecraft:deepslate_tiles
setblock 327 63 -11 minecraft:deepslate_tiles
setblock 329 63 -11 minecraft:deepslate_tiles
setblock 333 63 -11 minecraft:deepslate_tiles
setblock 336 63 -11 minecraft:deepslate_tiles
setblock 306 63 -11 minecraft:polished_deepslate
setblock 312 63 -11 minecraft:polished_deepslate
setblock 314 63 -11 minecraft:polished_deepslate
setblock 326 63 -11 minecraft:polished_deepslate
setblock 328 63 -11 minecraft:polished_deepslate
setblock 334 63 -11 minecraft:polished_deepslate
setblock 305 63 -11 minecraft:quartz_block
setblock 308 63 -11 minecraft:quartz_block
setblock 310 63 -11 minecraft:quartz_block
fill 316 63 -11 318 63 -11 minecraft:quartz_block
fill 322 63 -11 324 63 -11 minecraft:quartz_block
setblock 330 63 -11 minecraft:quartz_block
setblock 332 63 -11 minecraft:quartz_block
setblock 335 63 -11 minecraft:quartz_block
setblock 309 63 -11 minecraft:sea_lantern
setblock 331 63 -11 minecraft:sea_lantern
fill 319 63 -11 321 63 -11 minecraft:waxed_oxidized_cut_copper
fill 309 63 -10 313 63 -10 minecraft:cyan_concrete
setblock 304 63 -10 minecraft:deepslate_tiles
setblock 308 63 -10 minecraft:deepslate_tiles
setblock 316 63 -10 minecraft:deepslate_tiles
setblock 318 63 -10 minecraft:deepslate_tiles
setblock 322 63 -10 minecraft:deepslate_tiles
setblock 324 63 -10 minecraft:deepslate_tiles
setblock 332 63 -10 minecraft:deepslate_tiles
setblock 336 63 -10 minecraft:deepslate_tiles
fill 327 63 -10 331 63 -10 minecraft:orange_concrete
fill 306 63 -10 307 63 -10 minecraft:polished_deepslate
setblock 317 63 -10 minecraft:polished_deepslate
setblock 323 63 -10 minecraft:polished_deepslate
fill 333 63 -10 334 63 -10 minecraft:polished_deepslate
setblock 305 63 -10 minecraft:quartz_block
fill 314 63 -10 315 63 -10 minecraft:quartz_block
fill 325 63 -10 326 63 -10 minecraft:quartz_block
setblock 335 63 -10 minecraft:quartz_block
fill 319 63 -10 321 63 -10 minecraft:waxed_oxidized_cut_copper
fill 309 63 -9 313 63 -9 minecraft:cyan_concrete
setblock 304 63 -9 minecraft:deepslate_tiles
setblock 307 63 -9 minecraft:deepslate_tiles
setblock 315 63 -9 minecraft:deepslate_tiles
setblock 317 63 -9 minecraft:deepslate_tiles
setblock 323 63 -9 minecraft:deepslate_tiles
setblock 325 63 -9 minecraft:deepslate_tiles
setblock 333 63 -9 minecraft:deepslate_tiles
setblock 336 63 -9 minecraft:deepslate_tiles
fill 327 63 -9 331 63 -9 minecraft:orange_concrete
setblock 306 63 -9 minecraft:polished_deepslate
setblock 308 63 -9 minecraft:polished_deepslate
setblock 316 63 -9 minecraft:polished_deepslate
setblock 318 63 -9 minecraft:polished_deepslate
setblock 322 63 -9 minecraft:polished_deepslate
setblock 324 63 -9 minecraft:polished_deepslate
setblock 332 63 -9 minecraft:polished_deepslate
setblock 334 63 -9 minecraft:polished_deepslate
setblock 305 63 -9 minecraft:quartz_block
setblock 314 63 -9 minecraft:quartz_block
setblock 326 63 -9 minecraft:quartz_block
setblock 335 63 -9 minecraft:quartz_block
fill 319 63 -9 321 63 -9 minecraft:waxed_oxidized_cut_copper
fill 309 63 -8 313 63 -8 minecraft:cyan_concrete
setblock 304 63 -8 minecraft:deepslate_tiles
setblock 308 63 -8 minecraft:deepslate_tiles
setblock 314 63 -8 minecraft:deepslate_tiles
setblock 316 63 -8 minecraft:deepslate_tiles
setblock 318 63 -8 minecraft:deepslate_tiles
setblock 322 63 -8 minecraft:deepslate_tiles
setblock 324 63 -8 minecraft:deepslate_tiles
setblock 326 63 -8 minecraft:deepslate_tiles
setblock 332 63 -8 minecraft:deepslate_tiles
setblock 336 63 -8 minecraft:deepslate_tiles
fill 327 63 -8 331 63 -8 minecraft:orange_concrete
fill 306 63 -8 307 63 -8 minecraft:polished_deepslate
setblock 315 63 -8 minecraft:polished_deepslate
setblock 317 63 -8 minecraft:polished_deepslate
setblock 323 63 -8 minecraft:polished_deepslate
setblock 325 63 -8 minecraft:polished_deepslate
fill 333 63 -8 334 63 -8 minecraft:polished_deepslate
setblock 305 63 -8 minecraft:quartz_block
setblock 335 63 -8 minecraft:quartz_block
fill 319 63 -8 321 63 -8 minecraft:waxed_oxidized_cut_copper
fill 309 63 -7 313 63 -7 minecraft:cyan_concrete
setblock 304 63 -7 minecraft:deepslate_tiles
setblock 307 63 -7 minecraft:deepslate_tiles
setblock 315 63 -7 minecraft:deepslate_tiles
setblock 317 63 -7 minecraft:deepslate_tiles
setblock 323 63 -7 minecraft:deepslate_tiles
setblock 325 63 -7 minecraft:deepslate_tiles
setblock 333 63 -7 minecraft:deepslate_tiles
setblock 336 63 -7 minecraft:deepslate_tiles
fill 327 63 -7 331 63 -7 minecraft:orange_concrete
setblock 306 63 -7 minecraft:polished_deepslate
setblock 308 63 -7 minecraft:polished_deepslate
setblock 314 63 -7 minecraft:polished_deepslate
setblock 316 63 -7 minecraft:polished_deepslate
setblock 318 63 -7 minecraft:polished_deepslate
setblock 322 63 -7 minecraft:polished_deepslate
setblock 324 63 -7 minecraft:polished_deepslate
setblock 326 63 -7 minecraft:polished_deepslate
setblock 332 63 -7 minecraft:polished_deepslate
setblock 334 63 -7 minecraft:polished_deepslate
setblock 305 63 -7 minecraft:quartz_block
setblock 335 63 -7 minecraft:quartz_block
fill 319 63 -7 321 63 -7 minecraft:waxed_oxidized_cut_copper
fill 309 63 -6 313 63 -6 minecraft:cyan_concrete
setblock 304 63 -6 minecraft:deepslate_tiles
setblock 308 63 -6 minecraft:deepslate_tiles
setblock 314 63 -6 minecraft:deepslate_tiles
setblock 316 63 -6 minecraft:deepslate_tiles
setblock 318 63 -6 minecraft:deepslate_tiles
setblock 322 63 -6 minecraft:deepslate_tiles
setblock 324 63 -6 minecraft:deepslate_tiles
setblock 326 63 -6 minecraft:deepslate_tiles
setblock 332 63 -6 minecraft:deepslate_tiles
setblock 336 63 -6 minecraft:deepslate_tiles
fill 327 63 -6 331 63 -6 minecraft:orange_concrete
fill 306 63 -6 307 63 -6 minecraft:polished_deepslate
setblock 315 63 -6 minecraft:polished_deepslate
setblock 317 63 -6 minecraft:polished_deepslate
setblock 323 63 -6 minecraft:polished_deepslate
setblock 325 63 -6 minecraft:polished_deepslate
fill 333 63 -6 334 63 -6 minecraft:polished_deepslate
setblock 305 63 -6 minecraft:quartz_block
setblock 335 63 -6 minecraft:quartz_block
fill 319 63 -6 321 63 -6 minecraft:waxed_oxidized_cut_copper
setblock 315 63 -5 minecraft:chiseled_deepslate
setblock 325 63 -5 minecraft:chiseled_deepslate
setblock 304 63 -5 minecraft:deepslate_tiles
setblock 307 63 -5 minecraft:deepslate_tiles
setblock 309 63 -5 minecraft:deepslate_tiles
setblock 311 63 -5 minecraft:deepslate_tiles
setblock 313 63 -5 minecraft:deepslate_tiles
setblock 317 63 -5 minecraft:deepslate_tiles
setblock 323 63 -5 minecraft:deepslate_tiles
setblock 327 63 -5 minecraft:deepslate_tiles
setblock 329 63 -5 minecraft:deepslate_tiles
setblock 331 63 -5 minecraft:deepslate_tiles
setblock 333 63 -5 minecraft:deepslate_tiles
setblock 336 63 -5 minecraft:deepslate_tiles
setblock 306 63 -5 minecraft:polished_deepslate
setblock 308 63 -5 minecraft:polished_deepslate
setblock 312 63 -5 minecraft:polished_deepslate
setblock 314 63 -5 minecraft:polished_deepslate
setblock 316 63 -5 minecraft:polished_deepslate
setblock 318 63 -5 minecraft:polished_deepslate
setblock 322 63 -5 minecraft:polished_deepslate
setblock 324 63 -5 minecraft:polished_deepslate
setblock 326 63 -5 minecraft:polished_deepslate
setblock 328 63 -5 minecraft:polished_deepslate
setblock 332 63 -5 minecraft:polished_deepslate
setblock 334 63 -5 minecraft:polished_deepslate
setblock 305 63 -5 minecraft:quartz_block
setblock 310 63 -5 minecraft:quartz_block
setblock 330 63 -5 minecraft:quartz_block
setblock 335 63 -5 minecraft:quartz_block
fill 319 63 -5 321 63 -5 minecraft:waxed_oxidized_cut_copper
setblock 304 63 -4 minecraft:deepslate_tiles
setblock 308 63 -4 minecraft:deepslate_tiles
setblock 310 63 -4 minecraft:deepslate_tiles
setblock 312 63 -4 minecraft:deepslate_tiles
setblock 314 63 -4 minecraft:deepslate_tiles
setblock 316 63 -4 minecraft:deepslate_tiles
setblock 318 63 -4 minecraft:deepslate_tiles
setblock 322 63 -4 minecraft:deepslate_tiles
setblock 324 63 -4 minecraft:deepslate_tiles
setblock 326 63 -4 minecraft:deepslate_tiles
setblock 328 63 -4 minecraft:deepslate_tiles
setblock 330 63 -4 minecraft:deepslate_tiles
setblock 332 63 -4 minecraft:deepslate_tiles
setblock 336 63 -4 minecraft:deepslate_tiles
fill 306 63 -4 307 63 -4 minecraft:polished_deepslate
setblock 311 63 -4 minecraft:polished_deepslate
setblock 313 63 -4 minecraft:polished_deepslate
setblock 315 63 -4 minecraft:polished_deepslate
setblock 317 63 -4 minecraft:polished_deepslate
setblock 323 63 -4 minecraft:polished_deepslate
setblock 325 63 -4 minecraft:polished_deepslate
setblock 327 63 -4 minecraft:polished_deepslate
setblock 329 63 -4 minecraft:polished_deepslate
fill 333 63 -4 334 63 -4 minecraft:polished_deepslate
setblock 305 63 -4 minecraft:quartz_block
setblock 309 63 -4 minecraft:quartz_block
setblock 331 63 -4 minecraft:quartz_block
setblock 335 63 -4 minecraft:quartz_block
fill 319 63 -4 321 63 -4 minecraft:waxed_oxidized_cut_copper
setblock 304 63 -3 minecraft:deepslate_tiles
setblock 307 63 -3 minecraft:deepslate_tiles
setblock 311 63 -3 minecraft:deepslate_tiles
setblock 313 63 -3 minecraft:deepslate_tiles
setblock 315 63 -3 minecraft:deepslate_tiles
setblock 317 63 -3 minecraft:deepslate_tiles
setblock 323 63 -3 minecraft:deepslate_tiles
setblock 325 63 -3 minecraft:deepslate_tiles
setblock 327 63 -3 minecraft:deepslate_tiles
setblock 329 63 -3 minecraft:deepslate_tiles
setblock 333 63 -3 minecraft:deepslate_tiles
setblock 336 63 -3 minecraft:deepslate_tiles
setblock 306 63 -3 minecraft:polished_deepslate
setblock 308 63 -3 minecraft:polished_deepslate
setblock 310 63 -3 minecraft:polished_deepslate
setblock 312 63 -3 minecraft:polished_deepslate
setblock 314 63 -3 minecraft:polished_deepslate
setblock 316 63 -3 minecraft:polished_deepslate
setblock 318 63 -3 minecraft:polished_deepslate
setblock 322 63 -3 minecraft:polished_deepslate
setblock 324 63 -3 minecraft:polished_deepslate
setblock 326 63 -3 minecraft:polished_deepslate
setblock 328 63 -3 minecraft:polished_deepslate
setblock 330 63 -3 minecraft:polished_deepslate
setblock 332 63 -3 minecraft:polished_deepslate
setblock 334 63 -3 minecraft:polished_deepslate
setblock 305 63 -3 minecraft:quartz_block
setblock 309 63 -3 minecraft:quartz_block
setblock 331 63 -3 minecraft:quartz_block
setblock 335 63 -3 minecraft:quartz_block
fill 319 63 -3 321 63 -3 minecraft:waxed_oxidized_cut_copper
setblock 304 63 -2 minecraft:deepslate_tiles
setblock 308 63 -2 minecraft:deepslate_tiles
setblock 310 63 -2 minecraft:deepslate_tiles
setblock 312 63 -2 minecraft:deepslate_tiles
setblock 314 63 -2 minecraft:deepslate_tiles
setblock 316 63 -2 minecraft:deepslate_tiles
setblock 318 63 -2 minecraft:deepslate_tiles
setblock 322 63 -2 minecraft:deepslate_tiles
setblock 324 63 -2 minecraft:deepslate_tiles
setblock 326 63 -2 minecraft:deepslate_tiles
setblock 328 63 -2 minecraft:deepslate_tiles
setblock 330 63 -2 minecraft:deepslate_tiles
setblock 332 63 -2 minecraft:deepslate_tiles
setblock 336 63 -2 minecraft:deepslate_tiles
fill 306 63 -2 307 63 -2 minecraft:polished_deepslate
setblock 311 63 -2 minecraft:polished_deepslate
setblock 313 63 -2 minecraft:polished_deepslate
setblock 315 63 -2 minecraft:polished_deepslate
setblock 317 63 -2 minecraft:polished_deepslate
setblock 323 63 -2 minecraft:polished_deepslate
setblock 325 63 -2 minecraft:polished_deepslate
setblock 327 63 -2 minecraft:polished_deepslate
setblock 329 63 -2 minecraft:polished_deepslate
fill 333 63 -2 334 63 -2 minecraft:polished_deepslate
setblock 305 63 -2 minecraft:quartz_block
setblock 309 63 -2 minecraft:quartz_block
setblock 331 63 -2 minecraft:quartz_block
setblock 335 63 -2 minecraft:quartz_block
fill 319 63 -2 321 63 -2 minecraft:waxed_oxidized_cut_copper
setblock 304 63 -1 minecraft:deepslate_tiles
setblock 307 63 -1 minecraft:deepslate_tiles
setblock 333 63 -1 minecraft:deepslate_tiles
setblock 336 63 -1 minecraft:deepslate_tiles
setblock 306 63 -1 minecraft:polished_deepslate
setblock 334 63 -1 minecraft:polished_deepslate
setblock 305 63 -1 minecraft:quartz_block
setblock 335 63 -1 minecraft:quartz_block
fill 308 63 -1 332 63 -1 minecraft:waxed_oxidized_cut_copper
setblock 304 63 0 minecraft:deepslate_tiles
setblock 336 63 0 minecraft:deepslate_tiles
fill 306 63 0 307 63 0 minecraft:polished_deepslate
fill 333 63 0 334 63 0 minecraft:polished_deepslate
setblock 305 63 0 minecraft:quartz_block
setblock 335 63 0 minecraft:quartz_block
fill 308 63 0 332 63 0 minecraft:waxed_oxidized_cut_copper
setblock 304 63 1 minecraft:deepslate_tiles
setblock 307 63 1 minecraft:deepslate_tiles
setblock 333 63 1 minecraft:deepslate_tiles
setblock 336 63 1 minecraft:deepslate_tiles
setblock 306 63 1 minecraft:polished_deepslate
setblock 334 63 1 minecraft:polished_deepslate
setblock 305 63 1 minecraft:quartz_block
setblock 335 63 1 minecraft:quartz_block
fill 308 63 1 332 63 1 minecraft:waxed_oxidized_cut_copper
setblock 304 63 2 minecraft:deepslate_tiles
setblock 308 63 2 minecraft:deepslate_tiles
setblock 310 63 2 minecraft:deepslate_tiles
setblock 312 63 2 minecraft:deepslate_tiles
setblock 314 63 2 minecraft:deepslate_tiles
setblock 316 63 2 minecraft:deepslate_tiles
setblock 318 63 2 minecraft:deepslate_tiles
setblock 322 63 2 minecraft:deepslate_tiles
setblock 324 63 2 minecraft:deepslate_tiles
setblock 326 63 2 minecraft:deepslate_tiles
setblock 328 63 2 minecraft:deepslate_tiles
setblock 330 63 2 minecraft:deepslate_tiles
setblock 332 63 2 minecraft:deepslate_tiles
setblock 336 63 2 minecraft:deepslate_tiles
fill 306 63 2 307 63 2 minecraft:polished_deepslate
setblock 311 63 2 minecraft:polished_deepslate
setblock 313 63 2 minecraft:polished_deepslate
setblock 315 63 2 minecraft:polished_deepslate
setblock 317 63 2 minecraft:polished_deepslate
setblock 323 63 2 minecraft:polished_deepslate
setblock 325 63 2 minecraft:polished_deepslate
setblock 327 63 2 minecraft:polished_deepslate
setblock 329 63 2 minecraft:polished_deepslate
fill 333 63 2 334 63 2 minecraft:polished_deepslate
setblock 305 63 2 minecraft:quartz_block
setblock 309 63 2 minecraft:quartz_block
setblock 331 63 2 minecraft:quartz_block
setblock 335 63 2 minecraft:quartz_block
fill 319 63 2 321 63 2 minecraft:waxed_oxidized_cut_copper
setblock 304 63 3 minecraft:deepslate_tiles
setblock 307 63 3 minecraft:deepslate_tiles
setblock 311 63 3 minecraft:deepslate_tiles
setblock 313 63 3 minecraft:deepslate_tiles
setblock 315 63 3 minecraft:deepslate_tiles
setblock 317 63 3 minecraft:deepslate_tiles
setblock 323 63 3 minecraft:deepslate_tiles
setblock 325 63 3 minecraft:deepslate_tiles
setblock 327 63 3 minecraft:deepslate_tiles
setblock 329 63 3 minecraft:deepslate_tiles
setblock 333 63 3 minecraft:deepslate_tiles
setblock 336 63 3 minecraft:deepslate_tiles
setblock 306 63 3 minecraft:polished_deepslate
setblock 308 63 3 minecraft:polished_deepslate
setblock 310 63 3 minecraft:polished_deepslate
setblock 312 63 3 minecraft:polished_deepslate
setblock 314 63 3 minecraft:polished_deepslate
setblock 316 63 3 minecraft:polished_deepslate
setblock 318 63 3 minecraft:polished_deepslate
setblock 322 63 3 minecraft:polished_deepslate
setblock 324 63 3 minecraft:polished_deepslate
setblock 326 63 3 minecraft:polished_deepslate
setblock 328 63 3 minecraft:polished_deepslate
setblock 330 63 3 minecraft:polished_deepslate
setblock 332 63 3 minecraft:polished_deepslate
setblock 334 63 3 minecraft:polished_deepslate
setblock 305 63 3 minecraft:quartz_block
setblock 309 63 3 minecraft:quartz_block
setblock 331 63 3 minecraft:quartz_block
setblock 335 63 3 minecraft:quartz_block
fill 319 63 3 321 63 3 minecraft:waxed_oxidized_cut_copper
setblock 304 63 4 minecraft:deepslate_tiles
setblock 308 63 4 minecraft:deepslate_tiles
setblock 310 63 4 minecraft:deepslate_tiles
setblock 312 63 4 minecraft:deepslate_tiles
setblock 314 63 4 minecraft:deepslate_tiles
setblock 316 63 4 minecraft:deepslate_tiles
setblock 318 63 4 minecraft:deepslate_tiles
setblock 322 63 4 minecraft:deepslate_tiles
setblock 324 63 4 minecraft:deepslate_tiles
setblock 326 63 4 minecraft:deepslate_tiles
setblock 328 63 4 minecraft:deepslate_tiles
setblock 330 63 4 minecraft:deepslate_tiles
setblock 332 63 4 minecraft:deepslate_tiles
setblock 336 63 4 minecraft:deepslate_tiles
fill 306 63 4 307 63 4 minecraft:polished_deepslate
setblock 311 63 4 minecraft:polished_deepslate
setblock 313 63 4 minecraft:polished_deepslate
setblock 315 63 4 minecraft:polished_deepslate
setblock 317 63 4 minecraft:polished_deepslate
setblock 323 63 4 minecraft:polished_deepslate
setblock 325 63 4 minecraft:polished_deepslate
setblock 327 63 4 minecraft:polished_deepslate
setblock 329 63 4 minecraft:polished_deepslate
fill 333 63 4 334 63 4 minecraft:polished_deepslate
setblock 305 63 4 minecraft:quartz_block
setblock 309 63 4 minecraft:quartz_block
setblock 331 63 4 minecraft:quartz_block
setblock 335 63 4 minecraft:quartz_block
fill 319 63 4 321 63 4 minecraft:waxed_oxidized_cut_copper
setblock 315 63 5 minecraft:chiseled_deepslate
setblock 325 63 5 minecraft:chiseled_deepslate
setblock 304 63 5 minecraft:deepslate_tiles
setblock 307 63 5 minecraft:deepslate_tiles
setblock 309 63 5 minecraft:deepslate_tiles
setblock 311 63 5 minecraft:deepslate_tiles
setblock 313 63 5 minecraft:deepslate_tiles
setblock 317 63 5 minecraft:deepslate_tiles
setblock 323 63 5 minecraft:deepslate_tiles
setblock 327 63 5 minecraft:deepslate_tiles
setblock 329 63 5 minecraft:deepslate_tiles
setblock 331 63 5 minecraft:deepslate_tiles
setblock 333 63 5 minecraft:deepslate_tiles
setblock 336 63 5 minecraft:deepslate_tiles
setblock 306 63 5 minecraft:polished_deepslate
setblock 308 63 5 minecraft:polished_deepslate
setblock 312 63 5 minecraft:polished_deepslate
setblock 314 63 5 minecraft:polished_deepslate
setblock 316 63 5 minecraft:polished_deepslate
setblock 318 63 5 minecraft:polished_deepslate
setblock 322 63 5 minecraft:polished_deepslate
setblock 324 63 5 minecraft:polished_deepslate
setblock 326 63 5 minecraft:polished_deepslate
setblock 328 63 5 minecraft:polished_deepslate
setblock 332 63 5 minecraft:polished_deepslate
setblock 334 63 5 minecraft:polished_deepslate
setblock 305 63 5 minecraft:quartz_block
setblock 310 63 5 minecraft:quartz_block
setblock 330 63 5 minecraft:quartz_block
setblock 335 63 5 minecraft:quartz_block
fill 319 63 5 321 63 5 minecraft:waxed_oxidized_cut_copper
setblock 304 63 6 minecraft:deepslate_tiles
setblock 308 63 6 minecraft:deepslate_tiles
setblock 314 63 6 minecraft:deepslate_tiles
setblock 316 63 6 minecraft:deepslate_tiles
setblock 318 63 6 minecraft:deepslate_tiles
setblock 322 63 6 minecraft:deepslate_tiles
setblock 324 63 6 minecraft:deepslate_tiles
setblock 326 63 6 minecraft:deepslate_tiles
setblock 332 63 6 minecraft:deepslate_tiles
setblock 336 63 6 minecraft:deepslate_tiles
fill 309 63 6 313 63 6 minecraft:lime_concrete
fill 327 63 6 331 63 6 minecraft:magenta_concrete
fill 306 63 6 307 63 6 minecraft:polished_deepslate
setblock 315 63 6 minecraft:polished_deepslate
setblock 317 63 6 minecraft:polished_deepslate
setblock 323 63 6 minecraft:polished_deepslate
setblock 325 63 6 minecraft:polished_deepslate
fill 333 63 6 334 63 6 minecraft:polished_deepslate
setblock 305 63 6 minecraft:quartz_block
setblock 335 63 6 minecraft:quartz_block
fill 319 63 6 321 63 6 minecraft:waxed_oxidized_cut_copper
setblock 304 63 7 minecraft:deepslate_tiles
setblock 307 63 7 minecraft:deepslate_tiles
setblock 315 63 7 minecraft:deepslate_tiles
setblock 317 63 7 minecraft:deepslate_tiles
setblock 323 63 7 minecraft:deepslate_tiles
setblock 325 63 7 minecraft:deepslate_tiles
setblock 333 63 7 minecraft:deepslate_tiles
setblock 336 63 7 minecraft:deepslate_tiles
fill 309 63 7 313 63 7 minecraft:lime_concrete
fill 327 63 7 331 63 7 minecraft:magenta_concrete
setblock 306 63 7 minecraft:polished_deepslate
setblock 308 63 7 minecraft:polished_deepslate
setblock 314 63 7 minecraft:polished_deepslate
setblock 316 63 7 minecraft:polished_deepslate
setblock 318 63 7 minecraft:polished_deepslate
setblock 322 63 7 minecraft:polished_deepslate
setblock 324 63 7 minecraft:polished_deepslate
setblock 326 63 7 minecraft:polished_deepslate
setblock 332 63 7 minecraft:polished_deepslate
setblock 334 63 7 minecraft:polished_deepslate
setblock 305 63 7 minecraft:quartz_block
setblock 335 63 7 minecraft:quartz_block
fill 319 63 7 321 63 7 minecraft:waxed_oxidized_cut_copper
setblock 304 63 8 minecraft:deepslate_tiles
setblock 308 63 8 minecraft:deepslate_tiles
setblock 314 63 8 minecraft:deepslate_tiles
setblock 316 63 8 minecraft:deepslate_tiles
setblock 318 63 8 minecraft:deepslate_tiles
setblock 322 63 8 minecraft:deepslate_tiles
setblock 324 63 8 minecraft:deepslate_tiles
setblock 326 63 8 minecraft:deepslate_tiles
setblock 332 63 8 minecraft:deepslate_tiles
setblock 336 63 8 minecraft:deepslate_tiles
fill 309 63 8 313 63 8 minecraft:lime_concrete
fill 327 63 8 331 63 8 minecraft:magenta_concrete
fill 306 63 8 307 63 8 minecraft:polished_deepslate
setblock 315 63 8 minecraft:polished_deepslate
setblock 317 63 8 minecraft:polished_deepslate
setblock 323 63 8 minecraft:polished_deepslate
setblock 325 63 8 minecraft:polished_deepslate
fill 333 63 8 334 63 8 minecraft:polished_deepslate
setblock 305 63 8 minecraft:quartz_block
setblock 335 63 8 minecraft:quartz_block
fill 319 63 8 321 63 8 minecraft:waxed_oxidized_cut_copper
setblock 304 63 9 minecraft:deepslate_tiles
setblock 307 63 9 minecraft:deepslate_tiles
setblock 315 63 9 minecraft:deepslate_tiles
setblock 317 63 9 minecraft:deepslate_tiles
setblock 323 63 9 minecraft:deepslate_tiles
setblock 325 63 9 minecraft:deepslate_tiles
setblock 333 63 9 minecraft:deepslate_tiles
setblock 336 63 9 minecraft:deepslate_tiles
fill 309 63 9 313 63 9 minecraft:lime_concrete
fill 327 63 9 331 63 9 minecraft:magenta_concrete
setblock 306 63 9 minecraft:polished_deepslate
setblock 308 63 9 minecraft:polished_deepslate
setblock 316 63 9 minecraft:polished_deepslate
setblock 318 63 9 minecraft:polished_deepslate
setblock 322 63 9 minecraft:polished_deepslate
setblock 324 63 9 minecraft:polished_deepslate
setblock 332 63 9 minecraft:polished_deepslate
setblock 334 63 9 minecraft:polished_deepslate
setblock 305 63 9 minecraft:quartz_block
setblock 314 63 9 minecraft:quartz_block
setblock 326 63 9 minecraft:quartz_block
setblock 335 63 9 minecraft:quartz_block
fill 319 63 9 321 63 9 minecraft:waxed_oxidized_cut_copper
setblock 304 63 10 minecraft:deepslate_tiles
setblock 308 63 10 minecraft:deepslate_tiles
setblock 316 63 10 minecraft:deepslate_tiles
setblock 318 63 10 minecraft:deepslate_tiles
setblock 322 63 10 minecraft:deepslate_tiles
setblock 324 63 10 minecraft:deepslate_tiles
setblock 332 63 10 minecraft:deepslate_tiles
setblock 336 63 10 minecraft:deepslate_tiles
fill 309 63 10 313 63 10 minecraft:lime_concrete
fill 327 63 10 331 63 10 minecraft:magenta_concrete
fill 306 63 10 307 63 10 minecraft:polished_deepslate
setblock 317 63 10 minecraft:polished_deepslate
setblock 323 63 10 minecraft:polished_deepslate
fill 333 63 10 334 63 10 minecraft:polished_deepslate
setblock 305 63 10 minecraft:quartz_block
fill 314 63 10 315 63 10 minecraft:quartz_block
fill 325 63 10 326 63 10 minecraft:quartz_block
setblock 335 63 10 minecraft:quartz_block
fill 319 63 10 321 63 10 minecraft:waxed_oxidized_cut_copper
setblock 304 63 11 minecraft:deepslate_tiles
setblock 307 63 11 minecraft:deepslate_tiles
setblock 311 63 11 minecraft:deepslate_tiles
setblock 313 63 11 minecraft:deepslate_tiles
setblock 315 63 11 minecraft:deepslate_tiles
setblock 325 63 11 minecraft:deepslate_tiles
setblock 327 63 11 minecraft:deepslate_tiles
setblock 329 63 11 minecraft:deepslate_tiles
setblock 333 63 11 minecraft:deepslate_tiles
setblock 336 63 11 minecraft:deepslate_tiles
setblock 306 63 11 minecraft:polished_deepslate
setblock 312 63 11 minecraft:polished_deepslate
setblock 314 63 11 minecraft:polished_deepslate
setblock 326 63 11 minecraft:polished_deepslate
setblock 328 63 11 minecraft:polished_deepslate
setblock 334 63 11 minecraft:polished_deepslate
setblock 305 63 11 minecraft:quartz_block
setblock 308 63 11 minecraft:quartz_block
setblock 310 63 11 minecraft:quartz_block
fill 316 63 11 318 63 11 minecraft:quartz_block
fill 322 63 11 324 63 11 minecraft:quartz_block
setblock 330 63 11 minecraft:quartz_block
setblock 332 63 11 minecraft:quartz_block
setblock 335 63 11 minecraft:quartz_block
setblock 309 63 11 minecraft:sea_lantern
setblock 331 63 11 minecraft:sea_lantern
fill 319 63 11 321 63 11 minecraft:waxed_oxidized_cut_copper
setblock 304 63 12 minecraft:deepslate_tiles
setblock 308 63 12 minecraft:deepslate_tiles
setblock 310 63 12 minecraft:deepslate_tiles
setblock 312 63 12 minecraft:deepslate_tiles
setblock 314 63 12 minecraft:deepslate_tiles
setblock 316 63 12 minecraft:deepslate_tiles
setblock 318 63 12 minecraft:deepslate_tiles
setblock 322 63 12 minecraft:deepslate_tiles
setblock 324 63 12 minecraft:deepslate_tiles
setblock 326 63 12 minecraft:deepslate_tiles
setblock 328 63 12 minecraft:deepslate_tiles
setblock 330 63 12 minecraft:deepslate_tiles
setblock 332 63 12 minecraft:deepslate_tiles
setblock 336 63 12 minecraft:deepslate_tiles
fill 306 63 12 307 63 12 minecraft:polished_deepslate
setblock 311 63 12 minecraft:polished_deepslate
setblock 313 63 12 minecraft:polished_deepslate
setblock 315 63 12 minecraft:polished_deepslate
setblock 317 63 12 minecraft:polished_deepslate
setblock 323 63 12 minecraft:polished_deepslate
setblock 325 63 12 minecraft:polished_deepslate
setblock 327 63 12 minecraft:polished_deepslate
setblock 329 63 12 minecraft:polished_deepslate
fill 333 63 12 334 63 12 minecraft:polished_deepslate
setblock 305 63 12 minecraft:quartz_block
setblock 309 63 12 minecraft:quartz_block
fill 320 63 12 321 63 12 minecraft:quartz_block
setblock 331 63 12 minecraft:quartz_block
setblock 335 63 12 minecraft:quartz_block
setblock 319 63 12 minecraft:waxed_oxidized_cut_copper
setblock 304 63 13 minecraft:deepslate_tiles
setblock 307 63 13 minecraft:deepslate_tiles
setblock 309 63 13 minecraft:deepslate_tiles
setblock 311 63 13 minecraft:deepslate_tiles
setblock 313 63 13 minecraft:deepslate_tiles
setblock 315 63 13 minecraft:deepslate_tiles
setblock 317 63 13 minecraft:deepslate_tiles
setblock 319 63 13 minecraft:deepslate_tiles
setblock 323 63 13 minecraft:deepslate_tiles
setblock 325 63 13 minecraft:deepslate_tiles
setblock 327 63 13 minecraft:deepslate_tiles
setblock 329 63 13 minecraft:deepslate_tiles
setblock 331 63 13 minecraft:deepslate_tiles
setblock 333 63 13 minecraft:deepslate_tiles
setblock 336 63 13 minecraft:deepslate_tiles
setblock 306 63 13 minecraft:polished_deepslate
setblock 308 63 13 minecraft:polished_deepslate
setblock 310 63 13 minecraft:polished_deepslate
setblock 312 63 13 minecraft:polished_deepslate
setblock 314 63 13 minecraft:polished_deepslate
setblock 316 63 13 minecraft:polished_deepslate
setblock 318 63 13 minecraft:polished_deepslate
setblock 322 63 13 minecraft:polished_deepslate
setblock 324 63 13 minecraft:polished_deepslate
setblock 326 63 13 minecraft:polished_deepslate
setblock 328 63 13 minecraft:polished_deepslate
setblock 330 63 13 minecraft:polished_deepslate
setblock 332 63 13 minecraft:polished_deepslate
setblock 334 63 13 minecraft:polished_deepslate
setblock 305 63 13 minecraft:quartz_block
fill 320 63 13 321 63 13 minecraft:quartz_block
setblock 335 63 13 minecraft:quartz_block
setblock 304 63 14 minecraft:deepslate_tiles
setblock 336 63 14 minecraft:deepslate_tiles
fill 306 63 14 334 63 14 minecraft:polished_deepslate
setblock 305 63 14 minecraft:quartz_block
setblock 335 63 14 minecraft:quartz_block
setblock 304 63 15 minecraft:deepslate_tiles
setblock 336 63 15 minecraft:deepslate_tiles
fill 305 63 15 335 63 15 minecraft:quartz_block
fill 304 63 16 336 63 16 minecraft:deepslate_tiles
fill 304 64 -16 336 64 -16 minecraft:deepslate_tiles
setblock 304 64 -15 minecraft:deepslate_tiles
setblock 336 64 -15 minecraft:deepslate_tiles
setblock 308 64 -15 minecraft:quartz_block
setblock 314 64 -15 minecraft:quartz_block
setblock 320 64 -15 minecraft:quartz_block
setblock 326 64 -15 minecraft:quartz_block
setblock 332 64 -15 minecraft:quartz_block
setblock 304 64 -14 minecraft:deepslate_tiles
setblock 336 64 -14 minecraft:deepslate_tiles
setblock 304 64 -13 minecraft:deepslate_tiles
setblock 336 64 -13 minecraft:deepslate_tiles
setblock 304 64 -12 minecraft:deepslate_tiles
setblock 336 64 -12 minecraft:deepslate_tiles
setblock 305 64 -12 minecraft:quartz_block
setblock 335 64 -12 minecraft:quartz_block
setblock 304 64 -11 minecraft:deepslate_tiles
setblock 336 64 -11 minecraft:deepslate_tiles
setblock 304 64 -10 minecraft:deepslate_tiles
setblock 336 64 -10 minecraft:deepslate_tiles
setblock 304 64 -9 minecraft:deepslate_tiles
setblock 336 64 -9 minecraft:deepslate_tiles
setblock 304 64 -8 minecraft:deepslate_tiles
setblock 336 64 -8 minecraft:deepslate_tiles
setblock 304 64 -7 minecraft:deepslate_tiles
setblock 336 64 -7 minecraft:deepslate_tiles
setblock 304 64 -6 minecraft:deepslate_tiles
setblock 336 64 -6 minecraft:deepslate_tiles
setblock 305 64 -6 minecraft:quartz_block
setblock 335 64 -6 minecraft:quartz_block
setblock 304 64 -5 minecraft:deepslate_tiles
setblock 336 64 -5 minecraft:deepslate_tiles
setblock 304 64 -4 minecraft:deepslate_tiles
setblock 336 64 -4 minecraft:deepslate_tiles
setblock 304 64 -3 minecraft:deepslate_tiles
setblock 336 64 -3 minecraft:deepslate_tiles
setblock 304 64 -2 minecraft:deepslate_tiles
setblock 336 64 -2 minecraft:deepslate_tiles
setblock 304 64 -1 minecraft:deepslate_tiles
setblock 336 64 -1 minecraft:deepslate_tiles
setblock 304 64 0 minecraft:deepslate_tiles
setblock 336 64 0 minecraft:deepslate_tiles
setblock 305 64 0 minecraft:quartz_block
setblock 335 64 0 minecraft:quartz_block
setblock 304 64 1 minecraft:deepslate_tiles
setblock 336 64 1 minecraft:deepslate_tiles
setblock 304 64 2 minecraft:deepslate_tiles
setblock 336 64 2 minecraft:deepslate_tiles
setblock 304 64 3 minecraft:deepslate_tiles
setblock 336 64 3 minecraft:deepslate_tiles
setblock 304 64 4 minecraft:deepslate_tiles
setblock 336 64 4 minecraft:deepslate_tiles
setblock 304 64 5 minecraft:deepslate_tiles
setblock 336 64 5 minecraft:deepslate_tiles
setblock 304 64 6 minecraft:deepslate_tiles
setblock 336 64 6 minecraft:deepslate_tiles
setblock 305 64 6 minecraft:quartz_block
setblock 335 64 6 minecraft:quartz_block
setblock 304 64 7 minecraft:deepslate_tiles
setblock 336 64 7 minecraft:deepslate_tiles
setblock 304 64 8 minecraft:deepslate_tiles
setblock 336 64 8 minecraft:deepslate_tiles
setblock 304 64 9 minecraft:deepslate_tiles
setblock 336 64 9 minecraft:deepslate_tiles
setblock 304 64 10 minecraft:deepslate_tiles
setblock 336 64 10 minecraft:deepslate_tiles
setblock 304 64 11 minecraft:deepslate_tiles
setblock 336 64 11 minecraft:deepslate_tiles
setblock 304 64 12 minecraft:deepslate_tiles
setblock 336 64 12 minecraft:deepslate_tiles
setblock 305 64 12 minecraft:quartz_block
setblock 335 64 12 minecraft:quartz_block
setblock 304 64 13 minecraft:deepslate_tiles
setblock 336 64 13 minecraft:deepslate_tiles
setblock 304 64 14 minecraft:deepslate_tiles
setblock 336 64 14 minecraft:deepslate_tiles
setblock 304 64 15 minecraft:deepslate_tiles
setblock 336 64 15 minecraft:deepslate_tiles
setblock 308 64 15 minecraft:quartz_block
setblock 314 64 15 minecraft:quartz_block
setblock 320 64 15 minecraft:quartz_block
setblock 326 64 15 minecraft:quartz_block
setblock 332 64 15 minecraft:quartz_block
fill 304 64 16 336 64 16 minecraft:deepslate_tiles
fill 304 65 -16 336 65 -16 minecraft:deepslate_tiles
setblock 304 65 -15 minecraft:deepslate_tiles
setblock 336 65 -15 minecraft:deepslate_tiles
setblock 308 65 -15 minecraft:quartz_block
setblock 314 65 -15 minecraft:quartz_block
setblock 320 65 -15 minecraft:quartz_block
setblock 326 65 -15 minecraft:quartz_block
setblock 332 65 -15 minecraft:quartz_block
setblock 304 65 -14 minecraft:deepslate_tiles
setblock 336 65 -14 minecraft:deepslate_tiles
setblock 304 65 -13 minecraft:deepslate_tiles
setblock 336 65 -13 minecraft:deepslate_tiles
setblock 304 65 -12 minecraft:deepslate_tiles
setblock 336 65 -12 minecraft:deepslate_tiles
setblock 305 65 -12 minecraft:quartz_block
setblock 335 65 -12 minecraft:quartz_block
setblock 304 65 -11 minecraft:deepslate_tiles
setblock 336 65 -11 minecraft:deepslate_tiles
setblock 304 65 -10 minecraft:deepslate_tiles
setblock 336 65 -10 minecraft:deepslate_tiles
setblock 304 65 -9 minecraft:deepslate_tiles
setblock 336 65 -9 minecraft:deepslate_tiles
setblock 304 65 -8 minecraft:deepslate_tiles
setblock 336 65 -8 minecraft:deepslate_tiles
setblock 304 65 -7 minecraft:deepslate_tiles
setblock 336 65 -7 minecraft:deepslate_tiles
setblock 304 65 -6 minecraft:deepslate_tiles
setblock 336 65 -6 minecraft:deepslate_tiles
setblock 305 65 -6 minecraft:quartz_block
setblock 335 65 -6 minecraft:quartz_block
setblock 304 65 -5 minecraft:deepslate_tiles
setblock 336 65 -5 minecraft:deepslate_tiles
setblock 304 65 -4 minecraft:deepslate_tiles
setblock 336 65 -4 minecraft:deepslate_tiles
setblock 304 65 -3 minecraft:deepslate_tiles
setblock 336 65 -3 minecraft:deepslate_tiles
setblock 304 65 -2 minecraft:deepslate_tiles
setblock 336 65 -2 minecraft:deepslate_tiles
setblock 304 65 -1 minecraft:deepslate_tiles
setblock 336 65 -1 minecraft:deepslate_tiles
setblock 304 65 0 minecraft:deepslate_tiles
setblock 336 65 0 minecraft:deepslate_tiles
setblock 305 65 0 minecraft:quartz_block
setblock 335 65 0 minecraft:quartz_block
setblock 304 65 1 minecraft:deepslate_tiles
setblock 336 65 1 minecraft:deepslate_tiles
setblock 304 65 2 minecraft:deepslate_tiles
setblock 336 65 2 minecraft:deepslate_tiles
setblock 304 65 3 minecraft:deepslate_tiles
setblock 336 65 3 minecraft:deepslate_tiles
setblock 304 65 4 minecraft:deepslate_tiles
setblock 336 65 4 minecraft:deepslate_tiles
setblock 304 65 5 minecraft:deepslate_tiles
setblock 336 65 5 minecraft:deepslate_tiles
setblock 304 65 6 minecraft:deepslate_tiles
setblock 336 65 6 minecraft:deepslate_tiles
setblock 305 65 6 minecraft:quartz_block
setblock 335 65 6 minecraft:quartz_block
setblock 304 65 7 minecraft:deepslate_tiles
setblock 336 65 7 minecraft:deepslate_tiles
setblock 304 65 8 minecraft:deepslate_tiles
setblock 336 65 8 minecraft:deepslate_tiles
setblock 304 65 9 minecraft:deepslate_tiles
setblock 336 65 9 minecraft:deepslate_tiles
setblock 304 65 10 minecraft:deepslate_tiles
setblock 336 65 10 minecraft:deepslate_tiles
setblock 304 65 11 minecraft:deepslate_tiles
setblock 336 65 11 minecraft:deepslate_tiles
setblock 304 65 12 minecraft:deepslate_tiles
setblock 336 65 12 minecraft:deepslate_tiles
setblock 305 65 12 minecraft:quartz_block
setblock 335 65 12 minecraft:quartz_block
setblock 304 65 13 minecraft:deepslate_tiles
setblock 336 65 13 minecraft:deepslate_tiles
setblock 304 65 14 minecraft:deepslate_tiles
setblock 336 65 14 minecraft:deepslate_tiles
setblock 304 65 15 minecraft:deepslate_tiles
setblock 336 65 15 minecraft:deepslate_tiles
setblock 308 65 15 minecraft:quartz_block
setblock 314 65 15 minecraft:quartz_block
setblock 320 65 15 minecraft:quartz_block
setblock 326 65 15 minecraft:quartz_block
setblock 332 65 15 minecraft:quartz_block
fill 304 65 16 336 65 16 minecraft:deepslate_tiles
fill 304 66 -16 336 66 -16 minecraft:deepslate_tiles
setblock 304 66 -15 minecraft:deepslate_tiles
setblock 336 66 -15 minecraft:deepslate_tiles
fill 305 66 -15 335 66 -15 minecraft:quartz_block
setblock 304 66 -14 minecraft:deepslate_tiles
setblock 336 66 -14 minecraft:deepslate_tiles
setblock 305 66 -14 minecraft:quartz_block
setblock 335 66 -14 minecraft:quartz_block
setblock 304 66 -13 minecraft:deepslate_tiles
setblock 336 66 -13 minecraft:deepslate_tiles
setblock 305 66 -13 minecraft:quartz_block
setblock 335 66 -13 minecraft:quartz_block
setblock 304 66 -12 minecraft:deepslate_tiles
setblock 336 66 -12 minecraft:deepslate_tiles
setblock 305 66 -12 minecraft:quartz_block
setblock 335 66 -12 minecraft:quartz_block
setblock 304 66 -11 minecraft:deepslate_tiles
setblock 336 66 -11 minecraft:deepslate_tiles
setblock 305 66 -11 minecraft:quartz_block
setblock 335 66 -11 minecraft:quartz_block
setblock 304 66 -10 minecraft:deepslate_tiles
setblock 336 66 -10 minecraft:deepslate_tiles
setblock 305 66 -10 minecraft:quartz_block
setblock 335 66 -10 minecraft:quartz_block
setblock 304 66 -9 minecraft:deepslate_tiles
setblock 336 66 -9 minecraft:deepslate_tiles
setblock 305 66 -9 minecraft:quartz_block
setblock 335 66 -9 minecraft:quartz_block
setblock 304 66 -8 minecraft:deepslate_tiles
setblock 336 66 -8 minecraft:deepslate_tiles
setblock 305 66 -8 minecraft:quartz_block
setblock 335 66 -8 minecraft:quartz_block
setblock 304 66 -7 minecraft:deepslate_tiles
setblock 336 66 -7 minecraft:deepslate_tiles
setblock 305 66 -7 minecraft:quartz_block
setblock 335 66 -7 minecraft:quartz_block
setblock 304 66 -6 minecraft:deepslate_tiles
setblock 336 66 -6 minecraft:deepslate_tiles
setblock 305 66 -6 minecraft:quartz_block
setblock 335 66 -6 minecraft:quartz_block
setblock 304 66 -5 minecraft:deepslate_tiles
setblock 336 66 -5 minecraft:deepslate_tiles
setblock 305 66 -5 minecraft:quartz_block
setblock 335 66 -5 minecraft:quartz_block
setblock 304 66 -4 minecraft:deepslate_tiles
setblock 336 66 -4 minecraft:deepslate_tiles
setblock 305 66 -4 minecraft:quartz_block
setblock 335 66 -4 minecraft:quartz_block
setblock 304 66 -3 minecraft:deepslate_tiles
setblock 336 66 -3 minecraft:deepslate_tiles
setblock 305 66 -3 minecraft:quartz_block
setblock 335 66 -3 minecraft:quartz_block
setblock 304 66 -2 minecraft:deepslate_tiles
setblock 336 66 -2 minecraft:deepslate_tiles
setblock 305 66 -2 minecraft:quartz_block
setblock 335 66 -2 minecraft:quartz_block
setblock 304 66 -1 minecraft:deepslate_tiles
setblock 336 66 -1 minecraft:deepslate_tiles
setblock 305 66 -1 minecraft:quartz_block
setblock 335 66 -1 minecraft:quartz_block
setblock 304 66 0 minecraft:deepslate_tiles
setblock 336 66 0 minecraft:deepslate_tiles
setblock 305 66 0 minecraft:quartz_block
setblock 335 66 0 minecraft:quartz_block
setblock 304 66 1 minecraft:deepslate_tiles
setblock 336 66 1 minecraft:deepslate_tiles
setblock 305 66 1 minecraft:quartz_block
setblock 335 66 1 minecraft:quartz_block
setblock 304 66 2 minecraft:deepslate_tiles
setblock 336 66 2 minecraft:deepslate_tiles
setblock 305 66 2 minecraft:quartz_block
setblock 335 66 2 minecraft:quartz_block
setblock 304 66 3 minecraft:deepslate_tiles
setblock 336 66 3 minecraft:deepslate_tiles
setblock 305 66 3 minecraft:quartz_block
setblock 335 66 3 minecraft:quartz_block
setblock 304 66 4 minecraft:deepslate_tiles
setblock 336 66 4 minecraft:deepslate_tiles
setblock 305 66 4 minecraft:quartz_block
setblock 335 66 4 minecraft:quartz_block
setblock 304 66 5 minecraft:deepslate_tiles
setblock 336 66 5 minecraft:deepslate_tiles
setblock 305 66 5 minecraft:quartz_block
setblock 335 66 5 minecraft:quartz_block
setblock 304 66 6 minecraft:deepslate_tiles
setblock 336 66 6 minecraft:deepslate_tiles
setblock 305 66 6 minecraft:quartz_block
setblock 335 66 6 minecraft:quartz_block
setblock 304 66 7 minecraft:deepslate_tiles
setblock 336 66 7 minecraft:deepslate_tiles
setblock 305 66 7 minecraft:quartz_block
setblock 335 66 7 minecraft:quartz_block
setblock 304 66 8 minecraft:deepslate_tiles
setblock 336 66 8 minecraft:deepslate_tiles
setblock 305 66 8 minecraft:quartz_block
setblock 335 66 8 minecraft:quartz_block
setblock 304 66 9 minecraft:deepslate_tiles
setblock 336 66 9 minecraft:deepslate_tiles
setblock 305 66 9 minecraft:quartz_block
setblock 335 66 9 minecraft:quartz_block
setblock 304 66 10 minecraft:deepslate_tiles
setblock 336 66 10 minecraft:deepslate_tiles
setblock 305 66 10 minecraft:quartz_block
setblock 335 66 10 minecraft:quartz_block
setblock 304 66 11 minecraft:deepslate_tiles
setblock 336 66 11 minecraft:deepslate_tiles
setblock 305 66 11 minecraft:quartz_block
setblock 335 66 11 minecraft:quartz_block
setblock 304 66 12 minecraft:deepslate_tiles
setblock 336 66 12 minecraft:deepslate_tiles
setblock 305 66 12 minecraft:quartz_block
setblock 335 66 12 minecraft:quartz_block
setblock 304 66 13 minecraft:deepslate_tiles
setblock 336 66 13 minecraft:deepslate_tiles
setblock 305 66 13 minecraft:quartz_block
setblock 335 66 13 minecraft:quartz_block
setblock 304 66 14 minecraft:deepslate_tiles
setblock 336 66 14 minecraft:deepslate_tiles
setblock 305 66 14 minecraft:quartz_block
setblock 335 66 14 minecraft:quartz_block
setblock 304 66 15 minecraft:deepslate_tiles
setblock 336 66 15 minecraft:deepslate_tiles
fill 305 66 15 335 66 15 minecraft:quartz_block
fill 304 66 16 336 66 16 minecraft:deepslate_tiles
fill 304 67 -16 307 67 -16 minecraft:deepslate_tiles
fill 309 67 -16 313 67 -16 minecraft:deepslate_tiles
fill 315 67 -16 319 67 -16 minecraft:deepslate_tiles
fill 321 67 -16 325 67 -16 minecraft:deepslate_tiles
fill 327 67 -16 331 67 -16 minecraft:deepslate_tiles
fill 333 67 -16 336 67 -16 minecraft:deepslate_tiles
setblock 308 67 -16 minecraft:sea_lantern
setblock 314 67 -16 minecraft:sea_lantern
setblock 320 67 -16 minecraft:sea_lantern
setblock 326 67 -16 minecraft:sea_lantern
setblock 332 67 -16 minecraft:sea_lantern
setblock 304 67 -15 minecraft:deepslate_tiles
setblock 336 67 -15 minecraft:deepslate_tiles
setblock 308 67 -15 minecraft:light_blue_stained_glass
setblock 314 67 -15 minecraft:light_blue_stained_glass
setblock 320 67 -15 minecraft:light_blue_stained_glass
setblock 326 67 -15 minecraft:light_blue_stained_glass
setblock 332 67 -15 minecraft:light_blue_stained_glass
setblock 304 67 -14 minecraft:deepslate_tiles
setblock 336 67 -14 minecraft:deepslate_tiles
setblock 304 67 -13 minecraft:deepslate_tiles
setblock 336 67 -13 minecraft:deepslate_tiles
setblock 305 67 -12 minecraft:light_blue_stained_glass
setblock 335 67 -12 minecraft:light_blue_stained_glass
setblock 304 67 -12 minecraft:sea_lantern
setblock 336 67 -12 minecraft:sea_lantern
setblock 304 67 -11 minecraft:deepslate_tiles
setblock 336 67 -11 minecraft:deepslate_tiles
setblock 304 67 -10 minecraft:deepslate_tiles
setblock 336 67 -10 minecraft:deepslate_tiles
setblock 304 67 -9 minecraft:deepslate_tiles
setblock 336 67 -9 minecraft:deepslate_tiles
setblock 304 67 -8 minecraft:deepslate_tiles
setblock 336 67 -8 minecraft:deepslate_tiles
setblock 304 67 -7 minecraft:deepslate_tiles
setblock 336 67 -7 minecraft:deepslate_tiles
setblock 305 67 -6 minecraft:light_blue_stained_glass
setblock 335 67 -6 minecraft:light_blue_stained_glass
setblock 304 67 -6 minecraft:sea_lantern
setblock 336 67 -6 minecraft:sea_lantern
setblock 304 67 -5 minecraft:deepslate_tiles
setblock 336 67 -5 minecraft:deepslate_tiles
setblock 304 67 -4 minecraft:deepslate_tiles
setblock 336 67 -4 minecraft:deepslate_tiles
setblock 304 67 -3 minecraft:deepslate_tiles
setblock 336 67 -3 minecraft:deepslate_tiles
setblock 304 67 -2 minecraft:deepslate_tiles
setblock 336 67 -2 minecraft:deepslate_tiles
setblock 304 67 -1 minecraft:deepslate_tiles
setblock 336 67 -1 minecraft:deepslate_tiles
setblock 305 67 0 minecraft:light_blue_stained_glass
setblock 335 67 0 minecraft:light_blue_stained_glass
setblock 304 67 0 minecraft:sea_lantern
setblock 336 67 0 minecraft:sea_lantern
setblock 304 67 1 minecraft:deepslate_tiles
setblock 336 67 1 minecraft:deepslate_tiles
setblock 304 67 2 minecraft:deepslate_tiles
setblock 336 67 2 minecraft:deepslate_tiles
setblock 304 67 3 minecraft:deepslate_tiles
setblock 336 67 3 minecraft:deepslate_tiles
setblock 304 67 4 minecraft:deepslate_tiles
setblock 336 67 4 minecraft:deepslate_tiles
setblock 304 67 5 minecraft:deepslate_tiles
setblock 336 67 5 minecraft:deepslate_tiles
setblock 305 67 6 minecraft:light_blue_stained_glass
setblock 335 67 6 minecraft:light_blue_stained_glass
setblock 304 67 6 minecraft:sea_lantern
setblock 336 67 6 minecraft:sea_lantern
setblock 304 67 7 minecraft:deepslate_tiles
setblock 336 67 7 minecraft:deepslate_tiles
setblock 304 67 8 minecraft:deepslate_tiles
setblock 336 67 8 minecraft:deepslate_tiles
setblock 304 67 9 minecraft:deepslate_tiles
setblock 336 67 9 minecraft:deepslate_tiles
setblock 304 67 10 minecraft:deepslate_tiles
setblock 336 67 10 minecraft:deepslate_tiles
setblock 304 67 11 minecraft:deepslate_tiles
setblock 336 67 11 minecraft:deepslate_tiles
setblock 305 67 12 minecraft:light_blue_stained_glass
setblock 335 67 12 minecraft:light_blue_stained_glass
setblock 304 67 12 minecraft:sea_lantern
setblock 336 67 12 minecraft:sea_lantern
setblock 304 67 13 minecraft:deepslate_tiles
setblock 336 67 13 minecraft:deepslate_tiles
setblock 304 67 14 minecraft:deepslate_tiles
setblock 336 67 14 minecraft:deepslate_tiles
setblock 304 67 15 minecraft:deepslate_tiles
setblock 336 67 15 minecraft:deepslate_tiles
setblock 308 67 15 minecraft:light_blue_stained_glass
setblock 314 67 15 minecraft:light_blue_stained_glass
setblock 320 67 15 minecraft:light_blue_stained_glass
setblock 326 67 15 minecraft:light_blue_stained_glass
setblock 332 67 15 minecraft:light_blue_stained_glass
fill 304 67 16 307 67 16 minecraft:deepslate_tiles
fill 309 67 16 313 67 16 minecraft:deepslate_tiles
fill 315 67 16 319 67 16 minecraft:deepslate_tiles
fill 321 67 16 325 67 16 minecraft:deepslate_tiles
fill 327 67 16 331 67 16 minecraft:deepslate_tiles
fill 333 67 16 336 67 16 minecraft:deepslate_tiles
setblock 308 67 16 minecraft:sea_lantern
setblock 314 67 16 minecraft:sea_lantern
setblock 320 67 16 minecraft:sea_lantern
setblock 326 67 16 minecraft:sea_lantern
setblock 332 67 16 minecraft:sea_lantern
fill 304 68 -16 307 68 -16 minecraft:deepslate_tiles
fill 309 68 -16 313 68 -16 minecraft:deepslate_tiles
fill 315 68 -16 319 68 -16 minecraft:deepslate_tiles
fill 321 68 -16 325 68 -16 minecraft:deepslate_tiles
fill 327 68 -16 331 68 -16 minecraft:deepslate_tiles
fill 333 68 -16 336 68 -16 minecraft:deepslate_tiles
setblock 308 68 -16 minecraft:sea_lantern
setblock 314 68 -16 minecraft:sea_lantern
setblock 320 68 -16 minecraft:sea_lantern
setblock 326 68 -16 minecraft:sea_lantern
setblock 332 68 -16 minecraft:sea_lantern
setblock 304 68 -15 minecraft:deepslate_tiles
setblock 336 68 -15 minecraft:deepslate_tiles
setblock 308 68 -15 minecraft:light_blue_stained_glass
setblock 314 68 -15 minecraft:light_blue_stained_glass
setblock 320 68 -15 minecraft:light_blue_stained_glass
setblock 326 68 -15 minecraft:light_blue_stained_glass
setblock 332 68 -15 minecraft:light_blue_stained_glass
setblock 304 68 -14 minecraft:deepslate_tiles
setblock 336 68 -14 minecraft:deepslate_tiles
setblock 304 68 -13 minecraft:deepslate_tiles
setblock 336 68 -13 minecraft:deepslate_tiles
setblock 305 68 -12 minecraft:light_blue_stained_glass
setblock 335 68 -12 minecraft:light_blue_stained_glass
setblock 304 68 -12 minecraft:sea_lantern
setblock 336 68 -12 minecraft:sea_lantern
setblock 304 68 -11 minecraft:deepslate_tiles
setblock 336 68 -11 minecraft:deepslate_tiles
setblock 304 68 -10 minecraft:deepslate_tiles
setblock 336 68 -10 minecraft:deepslate_tiles
setblock 304 68 -9 minecraft:deepslate_tiles
setblock 336 68 -9 minecraft:deepslate_tiles
setblock 304 68 -8 minecraft:deepslate_tiles
setblock 336 68 -8 minecraft:deepslate_tiles
setblock 304 68 -7 minecraft:deepslate_tiles
setblock 336 68 -7 minecraft:deepslate_tiles
setblock 305 68 -6 minecraft:light_blue_stained_glass
setblock 335 68 -6 minecraft:light_blue_stained_glass
setblock 304 68 -6 minecraft:sea_lantern
setblock 336 68 -6 minecraft:sea_lantern
setblock 304 68 -5 minecraft:deepslate_tiles
setblock 336 68 -5 minecraft:deepslate_tiles
setblock 304 68 -4 minecraft:deepslate_tiles
setblock 336 68 -4 minecraft:deepslate_tiles
setblock 304 68 -3 minecraft:deepslate_tiles
setblock 336 68 -3 minecraft:deepslate_tiles
setblock 304 68 -2 minecraft:deepslate_tiles
setblock 336 68 -2 minecraft:deepslate_tiles
setblock 304 68 -1 minecraft:deepslate_tiles
setblock 336 68 -1 minecraft:deepslate_tiles
setblock 305 68 0 minecraft:light_blue_stained_glass
setblock 335 68 0 minecraft:light_blue_stained_glass
setblock 304 68 0 minecraft:sea_lantern
setblock 336 68 0 minecraft:sea_lantern
setblock 304 68 1 minecraft:deepslate_tiles
setblock 336 68 1 minecraft:deepslate_tiles
setblock 304 68 2 minecraft:deepslate_tiles
setblock 336 68 2 minecraft:deepslate_tiles
setblock 304 68 3 minecraft:deepslate_tiles
setblock 336 68 3 minecraft:deepslate_tiles
setblock 304 68 4 minecraft:deepslate_tiles
setblock 336 68 4 minecraft:deepslate_tiles
setblock 304 68 5 minecraft:deepslate_tiles
setblock 336 68 5 minecraft:deepslate_tiles
setblock 305 68 6 minecraft:light_blue_stained_glass
setblock 335 68 6 minecraft:light_blue_stained_glass
setblock 304 68 6 minecraft:sea_lantern
setblock 336 68 6 minecraft:sea_lantern
setblock 304 68 7 minecraft:deepslate_tiles
setblock 336 68 7 minecraft:deepslate_tiles
setblock 304 68 8 minecraft:deepslate_tiles
setblock 336 68 8 minecraft:deepslate_tiles
setblock 304 68 9 minecraft:deepslate_tiles
setblock 336 68 9 minecraft:deepslate_tiles
setblock 304 68 10 minecraft:deepslate_tiles
setblock 336 68 10 minecraft:deepslate_tiles
setblock 304 68 11 minecraft:deepslate_tiles
setblock 336 68 11 minecraft:deepslate_tiles
setblock 305 68 12 minecraft:light_blue_stained_glass
setblock 335 68 12 minecraft:light_blue_stained_glass
setblock 304 68 12 minecraft:sea_lantern
setblock 336 68 12 minecraft:sea_lantern
setblock 304 68 13 minecraft:deepslate_tiles
setblock 336 68 13 minecraft:deepslate_tiles
setblock 304 68 14 minecraft:deepslate_tiles
setblock 336 68 14 minecraft:deepslate_tiles
setblock 304 68 15 minecraft:deepslate_tiles
setblock 336 68 15 minecraft:deepslate_tiles
setblock 308 68 15 minecraft:light_blue_stained_glass
setblock 314 68 15 minecraft:light_blue_stained_glass
setblock 320 68 15 minecraft:light_blue_stained_glass
setblock 326 68 15 minecraft:light_blue_stained_glass
setblock 332 68 15 minecraft:light_blue_stained_glass
fill 304 68 16 307 68 16 minecraft:deepslate_tiles
fill 309 68 16 313 68 16 minecraft:deepslate_tiles
fill 315 68 16 319 68 16 minecraft:deepslate_tiles
fill 321 68 16 325 68 16 minecraft:deepslate_tiles
fill 327 68 16 331 68 16 minecraft:deepslate_tiles
fill 333 68 16 336 68 16 minecraft:deepslate_tiles
setblock 308 68 16 minecraft:sea_lantern
setblock 314 68 16 minecraft:sea_lantern
setblock 320 68 16 minecraft:sea_lantern
setblock 326 68 16 minecraft:sea_lantern
setblock 332 68 16 minecraft:sea_lantern
fill 304 69 -16 307 69 -16 minecraft:deepslate_tiles
fill 309 69 -16 313 69 -16 minecraft:deepslate_tiles
fill 315 69 -16 319 69 -16 minecraft:deepslate_tiles
fill 321 69 -16 325 69 -16 minecraft:deepslate_tiles
fill 327 69 -16 331 69 -16 minecraft:deepslate_tiles
fill 333 69 -16 336 69 -16 minecraft:deepslate_tiles
setblock 308 69 -16 minecraft:sea_lantern
setblock 314 69 -16 minecraft:sea_lantern
setblock 320 69 -16 minecraft:sea_lantern
setblock 326 69 -16 minecraft:sea_lantern
setblock 332 69 -16 minecraft:sea_lantern
setblock 304 69 -15 minecraft:deepslate_tiles
setblock 336 69 -15 minecraft:deepslate_tiles
setblock 308 69 -15 minecraft:light_blue_stained_glass
setblock 314 69 -15 minecraft:light_blue_stained_glass
setblock 320 69 -15 minecraft:light_blue_stained_glass
setblock 326 69 -15 minecraft:light_blue_stained_glass
setblock 332 69 -15 minecraft:light_blue_stained_glass
setblock 304 69 -14 minecraft:deepslate_tiles
setblock 336 69 -14 minecraft:deepslate_tiles
setblock 304 69 -13 minecraft:deepslate_tiles
setblock 336 69 -13 minecraft:deepslate_tiles
setblock 305 69 -12 minecraft:light_blue_stained_glass
setblock 335 69 -12 minecraft:light_blue_stained_glass
setblock 304 69 -12 minecraft:sea_lantern
setblock 336 69 -12 minecraft:sea_lantern
setblock 304 69 -11 minecraft:deepslate_tiles
setblock 336 69 -11 minecraft:deepslate_tiles
setblock 304 69 -10 minecraft:deepslate_tiles
setblock 336 69 -10 minecraft:deepslate_tiles
setblock 304 69 -9 minecraft:deepslate_tiles
setblock 336 69 -9 minecraft:deepslate_tiles
setblock 304 69 -8 minecraft:deepslate_tiles
setblock 336 69 -8 minecraft:deepslate_tiles
setblock 304 69 -7 minecraft:deepslate_tiles
setblock 336 69 -7 minecraft:deepslate_tiles
setblock 305 69 -6 minecraft:light_blue_stained_glass
setblock 335 69 -6 minecraft:light_blue_stained_glass
setblock 304 69 -6 minecraft:sea_lantern
setblock 336 69 -6 minecraft:sea_lantern
setblock 304 69 -5 minecraft:deepslate_tiles
setblock 336 69 -5 minecraft:deepslate_tiles
setblock 304 69 -4 minecraft:deepslate_tiles
setblock 336 69 -4 minecraft:deepslate_tiles
setblock 304 69 -3 minecraft:deepslate_tiles
setblock 336 69 -3 minecraft:deepslate_tiles
setblock 304 69 -2 minecraft:deepslate_tiles
setblock 336 69 -2 minecraft:deepslate_tiles
setblock 304 69 -1 minecraft:deepslate_tiles
setblock 336 69 -1 minecraft:deepslate_tiles
setblock 305 69 0 minecraft:light_blue_stained_glass
setblock 335 69 0 minecraft:light_blue_stained_glass
setblock 304 69 0 minecraft:sea_lantern
setblock 336 69 0 minecraft:sea_lantern
setblock 304 69 1 minecraft:deepslate_tiles
setblock 336 69 1 minecraft:deepslate_tiles
setblock 304 69 2 minecraft:deepslate_tiles
setblock 336 69 2 minecraft:deepslate_tiles
setblock 304 69 3 minecraft:deepslate_tiles
setblock 336 69 3 minecraft:deepslate_tiles
setblock 304 69 4 minecraft:deepslate_tiles
setblock 336 69 4 minecraft:deepslate_tiles
setblock 304 69 5 minecraft:deepslate_tiles
setblock 336 69 5 minecraft:deepslate_tiles
setblock 305 69 6 minecraft:light_blue_stained_glass
setblock 335 69 6 minecraft:light_blue_stained_glass
setblock 304 69 6 minecraft:sea_lantern
setblock 336 69 6 minecraft:sea_lantern
setblock 304 69 7 minecraft:deepslate_tiles
setblock 336 69 7 minecraft:deepslate_tiles
setblock 304 69 8 minecraft:deepslate_tiles
setblock 336 69 8 minecraft:deepslate_tiles
setblock 304 69 9 minecraft:deepslate_tiles
setblock 336 69 9 minecraft:deepslate_tiles
setblock 304 69 10 minecraft:deepslate_tiles
setblock 336 69 10 minecraft:deepslate_tiles
setblock 304 69 11 minecraft:deepslate_tiles
setblock 336 69 11 minecraft:deepslate_tiles
setblock 305 69 12 minecraft:light_blue_stained_glass
setblock 335 69 12 minecraft:light_blue_stained_glass
setblock 304 69 12 minecraft:sea_lantern
setblock 336 69 12 minecraft:sea_lantern
setblock 304 69 13 minecraft:deepslate_tiles
setblock 336 69 13 minecraft:deepslate_tiles
setblock 304 69 14 minecraft:deepslate_tiles
setblock 336 69 14 minecraft:deepslate_tiles
setblock 304 69 15 minecraft:deepslate_tiles
setblock 336 69 15 minecraft:deepslate_tiles
setblock 308 69 15 minecraft:light_blue_stained_glass
setblock 314 69 15 minecraft:light_blue_stained_glass
setblock 320 69 15 minecraft:light_blue_stained_glass
setblock 326 69 15 minecraft:light_blue_stained_glass
setblock 332 69 15 minecraft:light_blue_stained_glass
fill 304 69 16 307 69 16 minecraft:deepslate_tiles
fill 309 69 16 313 69 16 minecraft:deepslate_tiles
fill 315 69 16 319 69 16 minecraft:deepslate_tiles
fill 321 69 16 325 69 16 minecraft:deepslate_tiles
fill 327 69 16 331 69 16 minecraft:deepslate_tiles
fill 333 69 16 336 69 16 minecraft:deepslate_tiles
setblock 308 69 16 minecraft:sea_lantern
setblock 314 69 16 minecraft:sea_lantern
setblock 320 69 16 minecraft:sea_lantern
setblock 326 69 16 minecraft:sea_lantern
setblock 332 69 16 minecraft:sea_lantern
fill 304 70 -16 307 70 -16 minecraft:deepslate_tiles
fill 309 70 -16 313 70 -16 minecraft:deepslate_tiles
fill 315 70 -16 319 70 -16 minecraft:deepslate_tiles
fill 321 70 -16 325 70 -16 minecraft:deepslate_tiles
fill 327 70 -16 331 70 -16 minecraft:deepslate_tiles
fill 333 70 -16 336 70 -16 minecraft:deepslate_tiles
setblock 308 70 -16 minecraft:sea_lantern
setblock 314 70 -16 minecraft:sea_lantern
setblock 320 70 -16 minecraft:sea_lantern
setblock 326 70 -16 minecraft:sea_lantern
setblock 332 70 -16 minecraft:sea_lantern
setblock 304 70 -15 minecraft:deepslate_tiles
setblock 336 70 -15 minecraft:deepslate_tiles
setblock 308 70 -15 minecraft:light_blue_stained_glass
setblock 314 70 -15 minecraft:light_blue_stained_glass
setblock 320 70 -15 minecraft:light_blue_stained_glass
setblock 326 70 -15 minecraft:light_blue_stained_glass
setblock 332 70 -15 minecraft:light_blue_stained_glass
setblock 304 70 -14 minecraft:deepslate_tiles
setblock 336 70 -14 minecraft:deepslate_tiles
setblock 304 70 -13 minecraft:deepslate_tiles
setblock 336 70 -13 minecraft:deepslate_tiles
setblock 305 70 -12 minecraft:light_blue_stained_glass
setblock 335 70 -12 minecraft:light_blue_stained_glass
setblock 304 70 -12 minecraft:sea_lantern
setblock 336 70 -12 minecraft:sea_lantern
setblock 304 70 -11 minecraft:deepslate_tiles
setblock 336 70 -11 minecraft:deepslate_tiles
setblock 304 70 -10 minecraft:deepslate_tiles
setblock 336 70 -10 minecraft:deepslate_tiles
setblock 304 70 -9 minecraft:deepslate_tiles
setblock 336 70 -9 minecraft:deepslate_tiles
setblock 304 70 -8 minecraft:deepslate_tiles
setblock 336 70 -8 minecraft:deepslate_tiles
setblock 304 70 -7 minecraft:deepslate_tiles
setblock 336 70 -7 minecraft:deepslate_tiles
setblock 305 70 -6 minecraft:light_blue_stained_glass
setblock 335 70 -6 minecraft:light_blue_stained_glass
setblock 304 70 -6 minecraft:sea_lantern
setblock 336 70 -6 minecraft:sea_lantern
setblock 304 70 -5 minecraft:deepslate_tiles
setblock 336 70 -5 minecraft:deepslate_tiles
setblock 304 70 -4 minecraft:deepslate_tiles
setblock 336 70 -4 minecraft:deepslate_tiles
setblock 304 70 -3 minecraft:deepslate_tiles
setblock 336 70 -3 minecraft:deepslate_tiles
setblock 304 70 -2 minecraft:deepslate_tiles
setblock 336 70 -2 minecraft:deepslate_tiles
setblock 304 70 -1 minecraft:deepslate_tiles
setblock 336 70 -1 minecraft:deepslate_tiles
setblock 305 70 0 minecraft:light_blue_stained_glass
setblock 335 70 0 minecraft:light_blue_stained_glass
setblock 304 70 0 minecraft:sea_lantern
setblock 336 70 0 minecraft:sea_lantern
setblock 304 70 1 minecraft:deepslate_tiles
setblock 336 70 1 minecraft:deepslate_tiles
setblock 304 70 2 minecraft:deepslate_tiles
setblock 336 70 2 minecraft:deepslate_tiles
setblock 304 70 3 minecraft:deepslate_tiles
setblock 336 70 3 minecraft:deepslate_tiles
setblock 304 70 4 minecraft:deepslate_tiles
setblock 336 70 4 minecraft:deepslate_tiles
setblock 304 70 5 minecraft:deepslate_tiles
setblock 336 70 5 minecraft:deepslate_tiles
setblock 305 70 6 minecraft:light_blue_stained_glass
setblock 335 70 6 minecraft:light_blue_stained_glass
setblock 304 70 6 minecraft:sea_lantern
setblock 336 70 6 minecraft:sea_lantern
setblock 304 70 7 minecraft:deepslate_tiles
setblock 336 70 7 minecraft:deepslate_tiles
setblock 304 70 8 minecraft:deepslate_tiles
setblock 336 70 8 minecraft:deepslate_tiles
setblock 304 70 9 minecraft:deepslate_tiles
setblock 336 70 9 minecraft:deepslate_tiles
setblock 304 70 10 minecraft:deepslate_tiles
setblock 336 70 10 minecraft:deepslate_tiles
setblock 304 70 11 minecraft:deepslate_tiles
setblock 336 70 11 minecraft:deepslate_tiles
setblock 305 70 12 minecraft:light_blue_stained_glass
setblock 335 70 12 minecraft:light_blue_stained_glass
setblock 304 70 12 minecraft:sea_lantern
setblock 336 70 12 minecraft:sea_lantern
setblock 304 70 13 minecraft:deepslate_tiles
setblock 336 70 13 minecraft:deepslate_tiles
setblock 304 70 14 minecraft:deepslate_tiles
setblock 336 70 14 minecraft:deepslate_tiles
setblock 304 70 15 minecraft:deepslate_tiles
setblock 336 70 15 minecraft:deepslate_tiles
setblock 308 70 15 minecraft:light_blue_stained_glass
setblock 314 70 15 minecraft:light_blue_stained_glass
setblock 320 70 15 minecraft:light_blue_stained_glass
setblock 326 70 15 minecraft:light_blue_stained_glass
setblock 332 70 15 minecraft:light_blue_stained_glass
fill 304 70 16 307 70 16 minecraft:deepslate_tiles
fill 309 70 16 313 70 16 minecraft:deepslate_tiles
fill 315 70 16 319 70 16 minecraft:deepslate_tiles
fill 321 70 16 325 70 16 minecraft:deepslate_tiles
fill 327 70 16 331 70 16 minecraft:deepslate_tiles
fill 333 70 16 336 70 16 minecraft:deepslate_tiles
setblock 308 70 16 minecraft:sea_lantern
setblock 314 70 16 minecraft:sea_lantern
setblock 320 70 16 minecraft:sea_lantern
setblock 326 70 16 minecraft:sea_lantern
setblock 332 70 16 minecraft:sea_lantern
fill 304 71 -16 307 71 -16 minecraft:deepslate_tiles
fill 309 71 -16 313 71 -16 minecraft:deepslate_tiles
fill 315 71 -16 319 71 -16 minecraft:deepslate_tiles
fill 321 71 -16 325 71 -16 minecraft:deepslate_tiles
fill 327 71 -16 331 71 -16 minecraft:deepslate_tiles
fill 333 71 -16 336 71 -16 minecraft:deepslate_tiles
setblock 308 71 -16 minecraft:sea_lantern
setblock 314 71 -16 minecraft:sea_lantern
setblock 320 71 -16 minecraft:sea_lantern
setblock 326 71 -16 minecraft:sea_lantern
setblock 332 71 -16 minecraft:sea_lantern
setblock 304 71 -15 minecraft:deepslate_tiles
setblock 336 71 -15 minecraft:deepslate_tiles
setblock 308 71 -15 minecraft:light_blue_stained_glass
setblock 314 71 -15 minecraft:light_blue_stained_glass
setblock 320 71 -15 minecraft:light_blue_stained_glass
setblock 326 71 -15 minecraft:light_blue_stained_glass
setblock 332 71 -15 minecraft:light_blue_stained_glass
setblock 304 71 -14 minecraft:deepslate_tiles
setblock 336 71 -14 minecraft:deepslate_tiles
setblock 304 71 -13 minecraft:deepslate_tiles
setblock 336 71 -13 minecraft:deepslate_tiles
setblock 305 71 -12 minecraft:light_blue_stained_glass
setblock 335 71 -12 minecraft:light_blue_stained_glass
setblock 304 71 -12 minecraft:sea_lantern
setblock 336 71 -12 minecraft:sea_lantern
setblock 304 71 -11 minecraft:deepslate_tiles
setblock 336 71 -11 minecraft:deepslate_tiles
setblock 304 71 -10 minecraft:deepslate_tiles
setblock 336 71 -10 minecraft:deepslate_tiles
setblock 304 71 -9 minecraft:deepslate_tiles
setblock 336 71 -9 minecraft:deepslate_tiles
setblock 304 71 -8 minecraft:deepslate_tiles
setblock 336 71 -8 minecraft:deepslate_tiles
setblock 304 71 -7 minecraft:deepslate_tiles
setblock 336 71 -7 minecraft:deepslate_tiles
setblock 305 71 -6 minecraft:light_blue_stained_glass
setblock 335 71 -6 minecraft:light_blue_stained_glass
setblock 304 71 -6 minecraft:sea_lantern
setblock 336 71 -6 minecraft:sea_lantern
setblock 304 71 -5 minecraft:deepslate_tiles
setblock 336 71 -5 minecraft:deepslate_tiles
setblock 304 71 -4 minecraft:deepslate_tiles
setblock 336 71 -4 minecraft:deepslate_tiles
setblock 304 71 -3 minecraft:deepslate_tiles
setblock 336 71 -3 minecraft:deepslate_tiles
setblock 304 71 -2 minecraft:deepslate_tiles
setblock 336 71 -2 minecraft:deepslate_tiles
setblock 304 71 -1 minecraft:deepslate_tiles
setblock 336 71 -1 minecraft:deepslate_tiles
setblock 305 71 0 minecraft:light_blue_stained_glass
setblock 335 71 0 minecraft:light_blue_stained_glass
setblock 304 71 0 minecraft:sea_lantern
setblock 336 71 0 minecraft:sea_lantern
setblock 304 71 1 minecraft:deepslate_tiles
setblock 336 71 1 minecraft:deepslate_tiles
setblock 304 71 2 minecraft:deepslate_tiles
setblock 336 71 2 minecraft:deepslate_tiles
setblock 304 71 3 minecraft:deepslate_tiles
setblock 336 71 3 minecraft:deepslate_tiles
setblock 304 71 4 minecraft:deepslate_tiles
setblock 336 71 4 minecraft:deepslate_tiles
setblock 304 71 5 minecraft:deepslate_tiles
setblock 336 71 5 minecraft:deepslate_tiles
setblock 305 71 6 minecraft:light_blue_stained_glass
setblock 335 71 6 minecraft:light_blue_stained_glass
setblock 304 71 6 minecraft:sea_lantern
setblock 336 71 6 minecraft:sea_lantern
setblock 304 71 7 minecraft:deepslate_tiles
setblock 336 71 7 minecraft:deepslate_tiles
setblock 304 71 8 minecraft:deepslate_tiles
setblock 336 71 8 minecraft:deepslate_tiles
setblock 304 71 9 minecraft:deepslate_tiles
setblock 336 71 9 minecraft:deepslate_tiles
setblock 304 71 10 minecraft:deepslate_tiles
setblock 336 71 10 minecraft:deepslate_tiles
setblock 304 71 11 minecraft:deepslate_tiles
setblock 336 71 11 minecraft:deepslate_tiles
setblock 305 71 12 minecraft:light_blue_stained_glass
setblock 335 71 12 minecraft:light_blue_stained_glass
setblock 304 71 12 minecraft:sea_lantern
setblock 336 71 12 minecraft:sea_lantern
setblock 304 71 13 minecraft:deepslate_tiles
setblock 336 71 13 minecraft:deepslate_tiles
setblock 304 71 14 minecraft:deepslate_tiles
setblock 336 71 14 minecraft:deepslate_tiles
setblock 304 71 15 minecraft:deepslate_tiles
setblock 336 71 15 minecraft:deepslate_tiles
setblock 308 71 15 minecraft:light_blue_stained_glass
setblock 314 71 15 minecraft:light_blue_stained_glass
setblock 320 71 15 minecraft:light_blue_stained_glass
setblock 326 71 15 minecraft:light_blue_stained_glass
setblock 332 71 15 minecraft:light_blue_stained_glass
fill 304 71 16 307 71 16 minecraft:deepslate_tiles
fill 309 71 16 313 71 16 minecraft:deepslate_tiles
fill 315 71 16 319 71 16 minecraft:deepslate_tiles
fill 321 71 16 325 71 16 minecraft:deepslate_tiles
fill 327 71 16 331 71 16 minecraft:deepslate_tiles
fill 333 71 16 336 71 16 minecraft:deepslate_tiles
setblock 308 71 16 minecraft:sea_lantern
setblock 314 71 16 minecraft:sea_lantern
setblock 320 71 16 minecraft:sea_lantern
setblock 326 71 16 minecraft:sea_lantern
setblock 332 71 16 minecraft:sea_lantern
fill 304 72 -16 307 72 -16 minecraft:deepslate_tiles
fill 309 72 -16 313 72 -16 minecraft:deepslate_tiles
fill 315 72 -16 319 72 -16 minecraft:deepslate_tiles
fill 321 72 -16 325 72 -16 minecraft:deepslate_tiles
fill 327 72 -16 331 72 -16 minecraft:deepslate_tiles
fill 333 72 -16 336 72 -16 minecraft:deepslate_tiles
setblock 308 72 -16 minecraft:sea_lantern
setblock 314 72 -16 minecraft:sea_lantern
setblock 320 72 -16 minecraft:sea_lantern
setblock 326 72 -16 minecraft:sea_lantern
setblock 332 72 -16 minecraft:sea_lantern
setblock 304 72 -15 minecraft:deepslate_tiles
setblock 336 72 -15 minecraft:deepslate_tiles
setblock 308 72 -15 minecraft:light_blue_stained_glass
setblock 314 72 -15 minecraft:light_blue_stained_glass
setblock 320 72 -15 minecraft:light_blue_stained_glass
setblock 326 72 -15 minecraft:light_blue_stained_glass
setblock 332 72 -15 minecraft:light_blue_stained_glass
setblock 304 72 -14 minecraft:deepslate_tiles
setblock 336 72 -14 minecraft:deepslate_tiles
setblock 304 72 -13 minecraft:deepslate_tiles
setblock 336 72 -13 minecraft:deepslate_tiles
setblock 305 72 -12 minecraft:light_blue_stained_glass
setblock 335 72 -12 minecraft:light_blue_stained_glass
setblock 304 72 -12 minecraft:sea_lantern
setblock 336 72 -12 minecraft:sea_lantern
setblock 304 72 -11 minecraft:deepslate_tiles
setblock 336 72 -11 minecraft:deepslate_tiles
setblock 304 72 -10 minecraft:deepslate_tiles
setblock 336 72 -10 minecraft:deepslate_tiles
setblock 304 72 -9 minecraft:deepslate_tiles
setblock 336 72 -9 minecraft:deepslate_tiles
setblock 304 72 -8 minecraft:deepslate_tiles
setblock 336 72 -8 minecraft:deepslate_tiles
setblock 304 72 -7 minecraft:deepslate_tiles
setblock 336 72 -7 minecraft:deepslate_tiles
setblock 305 72 -6 minecraft:light_blue_stained_glass
setblock 335 72 -6 minecraft:light_blue_stained_glass
setblock 304 72 -6 minecraft:sea_lantern
setblock 336 72 -6 minecraft:sea_lantern
setblock 304 72 -5 minecraft:deepslate_tiles
setblock 336 72 -5 minecraft:deepslate_tiles
setblock 304 72 -4 minecraft:deepslate_tiles
setblock 336 72 -4 minecraft:deepslate_tiles
fill 318 72 -4 322 72 -4 minecraft:quartz_block
setblock 304 72 -3 minecraft:deepslate_tiles
setblock 336 72 -3 minecraft:deepslate_tiles
fill 317 72 -3 319 72 -3 minecraft:quartz_block
fill 321 72 -3 323 72 -3 minecraft:quartz_block
setblock 304 72 -2 minecraft:deepslate_tiles
setblock 336 72 -2 minecraft:deepslate_tiles
fill 316 72 -2 317 72 -2 minecraft:quartz_block
fill 323 72 -2 324 72 -2 minecraft:quartz_block
setblock 304 72 -1 minecraft:deepslate_tiles
setblock 336 72 -1 minecraft:deepslate_tiles
fill 316 72 -1 317 72 -1 minecraft:quartz_block
fill 323 72 -1 324 72 -1 minecraft:quartz_block
setblock 305 72 0 minecraft:light_blue_stained_glass
setblock 335 72 0 minecraft:light_blue_stained_glass
setblock 316 72 0 minecraft:quartz_block
setblock 324 72 0 minecraft:quartz_block
setblock 304 72 0 minecraft:sea_lantern
setblock 336 72 0 minecraft:sea_lantern
setblock 304 72 1 minecraft:deepslate_tiles
setblock 336 72 1 minecraft:deepslate_tiles
fill 316 72 1 317 72 1 minecraft:quartz_block
fill 323 72 1 324 72 1 minecraft:quartz_block
setblock 304 72 2 minecraft:deepslate_tiles
setblock 336 72 2 minecraft:deepslate_tiles
fill 316 72 2 317 72 2 minecraft:quartz_block
fill 323 72 2 324 72 2 minecraft:quartz_block
setblock 304 72 3 minecraft:deepslate_tiles
setblock 336 72 3 minecraft:deepslate_tiles
fill 317 72 3 319 72 3 minecraft:quartz_block
fill 321 72 3 323 72 3 minecraft:quartz_block
setblock 304 72 4 minecraft:deepslate_tiles
setblock 336 72 4 minecraft:deepslate_tiles
fill 318 72 4 322 72 4 minecraft:quartz_block
setblock 304 72 5 minecraft:deepslate_tiles
setblock 336 72 5 minecraft:deepslate_tiles
setblock 305 72 6 minecraft:light_blue_stained_glass
setblock 335 72 6 minecraft:light_blue_stained_glass
setblock 304 72 6 minecraft:sea_lantern
setblock 336 72 6 minecraft:sea_lantern
setblock 304 72 7 minecraft:deepslate_tiles
setblock 336 72 7 minecraft:deepslate_tiles
setblock 304 72 8 minecraft:deepslate_tiles
setblock 336 72 8 minecraft:deepslate_tiles
setblock 304 72 9 minecraft:deepslate_tiles
setblock 336 72 9 minecraft:deepslate_tiles
setblock 304 72 10 minecraft:deepslate_tiles
setblock 336 72 10 minecraft:deepslate_tiles
setblock 304 72 11 minecraft:deepslate_tiles
setblock 336 72 11 minecraft:deepslate_tiles
setblock 305 72 12 minecraft:light_blue_stained_glass
setblock 335 72 12 minecraft:light_blue_stained_glass
setblock 304 72 12 minecraft:sea_lantern
setblock 336 72 12 minecraft:sea_lantern
setblock 304 72 13 minecraft:deepslate_tiles
setblock 336 72 13 minecraft:deepslate_tiles
setblock 304 72 14 minecraft:deepslate_tiles
setblock 336 72 14 minecraft:deepslate_tiles
setblock 304 72 15 minecraft:deepslate_tiles
setblock 336 72 15 minecraft:deepslate_tiles
setblock 308 72 15 minecraft:light_blue_stained_glass
setblock 314 72 15 minecraft:light_blue_stained_glass
setblock 320 72 15 minecraft:light_blue_stained_glass
setblock 326 72 15 minecraft:light_blue_stained_glass
setblock 332 72 15 minecraft:light_blue_stained_glass
fill 304 72 16 307 72 16 minecraft:deepslate_tiles
fill 309 72 16 313 72 16 minecraft:deepslate_tiles
fill 315 72 16 319 72 16 minecraft:deepslate_tiles
fill 321 72 16 325 72 16 minecraft:deepslate_tiles
fill 327 72 16 331 72 16 minecraft:deepslate_tiles
fill 333 72 16 336 72 16 minecraft:deepslate_tiles
setblock 308 72 16 minecraft:sea_lantern
setblock 314 72 16 minecraft:sea_lantern
setblock 320 72 16 minecraft:sea_lantern
setblock 326 72 16 minecraft:sea_lantern
setblock 332 72 16 minecraft:sea_lantern
fill 304 73 -16 307 73 -16 minecraft:deepslate_tiles
fill 309 73 -16 313 73 -16 minecraft:deepslate_tiles
fill 315 73 -16 319 73 -16 minecraft:deepslate_tiles
fill 321 73 -16 325 73 -16 minecraft:deepslate_tiles
fill 327 73 -16 331 73 -16 minecraft:deepslate_tiles
fill 333 73 -16 336 73 -16 minecraft:deepslate_tiles
setblock 308 73 -16 minecraft:sea_lantern
setblock 314 73 -16 minecraft:sea_lantern
setblock 320 73 -16 minecraft:sea_lantern
setblock 326 73 -16 minecraft:sea_lantern
setblock 332 73 -16 minecraft:sea_lantern
setblock 304 73 -15 minecraft:deepslate_tiles
setblock 336 73 -15 minecraft:deepslate_tiles
setblock 308 73 -15 minecraft:light_blue_stained_glass
setblock 314 73 -15 minecraft:light_blue_stained_glass
setblock 320 73 -15 minecraft:light_blue_stained_glass
setblock 326 73 -15 minecraft:light_blue_stained_glass
setblock 332 73 -15 minecraft:light_blue_stained_glass
setblock 304 73 -14 minecraft:deepslate_tiles
setblock 336 73 -14 minecraft:deepslate_tiles
setblock 304 73 -13 minecraft:deepslate_tiles
setblock 336 73 -13 minecraft:deepslate_tiles
setblock 305 73 -12 minecraft:light_blue_stained_glass
setblock 335 73 -12 minecraft:light_blue_stained_glass
setblock 304 73 -12 minecraft:sea_lantern
setblock 336 73 -12 minecraft:sea_lantern
setblock 304 73 -11 minecraft:deepslate_tiles
setblock 336 73 -11 minecraft:deepslate_tiles
setblock 304 73 -10 minecraft:deepslate_tiles
setblock 336 73 -10 minecraft:deepslate_tiles
setblock 304 73 -9 minecraft:deepslate_tiles
setblock 336 73 -9 minecraft:deepslate_tiles
setblock 304 73 -8 minecraft:deepslate_tiles
setblock 336 73 -8 minecraft:deepslate_tiles
setblock 304 73 -7 minecraft:deepslate_tiles
setblock 336 73 -7 minecraft:deepslate_tiles
setblock 305 73 -6 minecraft:light_blue_stained_glass
setblock 335 73 -6 minecraft:light_blue_stained_glass
setblock 304 73 -6 minecraft:sea_lantern
setblock 336 73 -6 minecraft:sea_lantern
setblock 304 73 -5 minecraft:deepslate_tiles
setblock 336 73 -5 minecraft:deepslate_tiles
setblock 304 73 -4 minecraft:deepslate_tiles
setblock 336 73 -4 minecraft:deepslate_tiles
setblock 304 73 -3 minecraft:deepslate_tiles
setblock 336 73 -3 minecraft:deepslate_tiles
setblock 304 73 -2 minecraft:deepslate_tiles
setblock 336 73 -2 minecraft:deepslate_tiles
setblock 320 73 -2 minecraft:light_blue_stained_glass
setblock 304 73 -1 minecraft:deepslate_tiles
setblock 336 73 -1 minecraft:deepslate_tiles
setblock 305 73 0 minecraft:light_blue_stained_glass
setblock 318 73 0 minecraft:light_blue_stained_glass
setblock 322 73 0 minecraft:light_blue_stained_glass
setblock 335 73 0 minecraft:light_blue_stained_glass
setblock 304 73 0 minecraft:sea_lantern
setblock 336 73 0 minecraft:sea_lantern
setblock 304 73 1 minecraft:deepslate_tiles
setblock 336 73 1 minecraft:deepslate_tiles
setblock 304 73 2 minecraft:deepslate_tiles
setblock 336 73 2 minecraft:deepslate_tiles
setblock 320 73 2 minecraft:light_blue_stained_glass
setblock 304 73 3 minecraft:deepslate_tiles
setblock 336 73 3 minecraft:deepslate_tiles
setblock 304 73 4 minecraft:deepslate_tiles
setblock 336 73 4 minecraft:deepslate_tiles
setblock 304 73 5 minecraft:deepslate_tiles
setblock 336 73 5 minecraft:deepslate_tiles
setblock 305 73 6 minecraft:light_blue_stained_glass
setblock 335 73 6 minecraft:light_blue_stained_glass
setblock 304 73 6 minecraft:sea_lantern
setblock 336 73 6 minecraft:sea_lantern
setblock 304 73 7 minecraft:deepslate_tiles
setblock 336 73 7 minecraft:deepslate_tiles
setblock 304 73 8 minecraft:deepslate_tiles
setblock 336 73 8 minecraft:deepslate_tiles
setblock 304 73 9 minecraft:deepslate_tiles
setblock 336 73 9 minecraft:deepslate_tiles
setblock 304 73 10 minecraft:deepslate_tiles
setblock 336 73 10 minecraft:deepslate_tiles
setblock 304 73 11 minecraft:deepslate_tiles
setblock 336 73 11 minecraft:deepslate_tiles
setblock 305 73 12 minecraft:light_blue_stained_glass
setblock 335 73 12 minecraft:light_blue_stained_glass
setblock 304 73 12 minecraft:sea_lantern
setblock 336 73 12 minecraft:sea_lantern
setblock 304 73 13 minecraft:deepslate_tiles
setblock 336 73 13 minecraft:deepslate_tiles
setblock 304 73 14 minecraft:deepslate_tiles
setblock 336 73 14 minecraft:deepslate_tiles
setblock 304 73 15 minecraft:deepslate_tiles
setblock 336 73 15 minecraft:deepslate_tiles
setblock 308 73 15 minecraft:light_blue_stained_glass
setblock 314 73 15 minecraft:light_blue_stained_glass
setblock 320 73 15 minecraft:light_blue_stained_glass
setblock 326 73 15 minecraft:light_blue_stained_glass
setblock 332 73 15 minecraft:light_blue_stained_glass
fill 304 73 16 307 73 16 minecraft:deepslate_tiles
fill 309 73 16 313 73 16 minecraft:deepslate_tiles
fill 315 73 16 319 73 16 minecraft:deepslate_tiles
fill 321 73 16 325 73 16 minecraft:deepslate_tiles
fill 327 73 16 331 73 16 minecraft:deepslate_tiles
fill 333 73 16 336 73 16 minecraft:deepslate_tiles
setblock 308 73 16 minecraft:sea_lantern
setblock 314 73 16 minecraft:sea_lantern
setblock 320 73 16 minecraft:sea_lantern
setblock 326 73 16 minecraft:sea_lantern
setblock 332 73 16 minecraft:sea_lantern
fill 304 74 -16 307 74 -16 minecraft:deepslate_tiles
fill 309 74 -16 313 74 -16 minecraft:deepslate_tiles
fill 315 74 -16 319 74 -16 minecraft:deepslate_tiles
fill 321 74 -16 325 74 -16 minecraft:deepslate_tiles
fill 327 74 -16 331 74 -16 minecraft:deepslate_tiles
fill 333 74 -16 336 74 -16 minecraft:deepslate_tiles
setblock 308 74 -16 minecraft:sea_lantern
setblock 314 74 -16 minecraft:sea_lantern
setblock 320 74 -16 minecraft:sea_lantern
setblock 326 74 -16 minecraft:sea_lantern
setblock 332 74 -16 minecraft:sea_lantern
setblock 304 74 -15 minecraft:deepslate_tiles
setblock 336 74 -15 minecraft:deepslate_tiles
setblock 308 74 -15 minecraft:light_blue_stained_glass
setblock 314 74 -15 minecraft:light_blue_stained_glass
setblock 320 74 -15 minecraft:light_blue_stained_glass
setblock 326 74 -15 minecraft:light_blue_stained_glass
setblock 332 74 -15 minecraft:light_blue_stained_glass
setblock 304 74 -14 minecraft:deepslate_tiles
setblock 336 74 -14 minecraft:deepslate_tiles
setblock 304 74 -13 minecraft:deepslate_tiles
setblock 336 74 -13 minecraft:deepslate_tiles
setblock 305 74 -12 minecraft:light_blue_stained_glass
setblock 335 74 -12 minecraft:light_blue_stained_glass
setblock 304 74 -12 minecraft:sea_lantern
setblock 336 74 -12 minecraft:sea_lantern
setblock 304 74 -11 minecraft:deepslate_tiles
setblock 336 74 -11 minecraft:deepslate_tiles
setblock 304 74 -10 minecraft:deepslate_tiles
setblock 336 74 -10 minecraft:deepslate_tiles
setblock 304 74 -9 minecraft:deepslate_tiles
setblock 336 74 -9 minecraft:deepslate_tiles
setblock 304 74 -8 minecraft:deepslate_tiles
setblock 336 74 -8 minecraft:deepslate_tiles
setblock 304 74 -7 minecraft:deepslate_tiles
setblock 336 74 -7 minecraft:deepslate_tiles
setblock 305 74 -6 minecraft:light_blue_stained_glass
setblock 335 74 -6 minecraft:light_blue_stained_glass
setblock 304 74 -6 minecraft:sea_lantern
setblock 336 74 -6 minecraft:sea_lantern
setblock 304 74 -5 minecraft:deepslate_tiles
setblock 336 74 -5 minecraft:deepslate_tiles
setblock 304 74 -4 minecraft:deepslate_tiles
setblock 336 74 -4 minecraft:deepslate_tiles
setblock 304 74 -3 minecraft:deepslate_tiles
setblock 336 74 -3 minecraft:deepslate_tiles
setblock 304 74 -2 minecraft:deepslate_tiles
setblock 336 74 -2 minecraft:deepslate_tiles
setblock 320 74 -2 minecraft:light_blue_stained_glass
setblock 304 74 -1 minecraft:deepslate_tiles
setblock 336 74 -1 minecraft:deepslate_tiles
fill 319 74 -1 321 74 -1 minecraft:sea_lantern
setblock 305 74 0 minecraft:light_blue_stained_glass
setblock 318 74 0 minecraft:light_blue_stained_glass
setblock 322 74 0 minecraft:light_blue_stained_glass
setblock 335 74 0 minecraft:light_blue_stained_glass
setblock 304 74 0 minecraft:sea_lantern
fill 319 74 0 321 74 0 minecraft:sea_lantern
setblock 336 74 0 minecraft:sea_lantern
setblock 304 74 1 minecraft:deepslate_tiles
setblock 336 74 1 minecraft:deepslate_tiles
fill 319 74 1 321 74 1 minecraft:sea_lantern
setblock 304 74 2 minecraft:deepslate_tiles
setblock 336 74 2 minecraft:deepslate_tiles
setblock 320 74 2 minecraft:light_blue_stained_glass
setblock 304 74 3 minecraft:deepslate_tiles
setblock 336 74 3 minecraft:deepslate_tiles
setblock 304 74 4 minecraft:deepslate_tiles
setblock 336 74 4 minecraft:deepslate_tiles
setblock 304 74 5 minecraft:deepslate_tiles
setblock 336 74 5 minecraft:deepslate_tiles
setblock 305 74 6 minecraft:light_blue_stained_glass
setblock 335 74 6 minecraft:light_blue_stained_glass
setblock 304 74 6 minecraft:sea_lantern
setblock 336 74 6 minecraft:sea_lantern
setblock 304 74 7 minecraft:deepslate_tiles
setblock 336 74 7 minecraft:deepslate_tiles
setblock 304 74 8 minecraft:deepslate_tiles
setblock 336 74 8 minecraft:deepslate_tiles
setblock 304 74 9 minecraft:deepslate_tiles
setblock 336 74 9 minecraft:deepslate_tiles
setblock 304 74 10 minecraft:deepslate_tiles
setblock 336 74 10 minecraft:deepslate_tiles
setblock 304 74 11 minecraft:deepslate_tiles
setblock 336 74 11 minecraft:deepslate_tiles
setblock 305 74 12 minecraft:light_blue_stained_glass
setblock 335 74 12 minecraft:light_blue_stained_glass
setblock 304 74 12 minecraft:sea_lantern
setblock 336 74 12 minecraft:sea_lantern
setblock 304 74 13 minecraft:deepslate_tiles
setblock 336 74 13 minecraft:deepslate_tiles
setblock 304 74 14 minecraft:deepslate_tiles
setblock 336 74 14 minecraft:deepslate_tiles
setblock 304 74 15 minecraft:deepslate_tiles
setblock 336 74 15 minecraft:deepslate_tiles
setblock 308 74 15 minecraft:light_blue_stained_glass
setblock 314 74 15 minecraft:light_blue_stained_glass
setblock 320 74 15 minecraft:light_blue_stained_glass
setblock 326 74 15 minecraft:light_blue_stained_glass
setblock 332 74 15 minecraft:light_blue_stained_glass
fill 304 74 16 307 74 16 minecraft:deepslate_tiles
fill 309 74 16 313 74 16 minecraft:deepslate_tiles
fill 315 74 16 319 74 16 minecraft:deepslate_tiles
fill 321 74 16 325 74 16 minecraft:deepslate_tiles
fill 327 74 16 331 74 16 minecraft:deepslate_tiles
fill 333 74 16 336 74 16 minecraft:deepslate_tiles
setblock 308 74 16 minecraft:sea_lantern
setblock 314 74 16 minecraft:sea_lantern
setblock 320 74 16 minecraft:sea_lantern
setblock 326 74 16 minecraft:sea_lantern
setblock 332 74 16 minecraft:sea_lantern
fill 304 75 -16 307 75 -16 minecraft:deepslate_tiles
fill 309 75 -16 313 75 -16 minecraft:deepslate_tiles
fill 315 75 -16 319 75 -16 minecraft:deepslate_tiles
fill 321 75 -16 325 75 -16 minecraft:deepslate_tiles
fill 327 75 -16 331 75 -16 minecraft:deepslate_tiles
fill 333 75 -16 336 75 -16 minecraft:deepslate_tiles
setblock 308 75 -16 minecraft:sea_lantern
setblock 314 75 -16 minecraft:sea_lantern
setblock 320 75 -16 minecraft:sea_lantern
setblock 326 75 -16 minecraft:sea_lantern
setblock 332 75 -16 minecraft:sea_lantern
setblock 304 75 -15 minecraft:deepslate_tiles
setblock 336 75 -15 minecraft:deepslate_tiles
setblock 308 75 -15 minecraft:light_blue_stained_glass
setblock 314 75 -15 minecraft:light_blue_stained_glass
setblock 320 75 -15 minecraft:light_blue_stained_glass
setblock 326 75 -15 minecraft:light_blue_stained_glass
setblock 332 75 -15 minecraft:light_blue_stained_glass
setblock 304 75 -14 minecraft:deepslate_tiles
setblock 336 75 -14 minecraft:deepslate_tiles
setblock 304 75 -13 minecraft:deepslate_tiles
setblock 336 75 -13 minecraft:deepslate_tiles
setblock 305 75 -12 minecraft:light_blue_stained_glass
setblock 335 75 -12 minecraft:light_blue_stained_glass
setblock 304 75 -12 minecraft:sea_lantern
setblock 336 75 -12 minecraft:sea_lantern
setblock 304 75 -11 minecraft:deepslate_tiles
setblock 336 75 -11 minecraft:deepslate_tiles
setblock 304 75 -10 minecraft:deepslate_tiles
setblock 336 75 -10 minecraft:deepslate_tiles
setblock 304 75 -9 minecraft:deepslate_tiles
setblock 336 75 -9 minecraft:deepslate_tiles
setblock 304 75 -8 minecraft:deepslate_tiles
setblock 336 75 -8 minecraft:deepslate_tiles
setblock 304 75 -7 minecraft:deepslate_tiles
setblock 336 75 -7 minecraft:deepslate_tiles
setblock 305 75 -6 minecraft:light_blue_stained_glass
setblock 335 75 -6 minecraft:light_blue_stained_glass
setblock 304 75 -6 minecraft:sea_lantern
setblock 336 75 -6 minecraft:sea_lantern
setblock 304 75 -5 minecraft:deepslate_tiles
setblock 336 75 -5 minecraft:deepslate_tiles
setblock 304 75 -4 minecraft:deepslate_tiles
setblock 336 75 -4 minecraft:deepslate_tiles
setblock 304 75 -3 minecraft:deepslate_tiles
setblock 336 75 -3 minecraft:deepslate_tiles
setblock 304 75 -2 minecraft:deepslate_tiles
setblock 336 75 -2 minecraft:deepslate_tiles
setblock 320 75 -2 minecraft:light_blue_stained_glass
setblock 304 75 -1 minecraft:deepslate_tiles
setblock 336 75 -1 minecraft:deepslate_tiles
fill 319 75 -1 321 75 -1 minecraft:sea_lantern
setblock 305 75 0 minecraft:light_blue_stained_glass
setblock 318 75 0 minecraft:light_blue_stained_glass
setblock 322 75 0 minecraft:light_blue_stained_glass
setblock 335 75 0 minecraft:light_blue_stained_glass
setblock 304 75 0 minecraft:sea_lantern
fill 319 75 0 321 75 0 minecraft:sea_lantern
setblock 336 75 0 minecraft:sea_lantern
setblock 304 75 1 minecraft:deepslate_tiles
setblock 336 75 1 minecraft:deepslate_tiles
fill 319 75 1 321 75 1 minecraft:sea_lantern
setblock 304 75 2 minecraft:deepslate_tiles
setblock 336 75 2 minecraft:deepslate_tiles
setblock 320 75 2 minecraft:light_blue_stained_glass
setblock 304 75 3 minecraft:deepslate_tiles
setblock 336 75 3 minecraft:deepslate_tiles
setblock 304 75 4 minecraft:deepslate_tiles
setblock 336 75 4 minecraft:deepslate_tiles
setblock 304 75 5 minecraft:deepslate_tiles
setblock 336 75 5 minecraft:deepslate_tiles
setblock 305 75 6 minecraft:light_blue_stained_glass
setblock 335 75 6 minecraft:light_blue_stained_glass
setblock 304 75 6 minecraft:sea_lantern
setblock 336 75 6 minecraft:sea_lantern
setblock 304 75 7 minecraft:deepslate_tiles
setblock 336 75 7 minecraft:deepslate_tiles
setblock 304 75 8 minecraft:deepslate_tiles
setblock 336 75 8 minecraft:deepslate_tiles
setblock 304 75 9 minecraft:deepslate_tiles
setblock 336 75 9 minecraft:deepslate_tiles
setblock 304 75 10 minecraft:deepslate_tiles
setblock 336 75 10 minecraft:deepslate_tiles
setblock 304 75 11 minecraft:deepslate_tiles
setblock 336 75 11 minecraft:deepslate_tiles
setblock 305 75 12 minecraft:light_blue_stained_glass
setblock 335 75 12 minecraft:light_blue_stained_glass
setblock 304 75 12 minecraft:sea_lantern
setblock 336 75 12 minecraft:sea_lantern
setblock 304 75 13 minecraft:deepslate_tiles
setblock 336 75 13 minecraft:deepslate_tiles
setblock 304 75 14 minecraft:deepslate_tiles
setblock 336 75 14 minecraft:deepslate_tiles
setblock 304 75 15 minecraft:deepslate_tiles
setblock 336 75 15 minecraft:deepslate_tiles
setblock 308 75 15 minecraft:light_blue_stained_glass
setblock 314 75 15 minecraft:light_blue_stained_glass
setblock 320 75 15 minecraft:light_blue_stained_glass
setblock 326 75 15 minecraft:light_blue_stained_glass
setblock 332 75 15 minecraft:light_blue_stained_glass
fill 304 75 16 307 75 16 minecraft:deepslate_tiles
fill 309 75 16 313 75 16 minecraft:deepslate_tiles
fill 315 75 16 319 75 16 minecraft:deepslate_tiles
fill 321 75 16 325 75 16 minecraft:deepslate_tiles
fill 327 75 16 331 75 16 minecraft:deepslate_tiles
fill 333 75 16 336 75 16 minecraft:deepslate_tiles
setblock 308 75 16 minecraft:sea_lantern
setblock 314 75 16 minecraft:sea_lantern
setblock 320 75 16 minecraft:sea_lantern
setblock 326 75 16 minecraft:sea_lantern
setblock 332 75 16 minecraft:sea_lantern
fill 304 76 -16 307 76 -16 minecraft:deepslate_tiles
fill 309 76 -16 313 76 -16 minecraft:deepslate_tiles
fill 315 76 -16 319 76 -16 minecraft:deepslate_tiles
fill 321 76 -16 325 76 -16 minecraft:deepslate_tiles
fill 327 76 -16 331 76 -16 minecraft:deepslate_tiles
fill 333 76 -16 336 76 -16 minecraft:deepslate_tiles
setblock 308 76 -16 minecraft:sea_lantern
setblock 314 76 -16 minecraft:sea_lantern
setblock 320 76 -16 minecraft:sea_lantern
setblock 326 76 -16 minecraft:sea_lantern
setblock 332 76 -16 minecraft:sea_lantern
setblock 304 76 -15 minecraft:deepslate_tiles
setblock 336 76 -15 minecraft:deepslate_tiles
setblock 308 76 -15 minecraft:light_blue_stained_glass
setblock 314 76 -15 minecraft:light_blue_stained_glass
setblock 320 76 -15 minecraft:light_blue_stained_glass
setblock 326 76 -15 minecraft:light_blue_stained_glass
setblock 332 76 -15 minecraft:light_blue_stained_glass
setblock 304 76 -14 minecraft:deepslate_tiles
setblock 336 76 -14 minecraft:deepslate_tiles
setblock 304 76 -13 minecraft:deepslate_tiles
setblock 336 76 -13 minecraft:deepslate_tiles
setblock 305 76 -12 minecraft:light_blue_stained_glass
setblock 335 76 -12 minecraft:light_blue_stained_glass
setblock 304 76 -12 minecraft:sea_lantern
setblock 336 76 -12 minecraft:sea_lantern
setblock 304 76 -11 minecraft:deepslate_tiles
setblock 336 76 -11 minecraft:deepslate_tiles
setblock 304 76 -10 minecraft:deepslate_tiles
setblock 336 76 -10 minecraft:deepslate_tiles
setblock 304 76 -9 minecraft:deepslate_tiles
setblock 336 76 -9 minecraft:deepslate_tiles
setblock 304 76 -8 minecraft:deepslate_tiles
setblock 336 76 -8 minecraft:deepslate_tiles
setblock 304 76 -7 minecraft:deepslate_tiles
setblock 336 76 -7 minecraft:deepslate_tiles
setblock 305 76 -6 minecraft:light_blue_stained_glass
setblock 335 76 -6 minecraft:light_blue_stained_glass
setblock 304 76 -6 minecraft:sea_lantern
setblock 336 76 -6 minecraft:sea_lantern
setblock 304 76 -5 minecraft:deepslate_tiles
setblock 336 76 -5 minecraft:deepslate_tiles
setblock 304 76 -4 minecraft:deepslate_tiles
setblock 336 76 -4 minecraft:deepslate_tiles
setblock 304 76 -3 minecraft:deepslate_tiles
setblock 336 76 -3 minecraft:deepslate_tiles
setblock 304 76 -2 minecraft:deepslate_tiles
setblock 336 76 -2 minecraft:deepslate_tiles
setblock 320 76 -2 minecraft:light_blue_stained_glass
setblock 304 76 -1 minecraft:deepslate_tiles
setblock 336 76 -1 minecraft:deepslate_tiles
fill 319 76 -1 321 76 -1 minecraft:sea_lantern
setblock 305 76 0 minecraft:light_blue_stained_glass
setblock 318 76 0 minecraft:light_blue_stained_glass
setblock 322 76 0 minecraft:light_blue_stained_glass
setblock 335 76 0 minecraft:light_blue_stained_glass
setblock 304 76 0 minecraft:sea_lantern
fill 319 76 0 321 76 0 minecraft:sea_lantern
setblock 336 76 0 minecraft:sea_lantern
setblock 304 76 1 minecraft:deepslate_tiles
setblock 336 76 1 minecraft:deepslate_tiles
fill 319 76 1 321 76 1 minecraft:sea_lantern
setblock 304 76 2 minecraft:deepslate_tiles
setblock 336 76 2 minecraft:deepslate_tiles
setblock 320 76 2 minecraft:light_blue_stained_glass
setblock 304 76 3 minecraft:deepslate_tiles
setblock 336 76 3 minecraft:deepslate_tiles
setblock 304 76 4 minecraft:deepslate_tiles
setblock 336 76 4 minecraft:deepslate_tiles
setblock 304 76 5 minecraft:deepslate_tiles
setblock 336 76 5 minecraft:deepslate_tiles
setblock 305 76 6 minecraft:light_blue_stained_glass
setblock 335 76 6 minecraft:light_blue_stained_glass
setblock 304 76 6 minecraft:sea_lantern
setblock 336 76 6 minecraft:sea_lantern
setblock 304 76 7 minecraft:deepslate_tiles
setblock 336 76 7 minecraft:deepslate_tiles
setblock 304 76 8 minecraft:deepslate_tiles
setblock 336 76 8 minecraft:deepslate_tiles
setblock 304 76 9 minecraft:deepslate_tiles
setblock 336 76 9 minecraft:deepslate_tiles
setblock 304 76 10 minecraft:deepslate_tiles
setblock 336 76 10 minecraft:deepslate_tiles
setblock 304 76 11 minecraft:deepslate_tiles
setblock 336 76 11 minecraft:deepslate_tiles
setblock 305 76 12 minecraft:light_blue_stained_glass
setblock 335 76 12 minecraft:light_blue_stained_glass
setblock 304 76 12 minecraft:sea_lantern
setblock 336 76 12 minecraft:sea_lantern
setblock 304 76 13 minecraft:deepslate_tiles
setblock 336 76 13 minecraft:deepslate_tiles
setblock 304 76 14 minecraft:deepslate_tiles
setblock 336 76 14 minecraft:deepslate_tiles
setblock 304 76 15 minecraft:deepslate_tiles
setblock 336 76 15 minecraft:deepslate_tiles
setblock 308 76 15 minecraft:light_blue_stained_glass
setblock 314 76 15 minecraft:light_blue_stained_glass
setblock 320 76 15 minecraft:light_blue_stained_glass
setblock 326 76 15 minecraft:light_blue_stained_glass
setblock 332 76 15 minecraft:light_blue_stained_glass
fill 304 76 16 307 76 16 minecraft:deepslate_tiles
fill 309 76 16 313 76 16 minecraft:deepslate_tiles
fill 315 76 16 319 76 16 minecraft:deepslate_tiles
fill 321 76 16 325 76 16 minecraft:deepslate_tiles
fill 327 76 16 331 76 16 minecraft:deepslate_tiles
fill 333 76 16 336 76 16 minecraft:deepslate_tiles
setblock 308 76 16 minecraft:sea_lantern
setblock 314 76 16 minecraft:sea_lantern
setblock 320 76 16 minecraft:sea_lantern
setblock 326 76 16 minecraft:sea_lantern
setblock 332 76 16 minecraft:sea_lantern
fill 304 77 -16 307 77 -16 minecraft:deepslate_tiles
fill 309 77 -16 313 77 -16 minecraft:deepslate_tiles
fill 315 77 -16 319 77 -16 minecraft:deepslate_tiles
fill 321 77 -16 325 77 -16 minecraft:deepslate_tiles
fill 327 77 -16 331 77 -16 minecraft:deepslate_tiles
fill 333 77 -16 336 77 -16 minecraft:deepslate_tiles
setblock 308 77 -16 minecraft:sea_lantern
setblock 314 77 -16 minecraft:sea_lantern
setblock 320 77 -16 minecraft:sea_lantern
setblock 326 77 -16 minecraft:sea_lantern
setblock 332 77 -16 minecraft:sea_lantern
setblock 304 77 -15 minecraft:deepslate_tiles
setblock 336 77 -15 minecraft:deepslate_tiles
setblock 308 77 -15 minecraft:light_blue_stained_glass
setblock 314 77 -15 minecraft:light_blue_stained_glass
setblock 320 77 -15 minecraft:light_blue_stained_glass
setblock 326 77 -15 minecraft:light_blue_stained_glass
setblock 332 77 -15 minecraft:light_blue_stained_glass
setblock 304 77 -14 minecraft:deepslate_tiles
setblock 336 77 -14 minecraft:deepslate_tiles
setblock 304 77 -13 minecraft:deepslate_tiles
setblock 336 77 -13 minecraft:deepslate_tiles
setblock 305 77 -12 minecraft:light_blue_stained_glass
setblock 335 77 -12 minecraft:light_blue_stained_glass
setblock 304 77 -12 minecraft:sea_lantern
setblock 336 77 -12 minecraft:sea_lantern
setblock 304 77 -11 minecraft:deepslate_tiles
setblock 336 77 -11 minecraft:deepslate_tiles
setblock 304 77 -10 minecraft:deepslate_tiles
setblock 336 77 -10 minecraft:deepslate_tiles
setblock 304 77 -9 minecraft:deepslate_tiles
setblock 336 77 -9 minecraft:deepslate_tiles
setblock 304 77 -8 minecraft:deepslate_tiles
setblock 336 77 -8 minecraft:deepslate_tiles
setblock 304 77 -7 minecraft:deepslate_tiles
setblock 336 77 -7 minecraft:deepslate_tiles
setblock 305 77 -6 minecraft:light_blue_stained_glass
setblock 335 77 -6 minecraft:light_blue_stained_glass
setblock 304 77 -6 minecraft:sea_lantern
setblock 336 77 -6 minecraft:sea_lantern
setblock 304 77 -5 minecraft:deepslate_tiles
setblock 336 77 -5 minecraft:deepslate_tiles
setblock 304 77 -4 minecraft:deepslate_tiles
setblock 336 77 -4 minecraft:deepslate_tiles
setblock 304 77 -3 minecraft:deepslate_tiles
setblock 336 77 -3 minecraft:deepslate_tiles
setblock 304 77 -2 minecraft:deepslate_tiles
setblock 336 77 -2 minecraft:deepslate_tiles
setblock 320 77 -2 minecraft:light_blue_stained_glass
setblock 304 77 -1 minecraft:deepslate_tiles
setblock 336 77 -1 minecraft:deepslate_tiles
fill 319 77 -1 321 77 -1 minecraft:sea_lantern
setblock 305 77 0 minecraft:light_blue_stained_glass
setblock 318 77 0 minecraft:light_blue_stained_glass
setblock 322 77 0 minecraft:light_blue_stained_glass
setblock 335 77 0 minecraft:light_blue_stained_glass
setblock 304 77 0 minecraft:sea_lantern
fill 319 77 0 321 77 0 minecraft:sea_lantern
setblock 336 77 0 minecraft:sea_lantern
setblock 304 77 1 minecraft:deepslate_tiles
setblock 336 77 1 minecraft:deepslate_tiles
fill 319 77 1 321 77 1 minecraft:sea_lantern
setblock 304 77 2 minecraft:deepslate_tiles
setblock 336 77 2 minecraft:deepslate_tiles
setblock 320 77 2 minecraft:light_blue_stained_glass
setblock 304 77 3 minecraft:deepslate_tiles
setblock 336 77 3 minecraft:deepslate_tiles
setblock 304 77 4 minecraft:deepslate_tiles
setblock 336 77 4 minecraft:deepslate_tiles
setblock 304 77 5 minecraft:deepslate_tiles
setblock 336 77 5 minecraft:deepslate_tiles
setblock 305 77 6 minecraft:light_blue_stained_glass
setblock 335 77 6 minecraft:light_blue_stained_glass
setblock 304 77 6 minecraft:sea_lantern
setblock 336 77 6 minecraft:sea_lantern
setblock 304 77 7 minecraft:deepslate_tiles
setblock 336 77 7 minecraft:deepslate_tiles
setblock 304 77 8 minecraft:deepslate_tiles
setblock 336 77 8 minecraft:deepslate_tiles
setblock 304 77 9 minecraft:deepslate_tiles
setblock 336 77 9 minecraft:deepslate_tiles
setblock 304 77 10 minecraft:deepslate_tiles
setblock 336 77 10 minecraft:deepslate_tiles
setblock 304 77 11 minecraft:deepslate_tiles
setblock 336 77 11 minecraft:deepslate_tiles
setblock 305 77 12 minecraft:light_blue_stained_glass
setblock 335 77 12 minecraft:light_blue_stained_glass
setblock 304 77 12 minecraft:sea_lantern
setblock 336 77 12 minecraft:sea_lantern
setblock 304 77 13 minecraft:deepslate_tiles
setblock 336 77 13 minecraft:deepslate_tiles
setblock 304 77 14 minecraft:deepslate_tiles
setblock 336 77 14 minecraft:deepslate_tiles
setblock 304 77 15 minecraft:deepslate_tiles
setblock 336 77 15 minecraft:deepslate_tiles
setblock 308 77 15 minecraft:light_blue_stained_glass
setblock 314 77 15 minecraft:light_blue_stained_glass
setblock 320 77 15 minecraft:light_blue_stained_glass
setblock 326 77 15 minecraft:light_blue_stained_glass
setblock 332 77 15 minecraft:light_blue_stained_glass
fill 304 77 16 307 77 16 minecraft:deepslate_tiles
fill 309 77 16 313 77 16 minecraft:deepslate_tiles
fill 315 77 16 319 77 16 minecraft:deepslate_tiles
fill 321 77 16 325 77 16 minecraft:deepslate_tiles
fill 327 77 16 331 77 16 minecraft:deepslate_tiles
fill 333 77 16 336 77 16 minecraft:deepslate_tiles
setblock 308 77 16 minecraft:sea_lantern
setblock 314 77 16 minecraft:sea_lantern
setblock 320 77 16 minecraft:sea_lantern
setblock 326 77 16 minecraft:sea_lantern
setblock 332 77 16 minecraft:sea_lantern
fill 304 78 -16 307 78 -16 minecraft:deepslate_tiles
fill 309 78 -16 313 78 -16 minecraft:deepslate_tiles
fill 315 78 -16 319 78 -16 minecraft:deepslate_tiles
fill 321 78 -16 325 78 -16 minecraft:deepslate_tiles
fill 327 78 -16 331 78 -16 minecraft:deepslate_tiles
fill 333 78 -16 336 78 -16 minecraft:deepslate_tiles
setblock 308 78 -16 minecraft:sea_lantern
setblock 314 78 -16 minecraft:sea_lantern
setblock 320 78 -16 minecraft:sea_lantern
setblock 326 78 -16 minecraft:sea_lantern
setblock 332 78 -16 minecraft:sea_lantern
setblock 304 78 -15 minecraft:deepslate_tiles
setblock 336 78 -15 minecraft:deepslate_tiles
setblock 308 78 -15 minecraft:light_blue_stained_glass
setblock 314 78 -15 minecraft:light_blue_stained_glass
setblock 320 78 -15 minecraft:light_blue_stained_glass
setblock 326 78 -15 minecraft:light_blue_stained_glass
setblock 332 78 -15 minecraft:light_blue_stained_glass
setblock 304 78 -14 minecraft:deepslate_tiles
setblock 336 78 -14 minecraft:deepslate_tiles
setblock 304 78 -13 minecraft:deepslate_tiles
setblock 336 78 -13 minecraft:deepslate_tiles
setblock 305 78 -12 minecraft:light_blue_stained_glass
setblock 335 78 -12 minecraft:light_blue_stained_glass
setblock 304 78 -12 minecraft:sea_lantern
setblock 336 78 -12 minecraft:sea_lantern
setblock 304 78 -11 minecraft:deepslate_tiles
setblock 336 78 -11 minecraft:deepslate_tiles
setblock 304 78 -10 minecraft:deepslate_tiles
setblock 336 78 -10 minecraft:deepslate_tiles
setblock 304 78 -9 minecraft:deepslate_tiles
setblock 336 78 -9 minecraft:deepslate_tiles
setblock 304 78 -8 minecraft:deepslate_tiles
setblock 336 78 -8 minecraft:deepslate_tiles
setblock 304 78 -7 minecraft:deepslate_tiles
setblock 336 78 -7 minecraft:deepslate_tiles
setblock 305 78 -6 minecraft:light_blue_stained_glass
setblock 335 78 -6 minecraft:light_blue_stained_glass
setblock 304 78 -6 minecraft:sea_lantern
setblock 336 78 -6 minecraft:sea_lantern
setblock 304 78 -5 minecraft:deepslate_tiles
setblock 336 78 -5 minecraft:deepslate_tiles
setblock 304 78 -4 minecraft:deepslate_tiles
setblock 336 78 -4 minecraft:deepslate_tiles
setblock 304 78 -3 minecraft:deepslate_tiles
setblock 336 78 -3 minecraft:deepslate_tiles
setblock 304 78 -2 minecraft:deepslate_tiles
setblock 336 78 -2 minecraft:deepslate_tiles
setblock 320 78 -2 minecraft:light_blue_stained_glass
setblock 304 78 -1 minecraft:deepslate_tiles
setblock 336 78 -1 minecraft:deepslate_tiles
fill 319 78 -1 321 78 -1 minecraft:sea_lantern
setblock 305 78 0 minecraft:light_blue_stained_glass
setblock 318 78 0 minecraft:light_blue_stained_glass
setblock 322 78 0 minecraft:light_blue_stained_glass
setblock 335 78 0 minecraft:light_blue_stained_glass
setblock 304 78 0 minecraft:sea_lantern
fill 319 78 0 321 78 0 minecraft:sea_lantern
setblock 336 78 0 minecraft:sea_lantern
setblock 304 78 1 minecraft:deepslate_tiles
setblock 336 78 1 minecraft:deepslate_tiles
fill 319 78 1 321 78 1 minecraft:sea_lantern
setblock 304 78 2 minecraft:deepslate_tiles
setblock 336 78 2 minecraft:deepslate_tiles
setblock 320 78 2 minecraft:light_blue_stained_glass
setblock 304 78 3 minecraft:deepslate_tiles
setblock 336 78 3 minecraft:deepslate_tiles
setblock 304 78 4 minecraft:deepslate_tiles
setblock 336 78 4 minecraft:deepslate_tiles
setblock 304 78 5 minecraft:deepslate_tiles
setblock 336 78 5 minecraft:deepslate_tiles
setblock 305 78 6 minecraft:light_blue_stained_glass
setblock 335 78 6 minecraft:light_blue_stained_glass
setblock 304 78 6 minecraft:sea_lantern
setblock 336 78 6 minecraft:sea_lantern
setblock 304 78 7 minecraft:deepslate_tiles
setblock 336 78 7 minecraft:deepslate_tiles
setblock 304 78 8 minecraft:deepslate_tiles
setblock 336 78 8 minecraft:deepslate_tiles
setblock 304 78 9 minecraft:deepslate_tiles
setblock 336 78 9 minecraft:deepslate_tiles
setblock 304 78 10 minecraft:deepslate_tiles
setblock 336 78 10 minecraft:deepslate_tiles
setblock 304 78 11 minecraft:deepslate_tiles
setblock 336 78 11 minecraft:deepslate_tiles
setblock 305 78 12 minecraft:light_blue_stained_glass
setblock 335 78 12 minecraft:light_blue_stained_glass
setblock 304 78 12 minecraft:sea_lantern
setblock 336 78 12 minecraft:sea_lantern
setblock 304 78 13 minecraft:deepslate_tiles
setblock 336 78 13 minecraft:deepslate_tiles
setblock 304 78 14 minecraft:deepslate_tiles
setblock 336 78 14 minecraft:deepslate_tiles
setblock 304 78 15 minecraft:deepslate_tiles
setblock 336 78 15 minecraft:deepslate_tiles
setblock 308 78 15 minecraft:light_blue_stained_glass
setblock 314 78 15 minecraft:light_blue_stained_glass
setblock 320 78 15 minecraft:light_blue_stained_glass
setblock 326 78 15 minecraft:light_blue_stained_glass
setblock 332 78 15 minecraft:light_blue_stained_glass
fill 304 78 16 307 78 16 minecraft:deepslate_tiles
fill 309 78 16 313 78 16 minecraft:deepslate_tiles
fill 315 78 16 319 78 16 minecraft:deepslate_tiles
fill 321 78 16 325 78 16 minecraft:deepslate_tiles
fill 327 78 16 331 78 16 minecraft:deepslate_tiles
fill 333 78 16 336 78 16 minecraft:deepslate_tiles
setblock 308 78 16 minecraft:sea_lantern
setblock 314 78 16 minecraft:sea_lantern
setblock 320 78 16 minecraft:sea_lantern
setblock 326 78 16 minecraft:sea_lantern
setblock 332 78 16 minecraft:sea_lantern
fill 304 79 -16 336 79 -16 minecraft:deepslate_tiles
setblock 304 79 -15 minecraft:deepslate_tiles
setblock 336 79 -15 minecraft:deepslate_tiles
setblock 308 79 -15 minecraft:polished_deepslate
setblock 314 79 -15 minecraft:polished_deepslate
setblock 320 79 -15 minecraft:polished_deepslate
setblock 326 79 -15 minecraft:polished_deepslate
setblock 332 79 -15 minecraft:polished_deepslate
setblock 304 79 -14 minecraft:deepslate_tiles
setblock 336 79 -14 minecraft:deepslate_tiles
setblock 304 79 -13 minecraft:deepslate_tiles
setblock 336 79 -13 minecraft:deepslate_tiles
setblock 304 79 -12 minecraft:deepslate_tiles
setblock 336 79 -12 minecraft:deepslate_tiles
setblock 305 79 -12 minecraft:polished_deepslate
setblock 335 79 -12 minecraft:polished_deepslate
setblock 304 79 -11 minecraft:deepslate_tiles
setblock 336 79 -11 minecraft:deepslate_tiles
setblock 304 79 -10 minecraft:deepslate_tiles
setblock 336 79 -10 minecraft:deepslate_tiles
setblock 304 79 -9 minecraft:deepslate_tiles
setblock 336 79 -9 minecraft:deepslate_tiles
setblock 304 79 -8 minecraft:deepslate_tiles
setblock 336 79 -8 minecraft:deepslate_tiles
setblock 304 79 -7 minecraft:deepslate_tiles
setblock 336 79 -7 minecraft:deepslate_tiles
setblock 304 79 -6 minecraft:deepslate_tiles
setblock 336 79 -6 minecraft:deepslate_tiles
setblock 305 79 -6 minecraft:polished_deepslate
setblock 335 79 -6 minecraft:polished_deepslate
setblock 304 79 -5 minecraft:deepslate_tiles
setblock 336 79 -5 minecraft:deepslate_tiles
setblock 304 79 -4 minecraft:deepslate_tiles
setblock 336 79 -4 minecraft:deepslate_tiles
setblock 304 79 -3 minecraft:deepslate_tiles
setblock 336 79 -3 minecraft:deepslate_tiles
setblock 304 79 -2 minecraft:deepslate_tiles
setblock 336 79 -2 minecraft:deepslate_tiles
setblock 320 79 -2 minecraft:light_blue_stained_glass
setblock 304 79 -1 minecraft:deepslate_tiles
setblock 336 79 -1 minecraft:deepslate_tiles
fill 319 79 -1 321 79 -1 minecraft:sea_lantern
setblock 304 79 0 minecraft:deepslate_tiles
setblock 336 79 0 minecraft:deepslate_tiles
setblock 318 79 0 minecraft:light_blue_stained_glass
setblock 322 79 0 minecraft:light_blue_stained_glass
setblock 305 79 0 minecraft:polished_deepslate
setblock 335 79 0 minecraft:polished_deepslate
fill 319 79 0 321 79 0 minecraft:sea_lantern
setblock 304 79 1 minecraft:deepslate_tiles
setblock 336 79 1 minecraft:deepslate_tiles
fill 319 79 1 321 79 1 minecraft:sea_lantern
setblock 304 79 2 minecraft:deepslate_tiles
setblock 336 79 2 minecraft:deepslate_tiles
setblock 320 79 2 minecraft:light_blue_stained_glass
setblock 304 79 3 minecraft:deepslate_tiles
setblock 336 79 3 minecraft:deepslate_tiles
setblock 304 79 4 minecraft:deepslate_tiles
setblock 336 79 4 minecraft:deepslate_tiles
setblock 304 79 5 minecraft:deepslate_tiles
setblock 336 79 5 minecraft:deepslate_tiles
setblock 304 79 6 minecraft:deepslate_tiles
setblock 336 79 6 minecraft:deepslate_tiles
setblock 305 79 6 minecraft:polished_deepslate
setblock 335 79 6 minecraft:polished_deepslate
setblock 304 79 7 minecraft:deepslate_tiles
setblock 336 79 7 minecraft:deepslate_tiles
setblock 304 79 8 minecraft:deepslate_tiles
setblock 336 79 8 minecraft:deepslate_tiles
setblock 304 79 9 minecraft:deepslate_tiles
setblock 336 79 9 minecraft:deepslate_tiles
setblock 304 79 10 minecraft:deepslate_tiles
setblock 336 79 10 minecraft:deepslate_tiles
setblock 304 79 11 minecraft:deepslate_tiles
setblock 336 79 11 minecraft:deepslate_tiles
setblock 304 79 12 minecraft:deepslate_tiles
setblock 336 79 12 minecraft:deepslate_tiles
setblock 305 79 12 minecraft:polished_deepslate
setblock 335 79 12 minecraft:polished_deepslate
setblock 304 79 13 minecraft:deepslate_tiles
setblock 336 79 13 minecraft:deepslate_tiles
setblock 304 79 14 minecraft:deepslate_tiles
setblock 336 79 14 minecraft:deepslate_tiles
setblock 304 79 15 minecraft:deepslate_tiles
setblock 336 79 15 minecraft:deepslate_tiles
setblock 308 79 15 minecraft:polished_deepslate
setblock 314 79 15 minecraft:polished_deepslate
setblock 320 79 15 minecraft:polished_deepslate
setblock 326 79 15 minecraft:polished_deepslate
setblock 332 79 15 minecraft:polished_deepslate
fill 304 79 16 336 79 16 minecraft:deepslate_tiles
fill 304 80 -16 336 80 -16 minecraft:deepslate_tiles
setblock 304 80 -15 minecraft:deepslate_tiles
setblock 336 80 -15 minecraft:deepslate_tiles
fill 305 80 -15 335 80 -15 minecraft:quartz_block
setblock 304 80 -14 minecraft:deepslate_tiles
setblock 336 80 -14 minecraft:deepslate_tiles
setblock 305 80 -14 minecraft:quartz_block
setblock 335 80 -14 minecraft:quartz_block
setblock 304 80 -13 minecraft:deepslate_tiles
setblock 336 80 -13 minecraft:deepslate_tiles
setblock 305 80 -13 minecraft:quartz_block
setblock 335 80 -13 minecraft:quartz_block
setblock 304 80 -12 minecraft:deepslate_tiles
setblock 336 80 -12 minecraft:deepslate_tiles
fill 305 80 -12 306 80 -12 minecraft:quartz_block
fill 334 80 -12 335 80 -12 minecraft:quartz_block
setblock 308 80 -12 minecraft:sea_lantern
setblock 332 80 -12 minecraft:sea_lantern
setblock 304 80 -11 minecraft:deepslate_tiles
setblock 336 80 -11 minecraft:deepslate_tiles
setblock 305 80 -11 minecraft:quartz_block
setblock 335 80 -11 minecraft:quartz_block
setblock 304 80 -10 minecraft:deepslate_tiles
setblock 336 80 -10 minecraft:deepslate_tiles
setblock 305 80 -10 minecraft:quartz_block
setblock 335 80 -10 minecraft:quartz_block
setblock 304 80 -9 minecraft:deepslate_tiles
setblock 336 80 -9 minecraft:deepslate_tiles
setblock 305 80 -9 minecraft:quartz_block
setblock 335 80 -9 minecraft:quartz_block
setblock 304 80 -8 minecraft:deepslate_tiles
setblock 336 80 -8 minecraft:deepslate_tiles
setblock 305 80 -8 minecraft:quartz_block
setblock 335 80 -8 minecraft:quartz_block
setblock 304 80 -7 minecraft:deepslate_tiles
setblock 336 80 -7 minecraft:deepslate_tiles
setblock 305 80 -7 minecraft:quartz_block
setblock 335 80 -7 minecraft:quartz_block
setblock 304 80 -6 minecraft:deepslate_tiles
setblock 336 80 -6 minecraft:deepslate_tiles
setblock 305 80 -6 minecraft:quartz_block
setblock 335 80 -6 minecraft:quartz_block
setblock 304 80 -5 minecraft:deepslate_tiles
setblock 336 80 -5 minecraft:deepslate_tiles
setblock 305 80 -5 minecraft:quartz_block
setblock 335 80 -5 minecraft:quartz_block
setblock 304 80 -4 minecraft:deepslate_tiles
setblock 336 80 -4 minecraft:deepslate_tiles
setblock 305 80 -4 minecraft:quartz_block
setblock 335 80 -4 minecraft:quartz_block
setblock 304 80 -3 minecraft:deepslate_tiles
setblock 336 80 -3 minecraft:deepslate_tiles
setblock 305 80 -3 minecraft:quartz_block
setblock 335 80 -3 minecraft:quartz_block
setblock 304 80 -2 minecraft:deepslate_tiles
setblock 336 80 -2 minecraft:deepslate_tiles
setblock 320 80 -2 minecraft:light_blue_stained_glass
setblock 305 80 -2 minecraft:quartz_block
setblock 335 80 -2 minecraft:quartz_block
setblock 304 80 -1 minecraft:deepslate_tiles
setblock 336 80 -1 minecraft:deepslate_tiles
setblock 305 80 -1 minecraft:quartz_block
setblock 335 80 -1 minecraft:quartz_block
setblock 304 80 0 minecraft:deepslate_tiles
setblock 336 80 0 minecraft:deepslate_tiles
setblock 318 80 0 minecraft:light_blue_stained_glass
setblock 322 80 0 minecraft:light_blue_stained_glass
fill 305 80 0 306 80 0 minecraft:quartz_block
fill 334 80 0 335 80 0 minecraft:quartz_block
setblock 308 80 0 minecraft:sea_lantern
setblock 332 80 0 minecraft:sea_lantern
setblock 304 80 1 minecraft:deepslate_tiles
setblock 336 80 1 minecraft:deepslate_tiles
setblock 305 80 1 minecraft:quartz_block
setblock 335 80 1 minecraft:quartz_block
setblock 304 80 2 minecraft:deepslate_tiles
setblock 336 80 2 minecraft:deepslate_tiles
setblock 320 80 2 minecraft:light_blue_stained_glass
setblock 305 80 2 minecraft:quartz_block
setblock 335 80 2 minecraft:quartz_block
setblock 304 80 3 minecraft:deepslate_tiles
setblock 336 80 3 minecraft:deepslate_tiles
setblock 305 80 3 minecraft:quartz_block
setblock 335 80 3 minecraft:quartz_block
setblock 304 80 4 minecraft:deepslate_tiles
setblock 336 80 4 minecraft:deepslate_tiles
setblock 305 80 4 minecraft:quartz_block
setblock 335 80 4 minecraft:quartz_block
setblock 304 80 5 minecraft:deepslate_tiles
setblock 336 80 5 minecraft:deepslate_tiles
setblock 305 80 5 minecraft:quartz_block
setblock 335 80 5 minecraft:quartz_block
setblock 304 80 6 minecraft:deepslate_tiles
setblock 336 80 6 minecraft:deepslate_tiles
setblock 305 80 6 minecraft:quartz_block
setblock 335 80 6 minecraft:quartz_block
setblock 304 80 7 minecraft:deepslate_tiles
setblock 336 80 7 minecraft:deepslate_tiles
setblock 305 80 7 minecraft:quartz_block
setblock 335 80 7 minecraft:quartz_block
setblock 304 80 8 minecraft:deepslate_tiles
setblock 336 80 8 minecraft:deepslate_tiles
setblock 305 80 8 minecraft:quartz_block
setblock 335 80 8 minecraft:quartz_block
setblock 304 80 9 minecraft:deepslate_tiles
setblock 336 80 9 minecraft:deepslate_tiles
setblock 305 80 9 minecraft:quartz_block
setblock 335 80 9 minecraft:quartz_block
setblock 304 80 10 minecraft:deepslate_tiles
setblock 336 80 10 minecraft:deepslate_tiles
setblock 305 80 10 minecraft:quartz_block
setblock 335 80 10 minecraft:quartz_block
setblock 304 80 11 minecraft:deepslate_tiles
setblock 336 80 11 minecraft:deepslate_tiles
setblock 305 80 11 minecraft:quartz_block
setblock 335 80 11 minecraft:quartz_block
setblock 304 80 12 minecraft:deepslate_tiles
setblock 336 80 12 minecraft:deepslate_tiles
fill 305 80 12 306 80 12 minecraft:quartz_block
fill 334 80 12 335 80 12 minecraft:quartz_block
setblock 308 80 12 minecraft:sea_lantern
setblock 332 80 12 minecraft:sea_lantern
setblock 304 80 13 minecraft:deepslate_tiles
setblock 336 80 13 minecraft:deepslate_tiles
setblock 305 80 13 minecraft:quartz_block
setblock 335 80 13 minecraft:quartz_block
setblock 304 80 14 minecraft:deepslate_tiles
setblock 336 80 14 minecraft:deepslate_tiles
setblock 305 80 14 minecraft:quartz_block
setblock 335 80 14 minecraft:quartz_block
setblock 304 80 15 minecraft:deepslate_tiles
setblock 336 80 15 minecraft:deepslate_tiles
fill 305 80 15 335 80 15 minecraft:quartz_block
fill 304 80 16 336 80 16 minecraft:deepslate_tiles
fill 304 81 -16 336 81 -16 minecraft:deepslate_tiles
setblock 304 81 -15 minecraft:deepslate_tiles
setblock 336 81 -15 minecraft:deepslate_tiles
setblock 308 81 -15 minecraft:quartz_block
setblock 314 81 -15 minecraft:quartz_block
setblock 320 81 -15 minecraft:quartz_block
setblock 326 81 -15 minecraft:quartz_block
setblock 332 81 -15 minecraft:quartz_block
setblock 304 81 -14 minecraft:deepslate_tiles
setblock 336 81 -14 minecraft:deepslate_tiles
setblock 304 81 -13 minecraft:deepslate_tiles
setblock 336 81 -13 minecraft:deepslate_tiles
setblock 304 81 -12 minecraft:deepslate_tiles
setblock 336 81 -12 minecraft:deepslate_tiles
setblock 305 81 -12 minecraft:quartz_block
fill 307 81 -12 309 81 -12 minecraft:quartz_block
fill 331 81 -12 333 81 -12 minecraft:quartz_block
setblock 335 81 -12 minecraft:quartz_block
setblock 314 81 -12 minecraft:sea_lantern
setblock 320 81 -12 minecraft:sea_lantern
setblock 326 81 -12 minecraft:sea_lantern
setblock 304 81 -11 minecraft:deepslate_tiles
setblock 336 81 -11 minecraft:deepslate_tiles
setblock 304 81 -10 minecraft:deepslate_tiles
setblock 336 81 -10 minecraft:deepslate_tiles
setblock 304 81 -9 minecraft:deepslate_tiles
setblock 336 81 -9 minecraft:deepslate_tiles
setblock 304 81 -8 minecraft:deepslate_tiles
setblock 336 81 -8 minecraft:deepslate_tiles
setblock 304 81 -7 minecraft:deepslate_tiles
setblock 336 81 -7 minecraft:deepslate_tiles
setblock 304 81 -6 minecraft:deepslate_tiles
setblock 336 81 -6 minecraft:deepslate_tiles
setblock 305 81 -6 minecraft:quartz_block
setblock 335 81 -6 minecraft:quartz_block
setblock 304 81 -5 minecraft:deepslate_tiles
setblock 336 81 -5 minecraft:deepslate_tiles
setblock 304 81 -4 minecraft:deepslate_tiles
setblock 336 81 -4 minecraft:deepslate_tiles
fill 318 81 -4 322 81 -4 minecraft:quartz_block
setblock 304 81 -3 minecraft:deepslate_tiles
setblock 336 81 -3 minecraft:deepslate_tiles
fill 317 81 -3 319 81 -3 minecraft:quartz_block
fill 321 81 -3 323 81 -3 minecraft:quartz_block
setblock 304 81 -2 minecraft:deepslate_tiles
setblock 336 81 -2 minecraft:deepslate_tiles
fill 316 81 -2 317 81 -2 minecraft:quartz_block
fill 323 81 -2 324 81 -2 minecraft:quartz_block
setblock 304 81 -1 minecraft:deepslate_tiles
setblock 336 81 -1 minecraft:deepslate_tiles
fill 316 81 -1 317 81 -1 minecraft:quartz_block
fill 323 81 -1 324 81 -1 minecraft:quartz_block
setblock 304 81 0 minecraft:deepslate_tiles
setblock 336 81 0 minecraft:deepslate_tiles
setblock 305 81 0 minecraft:quartz_block
fill 307 81 0 309 81 0 minecraft:quartz_block
setblock 316 81 0 minecraft:quartz_block
setblock 324 81 0 minecraft:quartz_block
fill 331 81 0 333 81 0 minecraft:quartz_block
setblock 335 81 0 minecraft:quartz_block
setblock 314 81 0 minecraft:sea_lantern
setblock 320 81 0 minecraft:sea_lantern
setblock 326 81 0 minecraft:sea_lantern
setblock 304 81 1 minecraft:deepslate_tiles
setblock 336 81 1 minecraft:deepslate_tiles
fill 316 81 1 317 81 1 minecraft:quartz_block
fill 323 81 1 324 81 1 minecraft:quartz_block
setblock 304 81 2 minecraft:deepslate_tiles
setblock 336 81 2 minecraft:deepslate_tiles
fill 316 81 2 317 81 2 minecraft:quartz_block
fill 323 81 2 324 81 2 minecraft:quartz_block
setblock 304 81 3 minecraft:deepslate_tiles
setblock 336 81 3 minecraft:deepslate_tiles
fill 317 81 3 319 81 3 minecraft:quartz_block
fill 321 81 3 323 81 3 minecraft:quartz_block
setblock 304 81 4 minecraft:deepslate_tiles
setblock 336 81 4 minecraft:deepslate_tiles
fill 318 81 4 322 81 4 minecraft:quartz_block
setblock 304 81 5 minecraft:deepslate_tiles
setblock 336 81 5 minecraft:deepslate_tiles
setblock 304 81 6 minecraft:deepslate_tiles
setblock 336 81 6 minecraft:deepslate_tiles
setblock 305 81 6 minecraft:quartz_block
setblock 335 81 6 minecraft:quartz_block
setblock 304 81 7 minecraft:deepslate_tiles
setblock 336 81 7 minecraft:deepslate_tiles
setblock 304 81 8 minecraft:deepslate_tiles
setblock 336 81 8 minecraft:deepslate_tiles
setblock 304 81 9 minecraft:deepslate_tiles
setblock 336 81 9 minecraft:deepslate_tiles
setblock 304 81 10 minecraft:deepslate_tiles
setblock 336 81 10 minecraft:deepslate_tiles
setblock 304 81 11 minecraft:deepslate_tiles
setblock 336 81 11 minecraft:deepslate_tiles
setblock 304 81 12 minecraft:deepslate_tiles
setblock 336 81 12 minecraft:deepslate_tiles
setblock 305 81 12 minecraft:quartz_block
fill 307 81 12 309 81 12 minecraft:quartz_block
fill 331 81 12 333 81 12 minecraft:quartz_block
setblock 335 81 12 minecraft:quartz_block
setblock 314 81 12 minecraft:sea_lantern
setblock 320 81 12 minecraft:sea_lantern
setblock 326 81 12 minecraft:sea_lantern
setblock 304 81 13 minecraft:deepslate_tiles
setblock 336 81 13 minecraft:deepslate_tiles
setblock 304 81 14 minecraft:deepslate_tiles
setblock 336 81 14 minecraft:deepslate_tiles
setblock 304 81 15 minecraft:deepslate_tiles
setblock 336 81 15 minecraft:deepslate_tiles
setblock 308 81 15 minecraft:quartz_block
setblock 314 81 15 minecraft:quartz_block
setblock 320 81 15 minecraft:quartz_block
setblock 326 81 15 minecraft:quartz_block
setblock 332 81 15 minecraft:quartz_block
fill 304 81 16 336 81 16 minecraft:deepslate_tiles
fill 304 82 -16 336 82 -16 minecraft:deepslate_tiles
setblock 304 82 -15 minecraft:deepslate_tiles
setblock 336 82 -15 minecraft:deepslate_tiles
setblock 308 82 -15 minecraft:quartz_block
setblock 314 82 -15 minecraft:quartz_block
setblock 320 82 -15 minecraft:quartz_block
setblock 326 82 -15 minecraft:quartz_block
setblock 332 82 -15 minecraft:quartz_block
setblock 304 82 -14 minecraft:deepslate_tiles
setblock 336 82 -14 minecraft:deepslate_tiles
setblock 304 82 -13 minecraft:deepslate_tiles
setblock 336 82 -13 minecraft:deepslate_tiles
setblock 304 82 -12 minecraft:deepslate_tiles
setblock 336 82 -12 minecraft:deepslate_tiles
setblock 305 82 -12 minecraft:quartz_block
fill 310 82 -12 330 82 -12 minecraft:quartz_block
setblock 335 82 -12 minecraft:quartz_block
setblock 304 82 -11 minecraft:deepslate_tiles
setblock 336 82 -11 minecraft:deepslate_tiles
setblock 304 82 -10 minecraft:deepslate_tiles
setblock 336 82 -10 minecraft:deepslate_tiles
setblock 304 82 -9 minecraft:deepslate_tiles
setblock 336 82 -9 minecraft:deepslate_tiles
setblock 304 82 -8 minecraft:deepslate_tiles
setblock 336 82 -8 minecraft:deepslate_tiles
setblock 304 82 -7 minecraft:deepslate_tiles
setblock 336 82 -7 minecraft:deepslate_tiles
setblock 304 82 -6 minecraft:deepslate_tiles
setblock 336 82 -6 minecraft:deepslate_tiles
setblock 305 82 -6 minecraft:quartz_block
setblock 335 82 -6 minecraft:quartz_block
setblock 304 82 -5 minecraft:deepslate_tiles
setblock 336 82 -5 minecraft:deepslate_tiles
setblock 304 82 -4 minecraft:deepslate_tiles
setblock 336 82 -4 minecraft:deepslate_tiles
setblock 304 82 -3 minecraft:deepslate_tiles
setblock 336 82 -3 minecraft:deepslate_tiles
setblock 304 82 -2 minecraft:deepslate_tiles
setblock 336 82 -2 minecraft:deepslate_tiles
setblock 304 82 -1 minecraft:deepslate_tiles
setblock 336 82 -1 minecraft:deepslate_tiles
setblock 304 82 0 minecraft:deepslate_tiles
setblock 336 82 0 minecraft:deepslate_tiles
setblock 305 82 0 minecraft:quartz_block
fill 310 82 0 330 82 0 minecraft:quartz_block
setblock 335 82 0 minecraft:quartz_block
setblock 304 82 1 minecraft:deepslate_tiles
setblock 336 82 1 minecraft:deepslate_tiles
setblock 304 82 2 minecraft:deepslate_tiles
setblock 336 82 2 minecraft:deepslate_tiles
setblock 304 82 3 minecraft:deepslate_tiles
setblock 336 82 3 minecraft:deepslate_tiles
setblock 304 82 4 minecraft:deepslate_tiles
setblock 336 82 4 minecraft:deepslate_tiles
setblock 304 82 5 minecraft:deepslate_tiles
setblock 336 82 5 minecraft:deepslate_tiles
setblock 304 82 6 minecraft:deepslate_tiles
setblock 336 82 6 minecraft:deepslate_tiles
setblock 305 82 6 minecraft:quartz_block
setblock 335 82 6 minecraft:quartz_block
setblock 304 82 7 minecraft:deepslate_tiles
setblock 336 82 7 minecraft:deepslate_tiles
setblock 304 82 8 minecraft:deepslate_tiles
setblock 336 82 8 minecraft:deepslate_tiles
setblock 304 82 9 minecraft:deepslate_tiles
setblock 336 82 9 minecraft:deepslate_tiles
setblock 304 82 10 minecraft:deepslate_tiles
setblock 336 82 10 minecraft:deepslate_tiles
setblock 304 82 11 minecraft:deepslate_tiles
setblock 336 82 11 minecraft:deepslate_tiles
setblock 304 82 12 minecraft:deepslate_tiles
setblock 336 82 12 minecraft:deepslate_tiles
setblock 305 82 12 minecraft:quartz_block
fill 310 82 12 330 82 12 minecraft:quartz_block
setblock 335 82 12 minecraft:quartz_block
setblock 304 82 13 minecraft:deepslate_tiles
setblock 336 82 13 minecraft:deepslate_tiles
setblock 304 82 14 minecraft:deepslate_tiles
setblock 336 82 14 minecraft:deepslate_tiles
setblock 304 82 15 minecraft:deepslate_tiles
setblock 336 82 15 minecraft:deepslate_tiles
setblock 308 82 15 minecraft:quartz_block
setblock 314 82 15 minecraft:quartz_block
setblock 320 82 15 minecraft:quartz_block
setblock 326 82 15 minecraft:quartz_block
setblock 332 82 15 minecraft:quartz_block
fill 304 82 16 336 82 16 minecraft:deepslate_tiles
fill 304 83 -16 336 83 -16 minecraft:deepslate_tiles
setblock 304 83 -15 minecraft:deepslate_tiles
setblock 336 83 -15 minecraft:deepslate_tiles
fill 305 83 -15 335 83 -15 minecraft:quartz_block
setblock 304 83 -14 minecraft:deepslate_tiles
setblock 336 83 -14 minecraft:deepslate_tiles
setblock 305 83 -14 minecraft:quartz_block
setblock 335 83 -14 minecraft:quartz_block
setblock 304 83 -13 minecraft:deepslate_tiles
setblock 336 83 -13 minecraft:deepslate_tiles
setblock 305 83 -13 minecraft:quartz_block
setblock 335 83 -13 minecraft:quartz_block
setblock 304 83 -12 minecraft:deepslate_tiles
setblock 336 83 -12 minecraft:deepslate_tiles
setblock 305 83 -12 minecraft:quartz_block
setblock 335 83 -12 minecraft:quartz_block
setblock 304 83 -11 minecraft:deepslate_tiles
setblock 336 83 -11 minecraft:deepslate_tiles
setblock 305 83 -11 minecraft:quartz_block
setblock 335 83 -11 minecraft:quartz_block
setblock 304 83 -10 minecraft:deepslate_tiles
setblock 336 83 -10 minecraft:deepslate_tiles
setblock 305 83 -10 minecraft:quartz_block
setblock 335 83 -10 minecraft:quartz_block
setblock 304 83 -9 minecraft:deepslate_tiles
setblock 336 83 -9 minecraft:deepslate_tiles
setblock 310 83 -9 minecraft:light_blue_stained_glass
setblock 327 83 -9 minecraft:light_blue_stained_glass
setblock 305 83 -9 minecraft:quartz_block
setblock 335 83 -9 minecraft:quartz_block
setblock 304 83 -8 minecraft:deepslate_tiles
setblock 336 83 -8 minecraft:deepslate_tiles
setblock 317 83 -8 minecraft:light_blue_stained_glass
setblock 305 83 -8 minecraft:quartz_block
setblock 335 83 -8 minecraft:quartz_block
setblock 304 83 -7 minecraft:deepslate_tiles
setblock 336 83 -7 minecraft:deepslate_tiles
setblock 305 83 -7 minecraft:quartz_block
setblock 335 83 -7 minecraft:quartz_block
setblock 304 83 -6 minecraft:deepslate_tiles
setblock 336 83 -6 minecraft:deepslate_tiles
setblock 305 83 -6 minecraft:quartz_block
setblock 335 83 -6 minecraft:quartz_block
setblock 304 83 -5 minecraft:deepslate_tiles
setblock 336 83 -5 minecraft:deepslate_tiles
setblock 305 83 -5 minecraft:quartz_block
setblock 335 83 -5 minecraft:quartz_block
setblock 304 83 -4 minecraft:deepslate_tiles
setblock 336 83 -4 minecraft:deepslate_tiles
setblock 330 83 -4 minecraft:light_blue_stained_glass
setblock 305 83 -4 minecraft:quartz_block
setblock 335 83 -4 minecraft:quartz_block
setblock 304 83 -3 minecraft:deepslate_tiles
setblock 336 83 -3 minecraft:deepslate_tiles
setblock 305 83 -3 minecraft:quartz_block
setblock 335 83 -3 minecraft:quartz_block
setblock 304 83 -2 minecraft:deepslate_tiles
setblock 336 83 -2 minecraft:deepslate_tiles
setblock 305 83 -2 minecraft:quartz_block
setblock 335 83 -2 minecraft:quartz_block
setblock 304 83 -1 minecraft:deepslate_tiles
setblock 336 83 -1 minecraft:deepslate_tiles
setblock 305 83 -1 minecraft:quartz_block
setblock 335 83 -1 minecraft:quartz_block
setblock 304 83 0 minecraft:deepslate_tiles
setblock 336 83 0 minecraft:deepslate_tiles
setblock 305 83 0 minecraft:quartz_block
setblock 335 83 0 minecraft:quartz_block
setblock 304 83 1 minecraft:deepslate_tiles
setblock 336 83 1 minecraft:deepslate_tiles
setblock 305 83 1 minecraft:quartz_block
setblock 335 83 1 minecraft:quartz_block
setblock 304 83 2 minecraft:deepslate_tiles
setblock 336 83 2 minecraft:deepslate_tiles
setblock 305 83 2 minecraft:quartz_block
setblock 335 83 2 minecraft:quartz_block
setblock 304 83 3 minecraft:deepslate_tiles
setblock 336 83 3 minecraft:deepslate_tiles
setblock 305 83 3 minecraft:quartz_block
setblock 335 83 3 minecraft:quartz_block
setblock 304 83 4 minecraft:deepslate_tiles
setblock 336 83 4 minecraft:deepslate_tiles
setblock 323 83 4 minecraft:light_blue_stained_glass
setblock 305 83 4 minecraft:quartz_block
setblock 335 83 4 minecraft:quartz_block
setblock 304 83 5 minecraft:deepslate_tiles
setblock 336 83 5 minecraft:deepslate_tiles
setblock 309 83 5 minecraft:light_blue_stained_glass
setblock 305 83 5 minecraft:quartz_block
setblock 335 83 5 minecraft:quartz_block
setblock 304 83 6 minecraft:deepslate_tiles
setblock 336 83 6 minecraft:deepslate_tiles
setblock 305 83 6 minecraft:quartz_block
setblock 335 83 6 minecraft:quartz_block
setblock 304 83 7 minecraft:deepslate_tiles
setblock 336 83 7 minecraft:deepslate_tiles
setblock 315 83 7 minecraft:light_blue_stained_glass
setblock 305 83 7 minecraft:quartz_block
setblock 335 83 7 minecraft:quartz_block
setblock 304 83 8 minecraft:deepslate_tiles
setblock 336 83 8 minecraft:deepslate_tiles
setblock 305 83 8 minecraft:quartz_block
setblock 335 83 8 minecraft:quartz_block
setblock 304 83 9 minecraft:deepslate_tiles
setblock 336 83 9 minecraft:deepslate_tiles
setblock 305 83 9 minecraft:quartz_block
setblock 335 83 9 minecraft:quartz_block
setblock 304 83 10 minecraft:deepslate_tiles
setblock 336 83 10 minecraft:deepslate_tiles
setblock 329 83 10 minecraft:light_blue_stained_glass
setblock 305 83 10 minecraft:quartz_block
setblock 335 83 10 minecraft:quartz_block
setblock 304 83 11 minecraft:deepslate_tiles
setblock 336 83 11 minecraft:deepslate_tiles
setblock 305 83 11 minecraft:quartz_block
setblock 335 83 11 minecraft:quartz_block
setblock 304 83 12 minecraft:deepslate_tiles
setblock 336 83 12 minecraft:deepslate_tiles
setblock 305 83 12 minecraft:quartz_block
setblock 335 83 12 minecraft:quartz_block
setblock 304 83 13 minecraft:deepslate_tiles
setblock 336 83 13 minecraft:deepslate_tiles
setblock 305 83 13 minecraft:quartz_block
setblock 335 83 13 minecraft:quartz_block
setblock 304 83 14 minecraft:deepslate_tiles
setblock 336 83 14 minecraft:deepslate_tiles
setblock 305 83 14 minecraft:quartz_block
setblock 335 83 14 minecraft:quartz_block
setblock 304 83 15 minecraft:deepslate_tiles
setblock 336 83 15 minecraft:deepslate_tiles
fill 305 83 15 335 83 15 minecraft:quartz_block
fill 304 83 16 336 83 16 minecraft:deepslate_tiles
fill 304 84 -16 336 84 -16 minecraft:black_concrete
fill 304 84 -15 336 84 -15 minecraft:black_concrete
fill 304 84 -14 336 84 -14 minecraft:black_concrete
fill 304 84 -13 336 84 -13 minecraft:black_concrete
fill 304 84 -12 336 84 -12 minecraft:black_concrete
fill 304 84 -11 336 84 -11 minecraft:black_concrete
fill 304 84 -10 336 84 -10 minecraft:black_concrete
fill 304 84 -9 309 84 -9 minecraft:black_concrete
fill 311 84 -9 326 84 -9 minecraft:black_concrete
fill 328 84 -9 336 84 -9 minecraft:black_concrete
setblock 310 84 -9 minecraft:sea_lantern
setblock 327 84 -9 minecraft:sea_lantern
fill 304 84 -8 316 84 -8 minecraft:black_concrete
fill 318 84 -8 336 84 -8 minecraft:black_concrete
setblock 317 84 -8 minecraft:sea_lantern
fill 304 84 -7 336 84 -7 minecraft:black_concrete
fill 304 84 -6 336 84 -6 minecraft:black_concrete
fill 304 84 -5 336 84 -5 minecraft:black_concrete
fill 304 84 -4 329 84 -4 minecraft:black_concrete
fill 331 84 -4 336 84 -4 minecraft:black_concrete
setblock 330 84 -4 minecraft:sea_lantern
fill 304 84 -3 336 84 -3 minecraft:black_concrete
fill 304 84 -2 336 84 -2 minecraft:black_concrete
fill 304 84 -1 336 84 -1 minecraft:black_concrete
fill 304 84 0 336 84 0 minecraft:black_concrete
fill 304 84 1 336 84 1 minecraft:black_concrete
fill 304 84 2 336 84 2 minecraft:black_concrete
fill 304 84 3 336 84 3 minecraft:black_concrete
fill 304 84 4 322 84 4 minecraft:black_concrete
fill 324 84 4 336 84 4 minecraft:black_concrete
setblock 323 84 4 minecraft:sea_lantern
fill 304 84 5 308 84 5 minecraft:black_concrete
fill 310 84 5 336 84 5 minecraft:black_concrete
setblock 309 84 5 minecraft:sea_lantern
fill 304 84 6 336 84 6 minecraft:black_concrete
fill 304 84 7 314 84 7 minecraft:black_concrete
fill 316 84 7 336 84 7 minecraft:black_concrete
setblock 315 84 7 minecraft:sea_lantern
fill 304 84 8 336 84 8 minecraft:black_concrete
fill 304 84 9 336 84 9 minecraft:black_concrete
fill 304 84 10 328 84 10 minecraft:black_concrete
fill 330 84 10 336 84 10 minecraft:black_concrete
setblock 329 84 10 minecraft:sea_lantern
fill 304 84 11 336 84 11 minecraft:black_concrete
fill 304 84 12 336 84 12 minecraft:black_concrete
fill 304 84 13 336 84 13 minecraft:black_concrete
fill 304 84 14 336 84 14 minecraft:black_concrete
fill 304 84 15 336 84 15 minecraft:black_concrete
fill 304 84 16 336 84 16 minecraft:black_concrete
function signal:world/decorate
