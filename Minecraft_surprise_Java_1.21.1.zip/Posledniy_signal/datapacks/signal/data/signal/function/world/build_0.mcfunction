fill -16 55 -16 16 84 16 minecraft:air
fill -16 61 -16 16 61 -16 minecraft:bedrock
fill -16 61 -15 16 61 -15 minecraft:bedrock
fill -16 61 -14 16 61 -14 minecraft:bedrock
fill -16 61 -13 16 61 -13 minecraft:bedrock
fill -16 61 -12 16 61 -12 minecraft:bedrock
fill -16 61 -11 16 61 -11 minecraft:bedrock
fill -16 61 -10 16 61 -10 minecraft:bedrock
fill -16 61 -9 16 61 -9 minecraft:bedrock
fill -16 61 -8 16 61 -8 minecraft:bedrock
fill -16 61 -7 16 61 -7 minecraft:bedrock
fill -16 61 -6 16 61 -6 minecraft:bedrock
fill -16 61 -5 16 61 -5 minecraft:bedrock
fill -16 61 -4 16 61 -4 minecraft:bedrock
fill -16 61 -3 16 61 -3 minecraft:bedrock
fill -16 61 -2 16 61 -2 minecraft:bedrock
fill -16 61 -1 16 61 -1 minecraft:bedrock
fill -16 61 0 16 61 0 minecraft:bedrock
fill -16 61 1 16 61 1 minecraft:bedrock
fill -16 61 2 16 61 2 minecraft:bedrock
fill -16 61 3 16 61 3 minecraft:bedrock
fill -16 61 4 16 61 4 minecraft:bedrock
fill -16 61 5 16 61 5 minecraft:bedrock
fill -16 61 6 16 61 6 minecraft:bedrock
fill -16 61 7 16 61 7 minecraft:bedrock
fill -16 61 8 16 61 8 minecraft:bedrock
fill -16 61 9 16 61 9 minecraft:bedrock
fill -16 61 10 16 61 10 minecraft:bedrock
fill -16 61 11 16 61 11 minecraft:bedrock
fill -16 61 12 16 61 12 minecraft:bedrock
fill -16 61 13 16 61 13 minecraft:bedrock
fill -16 61 14 16 61 14 minecraft:bedrock
fill -16 61 15 16 61 15 minecraft:bedrock
fill -16 61 16 16 61 16 minecraft:bedrock
fill -16 62 -16 16 62 -16 minecraft:bedrock
fill -16 62 -15 16 62 -15 minecraft:bedrock
fill -16 62 -14 16 62 -14 minecraft:bedrock
fill -16 62 -13 16 62 -13 minecraft:bedrock
fill -16 62 -12 16 62 -12 minecraft:bedrock
fill -16 62 -11 16 62 -11 minecraft:bedrock
fill -16 62 -10 16 62 -10 minecraft:bedrock
fill -16 62 -9 16 62 -9 minecraft:bedrock
fill -16 62 -8 16 62 -8 minecraft:bedrock
fill -16 62 -7 16 62 -7 minecraft:bedrock
fill -16 62 -6 16 62 -6 minecraft:bedrock
fill -16 62 -5 16 62 -5 minecraft:bedrock
fill -16 62 -4 16 62 -4 minecraft:bedrock
fill -16 62 -3 16 62 -3 minecraft:bedrock
fill -16 62 -2 16 62 -2 minecraft:bedrock
fill -16 62 -1 16 62 -1 minecraft:bedrock
fill -16 62 0 16 62 0 minecraft:bedrock
fill -16 62 1 16 62 1 minecraft:bedrock
fill -16 62 2 16 62 2 minecraft:bedrock
fill -16 62 3 16 62 3 minecraft:bedrock
fill -16 62 4 16 62 4 minecraft:bedrock
fill -16 62 5 16 62 5 minecraft:bedrock
fill -16 62 6 16 62 6 minecraft:bedrock
fill -16 62 7 16 62 7 minecraft:bedrock
fill -16 62 8 16 62 8 minecraft:bedrock
fill -16 62 9 16 62 9 minecraft:bedrock
fill -16 62 10 16 62 10 minecraft:bedrock
fill -16 62 11 16 62 11 minecraft:bedrock
fill -16 62 12 16 62 12 minecraft:bedrock
fill -16 62 13 16 62 13 minecraft:bedrock
fill -16 62 14 16 62 14 minecraft:bedrock
fill -16 62 15 16 62 15 minecraft:bedrock
fill -16 62 16 16 62 16 minecraft:bedrock
fill -16 63 -16 16 63 -16 minecraft:deepslate_tiles
setblock -16 63 -15 minecraft:deepslate_tiles
setblock 16 63 -15 minecraft:deepslate_tiles
fill -15 63 -15 15 63 -15 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -14 minecraft:deepslate_tiles
setblock 16 63 -14 minecraft:deepslate_tiles
fill -14 63 -14 -2 63 -14 minecraft:polished_deepslate
fill 2 63 -14 14 63 -14 minecraft:polished_deepslate
fill -1 63 -14 1 63 -14 minecraft:quartz_block
setblock -15 63 -14 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -14 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -13 minecraft:deepslate_tiles
setblock -13 63 -13 minecraft:deepslate_tiles
setblock -11 63 -13 minecraft:deepslate_tiles
setblock -9 63 -13 minecraft:deepslate_tiles
setblock -7 63 -13 minecraft:deepslate_tiles
setblock -5 63 -13 minecraft:deepslate_tiles
setblock -3 63 -13 minecraft:deepslate_tiles
setblock 3 63 -13 minecraft:deepslate_tiles
setblock 5 63 -13 minecraft:deepslate_tiles
setblock 7 63 -13 minecraft:deepslate_tiles
setblock 9 63 -13 minecraft:deepslate_tiles
setblock 11 63 -13 minecraft:deepslate_tiles
setblock 13 63 -13 minecraft:deepslate_tiles
setblock 16 63 -13 minecraft:deepslate_tiles
setblock -14 63 -13 minecraft:polished_deepslate
setblock -12 63 -13 minecraft:polished_deepslate
setblock -10 63 -13 minecraft:polished_deepslate
setblock -8 63 -13 minecraft:polished_deepslate
setblock -6 63 -13 minecraft:polished_deepslate
setblock -4 63 -13 minecraft:polished_deepslate
setblock -2 63 -13 minecraft:polished_deepslate
setblock 2 63 -13 minecraft:polished_deepslate
setblock 4 63 -13 minecraft:polished_deepslate
setblock 6 63 -13 minecraft:polished_deepslate
setblock 8 63 -13 minecraft:polished_deepslate
setblock 10 63 -13 minecraft:polished_deepslate
setblock 12 63 -13 minecraft:polished_deepslate
setblock 14 63 -13 minecraft:polished_deepslate
fill -1 63 -13 1 63 -13 minecraft:quartz_block
setblock -15 63 -13 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -13 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -12 minecraft:deepslate_tiles
setblock -12 63 -12 minecraft:deepslate_tiles
setblock -10 63 -12 minecraft:deepslate_tiles
setblock -8 63 -12 minecraft:deepslate_tiles
setblock -6 63 -12 minecraft:deepslate_tiles
setblock -4 63 -12 minecraft:deepslate_tiles
setblock 4 63 -12 minecraft:deepslate_tiles
setblock 6 63 -12 minecraft:deepslate_tiles
setblock 8 63 -12 minecraft:deepslate_tiles
setblock 10 63 -12 minecraft:deepslate_tiles
setblock 12 63 -12 minecraft:deepslate_tiles
setblock 16 63 -12 minecraft:deepslate_tiles
fill -14 63 -12 -13 63 -12 minecraft:polished_deepslate
setblock -9 63 -12 minecraft:polished_deepslate
setblock -7 63 -12 minecraft:polished_deepslate
setblock -5 63 -12 minecraft:polished_deepslate
setblock 5 63 -12 minecraft:polished_deepslate
setblock 7 63 -12 minecraft:polished_deepslate
setblock 9 63 -12 minecraft:polished_deepslate
fill 13 63 -12 14 63 -12 minecraft:polished_deepslate
fill -1 63 -12 1 63 -12 minecraft:quartz_block
setblock -15 63 -12 minecraft:waxed_oxidized_cut_copper
setblock -11 63 -12 minecraft:waxed_oxidized_cut_copper
fill -3 63 -12 -2 63 -12 minecraft:waxed_oxidized_cut_copper
fill 2 63 -12 3 63 -12 minecraft:waxed_oxidized_cut_copper
setblock 11 63 -12 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -12 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -11 minecraft:deepslate_tiles
setblock -13 63 -11 minecraft:deepslate_tiles
setblock -9 63 -11 minecraft:deepslate_tiles
setblock -7 63 -11 minecraft:deepslate_tiles
setblock -3 63 -11 minecraft:deepslate_tiles
setblock -1 63 -11 minecraft:deepslate_tiles
setblock 1 63 -11 minecraft:deepslate_tiles
setblock 3 63 -11 minecraft:deepslate_tiles
setblock 7 63 -11 minecraft:deepslate_tiles
setblock 9 63 -11 minecraft:deepslate_tiles
setblock 13 63 -11 minecraft:deepslate_tiles
setblock 16 63 -11 minecraft:deepslate_tiles
setblock -14 63 -11 minecraft:polished_deepslate
setblock -8 63 -11 minecraft:polished_deepslate
setblock -6 63 -11 minecraft:polished_deepslate
setblock -2 63 -11 minecraft:polished_deepslate
setblock 0 63 -11 minecraft:polished_deepslate
setblock 2 63 -11 minecraft:polished_deepslate
setblock 6 63 -11 minecraft:polished_deepslate
setblock 8 63 -11 minecraft:polished_deepslate
setblock 14 63 -11 minecraft:polished_deepslate
setblock -11 63 -11 minecraft:sea_lantern
setblock 11 63 -11 minecraft:sea_lantern
setblock -15 63 -11 minecraft:waxed_oxidized_cut_copper
setblock -12 63 -11 minecraft:waxed_oxidized_cut_copper
setblock -10 63 -11 minecraft:waxed_oxidized_cut_copper
fill -5 63 -11 -4 63 -11 minecraft:waxed_oxidized_cut_copper
fill 4 63 -11 5 63 -11 minecraft:waxed_oxidized_cut_copper
setblock 10 63 -11 minecraft:waxed_oxidized_cut_copper
setblock 12 63 -11 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -11 minecraft:waxed_oxidized_cut_copper
setblock -10 63 -10 minecraft:chiseled_deepslate
setblock -5 63 -10 minecraft:chiseled_deepslate
setblock 5 63 -10 minecraft:chiseled_deepslate
setblock 10 63 -10 minecraft:chiseled_deepslate
setblock -16 63 -10 minecraft:deepslate_tiles
setblock -12 63 -10 minecraft:deepslate_tiles
setblock -8 63 -10 minecraft:deepslate_tiles
setblock -4 63 -10 minecraft:deepslate_tiles
setblock -2 63 -10 minecraft:deepslate_tiles
setblock 2 63 -10 minecraft:deepslate_tiles
setblock 4 63 -10 minecraft:deepslate_tiles
setblock 8 63 -10 minecraft:deepslate_tiles
setblock 12 63 -10 minecraft:deepslate_tiles
setblock 16 63 -10 minecraft:deepslate_tiles
fill -14 63 -10 -13 63 -10 minecraft:polished_deepslate
setblock -9 63 -10 minecraft:polished_deepslate
setblock -3 63 -10 minecraft:polished_deepslate
setblock -1 63 -10 minecraft:polished_deepslate
setblock 1 63 -10 minecraft:polished_deepslate
setblock 3 63 -10 minecraft:polished_deepslate
setblock 9 63 -10 minecraft:polished_deepslate
fill 13 63 -10 14 63 -10 minecraft:polished_deepslate
setblock 0 63 -10 minecraft:waxed_cut_copper
setblock -15 63 -10 minecraft:waxed_oxidized_cut_copper
setblock -11 63 -10 minecraft:waxed_oxidized_cut_copper
fill -7 63 -10 -6 63 -10 minecraft:waxed_oxidized_cut_copper
fill 6 63 -10 7 63 -10 minecraft:waxed_oxidized_cut_copper
setblock 11 63 -10 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -10 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -9 minecraft:deepslate_tiles
setblock -13 63 -9 minecraft:deepslate_tiles
setblock -11 63 -9 minecraft:deepslate_tiles
setblock -9 63 -9 minecraft:deepslate_tiles
setblock -7 63 -9 minecraft:deepslate_tiles
setblock -5 63 -9 minecraft:deepslate_tiles
setblock -3 63 -9 minecraft:deepslate_tiles
setblock -1 63 -9 minecraft:deepslate_tiles
setblock 1 63 -9 minecraft:deepslate_tiles
setblock 3 63 -9 minecraft:deepslate_tiles
setblock 5 63 -9 minecraft:deepslate_tiles
setblock 7 63 -9 minecraft:deepslate_tiles
setblock 9 63 -9 minecraft:deepslate_tiles
setblock 11 63 -9 minecraft:deepslate_tiles
setblock 13 63 -9 minecraft:deepslate_tiles
setblock 16 63 -9 minecraft:deepslate_tiles
setblock -14 63 -9 minecraft:polished_deepslate
setblock -12 63 -9 minecraft:polished_deepslate
setblock -10 63 -9 minecraft:polished_deepslate
setblock -6 63 -9 minecraft:polished_deepslate
setblock -4 63 -9 minecraft:polished_deepslate
setblock -2 63 -9 minecraft:polished_deepslate
setblock 2 63 -9 minecraft:polished_deepslate
setblock 4 63 -9 minecraft:polished_deepslate
setblock 6 63 -9 minecraft:polished_deepslate
setblock 10 63 -9 minecraft:polished_deepslate
setblock 12 63 -9 minecraft:polished_deepslate
setblock 14 63 -9 minecraft:polished_deepslate
setblock 0 63 -9 minecraft:waxed_cut_copper
setblock -15 63 -9 minecraft:waxed_oxidized_cut_copper
setblock -8 63 -9 minecraft:waxed_oxidized_cut_copper
setblock 8 63 -9 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -9 minecraft:waxed_oxidized_cut_copper
fill -10 63 -8 -9 63 -8 minecraft:cyan_concrete
setblock -16 63 -8 minecraft:deepslate_tiles
setblock -12 63 -8 minecraft:deepslate_tiles
setblock -8 63 -8 minecraft:deepslate_tiles
setblock -6 63 -8 minecraft:deepslate_tiles
setblock -4 63 -8 minecraft:deepslate_tiles
setblock 2 63 -8 minecraft:deepslate_tiles
setblock 6 63 -8 minecraft:deepslate_tiles
setblock 8 63 -8 minecraft:deepslate_tiles
setblock 10 63 -8 minecraft:deepslate_tiles
setblock 16 63 -8 minecraft:deepslate_tiles
fill 4 63 -8 5 63 -8 minecraft:orange_concrete
fill -14 63 -8 -13 63 -8 minecraft:polished_deepslate
setblock -11 63 -8 minecraft:polished_deepslate
setblock -7 63 -8 minecraft:polished_deepslate
setblock -5 63 -8 minecraft:polished_deepslate
setblock -1 63 -8 minecraft:polished_deepslate
setblock 1 63 -8 minecraft:polished_deepslate
setblock 3 63 -8 minecraft:polished_deepslate
setblock 7 63 -8 minecraft:polished_deepslate
fill 13 63 -8 14 63 -8 minecraft:polished_deepslate
fill -3 63 -8 -2 63 -8 minecraft:purple_concrete
fill 11 63 -8 12 63 -8 minecraft:red_concrete
setblock 0 63 -8 minecraft:waxed_cut_copper
setblock -15 63 -8 minecraft:waxed_oxidized_cut_copper
setblock 9 63 -8 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -8 minecraft:waxed_oxidized_cut_copper
fill -10 63 -7 -9 63 -7 minecraft:cyan_concrete
setblock -16 63 -7 minecraft:deepslate_tiles
setblock -13 63 -7 minecraft:deepslate_tiles
setblock -11 63 -7 minecraft:deepslate_tiles
setblock -7 63 -7 minecraft:deepslate_tiles
setblock -5 63 -7 minecraft:deepslate_tiles
setblock 3 63 -7 minecraft:deepslate_tiles
setblock 7 63 -7 minecraft:deepslate_tiles
setblock 9 63 -7 minecraft:deepslate_tiles
setblock 13 63 -7 minecraft:deepslate_tiles
setblock 16 63 -7 minecraft:deepslate_tiles
fill 4 63 -7 5 63 -7 minecraft:orange_concrete
setblock -14 63 -7 minecraft:polished_deepslate
setblock -12 63 -7 minecraft:polished_deepslate
setblock -8 63 -7 minecraft:polished_deepslate
setblock -6 63 -7 minecraft:polished_deepslate
setblock -4 63 -7 minecraft:polished_deepslate
setblock 6 63 -7 minecraft:polished_deepslate
setblock 8 63 -7 minecraft:polished_deepslate
setblock 14 63 -7 minecraft:polished_deepslate
fill -3 63 -7 -2 63 -7 minecraft:purple_concrete
fill 11 63 -7 12 63 -7 minecraft:red_concrete
setblock 0 63 -7 minecraft:sea_lantern
setblock -15 63 -7 minecraft:waxed_oxidized_cut_copper
setblock -1 63 -7 minecraft:waxed_oxidized_cut_copper
fill 1 63 -7 2 63 -7 minecraft:waxed_oxidized_cut_copper
setblock 10 63 -7 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -7 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -6 minecraft:deepslate_tiles
setblock -12 63 -6 minecraft:deepslate_tiles
setblock -8 63 -6 minecraft:deepslate_tiles
setblock -6 63 -6 minecraft:deepslate_tiles
setblock -2 63 -6 minecraft:deepslate_tiles
setblock 2 63 -6 minecraft:deepslate_tiles
setblock 6 63 -6 minecraft:deepslate_tiles
setblock 8 63 -6 minecraft:deepslate_tiles
setblock 12 63 -6 minecraft:deepslate_tiles
setblock 16 63 -6 minecraft:deepslate_tiles
fill -14 63 -6 -13 63 -6 minecraft:polished_deepslate
setblock -11 63 -6 minecraft:polished_deepslate
setblock -9 63 -6 minecraft:polished_deepslate
setblock -7 63 -6 minecraft:polished_deepslate
setblock -5 63 -6 minecraft:polished_deepslate
setblock -1 63 -6 minecraft:polished_deepslate
setblock 1 63 -6 minecraft:polished_deepslate
setblock 5 63 -6 minecraft:polished_deepslate
setblock 7 63 -6 minecraft:polished_deepslate
setblock 9 63 -6 minecraft:polished_deepslate
setblock 11 63 -6 minecraft:polished_deepslate
fill 13 63 -6 14 63 -6 minecraft:polished_deepslate
setblock 0 63 -6 minecraft:waxed_cut_copper
setblock -15 63 -6 minecraft:waxed_oxidized_cut_copper
setblock -10 63 -6 minecraft:waxed_oxidized_cut_copper
fill -4 63 -6 -3 63 -6 minecraft:waxed_oxidized_cut_copper
fill 3 63 -6 4 63 -6 minecraft:waxed_oxidized_cut_copper
setblock 10 63 -6 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -6 minecraft:waxed_oxidized_cut_copper
setblock -10 63 -5 minecraft:chiseled_deepslate
setblock 10 63 -5 minecraft:chiseled_deepslate
setblock -16 63 -5 minecraft:deepslate_tiles
setblock -13 63 -5 minecraft:deepslate_tiles
setblock -9 63 -5 minecraft:deepslate_tiles
setblock -7 63 -5 minecraft:deepslate_tiles
setblock -3 63 -5 minecraft:deepslate_tiles
setblock 3 63 -5 minecraft:deepslate_tiles
setblock 7 63 -5 minecraft:deepslate_tiles
setblock 9 63 -5 minecraft:deepslate_tiles
setblock 13 63 -5 minecraft:deepslate_tiles
setblock 16 63 -5 minecraft:deepslate_tiles
setblock -14 63 -5 minecraft:polished_deepslate
setblock -12 63 -5 minecraft:polished_deepslate
setblock -8 63 -5 minecraft:polished_deepslate
setblock -6 63 -5 minecraft:polished_deepslate
setblock -2 63 -5 minecraft:polished_deepslate
setblock 2 63 -5 minecraft:polished_deepslate
setblock 6 63 -5 minecraft:polished_deepslate
setblock 8 63 -5 minecraft:polished_deepslate
setblock 12 63 -5 minecraft:polished_deepslate
setblock 14 63 -5 minecraft:polished_deepslate
setblock 0 63 -5 minecraft:waxed_cut_copper
setblock -15 63 -5 minecraft:waxed_oxidized_cut_copper
setblock -11 63 -5 minecraft:waxed_oxidized_cut_copper
fill -5 63 -5 -4 63 -5 minecraft:waxed_oxidized_cut_copper
setblock -1 63 -5 minecraft:waxed_oxidized_cut_copper
setblock 1 63 -5 minecraft:waxed_oxidized_cut_copper
fill 4 63 -5 5 63 -5 minecraft:waxed_oxidized_cut_copper
setblock 11 63 -5 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -5 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -4 minecraft:deepslate_tiles
setblock -12 63 -4 minecraft:deepslate_tiles
setblock -10 63 -4 minecraft:deepslate_tiles
setblock -8 63 -4 minecraft:deepslate_tiles
setblock -4 63 -4 minecraft:deepslate_tiles
setblock -2 63 -4 minecraft:deepslate_tiles
setblock 2 63 -4 minecraft:deepslate_tiles
setblock 4 63 -4 minecraft:deepslate_tiles
setblock 8 63 -4 minecraft:deepslate_tiles
setblock 10 63 -4 minecraft:deepslate_tiles
setblock 12 63 -4 minecraft:deepslate_tiles
setblock 16 63 -4 minecraft:deepslate_tiles
fill -14 63 -4 -13 63 -4 minecraft:polished_deepslate
setblock -9 63 -4 minecraft:polished_deepslate
setblock -7 63 -4 minecraft:polished_deepslate
setblock -3 63 -4 minecraft:polished_deepslate
setblock -1 63 -4 minecraft:polished_deepslate
setblock 1 63 -4 minecraft:polished_deepslate
setblock 3 63 -4 minecraft:polished_deepslate
setblock 7 63 -4 minecraft:polished_deepslate
setblock 9 63 -4 minecraft:polished_deepslate
fill 13 63 -4 14 63 -4 minecraft:polished_deepslate
setblock 0 63 -4 minecraft:waxed_cut_copper
setblock -15 63 -4 minecraft:waxed_oxidized_cut_copper
setblock -11 63 -4 minecraft:waxed_oxidized_cut_copper
fill -6 63 -4 -5 63 -4 minecraft:waxed_oxidized_cut_copper
fill 5 63 -4 6 63 -4 minecraft:waxed_oxidized_cut_copper
setblock 11 63 -4 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -4 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -3 minecraft:deepslate_tiles
setblock -13 63 -3 minecraft:deepslate_tiles
setblock -11 63 -3 minecraft:deepslate_tiles
setblock -9 63 -3 minecraft:deepslate_tiles
setblock -7 63 -3 minecraft:deepslate_tiles
setblock -5 63 -3 minecraft:deepslate_tiles
setblock -3 63 -3 minecraft:deepslate_tiles
setblock -1 63 -3 minecraft:deepslate_tiles
setblock 1 63 -3 minecraft:deepslate_tiles
setblock 3 63 -3 minecraft:deepslate_tiles
setblock 5 63 -3 minecraft:deepslate_tiles
setblock 7 63 -3 minecraft:deepslate_tiles
setblock 9 63 -3 minecraft:deepslate_tiles
setblock 11 63 -3 minecraft:deepslate_tiles
setblock 13 63 -3 minecraft:deepslate_tiles
setblock 16 63 -3 minecraft:deepslate_tiles
setblock -14 63 -3 minecraft:polished_deepslate
setblock -10 63 -3 minecraft:polished_deepslate
setblock -8 63 -3 minecraft:polished_deepslate
setblock -4 63 -3 minecraft:polished_deepslate
setblock -2 63 -3 minecraft:polished_deepslate
setblock 2 63 -3 minecraft:polished_deepslate
setblock 4 63 -3 minecraft:polished_deepslate
setblock 8 63 -3 minecraft:polished_deepslate
setblock 10 63 -3 minecraft:polished_deepslate
setblock 14 63 -3 minecraft:polished_deepslate
setblock 0 63 -3 minecraft:waxed_cut_copper
setblock -15 63 -3 minecraft:waxed_oxidized_cut_copper
setblock -12 63 -3 minecraft:waxed_oxidized_cut_copper
setblock -6 63 -3 minecraft:waxed_oxidized_cut_copper
setblock 6 63 -3 minecraft:waxed_oxidized_cut_copper
setblock 12 63 -3 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -3 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -2 minecraft:deepslate_tiles
setblock -10 63 -2 minecraft:deepslate_tiles
setblock -8 63 -2 minecraft:deepslate_tiles
setblock -6 63 -2 minecraft:deepslate_tiles
setblock -4 63 -2 minecraft:deepslate_tiles
setblock -2 63 -2 minecraft:deepslate_tiles
setblock 2 63 -2 minecraft:deepslate_tiles
setblock 4 63 -2 minecraft:deepslate_tiles
setblock 6 63 -2 minecraft:deepslate_tiles
setblock 8 63 -2 minecraft:deepslate_tiles
setblock 10 63 -2 minecraft:deepslate_tiles
setblock 16 63 -2 minecraft:deepslate_tiles
fill -14 63 -2 -13 63 -2 minecraft:polished_deepslate
setblock -11 63 -2 minecraft:polished_deepslate
setblock -9 63 -2 minecraft:polished_deepslate
setblock -5 63 -2 minecraft:polished_deepslate
setblock -3 63 -2 minecraft:polished_deepslate
setblock -1 63 -2 minecraft:polished_deepslate
setblock 1 63 -2 minecraft:polished_deepslate
setblock 3 63 -2 minecraft:polished_deepslate
setblock 5 63 -2 minecraft:polished_deepslate
setblock 9 63 -2 minecraft:polished_deepslate
setblock 11 63 -2 minecraft:polished_deepslate
fill 13 63 -2 14 63 -2 minecraft:polished_deepslate
setblock 0 63 -2 minecraft:waxed_cut_copper
setblock -15 63 -2 minecraft:waxed_oxidized_cut_copper
setblock -12 63 -2 minecraft:waxed_oxidized_cut_copper
setblock -7 63 -2 minecraft:waxed_oxidized_cut_copper
setblock 7 63 -2 minecraft:waxed_oxidized_cut_copper
setblock 12 63 -2 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -2 minecraft:waxed_oxidized_cut_copper
setblock -16 63 -1 minecraft:deepslate_tiles
setblock -13 63 -1 minecraft:deepslate_tiles
setblock -11 63 -1 minecraft:deepslate_tiles
setblock -9 63 -1 minecraft:deepslate_tiles
setblock -5 63 -1 minecraft:deepslate_tiles
setblock -3 63 -1 minecraft:deepslate_tiles
setblock -1 63 -1 minecraft:deepslate_tiles
setblock 1 63 -1 minecraft:deepslate_tiles
setblock 3 63 -1 minecraft:deepslate_tiles
setblock 5 63 -1 minecraft:deepslate_tiles
setblock 9 63 -1 minecraft:deepslate_tiles
setblock 11 63 -1 minecraft:deepslate_tiles
setblock 13 63 -1 minecraft:deepslate_tiles
setblock 16 63 -1 minecraft:deepslate_tiles
setblock -14 63 -1 minecraft:polished_deepslate
setblock -10 63 -1 minecraft:polished_deepslate
setblock -8 63 -1 minecraft:polished_deepslate
setblock -6 63 -1 minecraft:polished_deepslate
setblock -4 63 -1 minecraft:polished_deepslate
setblock -2 63 -1 minecraft:polished_deepslate
setblock 2 63 -1 minecraft:polished_deepslate
setblock 4 63 -1 minecraft:polished_deepslate
setblock 6 63 -1 minecraft:polished_deepslate
setblock 8 63 -1 minecraft:polished_deepslate
setblock 10 63 -1 minecraft:polished_deepslate
setblock 14 63 -1 minecraft:polished_deepslate
setblock 0 63 -1 minecraft:waxed_cut_copper
setblock -15 63 -1 minecraft:waxed_oxidized_cut_copper
setblock -12 63 -1 minecraft:waxed_oxidized_cut_copper
setblock -7 63 -1 minecraft:waxed_oxidized_cut_copper
setblock 7 63 -1 minecraft:waxed_oxidized_cut_copper
setblock 12 63 -1 minecraft:waxed_oxidized_cut_copper
setblock 15 63 -1 minecraft:waxed_oxidized_cut_copper
setblock -16 63 0 minecraft:deepslate_tiles
setblock 16 63 0 minecraft:deepslate_tiles
fill -14 63 0 -13 63 0 minecraft:polished_deepslate
setblock -11 63 0 minecraft:polished_deepslate
setblock 11 63 0 minecraft:polished_deepslate
fill 13 63 0 14 63 0 minecraft:polished_deepslate
setblock -7 63 0 minecraft:sea_lantern
setblock 0 63 0 minecraft:sea_lantern
setblock 7 63 0 minecraft:sea_lantern
fill -10 63 0 -8 63 0 minecraft:waxed_cut_copper
fill -6 63 0 -1 63 0 minecraft:waxed_cut_copper
fill 1 63 0 6 63 0 minecraft:waxed_cut_copper
fill 8 63 0 10 63 0 minecraft:waxed_cut_copper
setblock -15 63 0 minecraft:waxed_oxidized_cut_copper
setblock -12 63 0 minecraft:waxed_oxidized_cut_copper
setblock 12 63 0 minecraft:waxed_oxidized_cut_copper
setblock 15 63 0 minecraft:waxed_oxidized_cut_copper
setblock -16 63 1 minecraft:deepslate_tiles
setblock -13 63 1 minecraft:deepslate_tiles
setblock -11 63 1 minecraft:deepslate_tiles
setblock -9 63 1 minecraft:deepslate_tiles
setblock -5 63 1 minecraft:deepslate_tiles
setblock -3 63 1 minecraft:deepslate_tiles
setblock -1 63 1 minecraft:deepslate_tiles
setblock 1 63 1 minecraft:deepslate_tiles
setblock 3 63 1 minecraft:deepslate_tiles
setblock 5 63 1 minecraft:deepslate_tiles
setblock 9 63 1 minecraft:deepslate_tiles
setblock 11 63 1 minecraft:deepslate_tiles
setblock 13 63 1 minecraft:deepslate_tiles
setblock 16 63 1 minecraft:deepslate_tiles
setblock -14 63 1 minecraft:polished_deepslate
setblock -10 63 1 minecraft:polished_deepslate
setblock -8 63 1 minecraft:polished_deepslate
setblock -6 63 1 minecraft:polished_deepslate
setblock -4 63 1 minecraft:polished_deepslate
setblock -2 63 1 minecraft:polished_deepslate
setblock 2 63 1 minecraft:polished_deepslate
setblock 4 63 1 minecraft:polished_deepslate
setblock 6 63 1 minecraft:polished_deepslate
setblock 8 63 1 minecraft:polished_deepslate
setblock 10 63 1 minecraft:polished_deepslate
setblock 14 63 1 minecraft:polished_deepslate
setblock 0 63 1 minecraft:waxed_cut_copper
setblock -15 63 1 minecraft:waxed_oxidized_cut_copper
setblock -12 63 1 minecraft:waxed_oxidized_cut_copper
setblock -7 63 1 minecraft:waxed_oxidized_cut_copper
setblock 7 63 1 minecraft:waxed_oxidized_cut_copper
setblock 12 63 1 minecraft:waxed_oxidized_cut_copper
setblock 15 63 1 minecraft:waxed_oxidized_cut_copper
setblock -16 63 2 minecraft:deepslate_tiles
setblock -10 63 2 minecraft:deepslate_tiles
setblock -8 63 2 minecraft:deepslate_tiles
setblock -6 63 2 minecraft:deepslate_tiles
setblock -4 63 2 minecraft:deepslate_tiles
setblock -2 63 2 minecraft:deepslate_tiles
setblock 2 63 2 minecraft:deepslate_tiles
setblock 4 63 2 minecraft:deepslate_tiles
setblock 6 63 2 minecraft:deepslate_tiles
setblock 8 63 2 minecraft:deepslate_tiles
setblock 10 63 2 minecraft:deepslate_tiles
setblock 16 63 2 minecraft:deepslate_tiles
fill -14 63 2 -13 63 2 minecraft:polished_deepslate
setblock -11 63 2 minecraft:polished_deepslate
setblock -9 63 2 minecraft:polished_deepslate
setblock -5 63 2 minecraft:polished_deepslate
setblock -3 63 2 minecraft:polished_deepslate
setblock -1 63 2 minecraft:polished_deepslate
setblock 1 63 2 minecraft:polished_deepslate
setblock 3 63 2 minecraft:polished_deepslate
setblock 5 63 2 minecraft:polished_deepslate
setblock 9 63 2 minecraft:polished_deepslate
setblock 11 63 2 minecraft:polished_deepslate
fill 13 63 2 14 63 2 minecraft:polished_deepslate
setblock 0 63 2 minecraft:waxed_cut_copper
setblock -15 63 2 minecraft:waxed_oxidized_cut_copper
setblock -12 63 2 minecraft:waxed_oxidized_cut_copper
setblock -7 63 2 minecraft:waxed_oxidized_cut_copper
setblock 7 63 2 minecraft:waxed_oxidized_cut_copper
setblock 12 63 2 minecraft:waxed_oxidized_cut_copper
setblock 15 63 2 minecraft:waxed_oxidized_cut_copper
setblock -16 63 3 minecraft:deepslate_tiles
setblock -13 63 3 minecraft:deepslate_tiles
setblock -11 63 3 minecraft:deepslate_tiles
setblock -9 63 3 minecraft:deepslate_tiles
setblock -7 63 3 minecraft:deepslate_tiles
setblock -5 63 3 minecraft:deepslate_tiles
setblock -3 63 3 minecraft:deepslate_tiles
setblock -1 63 3 minecraft:deepslate_tiles
setblock 1 63 3 minecraft:deepslate_tiles
setblock 3 63 3 minecraft:deepslate_tiles
setblock 5 63 3 minecraft:deepslate_tiles
setblock 7 63 3 minecraft:deepslate_tiles
setblock 9 63 3 minecraft:deepslate_tiles
setblock 11 63 3 minecraft:deepslate_tiles
setblock 13 63 3 minecraft:deepslate_tiles
setblock 16 63 3 minecraft:deepslate_tiles
setblock -14 63 3 minecraft:polished_deepslate
setblock -10 63 3 minecraft:polished_deepslate
setblock -8 63 3 minecraft:polished_deepslate
setblock -4 63 3 minecraft:polished_deepslate
setblock -2 63 3 minecraft:polished_deepslate
setblock 2 63 3 minecraft:polished_deepslate
setblock 4 63 3 minecraft:polished_deepslate
setblock 8 63 3 minecraft:polished_deepslate
setblock 10 63 3 minecraft:polished_deepslate
setblock 14 63 3 minecraft:polished_deepslate
setblock 0 63 3 minecraft:waxed_cut_copper
setblock -15 63 3 minecraft:waxed_oxidized_cut_copper
setblock -12 63 3 minecraft:waxed_oxidized_cut_copper
setblock -6 63 3 minecraft:waxed_oxidized_cut_copper
setblock 6 63 3 minecraft:waxed_oxidized_cut_copper
setblock 12 63 3 minecraft:waxed_oxidized_cut_copper
setblock 15 63 3 minecraft:waxed_oxidized_cut_copper
setblock -16 63 4 minecraft:deepslate_tiles
setblock -12 63 4 minecraft:deepslate_tiles
setblock -10 63 4 minecraft:deepslate_tiles
setblock -8 63 4 minecraft:deepslate_tiles
setblock -4 63 4 minecraft:deepslate_tiles
setblock -2 63 4 minecraft:deepslate_tiles
setblock 2 63 4 minecraft:deepslate_tiles
setblock 4 63 4 minecraft:deepslate_tiles
setblock 8 63 4 minecraft:deepslate_tiles
setblock 10 63 4 minecraft:deepslate_tiles
setblock 12 63 4 minecraft:deepslate_tiles
setblock 16 63 4 minecraft:deepslate_tiles
fill -14 63 4 -13 63 4 minecraft:polished_deepslate
setblock -9 63 4 minecraft:polished_deepslate
setblock -7 63 4 minecraft:polished_deepslate
setblock -3 63 4 minecraft:polished_deepslate
setblock -1 63 4 minecraft:polished_deepslate
setblock 1 63 4 minecraft:polished_deepslate
setblock 3 63 4 minecraft:polished_deepslate
setblock 7 63 4 minecraft:polished_deepslate
setblock 9 63 4 minecraft:polished_deepslate
fill 13 63 4 14 63 4 minecraft:polished_deepslate
setblock 0 63 4 minecraft:waxed_cut_copper
setblock -15 63 4 minecraft:waxed_oxidized_cut_copper
setblock -11 63 4 minecraft:waxed_oxidized_cut_copper
fill -6 63 4 -5 63 4 minecraft:waxed_oxidized_cut_copper
fill 5 63 4 6 63 4 minecraft:waxed_oxidized_cut_copper
setblock 11 63 4 minecraft:waxed_oxidized_cut_copper
setblock 15 63 4 minecraft:waxed_oxidized_cut_copper
setblock -10 63 5 minecraft:chiseled_deepslate
setblock 10 63 5 minecraft:chiseled_deepslate
setblock -16 63 5 minecraft:deepslate_tiles
setblock -13 63 5 minecraft:deepslate_tiles
setblock -9 63 5 minecraft:deepslate_tiles
setblock -7 63 5 minecraft:deepslate_tiles
setblock -3 63 5 minecraft:deepslate_tiles
setblock 3 63 5 minecraft:deepslate_tiles
setblock 7 63 5 minecraft:deepslate_tiles
setblock 9 63 5 minecraft:deepslate_tiles
setblock 13 63 5 minecraft:deepslate_tiles
setblock 16 63 5 minecraft:deepslate_tiles
setblock -14 63 5 minecraft:polished_deepslate
setblock -12 63 5 minecraft:polished_deepslate
setblock -8 63 5 minecraft:polished_deepslate
setblock -6 63 5 minecraft:polished_deepslate
setblock -2 63 5 minecraft:polished_deepslate
setblock 2 63 5 minecraft:polished_deepslate
setblock 6 63 5 minecraft:polished_deepslate
setblock 8 63 5 minecraft:polished_deepslate
setblock 12 63 5 minecraft:polished_deepslate
setblock 14 63 5 minecraft:polished_deepslate
setblock 0 63 5 minecraft:waxed_cut_copper
setblock -15 63 5 minecraft:waxed_oxidized_cut_copper
setblock -11 63 5 minecraft:waxed_oxidized_cut_copper
fill -5 63 5 -4 63 5 minecraft:waxed_oxidized_cut_copper
setblock -1 63 5 minecraft:waxed_oxidized_cut_copper
setblock 1 63 5 minecraft:waxed_oxidized_cut_copper
fill 4 63 5 5 63 5 minecraft:waxed_oxidized_cut_copper
setblock 11 63 5 minecraft:waxed_oxidized_cut_copper
setblock 15 63 5 minecraft:waxed_oxidized_cut_copper
setblock -16 63 6 minecraft:deepslate_tiles
setblock -12 63 6 minecraft:deepslate_tiles
setblock -8 63 6 minecraft:deepslate_tiles
setblock -6 63 6 minecraft:deepslate_tiles
setblock -2 63 6 minecraft:deepslate_tiles
setblock 2 63 6 minecraft:deepslate_tiles
setblock 6 63 6 minecraft:deepslate_tiles
setblock 8 63 6 minecraft:deepslate_tiles
setblock 12 63 6 minecraft:deepslate_tiles
setblock 16 63 6 minecraft:deepslate_tiles
fill -14 63 6 -13 63 6 minecraft:polished_deepslate
setblock -11 63 6 minecraft:polished_deepslate
setblock -9 63 6 minecraft:polished_deepslate
setblock -7 63 6 minecraft:polished_deepslate
setblock -5 63 6 minecraft:polished_deepslate
setblock -1 63 6 minecraft:polished_deepslate
setblock 1 63 6 minecraft:polished_deepslate
setblock 5 63 6 minecraft:polished_deepslate
setblock 7 63 6 minecraft:polished_deepslate
setblock 9 63 6 minecraft:polished_deepslate
setblock 11 63 6 minecraft:polished_deepslate
fill 13 63 6 14 63 6 minecraft:polished_deepslate
setblock 0 63 6 minecraft:waxed_cut_copper
setblock -15 63 6 minecraft:waxed_oxidized_cut_copper
setblock -10 63 6 minecraft:waxed_oxidized_cut_copper
fill -4 63 6 -3 63 6 minecraft:waxed_oxidized_cut_copper
fill 3 63 6 4 63 6 minecraft:waxed_oxidized_cut_copper
setblock 10 63 6 minecraft:waxed_oxidized_cut_copper
setblock 15 63 6 minecraft:waxed_oxidized_cut_copper
setblock -16 63 7 minecraft:deepslate_tiles
setblock -13 63 7 minecraft:deepslate_tiles
setblock -11 63 7 minecraft:deepslate_tiles
setblock -9 63 7 minecraft:deepslate_tiles
setblock -7 63 7 minecraft:deepslate_tiles
setblock -5 63 7 minecraft:deepslate_tiles
setblock -3 63 7 minecraft:deepslate_tiles
setblock 3 63 7 minecraft:deepslate_tiles
setblock 5 63 7 minecraft:deepslate_tiles
setblock 7 63 7 minecraft:deepslate_tiles
setblock 9 63 7 minecraft:deepslate_tiles
setblock 11 63 7 minecraft:deepslate_tiles
setblock 13 63 7 minecraft:deepslate_tiles
setblock 16 63 7 minecraft:deepslate_tiles
setblock -14 63 7 minecraft:polished_deepslate
setblock -12 63 7 minecraft:polished_deepslate
setblock -8 63 7 minecraft:polished_deepslate
setblock -6 63 7 minecraft:polished_deepslate
setblock -4 63 7 minecraft:polished_deepslate
setblock 4 63 7 minecraft:polished_deepslate
setblock 6 63 7 minecraft:polished_deepslate
setblock 8 63 7 minecraft:polished_deepslate
setblock 12 63 7 minecraft:polished_deepslate
setblock 14 63 7 minecraft:polished_deepslate
setblock 0 63 7 minecraft:sea_lantern
setblock -15 63 7 minecraft:waxed_oxidized_cut_copper
setblock -10 63 7 minecraft:waxed_oxidized_cut_copper
fill -2 63 7 -1 63 7 minecraft:waxed_oxidized_cut_copper
fill 1 63 7 2 63 7 minecraft:waxed_oxidized_cut_copper
setblock 10 63 7 minecraft:waxed_oxidized_cut_copper
setblock 15 63 7 minecraft:waxed_oxidized_cut_copper
setblock -16 63 8 minecraft:deepslate_tiles
setblock -12 63 8 minecraft:deepslate_tiles
setblock -10 63 8 minecraft:deepslate_tiles
setblock -8 63 8 minecraft:deepslate_tiles
setblock -6 63 8 minecraft:deepslate_tiles
setblock -4 63 8 minecraft:deepslate_tiles
setblock -2 63 8 minecraft:deepslate_tiles
setblock 2 63 8 minecraft:deepslate_tiles
setblock 4 63 8 minecraft:deepslate_tiles
setblock 6 63 8 minecraft:deepslate_tiles
setblock 8 63 8 minecraft:deepslate_tiles
setblock 10 63 8 minecraft:deepslate_tiles
setblock 12 63 8 minecraft:deepslate_tiles
setblock 16 63 8 minecraft:deepslate_tiles
fill -14 63 8 -13 63 8 minecraft:polished_deepslate
setblock -11 63 8 minecraft:polished_deepslate
setblock -7 63 8 minecraft:polished_deepslate
setblock -5 63 8 minecraft:polished_deepslate
setblock -3 63 8 minecraft:polished_deepslate
setblock -1 63 8 minecraft:polished_deepslate
setblock 1 63 8 minecraft:polished_deepslate
setblock 3 63 8 minecraft:polished_deepslate
setblock 5 63 8 minecraft:polished_deepslate
setblock 7 63 8 minecraft:polished_deepslate
setblock 11 63 8 minecraft:polished_deepslate
fill 13 63 8 14 63 8 minecraft:polished_deepslate
setblock 0 63 8 minecraft:waxed_cut_copper
setblock -15 63 8 minecraft:waxed_oxidized_cut_copper
setblock -9 63 8 minecraft:waxed_oxidized_cut_copper
setblock 9 63 8 minecraft:waxed_oxidized_cut_copper
setblock 15 63 8 minecraft:waxed_oxidized_cut_copper
setblock -16 63 9 minecraft:deepslate_tiles
setblock -13 63 9 minecraft:deepslate_tiles
setblock -11 63 9 minecraft:deepslate_tiles
setblock -9 63 9 minecraft:deepslate_tiles
setblock -7 63 9 minecraft:deepslate_tiles
setblock -5 63 9 minecraft:deepslate_tiles
setblock -3 63 9 minecraft:deepslate_tiles
setblock -1 63 9 minecraft:deepslate_tiles
setblock 1 63 9 minecraft:deepslate_tiles
setblock 3 63 9 minecraft:deepslate_tiles
setblock 5 63 9 minecraft:deepslate_tiles
setblock 7 63 9 minecraft:deepslate_tiles
setblock 9 63 9 minecraft:deepslate_tiles
setblock 11 63 9 minecraft:deepslate_tiles
setblock 13 63 9 minecraft:deepslate_tiles
setblock 16 63 9 minecraft:deepslate_tiles
setblock -14 63 9 minecraft:polished_deepslate
setblock -12 63 9 minecraft:polished_deepslate
setblock -10 63 9 minecraft:polished_deepslate
setblock -6 63 9 minecraft:polished_deepslate
setblock -4 63 9 minecraft:polished_deepslate
setblock -2 63 9 minecraft:polished_deepslate
setblock 2 63 9 minecraft:polished_deepslate
setblock 4 63 9 minecraft:polished_deepslate
setblock 6 63 9 minecraft:polished_deepslate
setblock 10 63 9 minecraft:polished_deepslate
setblock 12 63 9 minecraft:polished_deepslate
setblock 14 63 9 minecraft:polished_deepslate
setblock 0 63 9 minecraft:waxed_cut_copper
setblock -15 63 9 minecraft:waxed_oxidized_cut_copper
setblock -8 63 9 minecraft:waxed_oxidized_cut_copper
setblock 8 63 9 minecraft:waxed_oxidized_cut_copper
setblock 15 63 9 minecraft:waxed_oxidized_cut_copper
setblock -10 63 10 minecraft:chiseled_deepslate
setblock -5 63 10 minecraft:chiseled_deepslate
setblock 5 63 10 minecraft:chiseled_deepslate
setblock 10 63 10 minecraft:chiseled_deepslate
setblock -16 63 10 minecraft:deepslate_tiles
setblock -12 63 10 minecraft:deepslate_tiles
setblock -8 63 10 minecraft:deepslate_tiles
setblock -4 63 10 minecraft:deepslate_tiles
setblock -2 63 10 minecraft:deepslate_tiles
setblock 2 63 10 minecraft:deepslate_tiles
setblock 4 63 10 minecraft:deepslate_tiles
setblock 8 63 10 minecraft:deepslate_tiles
setblock 12 63 10 minecraft:deepslate_tiles
setblock 16 63 10 minecraft:deepslate_tiles
fill -14 63 10 -13 63 10 minecraft:polished_deepslate
setblock -9 63 10 minecraft:polished_deepslate
setblock -3 63 10 minecraft:polished_deepslate
setblock -1 63 10 minecraft:polished_deepslate
setblock 1 63 10 minecraft:polished_deepslate
setblock 3 63 10 minecraft:polished_deepslate
setblock 9 63 10 minecraft:polished_deepslate
fill 13 63 10 14 63 10 minecraft:polished_deepslate
setblock 0 63 10 minecraft:waxed_cut_copper
setblock -15 63 10 minecraft:waxed_oxidized_cut_copper
setblock -11 63 10 minecraft:waxed_oxidized_cut_copper
fill -7 63 10 -6 63 10 minecraft:waxed_oxidized_cut_copper
fill 6 63 10 7 63 10 minecraft:waxed_oxidized_cut_copper
setblock 11 63 10 minecraft:waxed_oxidized_cut_copper
setblock 15 63 10 minecraft:waxed_oxidized_cut_copper
setblock -16 63 11 minecraft:deepslate_tiles
setblock -13 63 11 minecraft:deepslate_tiles
setblock -9 63 11 minecraft:deepslate_tiles
setblock -7 63 11 minecraft:deepslate_tiles
setblock -3 63 11 minecraft:deepslate_tiles
setblock -1 63 11 minecraft:deepslate_tiles
setblock 1 63 11 minecraft:deepslate_tiles
setblock 3 63 11 minecraft:deepslate_tiles
setblock 7 63 11 minecraft:deepslate_tiles
setblock 9 63 11 minecraft:deepslate_tiles
setblock 13 63 11 minecraft:deepslate_tiles
setblock 16 63 11 minecraft:deepslate_tiles
setblock -14 63 11 minecraft:polished_deepslate
setblock -8 63 11 minecraft:polished_deepslate
setblock -6 63 11 minecraft:polished_deepslate
setblock -2 63 11 minecraft:polished_deepslate
setblock 0 63 11 minecraft:polished_deepslate
setblock 2 63 11 minecraft:polished_deepslate
setblock 6 63 11 minecraft:polished_deepslate
setblock 8 63 11 minecraft:polished_deepslate
setblock 14 63 11 minecraft:polished_deepslate
setblock -11 63 11 minecraft:sea_lantern
setblock 11 63 11 minecraft:sea_lantern
setblock -15 63 11 minecraft:waxed_oxidized_cut_copper
setblock -12 63 11 minecraft:waxed_oxidized_cut_copper
setblock -10 63 11 minecraft:waxed_oxidized_cut_copper
fill -5 63 11 -4 63 11 minecraft:waxed_oxidized_cut_copper
fill 4 63 11 5 63 11 minecraft:waxed_oxidized_cut_copper
setblock 10 63 11 minecraft:waxed_oxidized_cut_copper
setblock 12 63 11 minecraft:waxed_oxidized_cut_copper
setblock 15 63 11 minecraft:waxed_oxidized_cut_copper
setblock -16 63 12 minecraft:deepslate_tiles
setblock -12 63 12 minecraft:deepslate_tiles
setblock -10 63 12 minecraft:deepslate_tiles
setblock -8 63 12 minecraft:deepslate_tiles
setblock -6 63 12 minecraft:deepslate_tiles
setblock -4 63 12 minecraft:deepslate_tiles
setblock 4 63 12 minecraft:deepslate_tiles
setblock 6 63 12 minecraft:deepslate_tiles
setblock 8 63 12 minecraft:deepslate_tiles
setblock 10 63 12 minecraft:deepslate_tiles
setblock 12 63 12 minecraft:deepslate_tiles
setblock 16 63 12 minecraft:deepslate_tiles
fill -14 63 12 -13 63 12 minecraft:polished_deepslate
setblock -9 63 12 minecraft:polished_deepslate
setblock -7 63 12 minecraft:polished_deepslate
setblock -5 63 12 minecraft:polished_deepslate
setblock 5 63 12 minecraft:polished_deepslate
setblock 7 63 12 minecraft:polished_deepslate
setblock 9 63 12 minecraft:polished_deepslate
fill 13 63 12 14 63 12 minecraft:polished_deepslate
setblock -15 63 12 minecraft:waxed_oxidized_cut_copper
setblock -11 63 12 minecraft:waxed_oxidized_cut_copper
fill -3 63 12 3 63 12 minecraft:waxed_oxidized_cut_copper
setblock 11 63 12 minecraft:waxed_oxidized_cut_copper
setblock 15 63 12 minecraft:waxed_oxidized_cut_copper
setblock -16 63 13 minecraft:deepslate_tiles
setblock -13 63 13 minecraft:deepslate_tiles
setblock -11 63 13 minecraft:deepslate_tiles
setblock -9 63 13 minecraft:deepslate_tiles
setblock -7 63 13 minecraft:deepslate_tiles
setblock -5 63 13 minecraft:deepslate_tiles
setblock -3 63 13 minecraft:deepslate_tiles
setblock -1 63 13 minecraft:deepslate_tiles
setblock 1 63 13 minecraft:deepslate_tiles
setblock 3 63 13 minecraft:deepslate_tiles
setblock 5 63 13 minecraft:deepslate_tiles
setblock 7 63 13 minecraft:deepslate_tiles
setblock 9 63 13 minecraft:deepslate_tiles
setblock 11 63 13 minecraft:deepslate_tiles
setblock 13 63 13 minecraft:deepslate_tiles
setblock 16 63 13 minecraft:deepslate_tiles
setblock -14 63 13 minecraft:polished_deepslate
setblock -12 63 13 minecraft:polished_deepslate
setblock -10 63 13 minecraft:polished_deepslate
setblock -8 63 13 minecraft:polished_deepslate
setblock -6 63 13 minecraft:polished_deepslate
setblock -4 63 13 minecraft:polished_deepslate
setblock -2 63 13 minecraft:polished_deepslate
setblock 0 63 13 minecraft:polished_deepslate
setblock 2 63 13 minecraft:polished_deepslate
setblock 4 63 13 minecraft:polished_deepslate
setblock 6 63 13 minecraft:polished_deepslate
setblock 8 63 13 minecraft:polished_deepslate
setblock 10 63 13 minecraft:polished_deepslate
setblock 12 63 13 minecraft:polished_deepslate
setblock 14 63 13 minecraft:polished_deepslate
setblock -15 63 13 minecraft:waxed_oxidized_cut_copper
setblock 15 63 13 minecraft:waxed_oxidized_cut_copper
setblock -16 63 14 minecraft:deepslate_tiles
setblock 16 63 14 minecraft:deepslate_tiles
fill -14 63 14 14 63 14 minecraft:polished_deepslate
setblock -15 63 14 minecraft:waxed_oxidized_cut_copper
setblock 15 63 14 minecraft:waxed_oxidized_cut_copper
setblock -16 63 15 minecraft:deepslate_tiles
setblock 16 63 15 minecraft:deepslate_tiles
fill -15 63 15 15 63 15 minecraft:waxed_oxidized_cut_copper
fill -16 63 16 16 63 16 minecraft:deepslate_tiles
fill -16 64 -16 16 64 -16 minecraft:deepslate_tiles
setblock -16 64 -15 minecraft:deepslate_tiles
setblock 16 64 -15 minecraft:deepslate_tiles
setblock -12 64 -15 minecraft:waxed_oxidized_cut_copper
setblock -6 64 -15 minecraft:waxed_oxidized_cut_copper
setblock 0 64 -15 minecraft:waxed_oxidized_cut_copper
setblock 6 64 -15 minecraft:waxed_oxidized_cut_copper
setblock 12 64 -15 minecraft:waxed_oxidized_cut_copper
setblock -16 64 -14 minecraft:deepslate_tiles
setblock 16 64 -14 minecraft:deepslate_tiles
setblock -16 64 -13 minecraft:deepslate_tiles
setblock 16 64 -13 minecraft:deepslate_tiles
setblock -16 64 -12 minecraft:deepslate_tiles
setblock 16 64 -12 minecraft:deepslate_tiles
setblock -15 64 -12 minecraft:waxed_oxidized_cut_copper
setblock 15 64 -12 minecraft:waxed_oxidized_cut_copper
setblock -16 64 -11 minecraft:deepslate_tiles
setblock 16 64 -11 minecraft:deepslate_tiles
setblock -16 64 -10 minecraft:deepslate_tiles
setblock 16 64 -10 minecraft:deepslate_tiles
setblock -16 64 -9 minecraft:deepslate_tiles
setblock 16 64 -9 minecraft:deepslate_tiles
setblock -16 64 -8 minecraft:deepslate_tiles
setblock 16 64 -8 minecraft:deepslate_tiles
setblock -16 64 -7 minecraft:deepslate_tiles
setblock 16 64 -7 minecraft:deepslate_tiles
setblock -16 64 -6 minecraft:deepslate_tiles
setblock 16 64 -6 minecraft:deepslate_tiles
setblock -15 64 -6 minecraft:waxed_oxidized_cut_copper
setblock 15 64 -6 minecraft:waxed_oxidized_cut_copper
setblock -16 64 -5 minecraft:deepslate_tiles
setblock 16 64 -5 minecraft:deepslate_tiles
setblock -16 64 -4 minecraft:deepslate_tiles
setblock 16 64 -4 minecraft:deepslate_tiles
setblock -16 64 -3 minecraft:deepslate_tiles
setblock 16 64 -3 minecraft:deepslate_tiles
setblock -16 64 -2 minecraft:deepslate_tiles
setblock 16 64 -2 minecraft:deepslate_tiles
setblock -16 64 -1 minecraft:deepslate_tiles
setblock 16 64 -1 minecraft:deepslate_tiles
setblock -16 64 0 minecraft:deepslate_tiles
setblock 16 64 0 minecraft:deepslate_tiles
setblock -15 64 0 minecraft:waxed_oxidized_cut_copper
setblock 15 64 0 minecraft:waxed_oxidized_cut_copper
setblock -16 64 1 minecraft:deepslate_tiles
setblock 16 64 1 minecraft:deepslate_tiles
setblock -16 64 2 minecraft:deepslate_tiles
setblock 16 64 2 minecraft:deepslate_tiles
setblock -16 64 3 minecraft:deepslate_tiles
setblock 16 64 3 minecraft:deepslate_tiles
setblock -16 64 4 minecraft:deepslate_tiles
setblock 16 64 4 minecraft:deepslate_tiles
setblock -16 64 5 minecraft:deepslate_tiles
setblock 16 64 5 minecraft:deepslate_tiles
setblock -16 64 6 minecraft:deepslate_tiles
setblock 16 64 6 minecraft:deepslate_tiles
setblock -15 64 6 minecraft:waxed_oxidized_cut_copper
setblock 15 64 6 minecraft:waxed_oxidized_cut_copper
setblock -16 64 7 minecraft:deepslate_tiles
setblock 16 64 7 minecraft:deepslate_tiles
setblock -16 64 8 minecraft:deepslate_tiles
setblock 16 64 8 minecraft:deepslate_tiles
setblock -16 64 9 minecraft:deepslate_tiles
setblock 16 64 9 minecraft:deepslate_tiles
setblock -16 64 10 minecraft:deepslate_tiles
setblock 16 64 10 minecraft:deepslate_tiles
setblock -16 64 11 minecraft:deepslate_tiles
setblock 16 64 11 minecraft:deepslate_tiles
fill -13 64 11 -11 64 11 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 11 64 11 13 64 11 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock -16 64 12 minecraft:deepslate_tiles
setblock 16 64 12 minecraft:deepslate_tiles
fill -13 64 12 -11 64 12 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 11 64 12 13 64 12 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock -15 64 12 minecraft:waxed_oxidized_cut_copper
setblock 15 64 12 minecraft:waxed_oxidized_cut_copper
setblock -16 64 13 minecraft:deepslate_tiles
setblock 16 64 13 minecraft:deepslate_tiles
fill -13 64 13 -11 64 13 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 11 64 13 13 64 13 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock -16 64 14 minecraft:deepslate_tiles
setblock 16 64 14 minecraft:deepslate_tiles
setblock -16 64 15 minecraft:deepslate_tiles
setblock 16 64 15 minecraft:deepslate_tiles
setblock -12 64 15 minecraft:waxed_oxidized_cut_copper
setblock -6 64 15 minecraft:waxed_oxidized_cut_copper
setblock 0 64 15 minecraft:waxed_oxidized_cut_copper
setblock 6 64 15 minecraft:waxed_oxidized_cut_copper
setblock 12 64 15 minecraft:waxed_oxidized_cut_copper
fill -16 64 16 16 64 16 minecraft:deepslate_tiles
fill -16 65 -16 16 65 -16 minecraft:deepslate_tiles
setblock -16 65 -15 minecraft:deepslate_tiles
setblock 16 65 -15 minecraft:deepslate_tiles
setblock -12 65 -15 minecraft:waxed_oxidized_cut_copper
setblock -6 65 -15 minecraft:waxed_oxidized_cut_copper
setblock 0 65 -15 minecraft:waxed_oxidized_cut_copper
setblock 6 65 -15 minecraft:waxed_oxidized_cut_copper
setblock 12 65 -15 minecraft:waxed_oxidized_cut_copper
setblock -16 65 -14 minecraft:deepslate_tiles
setblock 16 65 -14 minecraft:deepslate_tiles
setblock -16 65 -13 minecraft:deepslate_tiles
setblock 16 65 -13 minecraft:deepslate_tiles
setblock -16 65 -12 minecraft:deepslate_tiles
setblock 16 65 -12 minecraft:deepslate_tiles
setblock -15 65 -12 minecraft:waxed_oxidized_cut_copper
setblock 15 65 -12 minecraft:waxed_oxidized_cut_copper
setblock -16 65 -11 minecraft:deepslate_tiles
setblock 16 65 -11 minecraft:deepslate_tiles
setblock -16 65 -10 minecraft:deepslate_tiles
setblock 16 65 -10 minecraft:deepslate_tiles
setblock -16 65 -9 minecraft:deepslate_tiles
setblock 16 65 -9 minecraft:deepslate_tiles
setblock -16 65 -8 minecraft:deepslate_tiles
setblock 16 65 -8 minecraft:deepslate_tiles
setblock -16 65 -7 minecraft:deepslate_tiles
setblock 16 65 -7 minecraft:deepslate_tiles
setblock -16 65 -6 minecraft:deepslate_tiles
setblock 16 65 -6 minecraft:deepslate_tiles
setblock -15 65 -6 minecraft:waxed_oxidized_cut_copper
setblock 15 65 -6 minecraft:waxed_oxidized_cut_copper
setblock -16 65 -5 minecraft:deepslate_tiles
setblock 16 65 -5 minecraft:deepslate_tiles
setblock -16 65 -4 minecraft:deepslate_tiles
setblock 16 65 -4 minecraft:deepslate_tiles
setblock -16 65 -3 minecraft:deepslate_tiles
setblock 16 65 -3 minecraft:deepslate_tiles
setblock -16 65 -2 minecraft:deepslate_tiles
setblock 16 65 -2 minecraft:deepslate_tiles
setblock -16 65 -1 minecraft:deepslate_tiles
setblock 16 65 -1 minecraft:deepslate_tiles
setblock -16 65 0 minecraft:deepslate_tiles
setblock 16 65 0 minecraft:deepslate_tiles
setblock -15 65 0 minecraft:waxed_oxidized_cut_copper
setblock 15 65 0 minecraft:waxed_oxidized_cut_copper
setblock -16 65 1 minecraft:deepslate_tiles
setblock 16 65 1 minecraft:deepslate_tiles
setblock -16 65 2 minecraft:deepslate_tiles
setblock 16 65 2 minecraft:deepslate_tiles
setblock -16 65 3 minecraft:deepslate_tiles
setblock 16 65 3 minecraft:deepslate_tiles
setblock -16 65 4 minecraft:deepslate_tiles
setblock 16 65 4 minecraft:deepslate_tiles
setblock -16 65 5 minecraft:deepslate_tiles
setblock 16 65 5 minecraft:deepslate_tiles
setblock -16 65 6 minecraft:deepslate_tiles
setblock 16 65 6 minecraft:deepslate_tiles
setblock -15 65 6 minecraft:waxed_oxidized_cut_copper
setblock 15 65 6 minecraft:waxed_oxidized_cut_copper
setblock -16 65 7 minecraft:deepslate_tiles
setblock 16 65 7 minecraft:deepslate_tiles
setblock -16 65 8 minecraft:deepslate_tiles
setblock 16 65 8 minecraft:deepslate_tiles
setblock -16 65 9 minecraft:deepslate_tiles
setblock 16 65 9 minecraft:deepslate_tiles
setblock -16 65 10 minecraft:deepslate_tiles
setblock 16 65 10 minecraft:deepslate_tiles
setblock -16 65 11 minecraft:deepslate_tiles
setblock 16 65 11 minecraft:deepslate_tiles
setblock -16 65 12 minecraft:deepslate_tiles
setblock 16 65 12 minecraft:deepslate_tiles
setblock -12 65 12 minecraft:flowering_azalea_leaves[persistent=true]
setblock 12 65 12 minecraft:flowering_azalea_leaves[persistent=true]
setblock -15 65 12 minecraft:waxed_oxidized_cut_copper
setblock 15 65 12 minecraft:waxed_oxidized_cut_copper
setblock -16 65 13 minecraft:deepslate_tiles
setblock 16 65 13 minecraft:deepslate_tiles
setblock -16 65 14 minecraft:deepslate_tiles
setblock 16 65 14 minecraft:deepslate_tiles
setblock -16 65 15 minecraft:deepslate_tiles
setblock 16 65 15 minecraft:deepslate_tiles
setblock -12 65 15 minecraft:waxed_oxidized_cut_copper
setblock -6 65 15 minecraft:waxed_oxidized_cut_copper
setblock 0 65 15 minecraft:waxed_oxidized_cut_copper
setblock 6 65 15 minecraft:waxed_oxidized_cut_copper
setblock 12 65 15 minecraft:waxed_oxidized_cut_copper
fill -16 65 16 16 65 16 minecraft:deepslate_tiles
fill -16 66 -16 16 66 -16 minecraft:deepslate_tiles
setblock -16 66 -15 minecraft:deepslate_tiles
setblock 16 66 -15 minecraft:deepslate_tiles
fill -15 66 -15 15 66 -15 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -14 minecraft:deepslate_tiles
setblock 16 66 -14 minecraft:deepslate_tiles
setblock -15 66 -14 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -14 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -13 minecraft:deepslate_tiles
setblock 16 66 -13 minecraft:deepslate_tiles
setblock -15 66 -13 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -13 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -12 minecraft:deepslate_tiles
setblock 16 66 -12 minecraft:deepslate_tiles
setblock -15 66 -12 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -12 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -11 minecraft:deepslate_tiles
setblock 16 66 -11 minecraft:deepslate_tiles
setblock -15 66 -11 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -11 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -10 minecraft:deepslate_tiles
setblock 16 66 -10 minecraft:deepslate_tiles
setblock -15 66 -10 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -10 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -9 minecraft:deepslate_tiles
setblock 16 66 -9 minecraft:deepslate_tiles
setblock -15 66 -9 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -9 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -8 minecraft:deepslate_tiles
setblock 16 66 -8 minecraft:deepslate_tiles
setblock -15 66 -8 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -8 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -7 minecraft:deepslate_tiles
setblock 16 66 -7 minecraft:deepslate_tiles
setblock -15 66 -7 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -7 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -6 minecraft:deepslate_tiles
setblock 16 66 -6 minecraft:deepslate_tiles
setblock -15 66 -6 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -6 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -5 minecraft:deepslate_tiles
setblock 16 66 -5 minecraft:deepslate_tiles
setblock -15 66 -5 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -5 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -4 minecraft:deepslate_tiles
setblock 16 66 -4 minecraft:deepslate_tiles
setblock -15 66 -4 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -4 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -3 minecraft:deepslate_tiles
setblock 16 66 -3 minecraft:deepslate_tiles
setblock -15 66 -3 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -3 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -2 minecraft:deepslate_tiles
setblock 16 66 -2 minecraft:deepslate_tiles
setblock -15 66 -2 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -2 minecraft:waxed_oxidized_cut_copper
setblock -16 66 -1 minecraft:deepslate_tiles
setblock 16 66 -1 minecraft:deepslate_tiles
setblock -15 66 -1 minecraft:waxed_oxidized_cut_copper
setblock 15 66 -1 minecraft:waxed_oxidized_cut_copper
setblock -16 66 0 minecraft:deepslate_tiles
setblock 16 66 0 minecraft:deepslate_tiles
setblock -15 66 0 minecraft:waxed_oxidized_cut_copper
setblock 15 66 0 minecraft:waxed_oxidized_cut_copper
setblock -16 66 1 minecraft:deepslate_tiles
setblock 16 66 1 minecraft:deepslate_tiles
setblock -15 66 1 minecraft:waxed_oxidized_cut_copper
setblock 15 66 1 minecraft:waxed_oxidized_cut_copper
setblock -16 66 2 minecraft:deepslate_tiles
setblock 16 66 2 minecraft:deepslate_tiles
setblock -15 66 2 minecraft:waxed_oxidized_cut_copper
setblock 15 66 2 minecraft:waxed_oxidized_cut_copper
setblock -16 66 3 minecraft:deepslate_tiles
setblock 16 66 3 minecraft:deepslate_tiles
setblock -15 66 3 minecraft:waxed_oxidized_cut_copper
setblock 15 66 3 minecraft:waxed_oxidized_cut_copper
setblock -16 66 4 minecraft:deepslate_tiles
setblock 16 66 4 minecraft:deepslate_tiles
setblock -15 66 4 minecraft:waxed_oxidized_cut_copper
setblock 15 66 4 minecraft:waxed_oxidized_cut_copper
setblock -16 66 5 minecraft:deepslate_tiles
setblock 16 66 5 minecraft:deepslate_tiles
setblock -15 66 5 minecraft:waxed_oxidized_cut_copper
setblock 15 66 5 minecraft:waxed_oxidized_cut_copper
setblock -16 66 6 minecraft:deepslate_tiles
setblock 16 66 6 minecraft:deepslate_tiles
setblock -15 66 6 minecraft:waxed_oxidized_cut_copper
setblock 15 66 6 minecraft:waxed_oxidized_cut_copper
setblock -16 66 7 minecraft:deepslate_tiles
setblock 16 66 7 minecraft:deepslate_tiles
setblock -15 66 7 minecraft:waxed_oxidized_cut_copper
setblock 15 66 7 minecraft:waxed_oxidized_cut_copper
setblock -16 66 8 minecraft:deepslate_tiles
setblock 16 66 8 minecraft:deepslate_tiles
setblock -15 66 8 minecraft:waxed_oxidized_cut_copper
setblock 15 66 8 minecraft:waxed_oxidized_cut_copper
setblock -16 66 9 minecraft:deepslate_tiles
setblock 16 66 9 minecraft:deepslate_tiles
setblock -15 66 9 minecraft:waxed_oxidized_cut_copper
setblock 15 66 9 minecraft:waxed_oxidized_cut_copper
setblock -16 66 10 minecraft:deepslate_tiles
setblock 16 66 10 minecraft:deepslate_tiles
setblock -15 66 10 minecraft:waxed_oxidized_cut_copper
setblock 15 66 10 minecraft:waxed_oxidized_cut_copper
setblock -16 66 11 minecraft:deepslate_tiles
setblock 16 66 11 minecraft:deepslate_tiles
setblock -15 66 11 minecraft:waxed_oxidized_cut_copper
setblock 15 66 11 minecraft:waxed_oxidized_cut_copper
setblock -16 66 12 minecraft:deepslate_tiles
setblock 16 66 12 minecraft:deepslate_tiles
setblock -12 66 12 minecraft:flowering_azalea_leaves[persistent=true]
setblock 12 66 12 minecraft:flowering_azalea_leaves[persistent=true]
setblock -15 66 12 minecraft:waxed_oxidized_cut_copper
setblock 15 66 12 minecraft:waxed_oxidized_cut_copper
setblock -16 66 13 minecraft:deepslate_tiles
setblock 16 66 13 minecraft:deepslate_tiles
setblock -15 66 13 minecraft:waxed_oxidized_cut_copper
setblock 15 66 13 minecraft:waxed_oxidized_cut_copper
setblock -16 66 14 minecraft:deepslate_tiles
setblock 16 66 14 minecraft:deepslate_tiles
setblock -15 66 14 minecraft:waxed_oxidized_cut_copper
setblock 15 66 14 minecraft:waxed_oxidized_cut_copper
setblock -16 66 15 minecraft:deepslate_tiles
setblock 16 66 15 minecraft:deepslate_tiles
fill -15 66 15 15 66 15 minecraft:waxed_oxidized_cut_copper
fill -16 66 16 16 66 16 minecraft:deepslate_tiles
fill -16 67 -16 -13 67 -16 minecraft:deepslate_tiles
fill -11 67 -16 -7 67 -16 minecraft:deepslate_tiles
fill -5 67 -16 -1 67 -16 minecraft:deepslate_tiles
fill 1 67 -16 5 67 -16 minecraft:deepslate_tiles
fill 7 67 -16 11 67 -16 minecraft:deepslate_tiles
fill 13 67 -16 16 67 -16 minecraft:deepslate_tiles
setblock -12 67 -16 minecraft:sea_lantern
setblock -6 67 -16 minecraft:sea_lantern
setblock 0 67 -16 minecraft:sea_lantern
setblock 6 67 -16 minecraft:sea_lantern
setblock 12 67 -16 minecraft:sea_lantern
setblock -12 67 -15 minecraft:cyan_stained_glass
setblock -6 67 -15 minecraft:cyan_stained_glass
setblock 0 67 -15 minecraft:cyan_stained_glass
setblock 6 67 -15 minecraft:cyan_stained_glass
setblock 12 67 -15 minecraft:cyan_stained_glass
setblock -16 67 -15 minecraft:deepslate_tiles
setblock 16 67 -15 minecraft:deepslate_tiles
setblock -16 67 -14 minecraft:deepslate_tiles
setblock 16 67 -14 minecraft:deepslate_tiles
setblock -16 67 -13 minecraft:deepslate_tiles
setblock 16 67 -13 minecraft:deepslate_tiles
setblock -15 67 -12 minecraft:cyan_stained_glass
setblock 15 67 -12 minecraft:cyan_stained_glass
setblock -16 67 -12 minecraft:sea_lantern
setblock 16 67 -12 minecraft:sea_lantern
setblock -16 67 -11 minecraft:deepslate_tiles
setblock 16 67 -11 minecraft:deepslate_tiles
setblock -16 67 -10 minecraft:deepslate_tiles
setblock 16 67 -10 minecraft:deepslate_tiles
setblock -16 67 -9 minecraft:deepslate_tiles
setblock 16 67 -9 minecraft:deepslate_tiles
setblock -16 67 -8 minecraft:deepslate_tiles
setblock 16 67 -8 minecraft:deepslate_tiles
setblock -16 67 -7 minecraft:deepslate_tiles
setblock 16 67 -7 minecraft:deepslate_tiles
setblock -15 67 -6 minecraft:cyan_stained_glass
setblock 15 67 -6 minecraft:cyan_stained_glass
setblock -16 67 -6 minecraft:sea_lantern
setblock 16 67 -6 minecraft:sea_lantern
setblock -16 67 -5 minecraft:deepslate_tiles
setblock 16 67 -5 minecraft:deepslate_tiles
setblock -16 67 -4 minecraft:deepslate_tiles
setblock 16 67 -4 minecraft:deepslate_tiles
setblock -16 67 -3 minecraft:deepslate_tiles
setblock 16 67 -3 minecraft:deepslate_tiles
setblock -16 67 -2 minecraft:deepslate_tiles
setblock 16 67 -2 minecraft:deepslate_tiles
setblock -16 67 -1 minecraft:deepslate_tiles
setblock 16 67 -1 minecraft:deepslate_tiles
setblock -15 67 0 minecraft:cyan_stained_glass
setblock 15 67 0 minecraft:cyan_stained_glass
setblock -16 67 0 minecraft:sea_lantern
setblock 16 67 0 minecraft:sea_lantern
setblock -16 67 1 minecraft:deepslate_tiles
setblock 16 67 1 minecraft:deepslate_tiles
setblock -16 67 2 minecraft:deepslate_tiles
setblock 16 67 2 minecraft:deepslate_tiles
setblock -16 67 3 minecraft:deepslate_tiles
setblock 16 67 3 minecraft:deepslate_tiles
setblock -16 67 4 minecraft:deepslate_tiles
setblock 16 67 4 minecraft:deepslate_tiles
setblock -16 67 5 minecraft:deepslate_tiles
setblock 16 67 5 minecraft:deepslate_tiles
setblock -15 67 6 minecraft:cyan_stained_glass
setblock 15 67 6 minecraft:cyan_stained_glass
setblock -16 67 6 minecraft:sea_lantern
setblock 16 67 6 minecraft:sea_lantern
setblock -16 67 7 minecraft:deepslate_tiles
setblock 16 67 7 minecraft:deepslate_tiles
setblock -16 67 8 minecraft:deepslate_tiles
setblock 16 67 8 minecraft:deepslate_tiles
setblock -16 67 9 minecraft:deepslate_tiles
setblock 16 67 9 minecraft:deepslate_tiles
setblock -16 67 10 minecraft:deepslate_tiles
setblock 16 67 10 minecraft:deepslate_tiles
setblock -16 67 11 minecraft:deepslate_tiles
setblock 16 67 11 minecraft:deepslate_tiles
setblock -15 67 12 minecraft:cyan_stained_glass
setblock 15 67 12 minecraft:cyan_stained_glass
setblock -16 67 12 minecraft:sea_lantern
setblock 16 67 12 minecraft:sea_lantern
setblock -16 67 13 minecraft:deepslate_tiles
setblock 16 67 13 minecraft:deepslate_tiles
setblock -16 67 14 minecraft:deepslate_tiles
setblock 16 67 14 minecraft:deepslate_tiles
setblock -12 67 15 minecraft:cyan_stained_glass
setblock -6 67 15 minecraft:cyan_stained_glass
setblock 0 67 15 minecraft:cyan_stained_glass
setblock 6 67 15 minecraft:cyan_stained_glass
setblock 12 67 15 minecraft:cyan_stained_glass
setblock -16 67 15 minecraft:deepslate_tiles
setblock 16 67 15 minecraft:deepslate_tiles
fill -16 67 16 -13 67 16 minecraft:deepslate_tiles
fill -11 67 16 -7 67 16 minecraft:deepslate_tiles
fill -5 67 16 -1 67 16 minecraft:deepslate_tiles
fill 1 67 16 5 67 16 minecraft:deepslate_tiles
fill 7 67 16 11 67 16 minecraft:deepslate_tiles
fill 13 67 16 16 67 16 minecraft:deepslate_tiles
setblock -12 67 16 minecraft:sea_lantern
setblock -6 67 16 minecraft:sea_lantern
setblock 0 67 16 minecraft:sea_lantern
setblock 6 67 16 minecraft:sea_lantern
setblock 12 67 16 minecraft:sea_lantern
fill -16 68 -16 -13 68 -16 minecraft:deepslate_tiles
fill -11 68 -16 -7 68 -16 minecraft:deepslate_tiles
fill -5 68 -16 -1 68 -16 minecraft:deepslate_tiles
fill 1 68 -16 5 68 -16 minecraft:deepslate_tiles
fill 7 68 -16 11 68 -16 minecraft:deepslate_tiles
fill 13 68 -16 16 68 -16 minecraft:deepslate_tiles
setblock -12 68 -16 minecraft:sea_lantern
setblock -6 68 -16 minecraft:sea_lantern
setblock 0 68 -16 minecraft:sea_lantern
setblock 6 68 -16 minecraft:sea_lantern
setblock 12 68 -16 minecraft:sea_lantern
setblock -12 68 -15 minecraft:cyan_stained_glass
setblock -6 68 -15 minecraft:cyan_stained_glass
setblock 0 68 -15 minecraft:cyan_stained_glass
setblock 6 68 -15 minecraft:cyan_stained_glass
setblock 12 68 -15 minecraft:cyan_stained_glass
setblock -16 68 -15 minecraft:deepslate_tiles
setblock 16 68 -15 minecraft:deepslate_tiles
setblock -16 68 -14 minecraft:deepslate_tiles
setblock 16 68 -14 minecraft:deepslate_tiles
setblock -16 68 -13 minecraft:deepslate_tiles
setblock 16 68 -13 minecraft:deepslate_tiles
setblock -15 68 -12 minecraft:cyan_stained_glass
setblock 15 68 -12 minecraft:cyan_stained_glass
setblock -16 68 -12 minecraft:sea_lantern
setblock 16 68 -12 minecraft:sea_lantern
setblock -16 68 -11 minecraft:deepslate_tiles
setblock 16 68 -11 minecraft:deepslate_tiles
setblock -16 68 -10 minecraft:deepslate_tiles
setblock 16 68 -10 minecraft:deepslate_tiles
setblock -16 68 -9 minecraft:deepslate_tiles
setblock 16 68 -9 minecraft:deepslate_tiles
setblock -16 68 -8 minecraft:deepslate_tiles
setblock 16 68 -8 minecraft:deepslate_tiles
setblock -16 68 -7 minecraft:deepslate_tiles
setblock 16 68 -7 minecraft:deepslate_tiles
setblock -15 68 -6 minecraft:cyan_stained_glass
setblock 15 68 -6 minecraft:cyan_stained_glass
setblock -16 68 -6 minecraft:sea_lantern
setblock 16 68 -6 minecraft:sea_lantern
setblock -16 68 -5 minecraft:deepslate_tiles
setblock 16 68 -5 minecraft:deepslate_tiles
setblock -16 68 -4 minecraft:deepslate_tiles
setblock 16 68 -4 minecraft:deepslate_tiles
setblock -16 68 -3 minecraft:deepslate_tiles
setblock 16 68 -3 minecraft:deepslate_tiles
setblock -16 68 -2 minecraft:deepslate_tiles
setblock 16 68 -2 minecraft:deepslate_tiles
setblock -16 68 -1 minecraft:deepslate_tiles
setblock 16 68 -1 minecraft:deepslate_tiles
setblock -15 68 0 minecraft:cyan_stained_glass
setblock 15 68 0 minecraft:cyan_stained_glass
setblock -16 68 0 minecraft:sea_lantern
setblock 16 68 0 minecraft:sea_lantern
setblock -16 68 1 minecraft:deepslate_tiles
setblock 16 68 1 minecraft:deepslate_tiles
setblock -16 68 2 minecraft:deepslate_tiles
setblock 16 68 2 minecraft:deepslate_tiles
setblock -16 68 3 minecraft:deepslate_tiles
setblock 16 68 3 minecraft:deepslate_tiles
setblock -16 68 4 minecraft:deepslate_tiles
setblock 16 68 4 minecraft:deepslate_tiles
setblock -16 68 5 minecraft:deepslate_tiles
setblock 16 68 5 minecraft:deepslate_tiles
setblock -15 68 6 minecraft:cyan_stained_glass
setblock 15 68 6 minecraft:cyan_stained_glass
setblock -16 68 6 minecraft:sea_lantern
setblock 16 68 6 minecraft:sea_lantern
setblock -16 68 7 minecraft:deepslate_tiles
setblock 16 68 7 minecraft:deepslate_tiles
setblock -16 68 8 minecraft:deepslate_tiles
setblock 16 68 8 minecraft:deepslate_tiles
setblock -16 68 9 minecraft:deepslate_tiles
setblock 16 68 9 minecraft:deepslate_tiles
setblock -16 68 10 minecraft:deepslate_tiles
setblock 16 68 10 minecraft:deepslate_tiles
setblock -16 68 11 minecraft:deepslate_tiles
setblock 16 68 11 minecraft:deepslate_tiles
setblock -15 68 12 minecraft:cyan_stained_glass
setblock 15 68 12 minecraft:cyan_stained_glass
setblock -16 68 12 minecraft:sea_lantern
setblock 16 68 12 minecraft:sea_lantern
setblock -16 68 13 minecraft:deepslate_tiles
setblock 16 68 13 minecraft:deepslate_tiles
setblock -16 68 14 minecraft:deepslate_tiles
setblock 16 68 14 minecraft:deepslate_tiles
setblock -12 68 15 minecraft:cyan_stained_glass
setblock -6 68 15 minecraft:cyan_stained_glass
setblock 0 68 15 minecraft:cyan_stained_glass
setblock 6 68 15 minecraft:cyan_stained_glass
setblock 12 68 15 minecraft:cyan_stained_glass
setblock -16 68 15 minecraft:deepslate_tiles
setblock 16 68 15 minecraft:deepslate_tiles
fill -16 68 16 -13 68 16 minecraft:deepslate_tiles
fill -11 68 16 -7 68 16 minecraft:deepslate_tiles
fill -5 68 16 -1 68 16 minecraft:deepslate_tiles
fill 1 68 16 5 68 16 minecraft:deepslate_tiles
fill 7 68 16 11 68 16 minecraft:deepslate_tiles
fill 13 68 16 16 68 16 minecraft:deepslate_tiles
setblock -12 68 16 minecraft:sea_lantern
setblock -6 68 16 minecraft:sea_lantern
setblock 0 68 16 minecraft:sea_lantern
setblock 6 68 16 minecraft:sea_lantern
setblock 12 68 16 minecraft:sea_lantern
fill -16 69 -16 -13 69 -16 minecraft:deepslate_tiles
fill -11 69 -16 -7 69 -16 minecraft:deepslate_tiles
fill -5 69 -16 -1 69 -16 minecraft:deepslate_tiles
fill 1 69 -16 5 69 -16 minecraft:deepslate_tiles
fill 7 69 -16 11 69 -16 minecraft:deepslate_tiles
fill 13 69 -16 16 69 -16 minecraft:deepslate_tiles
setblock -12 69 -16 minecraft:sea_lantern
setblock -6 69 -16 minecraft:sea_lantern
setblock 0 69 -16 minecraft:sea_lantern
setblock 6 69 -16 minecraft:sea_lantern
setblock 12 69 -16 minecraft:sea_lantern
setblock -12 69 -15 minecraft:cyan_stained_glass
setblock -6 69 -15 minecraft:cyan_stained_glass
setblock 0 69 -15 minecraft:cyan_stained_glass
setblock 6 69 -15 minecraft:cyan_stained_glass
setblock 12 69 -15 minecraft:cyan_stained_glass
setblock -16 69 -15 minecraft:deepslate_tiles
setblock 16 69 -15 minecraft:deepslate_tiles
setblock -16 69 -14 minecraft:deepslate_tiles
setblock 16 69 -14 minecraft:deepslate_tiles
setblock -16 69 -13 minecraft:deepslate_tiles
setblock 16 69 -13 minecraft:deepslate_tiles
setblock -15 69 -12 minecraft:cyan_stained_glass
setblock 15 69 -12 minecraft:cyan_stained_glass
setblock -16 69 -12 minecraft:sea_lantern
setblock 16 69 -12 minecraft:sea_lantern
setblock -16 69 -11 minecraft:deepslate_tiles
setblock 16 69 -11 minecraft:deepslate_tiles
setblock -16 69 -10 minecraft:deepslate_tiles
setblock 16 69 -10 minecraft:deepslate_tiles
setblock -16 69 -9 minecraft:deepslate_tiles
setblock 16 69 -9 minecraft:deepslate_tiles
setblock -16 69 -8 minecraft:deepslate_tiles
setblock 16 69 -8 minecraft:deepslate_tiles
setblock -16 69 -7 minecraft:deepslate_tiles
setblock 16 69 -7 minecraft:deepslate_tiles
setblock -15 69 -6 minecraft:cyan_stained_glass
setblock 15 69 -6 minecraft:cyan_stained_glass
setblock -16 69 -6 minecraft:sea_lantern
setblock 16 69 -6 minecraft:sea_lantern
setblock -16 69 -5 minecraft:deepslate_tiles
setblock 16 69 -5 minecraft:deepslate_tiles
setblock -16 69 -4 minecraft:deepslate_tiles
setblock 16 69 -4 minecraft:deepslate_tiles
setblock -16 69 -3 minecraft:deepslate_tiles
setblock 16 69 -3 minecraft:deepslate_tiles
setblock -16 69 -2 minecraft:deepslate_tiles
setblock 16 69 -2 minecraft:deepslate_tiles
setblock -16 69 -1 minecraft:deepslate_tiles
setblock 16 69 -1 minecraft:deepslate_tiles
setblock -15 69 0 minecraft:cyan_stained_glass
setblock 15 69 0 minecraft:cyan_stained_glass
setblock -16 69 0 minecraft:sea_lantern
setblock 16 69 0 minecraft:sea_lantern
setblock -16 69 1 minecraft:deepslate_tiles
setblock 16 69 1 minecraft:deepslate_tiles
setblock -16 69 2 minecraft:deepslate_tiles
setblock 16 69 2 minecraft:deepslate_tiles
setblock -16 69 3 minecraft:deepslate_tiles
setblock 16 69 3 minecraft:deepslate_tiles
setblock -16 69 4 minecraft:deepslate_tiles
setblock 16 69 4 minecraft:deepslate_tiles
setblock -16 69 5 minecraft:deepslate_tiles
setblock 16 69 5 minecraft:deepslate_tiles
setblock -15 69 6 minecraft:cyan_stained_glass
setblock 15 69 6 minecraft:cyan_stained_glass
setblock -16 69 6 minecraft:sea_lantern
setblock 16 69 6 minecraft:sea_lantern
setblock -16 69 7 minecraft:deepslate_tiles
setblock 16 69 7 minecraft:deepslate_tiles
setblock -16 69 8 minecraft:deepslate_tiles
setblock 16 69 8 minecraft:deepslate_tiles
setblock -16 69 9 minecraft:deepslate_tiles
setblock 16 69 9 minecraft:deepslate_tiles
setblock -16 69 10 minecraft:deepslate_tiles
setblock 16 69 10 minecraft:deepslate_tiles
setblock -16 69 11 minecraft:deepslate_tiles
setblock 16 69 11 minecraft:deepslate_tiles
setblock -15 69 12 minecraft:cyan_stained_glass
setblock 15 69 12 minecraft:cyan_stained_glass
setblock -16 69 12 minecraft:sea_lantern
setblock 16 69 12 minecraft:sea_lantern
setblock -16 69 13 minecraft:deepslate_tiles
setblock 16 69 13 minecraft:deepslate_tiles
setblock -16 69 14 minecraft:deepslate_tiles
setblock 16 69 14 minecraft:deepslate_tiles
setblock -12 69 15 minecraft:cyan_stained_glass
setblock -6 69 15 minecraft:cyan_stained_glass
setblock 0 69 15 minecraft:cyan_stained_glass
setblock 6 69 15 minecraft:cyan_stained_glass
setblock 12 69 15 minecraft:cyan_stained_glass
setblock -16 69 15 minecraft:deepslate_tiles
setblock 16 69 15 minecraft:deepslate_tiles
fill -16 69 16 -13 69 16 minecraft:deepslate_tiles
fill -11 69 16 -7 69 16 minecraft:deepslate_tiles
fill -5 69 16 -1 69 16 minecraft:deepslate_tiles
fill 1 69 16 5 69 16 minecraft:deepslate_tiles
fill 7 69 16 11 69 16 minecraft:deepslate_tiles
fill 13 69 16 16 69 16 minecraft:deepslate_tiles
setblock -12 69 16 minecraft:sea_lantern
setblock -6 69 16 minecraft:sea_lantern
setblock 0 69 16 minecraft:sea_lantern
setblock 6 69 16 minecraft:sea_lantern
setblock 12 69 16 minecraft:sea_lantern
fill -16 70 -16 -13 70 -16 minecraft:deepslate_tiles
fill -11 70 -16 -7 70 -16 minecraft:deepslate_tiles
fill -5 70 -16 -1 70 -16 minecraft:deepslate_tiles
fill 1 70 -16 5 70 -16 minecraft:deepslate_tiles
fill 7 70 -16 11 70 -16 minecraft:deepslate_tiles
fill 13 70 -16 16 70 -16 minecraft:deepslate_tiles
setblock -12 70 -16 minecraft:sea_lantern
setblock -6 70 -16 minecraft:sea_lantern
setblock 0 70 -16 minecraft:sea_lantern
setblock 6 70 -16 minecraft:sea_lantern
setblock 12 70 -16 minecraft:sea_lantern
setblock -12 70 -15 minecraft:cyan_stained_glass
setblock -6 70 -15 minecraft:cyan_stained_glass
setblock 0 70 -15 minecraft:cyan_stained_glass
setblock 6 70 -15 minecraft:cyan_stained_glass
setblock 12 70 -15 minecraft:cyan_stained_glass
setblock -16 70 -15 minecraft:deepslate_tiles
setblock 16 70 -15 minecraft:deepslate_tiles
setblock -16 70 -14 minecraft:deepslate_tiles
setblock 16 70 -14 minecraft:deepslate_tiles
setblock -16 70 -13 minecraft:deepslate_tiles
setblock 16 70 -13 minecraft:deepslate_tiles
setblock -15 70 -12 minecraft:cyan_stained_glass
setblock 15 70 -12 minecraft:cyan_stained_glass
setblock -16 70 -12 minecraft:sea_lantern
setblock 16 70 -12 minecraft:sea_lantern
setblock -16 70 -11 minecraft:deepslate_tiles
setblock 16 70 -11 minecraft:deepslate_tiles
setblock -16 70 -10 minecraft:deepslate_tiles
setblock 16 70 -10 minecraft:deepslate_tiles
setblock -16 70 -9 minecraft:deepslate_tiles
setblock 16 70 -9 minecraft:deepslate_tiles
setblock -16 70 -8 minecraft:deepslate_tiles
setblock 16 70 -8 minecraft:deepslate_tiles
setblock -16 70 -7 minecraft:deepslate_tiles
setblock 16 70 -7 minecraft:deepslate_tiles
setblock -15 70 -6 minecraft:cyan_stained_glass
setblock 15 70 -6 minecraft:cyan_stained_glass
setblock -16 70 -6 minecraft:sea_lantern
setblock 16 70 -6 minecraft:sea_lantern
setblock -16 70 -5 minecraft:deepslate_tiles
setblock 16 70 -5 minecraft:deepslate_tiles
setblock -16 70 -4 minecraft:deepslate_tiles
setblock 16 70 -4 minecraft:deepslate_tiles
setblock -16 70 -3 minecraft:deepslate_tiles
setblock 16 70 -3 minecraft:deepslate_tiles
setblock -16 70 -2 minecraft:deepslate_tiles
setblock 16 70 -2 minecraft:deepslate_tiles
setblock -16 70 -1 minecraft:deepslate_tiles
setblock 16 70 -1 minecraft:deepslate_tiles
setblock -15 70 0 minecraft:cyan_stained_glass
setblock 15 70 0 minecraft:cyan_stained_glass
setblock -16 70 0 minecraft:sea_lantern
setblock 16 70 0 minecraft:sea_lantern
setblock -16 70 1 minecraft:deepslate_tiles
setblock 16 70 1 minecraft:deepslate_tiles
setblock -16 70 2 minecraft:deepslate_tiles
setblock 16 70 2 minecraft:deepslate_tiles
setblock -16 70 3 minecraft:deepslate_tiles
setblock 16 70 3 minecraft:deepslate_tiles
setblock -16 70 4 minecraft:deepslate_tiles
setblock 16 70 4 minecraft:deepslate_tiles
setblock -16 70 5 minecraft:deepslate_tiles
setblock 16 70 5 minecraft:deepslate_tiles
setblock -15 70 6 minecraft:cyan_stained_glass
setblock 15 70 6 minecraft:cyan_stained_glass
setblock -16 70 6 minecraft:sea_lantern
setblock 16 70 6 minecraft:sea_lantern
setblock -16 70 7 minecraft:deepslate_tiles
setblock 16 70 7 minecraft:deepslate_tiles
setblock -16 70 8 minecraft:deepslate_tiles
setblock 16 70 8 minecraft:deepslate_tiles
setblock -16 70 9 minecraft:deepslate_tiles
setblock 16 70 9 minecraft:deepslate_tiles
setblock -16 70 10 minecraft:deepslate_tiles
setblock 16 70 10 minecraft:deepslate_tiles
setblock -16 70 11 minecraft:deepslate_tiles
setblock 16 70 11 minecraft:deepslate_tiles
setblock -15 70 12 minecraft:cyan_stained_glass
setblock 15 70 12 minecraft:cyan_stained_glass
setblock -16 70 12 minecraft:sea_lantern
setblock 16 70 12 minecraft:sea_lantern
setblock -16 70 13 minecraft:deepslate_tiles
setblock 16 70 13 minecraft:deepslate_tiles
setblock -16 70 14 minecraft:deepslate_tiles
setblock 16 70 14 minecraft:deepslate_tiles
setblock -12 70 15 minecraft:cyan_stained_glass
setblock -6 70 15 minecraft:cyan_stained_glass
setblock 0 70 15 minecraft:cyan_stained_glass
setblock 6 70 15 minecraft:cyan_stained_glass
setblock 12 70 15 minecraft:cyan_stained_glass
setblock -16 70 15 minecraft:deepslate_tiles
setblock 16 70 15 minecraft:deepslate_tiles
fill -16 70 16 -13 70 16 minecraft:deepslate_tiles
fill -11 70 16 -7 70 16 minecraft:deepslate_tiles
fill -5 70 16 -1 70 16 minecraft:deepslate_tiles
fill 1 70 16 5 70 16 minecraft:deepslate_tiles
fill 7 70 16 11 70 16 minecraft:deepslate_tiles
fill 13 70 16 16 70 16 minecraft:deepslate_tiles
setblock -12 70 16 minecraft:sea_lantern
setblock -6 70 16 minecraft:sea_lantern
setblock 0 70 16 minecraft:sea_lantern
setblock 6 70 16 minecraft:sea_lantern
setblock 12 70 16 minecraft:sea_lantern
fill -16 71 -16 -13 71 -16 minecraft:deepslate_tiles
fill -11 71 -16 -7 71 -16 minecraft:deepslate_tiles
fill -5 71 -16 -1 71 -16 minecraft:deepslate_tiles
fill 1 71 -16 5 71 -16 minecraft:deepslate_tiles
fill 7 71 -16 11 71 -16 minecraft:deepslate_tiles
fill 13 71 -16 16 71 -16 minecraft:deepslate_tiles
setblock -12 71 -16 minecraft:sea_lantern
setblock -6 71 -16 minecraft:sea_lantern
setblock 0 71 -16 minecraft:sea_lantern
setblock 6 71 -16 minecraft:sea_lantern
setblock 12 71 -16 minecraft:sea_lantern
setblock -12 71 -15 minecraft:cyan_stained_glass
setblock -6 71 -15 minecraft:cyan_stained_glass
setblock 0 71 -15 minecraft:cyan_stained_glass
setblock 6 71 -15 minecraft:cyan_stained_glass
setblock 12 71 -15 minecraft:cyan_stained_glass
setblock -16 71 -15 minecraft:deepslate_tiles
setblock 16 71 -15 minecraft:deepslate_tiles
setblock -16 71 -14 minecraft:deepslate_tiles
setblock 16 71 -14 minecraft:deepslate_tiles
setblock -16 71 -13 minecraft:deepslate_tiles
setblock 16 71 -13 minecraft:deepslate_tiles
setblock -15 71 -12 minecraft:cyan_stained_glass
setblock 15 71 -12 minecraft:cyan_stained_glass
setblock -16 71 -12 minecraft:sea_lantern
setblock 16 71 -12 minecraft:sea_lantern
setblock -16 71 -11 minecraft:deepslate_tiles
setblock 16 71 -11 minecraft:deepslate_tiles
setblock -16 71 -10 minecraft:deepslate_tiles
setblock 16 71 -10 minecraft:deepslate_tiles
setblock -16 71 -9 minecraft:deepslate_tiles
setblock 16 71 -9 minecraft:deepslate_tiles
setblock -16 71 -8 minecraft:deepslate_tiles
setblock 16 71 -8 minecraft:deepslate_tiles
setblock -16 71 -7 minecraft:deepslate_tiles
setblock 16 71 -7 minecraft:deepslate_tiles
setblock -15 71 -6 minecraft:cyan_stained_glass
setblock 15 71 -6 minecraft:cyan_stained_glass
setblock -16 71 -6 minecraft:sea_lantern
setblock 16 71 -6 minecraft:sea_lantern
setblock -16 71 -5 minecraft:deepslate_tiles
setblock 16 71 -5 minecraft:deepslate_tiles
setblock -16 71 -4 minecraft:deepslate_tiles
setblock 16 71 -4 minecraft:deepslate_tiles
setblock -16 71 -3 minecraft:deepslate_tiles
setblock 16 71 -3 minecraft:deepslate_tiles
setblock -16 71 -2 minecraft:deepslate_tiles
setblock 16 71 -2 minecraft:deepslate_tiles
setblock -16 71 -1 minecraft:deepslate_tiles
setblock 16 71 -1 minecraft:deepslate_tiles
setblock -15 71 0 minecraft:cyan_stained_glass
setblock 15 71 0 minecraft:cyan_stained_glass
setblock -16 71 0 minecraft:sea_lantern
setblock 16 71 0 minecraft:sea_lantern
setblock -16 71 1 minecraft:deepslate_tiles
setblock 16 71 1 minecraft:deepslate_tiles
setblock -16 71 2 minecraft:deepslate_tiles
setblock 16 71 2 minecraft:deepslate_tiles
setblock -16 71 3 minecraft:deepslate_tiles
setblock 16 71 3 minecraft:deepslate_tiles
setblock -16 71 4 minecraft:deepslate_tiles
setblock 16 71 4 minecraft:deepslate_tiles
setblock -16 71 5 minecraft:deepslate_tiles
setblock 16 71 5 minecraft:deepslate_tiles
setblock -15 71 6 minecraft:cyan_stained_glass
setblock 15 71 6 minecraft:cyan_stained_glass
setblock -16 71 6 minecraft:sea_lantern
setblock 16 71 6 minecraft:sea_lantern
setblock -16 71 7 minecraft:deepslate_tiles
setblock 16 71 7 minecraft:deepslate_tiles
setblock -16 71 8 minecraft:deepslate_tiles
setblock 16 71 8 minecraft:deepslate_tiles
setblock -16 71 9 minecraft:deepslate_tiles
setblock 16 71 9 minecraft:deepslate_tiles
setblock -16 71 10 minecraft:deepslate_tiles
setblock 16 71 10 minecraft:deepslate_tiles
setblock -16 71 11 minecraft:deepslate_tiles
setblock 16 71 11 minecraft:deepslate_tiles
setblock -15 71 12 minecraft:cyan_stained_glass
setblock 15 71 12 minecraft:cyan_stained_glass
setblock -16 71 12 minecraft:sea_lantern
setblock 16 71 12 minecraft:sea_lantern
setblock -16 71 13 minecraft:deepslate_tiles
setblock 16 71 13 minecraft:deepslate_tiles
setblock -16 71 14 minecraft:deepslate_tiles
setblock 16 71 14 minecraft:deepslate_tiles
setblock -12 71 15 minecraft:cyan_stained_glass
setblock -6 71 15 minecraft:cyan_stained_glass
setblock 0 71 15 minecraft:cyan_stained_glass
setblock 6 71 15 minecraft:cyan_stained_glass
setblock 12 71 15 minecraft:cyan_stained_glass
setblock -16 71 15 minecraft:deepslate_tiles
setblock 16 71 15 minecraft:deepslate_tiles
fill -16 71 16 -13 71 16 minecraft:deepslate_tiles
fill -11 71 16 -7 71 16 minecraft:deepslate_tiles
fill -5 71 16 -1 71 16 minecraft:deepslate_tiles
fill 1 71 16 5 71 16 minecraft:deepslate_tiles
fill 7 71 16 11 71 16 minecraft:deepslate_tiles
fill 13 71 16 16 71 16 minecraft:deepslate_tiles
setblock -12 71 16 minecraft:sea_lantern
setblock -6 71 16 minecraft:sea_lantern
setblock 0 71 16 minecraft:sea_lantern
setblock 6 71 16 minecraft:sea_lantern
setblock 12 71 16 minecraft:sea_lantern
fill -16 72 -16 -13 72 -16 minecraft:deepslate_tiles
fill -11 72 -16 -7 72 -16 minecraft:deepslate_tiles
fill -5 72 -16 -1 72 -16 minecraft:deepslate_tiles
fill 1 72 -16 5 72 -16 minecraft:deepslate_tiles
fill 7 72 -16 11 72 -16 minecraft:deepslate_tiles
fill 13 72 -16 16 72 -16 minecraft:deepslate_tiles
setblock -12 72 -16 minecraft:sea_lantern
setblock -6 72 -16 minecraft:sea_lantern
setblock 0 72 -16 minecraft:sea_lantern
setblock 6 72 -16 minecraft:sea_lantern
setblock 12 72 -16 minecraft:sea_lantern
setblock -12 72 -15 minecraft:cyan_stained_glass
setblock -6 72 -15 minecraft:cyan_stained_glass
setblock 0 72 -15 minecraft:cyan_stained_glass
setblock 6 72 -15 minecraft:cyan_stained_glass
setblock 12 72 -15 minecraft:cyan_stained_glass
setblock -16 72 -15 minecraft:deepslate_tiles
setblock 16 72 -15 minecraft:deepslate_tiles
setblock -16 72 -14 minecraft:deepslate_tiles
setblock 16 72 -14 minecraft:deepslate_tiles
setblock -4 72 -14 minecraft:waxed_cut_copper
setblock 4 72 -14 minecraft:waxed_cut_copper
setblock -16 72 -13 minecraft:deepslate_tiles
setblock 16 72 -13 minecraft:deepslate_tiles
setblock -15 72 -12 minecraft:cyan_stained_glass
setblock 15 72 -12 minecraft:cyan_stained_glass
setblock -16 72 -12 minecraft:sea_lantern
setblock 16 72 -12 minecraft:sea_lantern
setblock -16 72 -11 minecraft:deepslate_tiles
setblock 16 72 -11 minecraft:deepslate_tiles
setblock -16 72 -10 minecraft:deepslate_tiles
setblock 16 72 -10 minecraft:deepslate_tiles
setblock -16 72 -9 minecraft:deepslate_tiles
setblock 16 72 -9 minecraft:deepslate_tiles
setblock -16 72 -8 minecraft:deepslate_tiles
setblock 16 72 -8 minecraft:deepslate_tiles
setblock -16 72 -7 minecraft:deepslate_tiles
setblock 16 72 -7 minecraft:deepslate_tiles
setblock -15 72 -6 minecraft:cyan_stained_glass
setblock 15 72 -6 minecraft:cyan_stained_glass
setblock -16 72 -6 minecraft:sea_lantern
setblock 16 72 -6 minecraft:sea_lantern
setblock -16 72 -5 minecraft:deepslate_tiles
setblock 16 72 -5 minecraft:deepslate_tiles
setblock -16 72 -4 minecraft:deepslate_tiles
setblock 16 72 -4 minecraft:deepslate_tiles
setblock -16 72 -3 minecraft:deepslate_tiles
setblock 16 72 -3 minecraft:deepslate_tiles
setblock -16 72 -2 minecraft:deepslate_tiles
setblock 16 72 -2 minecraft:deepslate_tiles
setblock -16 72 -1 minecraft:deepslate_tiles
setblock 16 72 -1 minecraft:deepslate_tiles
setblock -15 72 0 minecraft:cyan_stained_glass
setblock 15 72 0 minecraft:cyan_stained_glass
setblock -16 72 0 minecraft:sea_lantern
setblock 16 72 0 minecraft:sea_lantern
setblock -16 72 1 minecraft:deepslate_tiles
setblock 16 72 1 minecraft:deepslate_tiles
setblock -16 72 2 minecraft:deepslate_tiles
setblock 16 72 2 minecraft:deepslate_tiles
setblock -16 72 3 minecraft:deepslate_tiles
setblock 16 72 3 minecraft:deepslate_tiles
setblock -16 72 4 minecraft:deepslate_tiles
setblock 16 72 4 minecraft:deepslate_tiles
setblock -16 72 5 minecraft:deepslate_tiles
setblock 16 72 5 minecraft:deepslate_tiles
setblock -15 72 6 minecraft:cyan_stained_glass
setblock 15 72 6 minecraft:cyan_stained_glass
setblock -16 72 6 minecraft:sea_lantern
setblock 16 72 6 minecraft:sea_lantern
setblock -16 72 7 minecraft:deepslate_tiles
setblock 16 72 7 minecraft:deepslate_tiles
setblock -16 72 8 minecraft:deepslate_tiles
setblock 16 72 8 minecraft:deepslate_tiles
setblock -16 72 9 minecraft:deepslate_tiles
setblock 16 72 9 minecraft:deepslate_tiles
setblock -16 72 10 minecraft:deepslate_tiles
setblock 16 72 10 minecraft:deepslate_tiles
setblock -16 72 11 minecraft:deepslate_tiles
setblock 16 72 11 minecraft:deepslate_tiles
setblock -15 72 12 minecraft:cyan_stained_glass
setblock 15 72 12 minecraft:cyan_stained_glass
setblock -16 72 12 minecraft:sea_lantern
setblock 16 72 12 minecraft:sea_lantern
setblock -16 72 13 minecraft:deepslate_tiles
setblock 16 72 13 minecraft:deepslate_tiles
setblock -16 72 14 minecraft:deepslate_tiles
setblock 16 72 14 minecraft:deepslate_tiles
setblock -12 72 15 minecraft:cyan_stained_glass
setblock -6 72 15 minecraft:cyan_stained_glass
setblock 0 72 15 minecraft:cyan_stained_glass
setblock 6 72 15 minecraft:cyan_stained_glass
setblock 12 72 15 minecraft:cyan_stained_glass
setblock -16 72 15 minecraft:deepslate_tiles
setblock 16 72 15 minecraft:deepslate_tiles
fill -16 72 16 -13 72 16 minecraft:deepslate_tiles
fill -11 72 16 -7 72 16 minecraft:deepslate_tiles
fill -5 72 16 -1 72 16 minecraft:deepslate_tiles
fill 1 72 16 5 72 16 minecraft:deepslate_tiles
fill 7 72 16 11 72 16 minecraft:deepslate_tiles
fill 13 72 16 16 72 16 minecraft:deepslate_tiles
setblock -12 72 16 minecraft:sea_lantern
setblock -6 72 16 minecraft:sea_lantern
setblock 0 72 16 minecraft:sea_lantern
setblock 6 72 16 minecraft:sea_lantern
setblock 12 72 16 minecraft:sea_lantern
fill -16 73 -16 -13 73 -16 minecraft:deepslate_tiles
fill -11 73 -16 -7 73 -16 minecraft:deepslate_tiles
fill -5 73 -16 -1 73 -16 minecraft:deepslate_tiles
fill 1 73 -16 5 73 -16 minecraft:deepslate_tiles
fill 7 73 -16 11 73 -16 minecraft:deepslate_tiles
fill 13 73 -16 16 73 -16 minecraft:deepslate_tiles
setblock -12 73 -16 minecraft:sea_lantern
setblock -6 73 -16 minecraft:sea_lantern
setblock 0 73 -16 minecraft:sea_lantern
setblock 6 73 -16 minecraft:sea_lantern
setblock 12 73 -16 minecraft:sea_lantern
setblock -12 73 -15 minecraft:cyan_stained_glass
setblock -6 73 -15 minecraft:cyan_stained_glass
setblock 0 73 -15 minecraft:cyan_stained_glass
setblock 6 73 -15 minecraft:cyan_stained_glass
setblock 12 73 -15 minecraft:cyan_stained_glass
setblock -16 73 -15 minecraft:deepslate_tiles
setblock 16 73 -15 minecraft:deepslate_tiles
setblock -16 73 -14 minecraft:deepslate_tiles
setblock 16 73 -14 minecraft:deepslate_tiles
setblock -5 73 -14 minecraft:waxed_cut_copper
setblock 5 73 -14 minecraft:waxed_cut_copper
setblock -16 73 -13 minecraft:deepslate_tiles
setblock 16 73 -13 minecraft:deepslate_tiles
setblock -15 73 -12 minecraft:cyan_stained_glass
setblock 15 73 -12 minecraft:cyan_stained_glass
setblock -16 73 -12 minecraft:sea_lantern
setblock 16 73 -12 minecraft:sea_lantern
setblock -16 73 -11 minecraft:deepslate_tiles
setblock 16 73 -11 minecraft:deepslate_tiles
setblock -16 73 -10 minecraft:deepslate_tiles
setblock 16 73 -10 minecraft:deepslate_tiles
setblock -16 73 -9 minecraft:deepslate_tiles
setblock 16 73 -9 minecraft:deepslate_tiles
setblock -16 73 -8 minecraft:deepslate_tiles
setblock 16 73 -8 minecraft:deepslate_tiles
setblock -16 73 -7 minecraft:deepslate_tiles
setblock 16 73 -7 minecraft:deepslate_tiles
setblock -15 73 -6 minecraft:cyan_stained_glass
setblock 15 73 -6 minecraft:cyan_stained_glass
setblock -16 73 -6 minecraft:sea_lantern
setblock 16 73 -6 minecraft:sea_lantern
setblock -16 73 -5 minecraft:deepslate_tiles
setblock 16 73 -5 minecraft:deepslate_tiles
setblock -16 73 -4 minecraft:deepslate_tiles
setblock 16 73 -4 minecraft:deepslate_tiles
setblock -16 73 -3 minecraft:deepslate_tiles
setblock 16 73 -3 minecraft:deepslate_tiles
setblock -16 73 -2 minecraft:deepslate_tiles
setblock 16 73 -2 minecraft:deepslate_tiles
setblock -16 73 -1 minecraft:deepslate_tiles
setblock 16 73 -1 minecraft:deepslate_tiles
setblock -15 73 0 minecraft:cyan_stained_glass
setblock 15 73 0 minecraft:cyan_stained_glass
setblock -16 73 0 minecraft:sea_lantern
setblock 16 73 0 minecraft:sea_lantern
setblock -16 73 1 minecraft:deepslate_tiles
setblock 16 73 1 minecraft:deepslate_tiles
setblock -16 73 2 minecraft:deepslate_tiles
setblock 16 73 2 minecraft:deepslate_tiles
setblock -16 73 3 minecraft:deepslate_tiles
setblock 16 73 3 minecraft:deepslate_tiles
setblock -16 73 4 minecraft:deepslate_tiles
setblock 16 73 4 minecraft:deepslate_tiles
setblock -16 73 5 minecraft:deepslate_tiles
setblock 16 73 5 minecraft:deepslate_tiles
setblock -15 73 6 minecraft:cyan_stained_glass
setblock 15 73 6 minecraft:cyan_stained_glass
setblock -16 73 6 minecraft:sea_lantern
setblock 16 73 6 minecraft:sea_lantern
setblock -16 73 7 minecraft:deepslate_tiles
setblock 16 73 7 minecraft:deepslate_tiles
setblock -16 73 8 minecraft:deepslate_tiles
setblock 16 73 8 minecraft:deepslate_tiles
setblock -16 73 9 minecraft:deepslate_tiles
setblock 16 73 9 minecraft:deepslate_tiles
setblock -16 73 10 minecraft:deepslate_tiles
setblock 16 73 10 minecraft:deepslate_tiles
setblock -16 73 11 minecraft:deepslate_tiles
setblock 16 73 11 minecraft:deepslate_tiles
setblock -15 73 12 minecraft:cyan_stained_glass
setblock 15 73 12 minecraft:cyan_stained_glass
setblock -16 73 12 minecraft:sea_lantern
setblock 16 73 12 minecraft:sea_lantern
setblock -16 73 13 minecraft:deepslate_tiles
setblock 16 73 13 minecraft:deepslate_tiles
setblock -16 73 14 minecraft:deepslate_tiles
setblock 16 73 14 minecraft:deepslate_tiles
setblock -12 73 15 minecraft:cyan_stained_glass
setblock -6 73 15 minecraft:cyan_stained_glass
setblock 0 73 15 minecraft:cyan_stained_glass
setblock 6 73 15 minecraft:cyan_stained_glass
setblock 12 73 15 minecraft:cyan_stained_glass
setblock -16 73 15 minecraft:deepslate_tiles
setblock 16 73 15 minecraft:deepslate_tiles
fill -16 73 16 -13 73 16 minecraft:deepslate_tiles
fill -11 73 16 -7 73 16 minecraft:deepslate_tiles
fill -5 73 16 -1 73 16 minecraft:deepslate_tiles
fill 1 73 16 5 73 16 minecraft:deepslate_tiles
fill 7 73 16 11 73 16 minecraft:deepslate_tiles
fill 13 73 16 16 73 16 minecraft:deepslate_tiles
setblock -12 73 16 minecraft:sea_lantern
setblock -6 73 16 minecraft:sea_lantern
setblock 0 73 16 minecraft:sea_lantern
setblock 6 73 16 minecraft:sea_lantern
setblock 12 73 16 minecraft:sea_lantern
fill -16 74 -16 -13 74 -16 minecraft:deepslate_tiles
fill -11 74 -16 -7 74 -16 minecraft:deepslate_tiles
fill -5 74 -16 -1 74 -16 minecraft:deepslate_tiles
fill 1 74 -16 5 74 -16 minecraft:deepslate_tiles
fill 7 74 -16 11 74 -16 minecraft:deepslate_tiles
fill 13 74 -16 16 74 -16 minecraft:deepslate_tiles
setblock -12 74 -16 minecraft:sea_lantern
setblock -6 74 -16 minecraft:sea_lantern
setblock 0 74 -16 minecraft:sea_lantern
setblock 6 74 -16 minecraft:sea_lantern
setblock 12 74 -16 minecraft:sea_lantern
setblock -12 74 -15 minecraft:cyan_stained_glass
setblock -6 74 -15 minecraft:cyan_stained_glass
setblock 0 74 -15 minecraft:cyan_stained_glass
setblock 6 74 -15 minecraft:cyan_stained_glass
setblock 12 74 -15 minecraft:cyan_stained_glass
setblock -16 74 -15 minecraft:deepslate_tiles
setblock 16 74 -15 minecraft:deepslate_tiles
setblock -16 74 -14 minecraft:deepslate_tiles
setblock 16 74 -14 minecraft:deepslate_tiles
setblock -6 74 -14 minecraft:waxed_cut_copper
setblock 6 74 -14 minecraft:waxed_cut_copper
setblock -16 74 -13 minecraft:deepslate_tiles
setblock 16 74 -13 minecraft:deepslate_tiles
setblock -15 74 -12 minecraft:cyan_stained_glass
setblock 15 74 -12 minecraft:cyan_stained_glass
setblock -16 74 -12 minecraft:sea_lantern
setblock 16 74 -12 minecraft:sea_lantern
setblock -16 74 -11 minecraft:deepslate_tiles
setblock 16 74 -11 minecraft:deepslate_tiles
setblock -16 74 -10 minecraft:deepslate_tiles
setblock 16 74 -10 minecraft:deepslate_tiles
setblock -16 74 -9 minecraft:deepslate_tiles
setblock 16 74 -9 minecraft:deepslate_tiles
setblock -16 74 -8 minecraft:deepslate_tiles
setblock 16 74 -8 minecraft:deepslate_tiles
setblock -16 74 -7 minecraft:deepslate_tiles
setblock 16 74 -7 minecraft:deepslate_tiles
setblock -15 74 -6 minecraft:cyan_stained_glass
setblock 15 74 -6 minecraft:cyan_stained_glass
setblock -16 74 -6 minecraft:sea_lantern
setblock 16 74 -6 minecraft:sea_lantern
setblock -16 74 -5 minecraft:deepslate_tiles
setblock 16 74 -5 minecraft:deepslate_tiles
setblock -16 74 -4 minecraft:deepslate_tiles
setblock 16 74 -4 minecraft:deepslate_tiles
setblock -16 74 -3 minecraft:deepslate_tiles
setblock 16 74 -3 minecraft:deepslate_tiles
setblock -16 74 -2 minecraft:deepslate_tiles
setblock 16 74 -2 minecraft:deepslate_tiles
setblock -16 74 -1 minecraft:deepslate_tiles
setblock 16 74 -1 minecraft:deepslate_tiles
setblock -15 74 0 minecraft:cyan_stained_glass
setblock 15 74 0 minecraft:cyan_stained_glass
setblock -16 74 0 minecraft:sea_lantern
setblock 16 74 0 minecraft:sea_lantern
setblock -16 74 1 minecraft:deepslate_tiles
setblock 16 74 1 minecraft:deepslate_tiles
setblock -16 74 2 minecraft:deepslate_tiles
setblock 16 74 2 minecraft:deepslate_tiles
setblock -16 74 3 minecraft:deepslate_tiles
setblock 16 74 3 minecraft:deepslate_tiles
setblock -16 74 4 minecraft:deepslate_tiles
setblock 16 74 4 minecraft:deepslate_tiles
setblock -16 74 5 minecraft:deepslate_tiles
setblock 16 74 5 minecraft:deepslate_tiles
setblock -15 74 6 minecraft:cyan_stained_glass
setblock 15 74 6 minecraft:cyan_stained_glass
setblock -16 74 6 minecraft:sea_lantern
setblock 16 74 6 minecraft:sea_lantern
setblock -16 74 7 minecraft:deepslate_tiles
setblock 16 74 7 minecraft:deepslate_tiles
setblock -16 74 8 minecraft:deepslate_tiles
setblock 16 74 8 minecraft:deepslate_tiles
setblock -16 74 9 minecraft:deepslate_tiles
setblock 16 74 9 minecraft:deepslate_tiles
setblock -16 74 10 minecraft:deepslate_tiles
setblock 16 74 10 minecraft:deepslate_tiles
setblock -16 74 11 minecraft:deepslate_tiles
setblock 16 74 11 minecraft:deepslate_tiles
setblock -15 74 12 minecraft:cyan_stained_glass
setblock 15 74 12 minecraft:cyan_stained_glass
setblock -16 74 12 minecraft:sea_lantern
setblock 16 74 12 minecraft:sea_lantern
setblock -16 74 13 minecraft:deepslate_tiles
setblock 16 74 13 minecraft:deepslate_tiles
setblock -16 74 14 minecraft:deepslate_tiles
setblock 16 74 14 minecraft:deepslate_tiles
setblock -12 74 15 minecraft:cyan_stained_glass
setblock -6 74 15 minecraft:cyan_stained_glass
setblock 0 74 15 minecraft:cyan_stained_glass
setblock 6 74 15 minecraft:cyan_stained_glass
setblock 12 74 15 minecraft:cyan_stained_glass
setblock -16 74 15 minecraft:deepslate_tiles
setblock 16 74 15 minecraft:deepslate_tiles
fill -16 74 16 -13 74 16 minecraft:deepslate_tiles
fill -11 74 16 -7 74 16 minecraft:deepslate_tiles
fill -5 74 16 -1 74 16 minecraft:deepslate_tiles
fill 1 74 16 5 74 16 minecraft:deepslate_tiles
fill 7 74 16 11 74 16 minecraft:deepslate_tiles
fill 13 74 16 16 74 16 minecraft:deepslate_tiles
setblock -12 74 16 minecraft:sea_lantern
setblock -6 74 16 minecraft:sea_lantern
setblock 0 74 16 minecraft:sea_lantern
setblock 6 74 16 minecraft:sea_lantern
setblock 12 74 16 minecraft:sea_lantern
fill -16 75 -16 -13 75 -16 minecraft:deepslate_tiles
fill -11 75 -16 -7 75 -16 minecraft:deepslate_tiles
fill -5 75 -16 -1 75 -16 minecraft:deepslate_tiles
fill 1 75 -16 5 75 -16 minecraft:deepslate_tiles
fill 7 75 -16 11 75 -16 minecraft:deepslate_tiles
fill 13 75 -16 16 75 -16 minecraft:deepslate_tiles
setblock -12 75 -16 minecraft:sea_lantern
setblock -6 75 -16 minecraft:sea_lantern
setblock 0 75 -16 minecraft:sea_lantern
setblock 6 75 -16 minecraft:sea_lantern
setblock 12 75 -16 minecraft:sea_lantern
setblock -12 75 -15 minecraft:cyan_stained_glass
setblock -6 75 -15 minecraft:cyan_stained_glass
setblock 0 75 -15 minecraft:cyan_stained_glass
setblock 6 75 -15 minecraft:cyan_stained_glass
setblock 12 75 -15 minecraft:cyan_stained_glass
setblock -16 75 -15 minecraft:deepslate_tiles
setblock 16 75 -15 minecraft:deepslate_tiles
setblock -16 75 -14 minecraft:deepslate_tiles
setblock 16 75 -14 minecraft:deepslate_tiles
fill -1 75 -14 1 75 -14 minecraft:sea_lantern
setblock -6 75 -14 minecraft:waxed_cut_copper
setblock 6 75 -14 minecraft:waxed_cut_copper
setblock -16 75 -13 minecraft:deepslate_tiles
setblock 16 75 -13 minecraft:deepslate_tiles
setblock -15 75 -12 minecraft:cyan_stained_glass
setblock 15 75 -12 minecraft:cyan_stained_glass
setblock -16 75 -12 minecraft:sea_lantern
setblock 16 75 -12 minecraft:sea_lantern
setblock -16 75 -11 minecraft:deepslate_tiles
setblock 16 75 -11 minecraft:deepslate_tiles
setblock -16 75 -10 minecraft:deepslate_tiles
setblock 16 75 -10 minecraft:deepslate_tiles
setblock -16 75 -9 minecraft:deepslate_tiles
setblock 16 75 -9 minecraft:deepslate_tiles
setblock -16 75 -8 minecraft:deepslate_tiles
setblock 16 75 -8 minecraft:deepslate_tiles
setblock -16 75 -7 minecraft:deepslate_tiles
setblock 16 75 -7 minecraft:deepslate_tiles
setblock -15 75 -6 minecraft:cyan_stained_glass
setblock 15 75 -6 minecraft:cyan_stained_glass
setblock -16 75 -6 minecraft:sea_lantern
setblock 16 75 -6 minecraft:sea_lantern
setblock -16 75 -5 minecraft:deepslate_tiles
setblock 16 75 -5 minecraft:deepslate_tiles
setblock -16 75 -4 minecraft:deepslate_tiles
setblock 16 75 -4 minecraft:deepslate_tiles
setblock -16 75 -3 minecraft:deepslate_tiles
setblock 16 75 -3 minecraft:deepslate_tiles
setblock -16 75 -2 minecraft:deepslate_tiles
setblock 16 75 -2 minecraft:deepslate_tiles
setblock -16 75 -1 minecraft:deepslate_tiles
setblock 16 75 -1 minecraft:deepslate_tiles
setblock -15 75 0 minecraft:cyan_stained_glass
setblock 15 75 0 minecraft:cyan_stained_glass
setblock -16 75 0 minecraft:sea_lantern
setblock 16 75 0 minecraft:sea_lantern
setblock -16 75 1 minecraft:deepslate_tiles
setblock 16 75 1 minecraft:deepslate_tiles
setblock -16 75 2 minecraft:deepslate_tiles
setblock 16 75 2 minecraft:deepslate_tiles
setblock -16 75 3 minecraft:deepslate_tiles
setblock 16 75 3 minecraft:deepslate_tiles
setblock -16 75 4 minecraft:deepslate_tiles
setblock 16 75 4 minecraft:deepslate_tiles
setblock -16 75 5 minecraft:deepslate_tiles
setblock 16 75 5 minecraft:deepslate_tiles
setblock -15 75 6 minecraft:cyan_stained_glass
setblock 15 75 6 minecraft:cyan_stained_glass
setblock -16 75 6 minecraft:sea_lantern
setblock 16 75 6 minecraft:sea_lantern
setblock -16 75 7 minecraft:deepslate_tiles
setblock 16 75 7 minecraft:deepslate_tiles
setblock -16 75 8 minecraft:deepslate_tiles
setblock 16 75 8 minecraft:deepslate_tiles
setblock -16 75 9 minecraft:deepslate_tiles
setblock 16 75 9 minecraft:deepslate_tiles
setblock -16 75 10 minecraft:deepslate_tiles
setblock 16 75 10 minecraft:deepslate_tiles
setblock -16 75 11 minecraft:deepslate_tiles
setblock 16 75 11 minecraft:deepslate_tiles
setblock -15 75 12 minecraft:cyan_stained_glass
setblock 15 75 12 minecraft:cyan_stained_glass
setblock -16 75 12 minecraft:sea_lantern
setblock 16 75 12 minecraft:sea_lantern
setblock -16 75 13 minecraft:deepslate_tiles
setblock 16 75 13 minecraft:deepslate_tiles
setblock -16 75 14 minecraft:deepslate_tiles
setblock 16 75 14 minecraft:deepslate_tiles
setblock -12 75 15 minecraft:cyan_stained_glass
setblock -6 75 15 minecraft:cyan_stained_glass
setblock 0 75 15 minecraft:cyan_stained_glass
setblock 6 75 15 minecraft:cyan_stained_glass
setblock 12 75 15 minecraft:cyan_stained_glass
setblock -16 75 15 minecraft:deepslate_tiles
setblock 16 75 15 minecraft:deepslate_tiles
fill -16 75 16 -13 75 16 minecraft:deepslate_tiles
fill -11 75 16 -7 75 16 minecraft:deepslate_tiles
fill -5 75 16 -1 75 16 minecraft:deepslate_tiles
fill 1 75 16 5 75 16 minecraft:deepslate_tiles
fill 7 75 16 11 75 16 minecraft:deepslate_tiles
fill 13 75 16 16 75 16 minecraft:deepslate_tiles
setblock -12 75 16 minecraft:sea_lantern
setblock -6 75 16 minecraft:sea_lantern
setblock 0 75 16 minecraft:sea_lantern
setblock 6 75 16 minecraft:sea_lantern
setblock 12 75 16 minecraft:sea_lantern
fill -16 76 -16 -13 76 -16 minecraft:deepslate_tiles
fill -11 76 -16 -7 76 -16 minecraft:deepslate_tiles
fill -5 76 -16 -1 76 -16 minecraft:deepslate_tiles
fill 1 76 -16 5 76 -16 minecraft:deepslate_tiles
fill 7 76 -16 11 76 -16 minecraft:deepslate_tiles
fill 13 76 -16 16 76 -16 minecraft:deepslate_tiles
setblock -12 76 -16 minecraft:sea_lantern
setblock -6 76 -16 minecraft:sea_lantern
setblock 0 76 -16 minecraft:sea_lantern
setblock 6 76 -16 minecraft:sea_lantern
setblock 12 76 -16 minecraft:sea_lantern
setblock -12 76 -15 minecraft:cyan_stained_glass
setblock -6 76 -15 minecraft:cyan_stained_glass
setblock 0 76 -15 minecraft:cyan_stained_glass
setblock 6 76 -15 minecraft:cyan_stained_glass
setblock 12 76 -15 minecraft:cyan_stained_glass
setblock -16 76 -15 minecraft:deepslate_tiles
setblock 16 76 -15 minecraft:deepslate_tiles
setblock -16 76 -14 minecraft:deepslate_tiles
setblock 16 76 -14 minecraft:deepslate_tiles
fill -1 76 -14 1 76 -14 minecraft:sea_lantern
setblock -6 76 -14 minecraft:waxed_cut_copper
setblock 6 76 -14 minecraft:waxed_cut_copper
setblock 0 76 -13 minecraft:cyan_stained_glass
setblock -16 76 -13 minecraft:deepslate_tiles
setblock 16 76 -13 minecraft:deepslate_tiles
setblock -15 76 -12 minecraft:cyan_stained_glass
setblock 15 76 -12 minecraft:cyan_stained_glass
setblock -16 76 -12 minecraft:sea_lantern
setblock 16 76 -12 minecraft:sea_lantern
setblock -16 76 -11 minecraft:deepslate_tiles
setblock 16 76 -11 minecraft:deepslate_tiles
setblock -16 76 -10 minecraft:deepslate_tiles
setblock 16 76 -10 minecraft:deepslate_tiles
setblock -16 76 -9 minecraft:deepslate_tiles
setblock 16 76 -9 minecraft:deepslate_tiles
setblock -16 76 -8 minecraft:deepslate_tiles
setblock 16 76 -8 minecraft:deepslate_tiles
setblock -16 76 -7 minecraft:deepslate_tiles
setblock 16 76 -7 minecraft:deepslate_tiles
setblock -15 76 -6 minecraft:cyan_stained_glass
setblock 15 76 -6 minecraft:cyan_stained_glass
setblock -16 76 -6 minecraft:sea_lantern
setblock 16 76 -6 minecraft:sea_lantern
setblock -16 76 -5 minecraft:deepslate_tiles
setblock 16 76 -5 minecraft:deepslate_tiles
setblock -16 76 -4 minecraft:deepslate_tiles
setblock 16 76 -4 minecraft:deepslate_tiles
setblock -16 76 -3 minecraft:deepslate_tiles
setblock 16 76 -3 minecraft:deepslate_tiles
setblock -16 76 -2 minecraft:deepslate_tiles
setblock 16 76 -2 minecraft:deepslate_tiles
setblock -16 76 -1 minecraft:deepslate_tiles
setblock 16 76 -1 minecraft:deepslate_tiles
setblock -15 76 0 minecraft:cyan_stained_glass
setblock 15 76 0 minecraft:cyan_stained_glass
setblock -16 76 0 minecraft:sea_lantern
setblock 16 76 0 minecraft:sea_lantern
setblock -16 76 1 minecraft:deepslate_tiles
setblock 16 76 1 minecraft:deepslate_tiles
setblock -16 76 2 minecraft:deepslate_tiles
setblock 16 76 2 minecraft:deepslate_tiles
setblock -16 76 3 minecraft:deepslate_tiles
setblock 16 76 3 minecraft:deepslate_tiles
setblock -16 76 4 minecraft:deepslate_tiles
setblock 16 76 4 minecraft:deepslate_tiles
setblock -16 76 5 minecraft:deepslate_tiles
setblock 16 76 5 minecraft:deepslate_tiles
setblock -15 76 6 minecraft:cyan_stained_glass
setblock 15 76 6 minecraft:cyan_stained_glass
setblock -16 76 6 minecraft:sea_lantern
setblock 16 76 6 minecraft:sea_lantern
setblock -16 76 7 minecraft:deepslate_tiles
setblock 16 76 7 minecraft:deepslate_tiles
setblock -16 76 8 minecraft:deepslate_tiles
setblock 16 76 8 minecraft:deepslate_tiles
setblock -16 76 9 minecraft:deepslate_tiles
setblock 16 76 9 minecraft:deepslate_tiles
setblock -16 76 10 minecraft:deepslate_tiles
setblock 16 76 10 minecraft:deepslate_tiles
setblock -16 76 11 minecraft:deepslate_tiles
setblock 16 76 11 minecraft:deepslate_tiles
setblock -15 76 12 minecraft:cyan_stained_glass
setblock 15 76 12 minecraft:cyan_stained_glass
setblock -16 76 12 minecraft:sea_lantern
setblock 16 76 12 minecraft:sea_lantern
setblock -16 76 13 minecraft:deepslate_tiles
setblock 16 76 13 minecraft:deepslate_tiles
setblock -16 76 14 minecraft:deepslate_tiles
setblock 16 76 14 minecraft:deepslate_tiles
setblock -12 76 15 minecraft:cyan_stained_glass
setblock -6 76 15 minecraft:cyan_stained_glass
setblock 0 76 15 minecraft:cyan_stained_glass
setblock 6 76 15 minecraft:cyan_stained_glass
setblock 12 76 15 minecraft:cyan_stained_glass
setblock -16 76 15 minecraft:deepslate_tiles
setblock 16 76 15 minecraft:deepslate_tiles
fill -16 76 16 -13 76 16 minecraft:deepslate_tiles
fill -11 76 16 -7 76 16 minecraft:deepslate_tiles
fill -5 76 16 -1 76 16 minecraft:deepslate_tiles
fill 1 76 16 5 76 16 minecraft:deepslate_tiles
fill 7 76 16 11 76 16 minecraft:deepslate_tiles
fill 13 76 16 16 76 16 minecraft:deepslate_tiles
setblock -12 76 16 minecraft:sea_lantern
setblock -6 76 16 minecraft:sea_lantern
setblock 0 76 16 minecraft:sea_lantern
setblock 6 76 16 minecraft:sea_lantern
setblock 12 76 16 minecraft:sea_lantern
fill -16 77 -16 -13 77 -16 minecraft:deepslate_tiles
fill -11 77 -16 -7 77 -16 minecraft:deepslate_tiles
fill -5 77 -16 -1 77 -16 minecraft:deepslate_tiles
fill 1 77 -16 5 77 -16 minecraft:deepslate_tiles
fill 7 77 -16 11 77 -16 minecraft:deepslate_tiles
fill 13 77 -16 16 77 -16 minecraft:deepslate_tiles
setblock -12 77 -16 minecraft:sea_lantern
setblock -6 77 -16 minecraft:sea_lantern
setblock 0 77 -16 minecraft:sea_lantern
setblock 6 77 -16 minecraft:sea_lantern
setblock 12 77 -16 minecraft:sea_lantern
setblock -12 77 -15 minecraft:cyan_stained_glass
setblock -6 77 -15 minecraft:cyan_stained_glass
setblock 0 77 -15 minecraft:cyan_stained_glass
setblock 6 77 -15 minecraft:cyan_stained_glass
setblock 12 77 -15 minecraft:cyan_stained_glass
setblock -16 77 -15 minecraft:deepslate_tiles
setblock 16 77 -15 minecraft:deepslate_tiles
setblock -16 77 -14 minecraft:deepslate_tiles
setblock 16 77 -14 minecraft:deepslate_tiles
fill -1 77 -14 1 77 -14 minecraft:sea_lantern
setblock -6 77 -14 minecraft:waxed_cut_copper
setblock 6 77 -14 minecraft:waxed_cut_copper
setblock -16 77 -13 minecraft:deepslate_tiles
setblock 16 77 -13 minecraft:deepslate_tiles
setblock -15 77 -12 minecraft:cyan_stained_glass
setblock 15 77 -12 minecraft:cyan_stained_glass
setblock -16 77 -12 minecraft:sea_lantern
setblock 16 77 -12 minecraft:sea_lantern
setblock -16 77 -11 minecraft:deepslate_tiles
setblock 16 77 -11 minecraft:deepslate_tiles
setblock -16 77 -10 minecraft:deepslate_tiles
setblock 16 77 -10 minecraft:deepslate_tiles
setblock -16 77 -9 minecraft:deepslate_tiles
setblock 16 77 -9 minecraft:deepslate_tiles
setblock -16 77 -8 minecraft:deepslate_tiles
setblock 16 77 -8 minecraft:deepslate_tiles
setblock -16 77 -7 minecraft:deepslate_tiles
setblock 16 77 -7 minecraft:deepslate_tiles
setblock -15 77 -6 minecraft:cyan_stained_glass
setblock 15 77 -6 minecraft:cyan_stained_glass
setblock -16 77 -6 minecraft:sea_lantern
setblock 16 77 -6 minecraft:sea_lantern
setblock -16 77 -5 minecraft:deepslate_tiles
setblock 16 77 -5 minecraft:deepslate_tiles
setblock -16 77 -4 minecraft:deepslate_tiles
setblock 16 77 -4 minecraft:deepslate_tiles
setblock -16 77 -3 minecraft:deepslate_tiles
setblock 16 77 -3 minecraft:deepslate_tiles
setblock -16 77 -2 minecraft:deepslate_tiles
setblock 16 77 -2 minecraft:deepslate_tiles
setblock -16 77 -1 minecraft:deepslate_tiles
setblock 16 77 -1 minecraft:deepslate_tiles
setblock -15 77 0 minecraft:cyan_stained_glass
setblock 15 77 0 minecraft:cyan_stained_glass
setblock -16 77 0 minecraft:sea_lantern
setblock 16 77 0 minecraft:sea_lantern
setblock -16 77 1 minecraft:deepslate_tiles
setblock 16 77 1 minecraft:deepslate_tiles
setblock -16 77 2 minecraft:deepslate_tiles
setblock 16 77 2 minecraft:deepslate_tiles
setblock -16 77 3 minecraft:deepslate_tiles
setblock 16 77 3 minecraft:deepslate_tiles
setblock -16 77 4 minecraft:deepslate_tiles
setblock 16 77 4 minecraft:deepslate_tiles
setblock -16 77 5 minecraft:deepslate_tiles
setblock 16 77 5 minecraft:deepslate_tiles
setblock -15 77 6 minecraft:cyan_stained_glass
setblock 15 77 6 minecraft:cyan_stained_glass
setblock -16 77 6 minecraft:sea_lantern
setblock 16 77 6 minecraft:sea_lantern
setblock -16 77 7 minecraft:deepslate_tiles
setblock 16 77 7 minecraft:deepslate_tiles
setblock -16 77 8 minecraft:deepslate_tiles
setblock 16 77 8 minecraft:deepslate_tiles
setblock -16 77 9 minecraft:deepslate_tiles
setblock 16 77 9 minecraft:deepslate_tiles
setblock -16 77 10 minecraft:deepslate_tiles
setblock 16 77 10 minecraft:deepslate_tiles
setblock -16 77 11 minecraft:deepslate_tiles
setblock 16 77 11 minecraft:deepslate_tiles
setblock -15 77 12 minecraft:cyan_stained_glass
setblock 15 77 12 minecraft:cyan_stained_glass
setblock -16 77 12 minecraft:sea_lantern
setblock 16 77 12 minecraft:sea_lantern
setblock -16 77 13 minecraft:deepslate_tiles
setblock 16 77 13 minecraft:deepslate_tiles
setblock -16 77 14 minecraft:deepslate_tiles
setblock 16 77 14 minecraft:deepslate_tiles
setblock -12 77 15 minecraft:cyan_stained_glass
setblock -6 77 15 minecraft:cyan_stained_glass
setblock 0 77 15 minecraft:cyan_stained_glass
setblock 6 77 15 minecraft:cyan_stained_glass
setblock 12 77 15 minecraft:cyan_stained_glass
setblock -16 77 15 minecraft:deepslate_tiles
setblock 16 77 15 minecraft:deepslate_tiles
fill -16 77 16 -13 77 16 minecraft:deepslate_tiles
fill -11 77 16 -7 77 16 minecraft:deepslate_tiles
fill -5 77 16 -1 77 16 minecraft:deepslate_tiles
fill 1 77 16 5 77 16 minecraft:deepslate_tiles
fill 7 77 16 11 77 16 minecraft:deepslate_tiles
fill 13 77 16 16 77 16 minecraft:deepslate_tiles
setblock -12 77 16 minecraft:sea_lantern
setblock -6 77 16 minecraft:sea_lantern
setblock 0 77 16 minecraft:sea_lantern
setblock 6 77 16 minecraft:sea_lantern
setblock 12 77 16 minecraft:sea_lantern
fill -16 78 -16 -13 78 -16 minecraft:deepslate_tiles
fill -11 78 -16 -7 78 -16 minecraft:deepslate_tiles
fill -5 78 -16 -1 78 -16 minecraft:deepslate_tiles
fill 1 78 -16 5 78 -16 minecraft:deepslate_tiles
fill 7 78 -16 11 78 -16 minecraft:deepslate_tiles
fill 13 78 -16 16 78 -16 minecraft:deepslate_tiles
setblock -12 78 -16 minecraft:sea_lantern
setblock -6 78 -16 minecraft:sea_lantern
setblock 0 78 -16 minecraft:sea_lantern
setblock 6 78 -16 minecraft:sea_lantern
setblock 12 78 -16 minecraft:sea_lantern
setblock -12 78 -15 minecraft:cyan_stained_glass
setblock -6 78 -15 minecraft:cyan_stained_glass
setblock 0 78 -15 minecraft:cyan_stained_glass
setblock 6 78 -15 minecraft:cyan_stained_glass
setblock 12 78 -15 minecraft:cyan_stained_glass
setblock -16 78 -15 minecraft:deepslate_tiles
setblock 16 78 -15 minecraft:deepslate_tiles
setblock -16 78 -14 minecraft:deepslate_tiles
setblock 16 78 -14 minecraft:deepslate_tiles
setblock -6 78 -14 minecraft:waxed_cut_copper
setblock 6 78 -14 minecraft:waxed_cut_copper
setblock -16 78 -13 minecraft:deepslate_tiles
setblock 16 78 -13 minecraft:deepslate_tiles
setblock -15 78 -12 minecraft:cyan_stained_glass
setblock 15 78 -12 minecraft:cyan_stained_glass
setblock -16 78 -12 minecraft:sea_lantern
setblock 16 78 -12 minecraft:sea_lantern
setblock -16 78 -11 minecraft:deepslate_tiles
setblock 16 78 -11 minecraft:deepslate_tiles
setblock -16 78 -10 minecraft:deepslate_tiles
setblock 16 78 -10 minecraft:deepslate_tiles
setblock -16 78 -9 minecraft:deepslate_tiles
setblock 16 78 -9 minecraft:deepslate_tiles
setblock -16 78 -8 minecraft:deepslate_tiles
setblock 16 78 -8 minecraft:deepslate_tiles
setblock -16 78 -7 minecraft:deepslate_tiles
setblock 16 78 -7 minecraft:deepslate_tiles
setblock -15 78 -6 minecraft:cyan_stained_glass
setblock 15 78 -6 minecraft:cyan_stained_glass
setblock -16 78 -6 minecraft:sea_lantern
setblock 16 78 -6 minecraft:sea_lantern
setblock -16 78 -5 minecraft:deepslate_tiles
setblock 16 78 -5 minecraft:deepslate_tiles
setblock -16 78 -4 minecraft:deepslate_tiles
setblock 16 78 -4 minecraft:deepslate_tiles
setblock -16 78 -3 minecraft:deepslate_tiles
setblock 16 78 -3 minecraft:deepslate_tiles
setblock -16 78 -2 minecraft:deepslate_tiles
setblock 16 78 -2 minecraft:deepslate_tiles
setblock -16 78 -1 minecraft:deepslate_tiles
setblock 16 78 -1 minecraft:deepslate_tiles
setblock -15 78 0 minecraft:cyan_stained_glass
setblock 15 78 0 minecraft:cyan_stained_glass
setblock -16 78 0 minecraft:sea_lantern
setblock 16 78 0 minecraft:sea_lantern
setblock -16 78 1 minecraft:deepslate_tiles
setblock 16 78 1 minecraft:deepslate_tiles
setblock -16 78 2 minecraft:deepslate_tiles
setblock 16 78 2 minecraft:deepslate_tiles
setblock -16 78 3 minecraft:deepslate_tiles
setblock 16 78 3 minecraft:deepslate_tiles
setblock -16 78 4 minecraft:deepslate_tiles
setblock 16 78 4 minecraft:deepslate_tiles
setblock -16 78 5 minecraft:deepslate_tiles
setblock 16 78 5 minecraft:deepslate_tiles
setblock -15 78 6 minecraft:cyan_stained_glass
setblock 15 78 6 minecraft:cyan_stained_glass
setblock -16 78 6 minecraft:sea_lantern
setblock 16 78 6 minecraft:sea_lantern
setblock -16 78 7 minecraft:deepslate_tiles
setblock 16 78 7 minecraft:deepslate_tiles
setblock -16 78 8 minecraft:deepslate_tiles
setblock 16 78 8 minecraft:deepslate_tiles
setblock -16 78 9 minecraft:deepslate_tiles
setblock 16 78 9 minecraft:deepslate_tiles
setblock -16 78 10 minecraft:deepslate_tiles
setblock 16 78 10 minecraft:deepslate_tiles
setblock -16 78 11 minecraft:deepslate_tiles
setblock 16 78 11 minecraft:deepslate_tiles
setblock -15 78 12 minecraft:cyan_stained_glass
setblock 15 78 12 minecraft:cyan_stained_glass
setblock -16 78 12 minecraft:sea_lantern
setblock 16 78 12 minecraft:sea_lantern
setblock -16 78 13 minecraft:deepslate_tiles
setblock 16 78 13 minecraft:deepslate_tiles
setblock -16 78 14 minecraft:deepslate_tiles
setblock 16 78 14 minecraft:deepslate_tiles
setblock -12 78 15 minecraft:cyan_stained_glass
setblock -6 78 15 minecraft:cyan_stained_glass
setblock 0 78 15 minecraft:cyan_stained_glass
setblock 6 78 15 minecraft:cyan_stained_glass
setblock 12 78 15 minecraft:cyan_stained_glass
setblock -16 78 15 minecraft:deepslate_tiles
setblock 16 78 15 minecraft:deepslate_tiles
fill -16 78 16 -13 78 16 minecraft:deepslate_tiles
fill -11 78 16 -7 78 16 minecraft:deepslate_tiles
fill -5 78 16 -1 78 16 minecraft:deepslate_tiles
fill 1 78 16 5 78 16 minecraft:deepslate_tiles
fill 7 78 16 11 78 16 minecraft:deepslate_tiles
fill 13 78 16 16 78 16 minecraft:deepslate_tiles
setblock -12 78 16 minecraft:sea_lantern
setblock -6 78 16 minecraft:sea_lantern
setblock 0 78 16 minecraft:sea_lantern
setblock 6 78 16 minecraft:sea_lantern
setblock 12 78 16 minecraft:sea_lantern
fill -16 79 -16 16 79 -16 minecraft:deepslate_tiles
setblock -16 79 -15 minecraft:deepslate_tiles
setblock 16 79 -15 minecraft:deepslate_tiles
setblock -12 79 -15 minecraft:polished_deepslate
setblock -6 79 -15 minecraft:polished_deepslate
setblock 0 79 -15 minecraft:polished_deepslate
setblock 6 79 -15 minecraft:polished_deepslate
setblock 12 79 -15 minecraft:polished_deepslate
setblock -16 79 -14 minecraft:deepslate_tiles
setblock 16 79 -14 minecraft:deepslate_tiles
setblock -6 79 -14 minecraft:waxed_cut_copper
setblock 6 79 -14 minecraft:waxed_cut_copper
setblock -16 79 -13 minecraft:deepslate_tiles
setblock 16 79 -13 minecraft:deepslate_tiles
setblock -16 79 -12 minecraft:deepslate_tiles
setblock 16 79 -12 minecraft:deepslate_tiles
setblock -15 79 -12 minecraft:polished_deepslate
setblock 15 79 -12 minecraft:polished_deepslate
setblock -16 79 -11 minecraft:deepslate_tiles
setblock 16 79 -11 minecraft:deepslate_tiles
setblock -16 79 -10 minecraft:deepslate_tiles
setblock 16 79 -10 minecraft:deepslate_tiles
setblock -16 79 -9 minecraft:deepslate_tiles
setblock 16 79 -9 minecraft:deepslate_tiles
setblock -16 79 -8 minecraft:deepslate_tiles
setblock 16 79 -8 minecraft:deepslate_tiles
setblock -16 79 -7 minecraft:deepslate_tiles
setblock 16 79 -7 minecraft:deepslate_tiles
setblock -16 79 -6 minecraft:deepslate_tiles
setblock 16 79 -6 minecraft:deepslate_tiles
setblock -15 79 -6 minecraft:polished_deepslate
setblock 15 79 -6 minecraft:polished_deepslate
setblock -16 79 -5 minecraft:deepslate_tiles
setblock 16 79 -5 minecraft:deepslate_tiles
setblock -16 79 -4 minecraft:deepslate_tiles
setblock 16 79 -4 minecraft:deepslate_tiles
setblock -16 79 -3 minecraft:deepslate_tiles
setblock 16 79 -3 minecraft:deepslate_tiles
setblock -16 79 -2 minecraft:deepslate_tiles
setblock 16 79 -2 minecraft:deepslate_tiles
setblock -16 79 -1 minecraft:deepslate_tiles
setblock 16 79 -1 minecraft:deepslate_tiles
setblock -16 79 0 minecraft:deepslate_tiles
setblock 16 79 0 minecraft:deepslate_tiles
setblock -15 79 0 minecraft:polished_deepslate
setblock 15 79 0 minecraft:polished_deepslate
setblock -16 79 1 minecraft:deepslate_tiles
setblock 16 79 1 minecraft:deepslate_tiles
setblock -16 79 2 minecraft:deepslate_tiles
setblock 16 79 2 minecraft:deepslate_tiles
setblock -16 79 3 minecraft:deepslate_tiles
setblock 16 79 3 minecraft:deepslate_tiles
setblock -16 79 4 minecraft:deepslate_tiles
setblock 16 79 4 minecraft:deepslate_tiles
setblock -16 79 5 minecraft:deepslate_tiles
setblock 16 79 5 minecraft:deepslate_tiles
setblock -16 79 6 minecraft:deepslate_tiles
setblock 16 79 6 minecraft:deepslate_tiles
setblock -15 79 6 minecraft:polished_deepslate
setblock 15 79 6 minecraft:polished_deepslate
setblock -16 79 7 minecraft:deepslate_tiles
setblock 16 79 7 minecraft:deepslate_tiles
setblock -16 79 8 minecraft:deepslate_tiles
setblock 16 79 8 minecraft:deepslate_tiles
setblock -16 79 9 minecraft:deepslate_tiles
setblock 16 79 9 minecraft:deepslate_tiles
setblock -16 79 10 minecraft:deepslate_tiles
setblock 16 79 10 minecraft:deepslate_tiles
setblock -16 79 11 minecraft:deepslate_tiles
setblock 16 79 11 minecraft:deepslate_tiles
setblock -16 79 12 minecraft:deepslate_tiles
setblock 16 79 12 minecraft:deepslate_tiles
setblock -15 79 12 minecraft:polished_deepslate
setblock 15 79 12 minecraft:polished_deepslate
setblock -16 79 13 minecraft:deepslate_tiles
setblock 16 79 13 minecraft:deepslate_tiles
setblock -16 79 14 minecraft:deepslate_tiles
setblock 16 79 14 minecraft:deepslate_tiles
setblock -16 79 15 minecraft:deepslate_tiles
setblock 16 79 15 minecraft:deepslate_tiles
setblock -12 79 15 minecraft:polished_deepslate
setblock -6 79 15 minecraft:polished_deepslate
setblock 0 79 15 minecraft:polished_deepslate
setblock 6 79 15 minecraft:polished_deepslate
setblock 12 79 15 minecraft:polished_deepslate
fill -16 79 16 16 79 16 minecraft:deepslate_tiles
fill -16 80 -16 16 80 -16 minecraft:deepslate_tiles
setblock -16 80 -15 minecraft:deepslate_tiles
setblock 16 80 -15 minecraft:deepslate_tiles
fill -15 80 -15 15 80 -15 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -14 minecraft:deepslate_tiles
setblock 16 80 -14 minecraft:deepslate_tiles
setblock -5 80 -14 minecraft:waxed_cut_copper
setblock 5 80 -14 minecraft:waxed_cut_copper
setblock -15 80 -14 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -14 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -13 minecraft:deepslate_tiles
setblock 16 80 -13 minecraft:deepslate_tiles
setblock -15 80 -13 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -13 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -12 minecraft:deepslate_tiles
setblock 16 80 -12 minecraft:deepslate_tiles
setblock -12 80 -12 minecraft:sea_lantern
setblock 12 80 -12 minecraft:sea_lantern
fill -15 80 -12 -14 80 -12 minecraft:waxed_oxidized_cut_copper
fill 14 80 -12 15 80 -12 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -11 minecraft:deepslate_tiles
setblock 16 80 -11 minecraft:deepslate_tiles
setblock -15 80 -11 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -11 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -10 minecraft:deepslate_tiles
setblock 16 80 -10 minecraft:deepslate_tiles
setblock -15 80 -10 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -10 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -9 minecraft:deepslate_tiles
setblock 16 80 -9 minecraft:deepslate_tiles
setblock -15 80 -9 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -9 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -8 minecraft:deepslate_tiles
setblock 16 80 -8 minecraft:deepslate_tiles
setblock -15 80 -8 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -8 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -7 minecraft:deepslate_tiles
setblock 16 80 -7 minecraft:deepslate_tiles
setblock -15 80 -7 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -7 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -6 minecraft:deepslate_tiles
setblock 16 80 -6 minecraft:deepslate_tiles
setblock -15 80 -6 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -6 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -5 minecraft:deepslate_tiles
setblock 16 80 -5 minecraft:deepslate_tiles
setblock -15 80 -5 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -5 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -4 minecraft:deepslate_tiles
setblock 16 80 -4 minecraft:deepslate_tiles
setblock -15 80 -4 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -4 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -3 minecraft:deepslate_tiles
setblock 16 80 -3 minecraft:deepslate_tiles
setblock -15 80 -3 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -3 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -2 minecraft:deepslate_tiles
setblock 16 80 -2 minecraft:deepslate_tiles
setblock -15 80 -2 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -2 minecraft:waxed_oxidized_cut_copper
setblock -16 80 -1 minecraft:deepslate_tiles
setblock 16 80 -1 minecraft:deepslate_tiles
setblock -15 80 -1 minecraft:waxed_oxidized_cut_copper
setblock 15 80 -1 minecraft:waxed_oxidized_cut_copper
setblock -16 80 0 minecraft:deepslate_tiles
setblock 16 80 0 minecraft:deepslate_tiles
setblock -12 80 0 minecraft:sea_lantern
setblock 12 80 0 minecraft:sea_lantern
fill -15 80 0 -14 80 0 minecraft:waxed_oxidized_cut_copper
fill 14 80 0 15 80 0 minecraft:waxed_oxidized_cut_copper
setblock -16 80 1 minecraft:deepslate_tiles
setblock 16 80 1 minecraft:deepslate_tiles
setblock -15 80 1 minecraft:waxed_oxidized_cut_copper
setblock 15 80 1 minecraft:waxed_oxidized_cut_copper
setblock -16 80 2 minecraft:deepslate_tiles
setblock 16 80 2 minecraft:deepslate_tiles
setblock -15 80 2 minecraft:waxed_oxidized_cut_copper
setblock 15 80 2 minecraft:waxed_oxidized_cut_copper
setblock -16 80 3 minecraft:deepslate_tiles
setblock 16 80 3 minecraft:deepslate_tiles
setblock -15 80 3 minecraft:waxed_oxidized_cut_copper
setblock 15 80 3 minecraft:waxed_oxidized_cut_copper
setblock -16 80 4 minecraft:deepslate_tiles
setblock 16 80 4 minecraft:deepslate_tiles
setblock -15 80 4 minecraft:waxed_oxidized_cut_copper
setblock 15 80 4 minecraft:waxed_oxidized_cut_copper
setblock -16 80 5 minecraft:deepslate_tiles
setblock 16 80 5 minecraft:deepslate_tiles
setblock -15 80 5 minecraft:waxed_oxidized_cut_copper
setblock 15 80 5 minecraft:waxed_oxidized_cut_copper
setblock -16 80 6 minecraft:deepslate_tiles
setblock 16 80 6 minecraft:deepslate_tiles
setblock -15 80 6 minecraft:waxed_oxidized_cut_copper
setblock 15 80 6 minecraft:waxed_oxidized_cut_copper
setblock -16 80 7 minecraft:deepslate_tiles
setblock 16 80 7 minecraft:deepslate_tiles
setblock -15 80 7 minecraft:waxed_oxidized_cut_copper
setblock 15 80 7 minecraft:waxed_oxidized_cut_copper
setblock -16 80 8 minecraft:deepslate_tiles
setblock 16 80 8 minecraft:deepslate_tiles
setblock -15 80 8 minecraft:waxed_oxidized_cut_copper
setblock 15 80 8 minecraft:waxed_oxidized_cut_copper
setblock -16 80 9 minecraft:deepslate_tiles
setblock 16 80 9 minecraft:deepslate_tiles
setblock -15 80 9 minecraft:waxed_oxidized_cut_copper
setblock 15 80 9 minecraft:waxed_oxidized_cut_copper
setblock -16 80 10 minecraft:deepslate_tiles
setblock 16 80 10 minecraft:deepslate_tiles
setblock -15 80 10 minecraft:waxed_oxidized_cut_copper
setblock 15 80 10 minecraft:waxed_oxidized_cut_copper
setblock -16 80 11 minecraft:deepslate_tiles
setblock 16 80 11 minecraft:deepslate_tiles
setblock -15 80 11 minecraft:waxed_oxidized_cut_copper
setblock 15 80 11 minecraft:waxed_oxidized_cut_copper
setblock -16 80 12 minecraft:deepslate_tiles
setblock 16 80 12 minecraft:deepslate_tiles
setblock -12 80 12 minecraft:sea_lantern
setblock 12 80 12 minecraft:sea_lantern
fill -15 80 12 -14 80 12 minecraft:waxed_oxidized_cut_copper
fill 14 80 12 15 80 12 minecraft:waxed_oxidized_cut_copper
setblock -16 80 13 minecraft:deepslate_tiles
setblock 16 80 13 minecraft:deepslate_tiles
setblock -15 80 13 minecraft:waxed_oxidized_cut_copper
setblock 15 80 13 minecraft:waxed_oxidized_cut_copper
setblock -16 80 14 minecraft:deepslate_tiles
setblock 16 80 14 minecraft:deepslate_tiles
setblock -15 80 14 minecraft:waxed_oxidized_cut_copper
setblock 15 80 14 minecraft:waxed_oxidized_cut_copper
setblock -16 80 15 minecraft:deepslate_tiles
setblock 16 80 15 minecraft:deepslate_tiles
fill -15 80 15 15 80 15 minecraft:waxed_oxidized_cut_copper
fill -16 80 16 16 80 16 minecraft:deepslate_tiles
fill -16 81 -16 16 81 -16 minecraft:deepslate_tiles
setblock -16 81 -15 minecraft:deepslate_tiles
setblock 16 81 -15 minecraft:deepslate_tiles
setblock -12 81 -15 minecraft:waxed_oxidized_cut_copper
setblock -6 81 -15 minecraft:waxed_oxidized_cut_copper
setblock 0 81 -15 minecraft:waxed_oxidized_cut_copper
setblock 6 81 -15 minecraft:waxed_oxidized_cut_copper
setblock 12 81 -15 minecraft:waxed_oxidized_cut_copper
setblock -16 81 -14 minecraft:deepslate_tiles
setblock 16 81 -14 minecraft:deepslate_tiles
setblock -4 81 -14 minecraft:waxed_cut_copper
setblock 4 81 -14 minecraft:waxed_cut_copper
setblock -16 81 -13 minecraft:deepslate_tiles
setblock 16 81 -13 minecraft:deepslate_tiles
setblock -16 81 -12 minecraft:deepslate_tiles
setblock 16 81 -12 minecraft:deepslate_tiles
setblock -6 81 -12 minecraft:sea_lantern
setblock 0 81 -12 minecraft:sea_lantern
setblock 6 81 -12 minecraft:sea_lantern
setblock -15 81 -12 minecraft:waxed_oxidized_cut_copper
fill -13 81 -12 -11 81 -12 minecraft:waxed_oxidized_cut_copper
fill 11 81 -12 13 81 -12 minecraft:waxed_oxidized_cut_copper
setblock 15 81 -12 minecraft:waxed_oxidized_cut_copper
setblock -16 81 -11 minecraft:deepslate_tiles
setblock 16 81 -11 minecraft:deepslate_tiles
setblock -16 81 -10 minecraft:deepslate_tiles
setblock 16 81 -10 minecraft:deepslate_tiles
setblock -16 81 -9 minecraft:deepslate_tiles
setblock 16 81 -9 minecraft:deepslate_tiles
setblock -16 81 -8 minecraft:deepslate_tiles
setblock 16 81 -8 minecraft:deepslate_tiles
setblock -16 81 -7 minecraft:deepslate_tiles
setblock 16 81 -7 minecraft:deepslate_tiles
setblock -16 81 -6 minecraft:deepslate_tiles
setblock 16 81 -6 minecraft:deepslate_tiles
setblock -15 81 -6 minecraft:waxed_oxidized_cut_copper
setblock 15 81 -6 minecraft:waxed_oxidized_cut_copper
setblock -16 81 -5 minecraft:deepslate_tiles
setblock 16 81 -5 minecraft:deepslate_tiles
setblock -16 81 -4 minecraft:deepslate_tiles
setblock 16 81 -4 minecraft:deepslate_tiles
setblock -16 81 -3 minecraft:deepslate_tiles
setblock 16 81 -3 minecraft:deepslate_tiles
setblock -16 81 -2 minecraft:deepslate_tiles
setblock 16 81 -2 minecraft:deepslate_tiles
setblock -16 81 -1 minecraft:deepslate_tiles
setblock 16 81 -1 minecraft:deepslate_tiles
setblock -16 81 0 minecraft:deepslate_tiles
setblock 16 81 0 minecraft:deepslate_tiles
setblock -6 81 0 minecraft:sea_lantern
setblock 0 81 0 minecraft:sea_lantern
setblock 6 81 0 minecraft:sea_lantern
setblock -15 81 0 minecraft:waxed_oxidized_cut_copper
fill -13 81 0 -11 81 0 minecraft:waxed_oxidized_cut_copper
fill 11 81 0 13 81 0 minecraft:waxed_oxidized_cut_copper
setblock 15 81 0 minecraft:waxed_oxidized_cut_copper
setblock -16 81 1 minecraft:deepslate_tiles
setblock 16 81 1 minecraft:deepslate_tiles
setblock -16 81 2 minecraft:deepslate_tiles
setblock 16 81 2 minecraft:deepslate_tiles
setblock -16 81 3 minecraft:deepslate_tiles
setblock 16 81 3 minecraft:deepslate_tiles
setblock -16 81 4 minecraft:deepslate_tiles
setblock 16 81 4 minecraft:deepslate_tiles
setblock -16 81 5 minecraft:deepslate_tiles
setblock 16 81 5 minecraft:deepslate_tiles
setblock -16 81 6 minecraft:deepslate_tiles
setblock 16 81 6 minecraft:deepslate_tiles
setblock -15 81 6 minecraft:waxed_oxidized_cut_copper
setblock 15 81 6 minecraft:waxed_oxidized_cut_copper
setblock -16 81 7 minecraft:deepslate_tiles
setblock 16 81 7 minecraft:deepslate_tiles
setblock -16 81 8 minecraft:deepslate_tiles
setblock 16 81 8 minecraft:deepslate_tiles
setblock -16 81 9 minecraft:deepslate_tiles
setblock 16 81 9 minecraft:deepslate_tiles
setblock -16 81 10 minecraft:deepslate_tiles
setblock 16 81 10 minecraft:deepslate_tiles
setblock -16 81 11 minecraft:deepslate_tiles
setblock 16 81 11 minecraft:deepslate_tiles
setblock -16 81 12 minecraft:deepslate_tiles
setblock 16 81 12 minecraft:deepslate_tiles
setblock -6 81 12 minecraft:sea_lantern
setblock 0 81 12 minecraft:sea_lantern
setblock 6 81 12 minecraft:sea_lantern
setblock -15 81 12 minecraft:waxed_oxidized_cut_copper
fill -13 81 12 -11 81 12 minecraft:waxed_oxidized_cut_copper
fill 11 81 12 13 81 12 minecraft:waxed_oxidized_cut_copper
setblock 15 81 12 minecraft:waxed_oxidized_cut_copper
setblock -16 81 13 minecraft:deepslate_tiles
setblock 16 81 13 minecraft:deepslate_tiles
setblock -16 81 14 minecraft:deepslate_tiles
setblock 16 81 14 minecraft:deepslate_tiles
setblock -16 81 15 minecraft:deepslate_tiles
setblock 16 81 15 minecraft:deepslate_tiles
setblock -12 81 15 minecraft:waxed_oxidized_cut_copper
setblock -6 81 15 minecraft:waxed_oxidized_cut_copper
setblock 0 81 15 minecraft:waxed_oxidized_cut_copper
setblock 6 81 15 minecraft:waxed_oxidized_cut_copper
setblock 12 81 15 minecraft:waxed_oxidized_cut_copper
fill -16 81 16 16 81 16 minecraft:deepslate_tiles
fill -16 82 -16 16 82 -16 minecraft:deepslate_tiles
setblock -16 82 -15 minecraft:deepslate_tiles
setblock 16 82 -15 minecraft:deepslate_tiles
setblock -12 82 -15 minecraft:waxed_oxidized_cut_copper
setblock -6 82 -15 minecraft:waxed_oxidized_cut_copper
setblock 0 82 -15 minecraft:waxed_oxidized_cut_copper
setblock 6 82 -15 minecraft:waxed_oxidized_cut_copper
setblock 12 82 -15 minecraft:waxed_oxidized_cut_copper
setblock -16 82 -14 minecraft:deepslate_tiles
setblock 16 82 -14 minecraft:deepslate_tiles
setblock -16 82 -13 minecraft:deepslate_tiles
setblock 16 82 -13 minecraft:deepslate_tiles
setblock -16 82 -12 minecraft:deepslate_tiles
setblock 16 82 -12 minecraft:deepslate_tiles
setblock -15 82 -12 minecraft:waxed_oxidized_cut_copper
fill -10 82 -12 10 82 -12 minecraft:waxed_oxidized_cut_copper
setblock 15 82 -12 minecraft:waxed_oxidized_cut_copper
setblock -16 82 -11 minecraft:deepslate_tiles
setblock 16 82 -11 minecraft:deepslate_tiles
setblock -16 82 -10 minecraft:deepslate_tiles
setblock 16 82 -10 minecraft:deepslate_tiles
setblock -16 82 -9 minecraft:deepslate_tiles
setblock 16 82 -9 minecraft:deepslate_tiles
setblock -16 82 -8 minecraft:deepslate_tiles
setblock 16 82 -8 minecraft:deepslate_tiles
setblock -16 82 -7 minecraft:deepslate_tiles
setblock 16 82 -7 minecraft:deepslate_tiles
setblock -16 82 -6 minecraft:deepslate_tiles
setblock 16 82 -6 minecraft:deepslate_tiles
setblock -15 82 -6 minecraft:waxed_oxidized_cut_copper
setblock 15 82 -6 minecraft:waxed_oxidized_cut_copper
setblock -16 82 -5 minecraft:deepslate_tiles
setblock 16 82 -5 minecraft:deepslate_tiles
setblock -16 82 -4 minecraft:deepslate_tiles
setblock 16 82 -4 minecraft:deepslate_tiles
setblock -16 82 -3 minecraft:deepslate_tiles
setblock 16 82 -3 minecraft:deepslate_tiles
setblock -16 82 -2 minecraft:deepslate_tiles
setblock 16 82 -2 minecraft:deepslate_tiles
setblock -16 82 -1 minecraft:deepslate_tiles
setblock 16 82 -1 minecraft:deepslate_tiles
setblock -16 82 0 minecraft:deepslate_tiles
setblock 16 82 0 minecraft:deepslate_tiles
setblock -15 82 0 minecraft:waxed_oxidized_cut_copper
fill -10 82 0 10 82 0 minecraft:waxed_oxidized_cut_copper
setblock 15 82 0 minecraft:waxed_oxidized_cut_copper
setblock -16 82 1 minecraft:deepslate_tiles
setblock 16 82 1 minecraft:deepslate_tiles
setblock -16 82 2 minecraft:deepslate_tiles
setblock 16 82 2 minecraft:deepslate_tiles
setblock -16 82 3 minecraft:deepslate_tiles
setblock 16 82 3 minecraft:deepslate_tiles
setblock -16 82 4 minecraft:deepslate_tiles
setblock 16 82 4 minecraft:deepslate_tiles
setblock -16 82 5 minecraft:deepslate_tiles
setblock 16 82 5 minecraft:deepslate_tiles
setblock -16 82 6 minecraft:deepslate_tiles
setblock 16 82 6 minecraft:deepslate_tiles
setblock -15 82 6 minecraft:waxed_oxidized_cut_copper
setblock 15 82 6 minecraft:waxed_oxidized_cut_copper
setblock -16 82 7 minecraft:deepslate_tiles
setblock 16 82 7 minecraft:deepslate_tiles
setblock -16 82 8 minecraft:deepslate_tiles
setblock 16 82 8 minecraft:deepslate_tiles
setblock -16 82 9 minecraft:deepslate_tiles
setblock 16 82 9 minecraft:deepslate_tiles
setblock -16 82 10 minecraft:deepslate_tiles
setblock 16 82 10 minecraft:deepslate_tiles
setblock -16 82 11 minecraft:deepslate_tiles
setblock 16 82 11 minecraft:deepslate_tiles
setblock -16 82 12 minecraft:deepslate_tiles
setblock 16 82 12 minecraft:deepslate_tiles
setblock -15 82 12 minecraft:waxed_oxidized_cut_copper
fill -10 82 12 10 82 12 minecraft:waxed_oxidized_cut_copper
setblock 15 82 12 minecraft:waxed_oxidized_cut_copper
setblock -16 82 13 minecraft:deepslate_tiles
setblock 16 82 13 minecraft:deepslate_tiles
setblock -16 82 14 minecraft:deepslate_tiles
setblock 16 82 14 minecraft:deepslate_tiles
setblock -16 82 15 minecraft:deepslate_tiles
setblock 16 82 15 minecraft:deepslate_tiles
setblock -12 82 15 minecraft:waxed_oxidized_cut_copper
setblock -6 82 15 minecraft:waxed_oxidized_cut_copper
setblock 0 82 15 minecraft:waxed_oxidized_cut_copper
setblock 6 82 15 minecraft:waxed_oxidized_cut_copper
setblock 12 82 15 minecraft:waxed_oxidized_cut_copper
fill -16 82 16 16 82 16 minecraft:deepslate_tiles
fill -16 83 -16 16 83 -16 minecraft:deepslate_tiles
setblock -16 83 -15 minecraft:deepslate_tiles
setblock 16 83 -15 minecraft:deepslate_tiles
fill -15 83 -15 15 83 -15 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -14 minecraft:deepslate_tiles
setblock 16 83 -14 minecraft:deepslate_tiles
setblock -15 83 -14 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -14 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -13 minecraft:deepslate_tiles
setblock 16 83 -13 minecraft:deepslate_tiles
setblock -15 83 -13 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -13 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -12 minecraft:deepslate_tiles
setblock 16 83 -12 minecraft:deepslate_tiles
setblock -15 83 -12 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -12 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -11 minecraft:deepslate_tiles
setblock 16 83 -11 minecraft:deepslate_tiles
setblock -15 83 -11 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -11 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -10 minecraft:deepslate_tiles
setblock 16 83 -10 minecraft:deepslate_tiles
setblock -15 83 -10 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -10 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -9 minecraft:deepslate_tiles
setblock 16 83 -9 minecraft:deepslate_tiles
setblock -10 83 -9 minecraft:light_blue_stained_glass
setblock 7 83 -9 minecraft:light_blue_stained_glass
setblock -15 83 -9 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -9 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -8 minecraft:deepslate_tiles
setblock 16 83 -8 minecraft:deepslate_tiles
setblock -3 83 -8 minecraft:light_blue_stained_glass
setblock -15 83 -8 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -8 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -7 minecraft:deepslate_tiles
setblock 16 83 -7 minecraft:deepslate_tiles
setblock -15 83 -7 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -7 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -6 minecraft:deepslate_tiles
setblock 16 83 -6 minecraft:deepslate_tiles
setblock -15 83 -6 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -6 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -5 minecraft:deepslate_tiles
setblock 16 83 -5 minecraft:deepslate_tiles
setblock -15 83 -5 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -5 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -4 minecraft:deepslate_tiles
setblock 16 83 -4 minecraft:deepslate_tiles
setblock 10 83 -4 minecraft:light_blue_stained_glass
setblock -15 83 -4 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -4 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -3 minecraft:deepslate_tiles
setblock 16 83 -3 minecraft:deepslate_tiles
setblock -15 83 -3 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -3 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -2 minecraft:deepslate_tiles
setblock 16 83 -2 minecraft:deepslate_tiles
setblock -15 83 -2 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -2 minecraft:waxed_oxidized_cut_copper
setblock -16 83 -1 minecraft:deepslate_tiles
setblock 16 83 -1 minecraft:deepslate_tiles
setblock -15 83 -1 minecraft:waxed_oxidized_cut_copper
setblock 15 83 -1 minecraft:waxed_oxidized_cut_copper
setblock -16 83 0 minecraft:deepslate_tiles
setblock 16 83 0 minecraft:deepslate_tiles
setblock -15 83 0 minecraft:waxed_oxidized_cut_copper
setblock 15 83 0 minecraft:waxed_oxidized_cut_copper
setblock -16 83 1 minecraft:deepslate_tiles
setblock 16 83 1 minecraft:deepslate_tiles
setblock -15 83 1 minecraft:waxed_oxidized_cut_copper
setblock 15 83 1 minecraft:waxed_oxidized_cut_copper
setblock -16 83 2 minecraft:deepslate_tiles
setblock 16 83 2 minecraft:deepslate_tiles
setblock -15 83 2 minecraft:waxed_oxidized_cut_copper
setblock 15 83 2 minecraft:waxed_oxidized_cut_copper
setblock -16 83 3 minecraft:deepslate_tiles
setblock 16 83 3 minecraft:deepslate_tiles
setblock -15 83 3 minecraft:waxed_oxidized_cut_copper
setblock 15 83 3 minecraft:waxed_oxidized_cut_copper
setblock -16 83 4 minecraft:deepslate_tiles
setblock 16 83 4 minecraft:deepslate_tiles
setblock 3 83 4 minecraft:light_blue_stained_glass
setblock -15 83 4 minecraft:waxed_oxidized_cut_copper
setblock 15 83 4 minecraft:waxed_oxidized_cut_copper
setblock -16 83 5 minecraft:deepslate_tiles
setblock 16 83 5 minecraft:deepslate_tiles
setblock -11 83 5 minecraft:light_blue_stained_glass
setblock -15 83 5 minecraft:waxed_oxidized_cut_copper
setblock 15 83 5 minecraft:waxed_oxidized_cut_copper
setblock -16 83 6 minecraft:deepslate_tiles
setblock 16 83 6 minecraft:deepslate_tiles
setblock -15 83 6 minecraft:waxed_oxidized_cut_copper
setblock 15 83 6 minecraft:waxed_oxidized_cut_copper
setblock -16 83 7 minecraft:deepslate_tiles
setblock 16 83 7 minecraft:deepslate_tiles
setblock -5 83 7 minecraft:light_blue_stained_glass
setblock -15 83 7 minecraft:waxed_oxidized_cut_copper
setblock 15 83 7 minecraft:waxed_oxidized_cut_copper
setblock -16 83 8 minecraft:deepslate_tiles
setblock 16 83 8 minecraft:deepslate_tiles
setblock -15 83 8 minecraft:waxed_oxidized_cut_copper
setblock 15 83 8 minecraft:waxed_oxidized_cut_copper
setblock -16 83 9 minecraft:deepslate_tiles
setblock 16 83 9 minecraft:deepslate_tiles
setblock -15 83 9 minecraft:waxed_oxidized_cut_copper
setblock 15 83 9 minecraft:waxed_oxidized_cut_copper
setblock -16 83 10 minecraft:deepslate_tiles
setblock 16 83 10 minecraft:deepslate_tiles
setblock 9 83 10 minecraft:light_blue_stained_glass
setblock -15 83 10 minecraft:waxed_oxidized_cut_copper
setblock 15 83 10 minecraft:waxed_oxidized_cut_copper
setblock -16 83 11 minecraft:deepslate_tiles
setblock 16 83 11 minecraft:deepslate_tiles
setblock -15 83 11 minecraft:waxed_oxidized_cut_copper
setblock 15 83 11 minecraft:waxed_oxidized_cut_copper
setblock -16 83 12 minecraft:deepslate_tiles
setblock 16 83 12 minecraft:deepslate_tiles
setblock -15 83 12 minecraft:waxed_oxidized_cut_copper
setblock 15 83 12 minecraft:waxed_oxidized_cut_copper
setblock -16 83 13 minecraft:deepslate_tiles
setblock 16 83 13 minecraft:deepslate_tiles
setblock -15 83 13 minecraft:waxed_oxidized_cut_copper
setblock 15 83 13 minecraft:waxed_oxidized_cut_copper
setblock -16 83 14 minecraft:deepslate_tiles
setblock 16 83 14 minecraft:deepslate_tiles
setblock -15 83 14 minecraft:waxed_oxidized_cut_copper
setblock 15 83 14 minecraft:waxed_oxidized_cut_copper
setblock -16 83 15 minecraft:deepslate_tiles
setblock 16 83 15 minecraft:deepslate_tiles
fill -15 83 15 15 83 15 minecraft:waxed_oxidized_cut_copper
fill -16 83 16 16 83 16 minecraft:deepslate_tiles
fill -16 84 -16 16 84 -16 minecraft:black_concrete
fill -16 84 -15 16 84 -15 minecraft:black_concrete
fill -16 84 -14 16 84 -14 minecraft:black_concrete
fill -16 84 -13 16 84 -13 minecraft:black_concrete
fill -16 84 -12 16 84 -12 minecraft:black_concrete
fill -16 84 -11 16 84 -11 minecraft:black_concrete
fill -16 84 -10 16 84 -10 minecraft:black_concrete
fill -16 84 -9 -11 84 -9 minecraft:black_concrete
fill -9 84 -9 6 84 -9 minecraft:black_concrete
fill 8 84 -9 16 84 -9 minecraft:black_concrete
setblock -10 84 -9 minecraft:sea_lantern
setblock 7 84 -9 minecraft:sea_lantern
fill -16 84 -8 -4 84 -8 minecraft:black_concrete
fill -2 84 -8 16 84 -8 minecraft:black_concrete
setblock -3 84 -8 minecraft:sea_lantern
fill -16 84 -7 16 84 -7 minecraft:black_concrete
fill -16 84 -6 16 84 -6 minecraft:black_concrete
fill -16 84 -5 16 84 -5 minecraft:black_concrete
fill -16 84 -4 9 84 -4 minecraft:black_concrete
fill 11 84 -4 16 84 -4 minecraft:black_concrete
setblock 10 84 -4 minecraft:sea_lantern
fill -16 84 -3 16 84 -3 minecraft:black_concrete
fill -16 84 -2 16 84 -2 minecraft:black_concrete
fill -16 84 -1 16 84 -1 minecraft:black_concrete
fill -16 84 0 16 84 0 minecraft:black_concrete
fill -16 84 1 16 84 1 minecraft:black_concrete
fill -16 84 2 16 84 2 minecraft:black_concrete
fill -16 84 3 16 84 3 minecraft:black_concrete
fill -16 84 4 2 84 4 minecraft:black_concrete
fill 4 84 4 16 84 4 minecraft:black_concrete
setblock 3 84 4 minecraft:sea_lantern
fill -16 84 5 -12 84 5 minecraft:black_concrete
fill -10 84 5 16 84 5 minecraft:black_concrete
setblock -11 84 5 minecraft:sea_lantern
fill -16 84 6 16 84 6 minecraft:black_concrete
fill -16 84 7 -6 84 7 minecraft:black_concrete
fill -4 84 7 16 84 7 minecraft:black_concrete
setblock -5 84 7 minecraft:sea_lantern
fill -16 84 8 16 84 8 minecraft:black_concrete
fill -16 84 9 16 84 9 minecraft:black_concrete
fill -16 84 10 8 84 10 minecraft:black_concrete
fill 10 84 10 16 84 10 minecraft:black_concrete
setblock 9 84 10 minecraft:sea_lantern
fill -16 84 11 16 84 11 minecraft:black_concrete
fill -16 84 12 16 84 12 minecraft:black_concrete
fill -16 84 13 16 84 13 minecraft:black_concrete
fill -16 84 14 16 84 14 minecraft:black_concrete
fill -16 84 15 16 84 15 minecraft:black_concrete
fill -16 84 16 16 84 16 minecraft:black_concrete
schedule function signal:world/build_1 1t replace
