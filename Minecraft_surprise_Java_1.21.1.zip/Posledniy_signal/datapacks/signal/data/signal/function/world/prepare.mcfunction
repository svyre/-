data modify storage signal:world ready set value 0b
title @a title {"text":"Подготовка карты…","color":"aqua"}
schedule function signal:world/build_0 40t replace
