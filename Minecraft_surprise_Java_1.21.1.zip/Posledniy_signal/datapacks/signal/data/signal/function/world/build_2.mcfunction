fill 112 55 -16 144 84 16 minecraft:air
fill 112 55 -16 144 55 -16 minecraft:bedrock
fill 112 55 -15 144 55 -15 minecraft:bedrock
fill 112 55 -14 144 55 -14 minecraft:bedrock
fill 112 55 -13 144 55 -13 minecraft:bedrock
fill 112 55 -12 144 55 -12 minecraft:bedrock
fill 112 55 -11 144 55 -11 minecraft:bedrock
fill 112 55 -10 144 55 -10 minecraft:bedrock
fill 112 55 -9 144 55 -9 minecraft:bedrock
fill 112 55 -8 144 55 -8 minecraft:bedrock
fill 112 55 -7 144 55 -7 minecraft:bedrock
fill 112 55 -6 144 55 -6 minecraft:bedrock
fill 112 55 -5 144 55 -5 minecraft:bedrock
fill 112 55 -4 144 55 -4 minecraft:bedrock
fill 112 55 -3 144 55 -3 minecraft:bedrock
fill 112 55 -2 144 55 -2 minecraft:bedrock
fill 112 55 -1 144 55 -1 minecraft:bedrock
fill 112 55 0 144 55 0 minecraft:bedrock
fill 112 55 1 144 55 1 minecraft:bedrock
fill 112 55 2 144 55 2 minecraft:bedrock
fill 112 55 3 144 55 3 minecraft:bedrock
fill 112 55 4 144 55 4 minecraft:bedrock
fill 112 55 5 144 55 5 minecraft:bedrock
fill 112 55 6 144 55 6 minecraft:bedrock
fill 112 55 7 144 55 7 minecraft:bedrock
fill 112 55 8 144 55 8 minecraft:bedrock
fill 112 55 9 144 55 9 minecraft:bedrock
fill 112 55 10 144 55 10 minecraft:bedrock
fill 112 55 11 144 55 11 minecraft:bedrock
fill 112 55 12 144 55 12 minecraft:bedrock
fill 112 55 13 144 55 13 minecraft:bedrock
fill 112 55 14 144 55 14 minecraft:bedrock
fill 112 55 15 144 55 15 minecraft:bedrock
fill 112 55 16 144 55 16 minecraft:bedrock
fill 112 56 -16 144 56 -16 minecraft:bedrock
fill 112 56 -15 144 56 -15 minecraft:bedrock
fill 112 56 -14 144 56 -14 minecraft:bedrock
fill 112 56 -13 144 56 -13 minecraft:bedrock
fill 112 56 -12 144 56 -12 minecraft:bedrock
fill 112 56 -11 144 56 -11 minecraft:bedrock
fill 112 56 -10 144 56 -10 minecraft:bedrock
fill 112 56 -9 144 56 -9 minecraft:bedrock
fill 112 56 -8 144 56 -8 minecraft:bedrock
fill 112 56 -7 144 56 -7 minecraft:bedrock
fill 112 56 -6 144 56 -6 minecraft:bedrock
fill 112 56 -5 144 56 -5 minecraft:bedrock
fill 112 56 -4 144 56 -4 minecraft:bedrock
fill 112 56 -3 144 56 -3 minecraft:bedrock
fill 112 56 -2 144 56 -2 minecraft:bedrock
fill 112 56 -1 144 56 -1 minecraft:bedrock
fill 112 56 0 144 56 0 minecraft:bedrock
fill 112 56 1 144 56 1 minecraft:bedrock
fill 112 56 2 144 56 2 minecraft:bedrock
fill 112 56 3 144 56 3 minecraft:bedrock
fill 112 56 4 144 56 4 minecraft:bedrock
fill 112 56 5 144 56 5 minecraft:bedrock
fill 112 56 6 144 56 6 minecraft:bedrock
fill 112 56 7 144 56 7 minecraft:bedrock
fill 112 56 8 144 56 8 minecraft:bedrock
fill 112 56 9 144 56 9 minecraft:bedrock
fill 112 56 10 144 56 10 minecraft:bedrock
fill 112 56 11 144 56 11 minecraft:bedrock
fill 112 56 12 144 56 12 minecraft:bedrock
fill 112 56 13 144 56 13 minecraft:bedrock
fill 112 56 14 144 56 14 minecraft:bedrock
fill 112 56 15 144 56 15 minecraft:bedrock
fill 112 56 16 144 56 16 minecraft:bedrock
fill 112 57 -16 144 57 -16 minecraft:deepslate_tiles
fill 113 57 -15 114 57 -15 minecraft:black_concrete
fill 116 57 -15 121 57 -15 minecraft:black_concrete
fill 123 57 -15 128 57 -15 minecraft:black_concrete
fill 130 57 -15 135 57 -15 minecraft:black_concrete
fill 137 57 -15 142 57 -15 minecraft:black_concrete
setblock 112 57 -15 minecraft:deepslate_tiles
setblock 115 57 -15 minecraft:deepslate_tiles
setblock 122 57 -15 minecraft:deepslate_tiles
setblock 129 57 -15 minecraft:deepslate_tiles
setblock 136 57 -15 minecraft:deepslate_tiles
fill 143 57 -15 144 57 -15 minecraft:deepslate_tiles
setblock 113 57 -14 minecraft:black_concrete
fill 115 57 -14 120 57 -14 minecraft:black_concrete
fill 122 57 -14 127 57 -14 minecraft:black_concrete
fill 129 57 -14 134 57 -14 minecraft:black_concrete
fill 136 57 -14 141 57 -14 minecraft:black_concrete
setblock 143 57 -14 minecraft:black_concrete
setblock 112 57 -14 minecraft:deepslate_tiles
setblock 114 57 -14 minecraft:deepslate_tiles
setblock 121 57 -14 minecraft:deepslate_tiles
setblock 128 57 -14 minecraft:deepslate_tiles
setblock 135 57 -14 minecraft:deepslate_tiles
setblock 142 57 -14 minecraft:deepslate_tiles
setblock 144 57 -14 minecraft:deepslate_tiles
fill 114 57 -13 119 57 -13 minecraft:black_concrete
fill 121 57 -13 126 57 -13 minecraft:black_concrete
fill 128 57 -13 133 57 -13 minecraft:black_concrete
fill 135 57 -13 140 57 -13 minecraft:black_concrete
fill 142 57 -13 143 57 -13 minecraft:black_concrete
fill 112 57 -13 113 57 -13 minecraft:deepslate_tiles
setblock 120 57 -13 minecraft:deepslate_tiles
setblock 127 57 -13 minecraft:deepslate_tiles
setblock 134 57 -13 minecraft:deepslate_tiles
setblock 141 57 -13 minecraft:deepslate_tiles
setblock 144 57 -13 minecraft:deepslate_tiles
fill 113 57 -12 118 57 -12 minecraft:black_concrete
fill 120 57 -12 125 57 -12 minecraft:black_concrete
fill 127 57 -12 132 57 -12 minecraft:black_concrete
fill 134 57 -12 139 57 -12 minecraft:black_concrete
fill 141 57 -12 143 57 -12 minecraft:black_concrete
setblock 112 57 -12 minecraft:deepslate_tiles
setblock 119 57 -12 minecraft:deepslate_tiles
setblock 126 57 -12 minecraft:deepslate_tiles
setblock 133 57 -12 minecraft:deepslate_tiles
setblock 140 57 -12 minecraft:deepslate_tiles
setblock 144 57 -12 minecraft:deepslate_tiles
fill 113 57 -11 117 57 -11 minecraft:black_concrete
fill 119 57 -11 124 57 -11 minecraft:black_concrete
fill 126 57 -11 131 57 -11 minecraft:black_concrete
fill 133 57 -11 138 57 -11 minecraft:black_concrete
fill 140 57 -11 143 57 -11 minecraft:black_concrete
setblock 112 57 -11 minecraft:deepslate_tiles
setblock 118 57 -11 minecraft:deepslate_tiles
setblock 125 57 -11 minecraft:deepslate_tiles
setblock 132 57 -11 minecraft:deepslate_tiles
setblock 139 57 -11 minecraft:deepslate_tiles
setblock 144 57 -11 minecraft:deepslate_tiles
fill 113 57 -10 116 57 -10 minecraft:black_concrete
fill 118 57 -10 123 57 -10 minecraft:black_concrete
fill 125 57 -10 130 57 -10 minecraft:black_concrete
fill 132 57 -10 137 57 -10 minecraft:black_concrete
fill 139 57 -10 143 57 -10 minecraft:black_concrete
setblock 112 57 -10 minecraft:deepslate_tiles
setblock 117 57 -10 minecraft:deepslate_tiles
setblock 124 57 -10 minecraft:deepslate_tiles
setblock 131 57 -10 minecraft:deepslate_tiles
setblock 138 57 -10 minecraft:deepslate_tiles
setblock 144 57 -10 minecraft:deepslate_tiles
fill 113 57 -9 115 57 -9 minecraft:black_concrete
fill 117 57 -9 122 57 -9 minecraft:black_concrete
fill 124 57 -9 129 57 -9 minecraft:black_concrete
fill 131 57 -9 136 57 -9 minecraft:black_concrete
fill 138 57 -9 143 57 -9 minecraft:black_concrete
setblock 112 57 -9 minecraft:deepslate_tiles
setblock 116 57 -9 minecraft:deepslate_tiles
setblock 123 57 -9 minecraft:deepslate_tiles
setblock 130 57 -9 minecraft:deepslate_tiles
setblock 137 57 -9 minecraft:deepslate_tiles
setblock 144 57 -9 minecraft:deepslate_tiles
fill 113 57 -8 114 57 -8 minecraft:black_concrete
fill 116 57 -8 121 57 -8 minecraft:black_concrete
fill 123 57 -8 128 57 -8 minecraft:black_concrete
fill 130 57 -8 135 57 -8 minecraft:black_concrete
fill 137 57 -8 142 57 -8 minecraft:black_concrete
setblock 112 57 -8 minecraft:deepslate_tiles
setblock 115 57 -8 minecraft:deepslate_tiles
setblock 122 57 -8 minecraft:deepslate_tiles
setblock 129 57 -8 minecraft:deepslate_tiles
setblock 136 57 -8 minecraft:deepslate_tiles
fill 143 57 -8 144 57 -8 minecraft:deepslate_tiles
setblock 113 57 -7 minecraft:black_concrete
setblock 143 57 -7 minecraft:black_concrete
setblock 112 57 -7 minecraft:deepslate_tiles
setblock 114 57 -7 minecraft:deepslate_tiles
setblock 142 57 -7 minecraft:deepslate_tiles
setblock 144 57 -7 minecraft:deepslate_tiles
setblock 115 57 -7 minecraft:sea_lantern
setblock 120 57 -7 minecraft:sea_lantern
setblock 125 57 -7 minecraft:sea_lantern
setblock 130 57 -7 minecraft:sea_lantern
setblock 135 57 -7 minecraft:sea_lantern
setblock 140 57 -7 minecraft:sea_lantern
fill 116 57 -7 119 57 -7 minecraft:waxed_oxidized_cut_copper
fill 121 57 -7 124 57 -7 minecraft:waxed_oxidized_cut_copper
fill 126 57 -7 129 57 -7 minecraft:waxed_oxidized_cut_copper
fill 131 57 -7 134 57 -7 minecraft:waxed_oxidized_cut_copper
fill 136 57 -7 139 57 -7 minecraft:waxed_oxidized_cut_copper
setblock 141 57 -7 minecraft:waxed_oxidized_cut_copper
fill 114 57 -6 119 57 -6 minecraft:black_concrete
fill 121 57 -6 126 57 -6 minecraft:black_concrete
fill 128 57 -6 133 57 -6 minecraft:black_concrete
fill 135 57 -6 140 57 -6 minecraft:black_concrete
fill 142 57 -6 143 57 -6 minecraft:black_concrete
fill 112 57 -6 113 57 -6 minecraft:deepslate_tiles
setblock 120 57 -6 minecraft:deepslate_tiles
setblock 127 57 -6 minecraft:deepslate_tiles
setblock 134 57 -6 minecraft:deepslate_tiles
setblock 141 57 -6 minecraft:deepslate_tiles
setblock 144 57 -6 minecraft:deepslate_tiles
fill 113 57 -5 118 57 -5 minecraft:black_concrete
fill 120 57 -5 125 57 -5 minecraft:black_concrete
fill 127 57 -5 132 57 -5 minecraft:black_concrete
fill 134 57 -5 139 57 -5 minecraft:black_concrete
fill 141 57 -5 143 57 -5 minecraft:black_concrete
setblock 112 57 -5 minecraft:deepslate_tiles
setblock 119 57 -5 minecraft:deepslate_tiles
setblock 126 57 -5 minecraft:deepslate_tiles
setblock 133 57 -5 minecraft:deepslate_tiles
setblock 140 57 -5 minecraft:deepslate_tiles
setblock 144 57 -5 minecraft:deepslate_tiles
fill 113 57 -4 117 57 -4 minecraft:black_concrete
fill 119 57 -4 124 57 -4 minecraft:black_concrete
fill 126 57 -4 131 57 -4 minecraft:black_concrete
fill 133 57 -4 138 57 -4 minecraft:black_concrete
fill 140 57 -4 143 57 -4 minecraft:black_concrete
setblock 112 57 -4 minecraft:deepslate_tiles
setblock 118 57 -4 minecraft:deepslate_tiles
setblock 125 57 -4 minecraft:deepslate_tiles
setblock 132 57 -4 minecraft:deepslate_tiles
setblock 139 57 -4 minecraft:deepslate_tiles
setblock 144 57 -4 minecraft:deepslate_tiles
fill 113 57 -3 116 57 -3 minecraft:black_concrete
fill 118 57 -3 123 57 -3 minecraft:black_concrete
fill 125 57 -3 130 57 -3 minecraft:black_concrete
fill 132 57 -3 137 57 -3 minecraft:black_concrete
fill 139 57 -3 143 57 -3 minecraft:black_concrete
setblock 112 57 -3 minecraft:deepslate_tiles
setblock 117 57 -3 minecraft:deepslate_tiles
setblock 124 57 -3 minecraft:deepslate_tiles
setblock 131 57 -3 minecraft:deepslate_tiles
setblock 138 57 -3 minecraft:deepslate_tiles
setblock 144 57 -3 minecraft:deepslate_tiles
fill 113 57 -2 115 57 -2 minecraft:black_concrete
fill 117 57 -2 122 57 -2 minecraft:black_concrete
fill 124 57 -2 129 57 -2 minecraft:black_concrete
fill 131 57 -2 136 57 -2 minecraft:black_concrete
fill 138 57 -2 143 57 -2 minecraft:black_concrete
setblock 112 57 -2 minecraft:deepslate_tiles
setblock 116 57 -2 minecraft:deepslate_tiles
setblock 123 57 -2 minecraft:deepslate_tiles
setblock 130 57 -2 minecraft:deepslate_tiles
setblock 137 57 -2 minecraft:deepslate_tiles
setblock 144 57 -2 minecraft:deepslate_tiles
fill 113 57 -1 114 57 -1 minecraft:black_concrete
fill 116 57 -1 121 57 -1 minecraft:black_concrete
fill 123 57 -1 128 57 -1 minecraft:black_concrete
fill 130 57 -1 135 57 -1 minecraft:black_concrete
fill 137 57 -1 142 57 -1 minecraft:black_concrete
setblock 112 57 -1 minecraft:deepslate_tiles
setblock 115 57 -1 minecraft:deepslate_tiles
setblock 122 57 -1 minecraft:deepslate_tiles
setblock 129 57 -1 minecraft:deepslate_tiles
setblock 136 57 -1 minecraft:deepslate_tiles
fill 143 57 -1 144 57 -1 minecraft:deepslate_tiles
setblock 113 57 0 minecraft:black_concrete
setblock 143 57 0 minecraft:black_concrete
setblock 112 57 0 minecraft:deepslate_tiles
setblock 114 57 0 minecraft:deepslate_tiles
setblock 142 57 0 minecraft:deepslate_tiles
setblock 144 57 0 minecraft:deepslate_tiles
setblock 115 57 0 minecraft:sea_lantern
setblock 120 57 0 minecraft:sea_lantern
setblock 125 57 0 minecraft:sea_lantern
setblock 130 57 0 minecraft:sea_lantern
setblock 135 57 0 minecraft:sea_lantern
setblock 140 57 0 minecraft:sea_lantern
fill 116 57 0 119 57 0 minecraft:waxed_oxidized_cut_copper
fill 121 57 0 124 57 0 minecraft:waxed_oxidized_cut_copper
fill 126 57 0 129 57 0 minecraft:waxed_oxidized_cut_copper
fill 131 57 0 134 57 0 minecraft:waxed_oxidized_cut_copper
fill 136 57 0 139 57 0 minecraft:waxed_oxidized_cut_copper
setblock 141 57 0 minecraft:waxed_oxidized_cut_copper
fill 114 57 1 119 57 1 minecraft:black_concrete
fill 121 57 1 126 57 1 minecraft:black_concrete
fill 128 57 1 133 57 1 minecraft:black_concrete
fill 135 57 1 140 57 1 minecraft:black_concrete
fill 142 57 1 143 57 1 minecraft:black_concrete
fill 112 57 1 113 57 1 minecraft:deepslate_tiles
setblock 120 57 1 minecraft:deepslate_tiles
setblock 127 57 1 minecraft:deepslate_tiles
setblock 134 57 1 minecraft:deepslate_tiles
setblock 141 57 1 minecraft:deepslate_tiles
setblock 144 57 1 minecraft:deepslate_tiles
fill 113 57 2 118 57 2 minecraft:black_concrete
fill 120 57 2 125 57 2 minecraft:black_concrete
fill 127 57 2 132 57 2 minecraft:black_concrete
fill 134 57 2 139 57 2 minecraft:black_concrete
fill 141 57 2 143 57 2 minecraft:black_concrete
setblock 112 57 2 minecraft:deepslate_tiles
setblock 119 57 2 minecraft:deepslate_tiles
setblock 126 57 2 minecraft:deepslate_tiles
setblock 133 57 2 minecraft:deepslate_tiles
setblock 140 57 2 minecraft:deepslate_tiles
setblock 144 57 2 minecraft:deepslate_tiles
fill 113 57 3 117 57 3 minecraft:black_concrete
fill 119 57 3 124 57 3 minecraft:black_concrete
fill 126 57 3 131 57 3 minecraft:black_concrete
fill 133 57 3 138 57 3 minecraft:black_concrete
fill 140 57 3 143 57 3 minecraft:black_concrete
setblock 112 57 3 minecraft:deepslate_tiles
setblock 118 57 3 minecraft:deepslate_tiles
setblock 125 57 3 minecraft:deepslate_tiles
setblock 132 57 3 minecraft:deepslate_tiles
setblock 139 57 3 minecraft:deepslate_tiles
setblock 144 57 3 minecraft:deepslate_tiles
fill 113 57 4 116 57 4 minecraft:black_concrete
fill 118 57 4 123 57 4 minecraft:black_concrete
fill 125 57 4 130 57 4 minecraft:black_concrete
fill 132 57 4 137 57 4 minecraft:black_concrete
fill 139 57 4 143 57 4 minecraft:black_concrete
setblock 112 57 4 minecraft:deepslate_tiles
setblock 117 57 4 minecraft:deepslate_tiles
setblock 124 57 4 minecraft:deepslate_tiles
setblock 131 57 4 minecraft:deepslate_tiles
setblock 138 57 4 minecraft:deepslate_tiles
setblock 144 57 4 minecraft:deepslate_tiles
fill 113 57 5 115 57 5 minecraft:black_concrete
fill 117 57 5 122 57 5 minecraft:black_concrete
fill 124 57 5 129 57 5 minecraft:black_concrete
fill 131 57 5 136 57 5 minecraft:black_concrete
fill 138 57 5 143 57 5 minecraft:black_concrete
setblock 112 57 5 minecraft:deepslate_tiles
setblock 116 57 5 minecraft:deepslate_tiles
setblock 123 57 5 minecraft:deepslate_tiles
setblock 130 57 5 minecraft:deepslate_tiles
setblock 137 57 5 minecraft:deepslate_tiles
setblock 144 57 5 minecraft:deepslate_tiles
fill 113 57 6 114 57 6 minecraft:black_concrete
fill 116 57 6 121 57 6 minecraft:black_concrete
fill 123 57 6 128 57 6 minecraft:black_concrete
fill 130 57 6 135 57 6 minecraft:black_concrete
fill 137 57 6 142 57 6 minecraft:black_concrete
setblock 112 57 6 minecraft:deepslate_tiles
setblock 115 57 6 minecraft:deepslate_tiles
setblock 122 57 6 minecraft:deepslate_tiles
setblock 129 57 6 minecraft:deepslate_tiles
setblock 136 57 6 minecraft:deepslate_tiles
fill 143 57 6 144 57 6 minecraft:deepslate_tiles
setblock 113 57 7 minecraft:black_concrete
setblock 143 57 7 minecraft:black_concrete
setblock 112 57 7 minecraft:deepslate_tiles
setblock 114 57 7 minecraft:deepslate_tiles
setblock 142 57 7 minecraft:deepslate_tiles
setblock 144 57 7 minecraft:deepslate_tiles
setblock 115 57 7 minecraft:sea_lantern
setblock 120 57 7 minecraft:sea_lantern
setblock 125 57 7 minecraft:sea_lantern
setblock 130 57 7 minecraft:sea_lantern
setblock 135 57 7 minecraft:sea_lantern
setblock 140 57 7 minecraft:sea_lantern
fill 116 57 7 119 57 7 minecraft:waxed_oxidized_cut_copper
fill 121 57 7 124 57 7 minecraft:waxed_oxidized_cut_copper
fill 126 57 7 129 57 7 minecraft:waxed_oxidized_cut_copper
fill 131 57 7 134 57 7 minecraft:waxed_oxidized_cut_copper
fill 136 57 7 139 57 7 minecraft:waxed_oxidized_cut_copper
setblock 141 57 7 minecraft:waxed_oxidized_cut_copper
fill 114 57 8 119 57 8 minecraft:black_concrete
fill 121 57 8 126 57 8 minecraft:black_concrete
fill 128 57 8 133 57 8 minecraft:black_concrete
fill 135 57 8 140 57 8 minecraft:black_concrete
fill 142 57 8 143 57 8 minecraft:black_concrete
fill 112 57 8 113 57 8 minecraft:deepslate_tiles
setblock 120 57 8 minecraft:deepslate_tiles
setblock 127 57 8 minecraft:deepslate_tiles
setblock 134 57 8 minecraft:deepslate_tiles
setblock 141 57 8 minecraft:deepslate_tiles
setblock 144 57 8 minecraft:deepslate_tiles
fill 113 57 9 118 57 9 minecraft:black_concrete
fill 120 57 9 125 57 9 minecraft:black_concrete
fill 127 57 9 132 57 9 minecraft:black_concrete
fill 134 57 9 139 57 9 minecraft:black_concrete
fill 141 57 9 143 57 9 minecraft:black_concrete
setblock 112 57 9 minecraft:deepslate_tiles
setblock 119 57 9 minecraft:deepslate_tiles
setblock 126 57 9 minecraft:deepslate_tiles
setblock 133 57 9 minecraft:deepslate_tiles
setblock 140 57 9 minecraft:deepslate_tiles
setblock 144 57 9 minecraft:deepslate_tiles
fill 113 57 10 117 57 10 minecraft:black_concrete
fill 119 57 10 124 57 10 minecraft:black_concrete
fill 126 57 10 131 57 10 minecraft:black_concrete
fill 133 57 10 138 57 10 minecraft:black_concrete
fill 140 57 10 143 57 10 minecraft:black_concrete
setblock 112 57 10 minecraft:deepslate_tiles
setblock 118 57 10 minecraft:deepslate_tiles
setblock 125 57 10 minecraft:deepslate_tiles
setblock 132 57 10 minecraft:deepslate_tiles
setblock 139 57 10 minecraft:deepslate_tiles
setblock 144 57 10 minecraft:deepslate_tiles
fill 113 57 11 116 57 11 minecraft:black_concrete
fill 118 57 11 123 57 11 minecraft:black_concrete
fill 125 57 11 130 57 11 minecraft:black_concrete
fill 132 57 11 137 57 11 minecraft:black_concrete
fill 139 57 11 143 57 11 minecraft:black_concrete
setblock 112 57 11 minecraft:deepslate_tiles
setblock 117 57 11 minecraft:deepslate_tiles
setblock 124 57 11 minecraft:deepslate_tiles
setblock 131 57 11 minecraft:deepslate_tiles
setblock 138 57 11 minecraft:deepslate_tiles
setblock 144 57 11 minecraft:deepslate_tiles
fill 113 57 12 115 57 12 minecraft:black_concrete
fill 117 57 12 122 57 12 minecraft:black_concrete
fill 124 57 12 129 57 12 minecraft:black_concrete
fill 131 57 12 136 57 12 minecraft:black_concrete
fill 138 57 12 143 57 12 minecraft:black_concrete
setblock 112 57 12 minecraft:deepslate_tiles
setblock 116 57 12 minecraft:deepslate_tiles
setblock 123 57 12 minecraft:deepslate_tiles
setblock 130 57 12 minecraft:deepslate_tiles
setblock 137 57 12 minecraft:deepslate_tiles
setblock 144 57 12 minecraft:deepslate_tiles
fill 113 57 13 114 57 13 minecraft:black_concrete
fill 116 57 13 121 57 13 minecraft:black_concrete
fill 123 57 13 128 57 13 minecraft:black_concrete
fill 130 57 13 135 57 13 minecraft:black_concrete
fill 137 57 13 142 57 13 minecraft:black_concrete
setblock 112 57 13 minecraft:deepslate_tiles
setblock 115 57 13 minecraft:deepslate_tiles
setblock 122 57 13 minecraft:deepslate_tiles
setblock 129 57 13 minecraft:deepslate_tiles
setblock 136 57 13 minecraft:deepslate_tiles
fill 143 57 13 144 57 13 minecraft:deepslate_tiles
setblock 113 57 14 minecraft:black_concrete
fill 115 57 14 120 57 14 minecraft:black_concrete
fill 122 57 14 127 57 14 minecraft:black_concrete
fill 129 57 14 134 57 14 minecraft:black_concrete
fill 136 57 14 141 57 14 minecraft:black_concrete
setblock 143 57 14 minecraft:black_concrete
setblock 112 57 14 minecraft:deepslate_tiles
setblock 114 57 14 minecraft:deepslate_tiles
setblock 121 57 14 minecraft:deepslate_tiles
setblock 128 57 14 minecraft:deepslate_tiles
setblock 135 57 14 minecraft:deepslate_tiles
setblock 142 57 14 minecraft:deepslate_tiles
setblock 144 57 14 minecraft:deepslate_tiles
fill 114 57 15 119 57 15 minecraft:black_concrete
fill 121 57 15 126 57 15 minecraft:black_concrete
fill 128 57 15 133 57 15 minecraft:black_concrete
fill 135 57 15 140 57 15 minecraft:black_concrete
fill 142 57 15 143 57 15 minecraft:black_concrete
fill 112 57 15 113 57 15 minecraft:deepslate_tiles
setblock 120 57 15 minecraft:deepslate_tiles
setblock 127 57 15 minecraft:deepslate_tiles
setblock 134 57 15 minecraft:deepslate_tiles
setblock 141 57 15 minecraft:deepslate_tiles
setblock 144 57 15 minecraft:deepslate_tiles
fill 112 57 16 144 57 16 minecraft:deepslate_tiles
fill 112 58 -16 144 58 -16 minecraft:deepslate_bricks
setblock 112 58 -15 minecraft:deepslate_bricks
setblock 144 58 -15 minecraft:deepslate_bricks
setblock 112 58 -14 minecraft:deepslate_bricks
setblock 144 58 -14 minecraft:deepslate_bricks
setblock 112 58 -13 minecraft:deepslate_bricks
setblock 144 58 -13 minecraft:deepslate_bricks
setblock 112 58 -12 minecraft:deepslate_bricks
setblock 144 58 -12 minecraft:deepslate_bricks
setblock 112 58 -11 minecraft:deepslate_bricks
setblock 144 58 -11 minecraft:deepslate_bricks
setblock 112 58 -10 minecraft:deepslate_bricks
setblock 144 58 -10 minecraft:deepslate_bricks
setblock 112 58 -9 minecraft:deepslate_bricks
setblock 144 58 -9 minecraft:deepslate_bricks
setblock 112 58 -8 minecraft:deepslate_bricks
setblock 144 58 -8 minecraft:deepslate_bricks
setblock 115 58 -7 minecraft:chiseled_deepslate
setblock 112 58 -7 minecraft:deepslate_bricks
setblock 144 58 -7 minecraft:deepslate_bricks
setblock 112 58 -6 minecraft:deepslate_bricks
setblock 144 58 -6 minecraft:deepslate_bricks
setblock 112 58 -5 minecraft:deepslate_bricks
setblock 144 58 -5 minecraft:deepslate_bricks
setblock 141 58 -4 minecraft:chiseled_deepslate
setblock 112 58 -4 minecraft:deepslate_bricks
setblock 144 58 -4 minecraft:deepslate_bricks
setblock 112 58 -3 minecraft:deepslate_bricks
setblock 144 58 -3 minecraft:deepslate_bricks
setblock 112 58 -2 minecraft:deepslate_bricks
setblock 144 58 -2 minecraft:deepslate_bricks
setblock 112 58 -1 minecraft:deepslate_bricks
setblock 144 58 -1 minecraft:deepslate_bricks
setblock 112 58 0 minecraft:deepslate_bricks
setblock 144 58 0 minecraft:deepslate_bricks
setblock 112 58 1 minecraft:deepslate_bricks
setblock 144 58 1 minecraft:deepslate_bricks
setblock 112 58 2 minecraft:deepslate_bricks
setblock 144 58 2 minecraft:deepslate_bricks
setblock 112 58 3 minecraft:deepslate_bricks
setblock 144 58 3 minecraft:deepslate_bricks
setblock 115 58 4 minecraft:chiseled_deepslate
setblock 112 58 4 minecraft:deepslate_bricks
setblock 144 58 4 minecraft:deepslate_bricks
setblock 112 58 5 minecraft:deepslate_bricks
setblock 144 58 5 minecraft:deepslate_bricks
setblock 112 58 6 minecraft:deepslate_bricks
setblock 144 58 6 minecraft:deepslate_bricks
setblock 141 58 7 minecraft:chiseled_deepslate
setblock 112 58 7 minecraft:deepslate_bricks
setblock 144 58 7 minecraft:deepslate_bricks
setblock 112 58 8 minecraft:deepslate_bricks
setblock 144 58 8 minecraft:deepslate_bricks
setblock 112 58 9 minecraft:deepslate_bricks
setblock 144 58 9 minecraft:deepslate_bricks
setblock 112 58 10 minecraft:deepslate_bricks
setblock 144 58 10 minecraft:deepslate_bricks
setblock 112 58 11 minecraft:deepslate_bricks
setblock 144 58 11 minecraft:deepslate_bricks
setblock 112 58 12 minecraft:deepslate_bricks
setblock 144 58 12 minecraft:deepslate_bricks
setblock 112 58 13 minecraft:deepslate_bricks
setblock 144 58 13 minecraft:deepslate_bricks
setblock 112 58 14 minecraft:deepslate_bricks
setblock 144 58 14 minecraft:deepslate_bricks
setblock 112 58 15 minecraft:deepslate_bricks
setblock 144 58 15 minecraft:deepslate_bricks
fill 112 58 16 144 58 16 minecraft:deepslate_bricks
fill 112 59 -16 144 59 -16 minecraft:deepslate_bricks
setblock 112 59 -15 minecraft:deepslate_bricks
setblock 144 59 -15 minecraft:deepslate_bricks
setblock 112 59 -14 minecraft:deepslate_bricks
setblock 144 59 -14 minecraft:deepslate_bricks
setblock 112 59 -13 minecraft:deepslate_bricks
setblock 144 59 -13 minecraft:deepslate_bricks
setblock 112 59 -12 minecraft:deepslate_bricks
setblock 144 59 -12 minecraft:deepslate_bricks
setblock 112 59 -11 minecraft:deepslate_bricks
setblock 144 59 -11 minecraft:deepslate_bricks
setblock 112 59 -10 minecraft:deepslate_bricks
setblock 144 59 -10 minecraft:deepslate_bricks
setblock 112 59 -9 minecraft:deepslate_bricks
setblock 144 59 -9 minecraft:deepslate_bricks
setblock 112 59 -8 minecraft:deepslate_bricks
setblock 144 59 -8 minecraft:deepslate_bricks
setblock 115 59 -7 minecraft:chiseled_deepslate
setblock 112 59 -7 minecraft:deepslate_bricks
setblock 144 59 -7 minecraft:deepslate_bricks
setblock 112 59 -6 minecraft:deepslate_bricks
setblock 144 59 -6 minecraft:deepslate_bricks
setblock 112 59 -5 minecraft:deepslate_bricks
setblock 144 59 -5 minecraft:deepslate_bricks
setblock 141 59 -4 minecraft:chiseled_deepslate
setblock 112 59 -4 minecraft:deepslate_bricks
setblock 144 59 -4 minecraft:deepslate_bricks
setblock 112 59 -3 minecraft:deepslate_bricks
setblock 144 59 -3 minecraft:deepslate_bricks
setblock 112 59 -2 minecraft:deepslate_bricks
setblock 144 59 -2 minecraft:deepslate_bricks
setblock 112 59 -1 minecraft:deepslate_bricks
setblock 144 59 -1 minecraft:deepslate_bricks
setblock 112 59 0 minecraft:deepslate_bricks
setblock 144 59 0 minecraft:deepslate_bricks
setblock 112 59 1 minecraft:deepslate_bricks
setblock 144 59 1 minecraft:deepslate_bricks
setblock 112 59 2 minecraft:deepslate_bricks
setblock 144 59 2 minecraft:deepslate_bricks
setblock 112 59 3 minecraft:deepslate_bricks
setblock 144 59 3 minecraft:deepslate_bricks
setblock 115 59 4 minecraft:chiseled_deepslate
setblock 112 59 4 minecraft:deepslate_bricks
setblock 144 59 4 minecraft:deepslate_bricks
setblock 112 59 5 minecraft:deepslate_bricks
setblock 144 59 5 minecraft:deepslate_bricks
setblock 112 59 6 minecraft:deepslate_bricks
setblock 144 59 6 minecraft:deepslate_bricks
setblock 141 59 7 minecraft:chiseled_deepslate
setblock 112 59 7 minecraft:deepslate_bricks
setblock 144 59 7 minecraft:deepslate_bricks
setblock 112 59 8 minecraft:deepslate_bricks
setblock 144 59 8 minecraft:deepslate_bricks
setblock 112 59 9 minecraft:deepslate_bricks
setblock 144 59 9 minecraft:deepslate_bricks
setblock 112 59 10 minecraft:deepslate_bricks
setblock 144 59 10 minecraft:deepslate_bricks
setblock 112 59 11 minecraft:deepslate_bricks
setblock 144 59 11 minecraft:deepslate_bricks
setblock 112 59 12 minecraft:deepslate_bricks
setblock 144 59 12 minecraft:deepslate_bricks
setblock 112 59 13 minecraft:deepslate_bricks
setblock 144 59 13 minecraft:deepslate_bricks
setblock 112 59 14 minecraft:deepslate_bricks
setblock 144 59 14 minecraft:deepslate_bricks
setblock 112 59 15 minecraft:deepslate_bricks
setblock 144 59 15 minecraft:deepslate_bricks
fill 112 59 16 144 59 16 minecraft:deepslate_bricks
fill 112 60 -16 144 60 -16 minecraft:deepslate_bricks
fill 112 60 -15 144 60 -15 minecraft:deepslate_bricks
fill 112 60 -14 144 60 -14 minecraft:deepslate_bricks
fill 112 60 -13 144 60 -13 minecraft:deepslate_bricks
fill 112 60 -12 144 60 -12 minecraft:deepslate_bricks
fill 112 60 -11 144 60 -11 minecraft:deepslate_bricks
fill 112 60 -10 144 60 -10 minecraft:deepslate_bricks
setblock 112 60 -9 minecraft:deepslate_bricks
setblock 144 60 -9 minecraft:deepslate_bricks
setblock 112 60 -8 minecraft:deepslate_bricks
setblock 144 60 -8 minecraft:deepslate_bricks
setblock 115 60 -7 minecraft:chiseled_deepslate
setblock 112 60 -7 minecraft:deepslate_bricks
setblock 144 60 -7 minecraft:deepslate_bricks
setblock 112 60 -6 minecraft:deepslate_bricks
setblock 144 60 -6 minecraft:deepslate_bricks
setblock 112 60 -5 minecraft:deepslate_bricks
setblock 144 60 -5 minecraft:deepslate_bricks
setblock 141 60 -4 minecraft:chiseled_deepslate
setblock 112 60 -4 minecraft:deepslate_bricks
setblock 144 60 -4 minecraft:deepslate_bricks
setblock 112 60 -3 minecraft:deepslate_bricks
setblock 144 60 -3 minecraft:deepslate_bricks
setblock 112 60 -2 minecraft:deepslate_bricks
setblock 144 60 -2 minecraft:deepslate_bricks
setblock 112 60 -1 minecraft:deepslate_bricks
setblock 144 60 -1 minecraft:deepslate_bricks
setblock 112 60 0 minecraft:deepslate_bricks
setblock 144 60 0 minecraft:deepslate_bricks
setblock 112 60 1 minecraft:deepslate_bricks
setblock 144 60 1 minecraft:deepslate_bricks
setblock 112 60 2 minecraft:deepslate_bricks
setblock 144 60 2 minecraft:deepslate_bricks
setblock 112 60 3 minecraft:deepslate_bricks
setblock 144 60 3 minecraft:deepslate_bricks
setblock 115 60 4 minecraft:chiseled_deepslate
setblock 112 60 4 minecraft:deepslate_bricks
setblock 144 60 4 minecraft:deepslate_bricks
setblock 112 60 5 minecraft:deepslate_bricks
setblock 144 60 5 minecraft:deepslate_bricks
setblock 112 60 6 minecraft:deepslate_bricks
setblock 144 60 6 minecraft:deepslate_bricks
setblock 141 60 7 minecraft:chiseled_deepslate
setblock 112 60 7 minecraft:deepslate_bricks
setblock 144 60 7 minecraft:deepslate_bricks
setblock 112 60 8 minecraft:deepslate_bricks
setblock 144 60 8 minecraft:deepslate_bricks
setblock 112 60 9 minecraft:deepslate_bricks
setblock 144 60 9 minecraft:deepslate_bricks
fill 112 60 10 144 60 10 minecraft:deepslate_bricks
fill 112 60 11 144 60 11 minecraft:deepslate_bricks
fill 112 60 12 144 60 12 minecraft:deepslate_bricks
fill 112 60 13 144 60 13 minecraft:deepslate_bricks
fill 112 60 14 144 60 14 minecraft:deepslate_bricks
fill 112 60 15 144 60 15 minecraft:deepslate_bricks
fill 112 60 16 144 60 16 minecraft:deepslate_bricks
fill 112 61 -16 144 61 -16 minecraft:deepslate_bricks
fill 112 61 -15 144 61 -15 minecraft:deepslate_bricks
fill 112 61 -14 144 61 -14 minecraft:deepslate_bricks
fill 112 61 -13 144 61 -13 minecraft:deepslate_bricks
fill 112 61 -12 144 61 -12 minecraft:deepslate_bricks
fill 112 61 -11 144 61 -11 minecraft:deepslate_bricks
fill 112 61 -10 127 61 -10 minecraft:deepslate_bricks
fill 130 61 -10 144 61 -10 minecraft:deepslate_bricks
fill 128 61 -10 129 61 -10 minecraft:polished_deepslate
setblock 112 61 -9 minecraft:deepslate_bricks
setblock 144 61 -9 minecraft:deepslate_bricks
fill 128 61 -9 129 61 -9 minecraft:polished_deepslate
setblock 112 61 -8 minecraft:deepslate_bricks
setblock 144 61 -8 minecraft:deepslate_bricks
setblock 112 61 -7 minecraft:deepslate_bricks
setblock 144 61 -7 minecraft:deepslate_bricks
setblock 112 61 -6 minecraft:deepslate_bricks
setblock 144 61 -6 minecraft:deepslate_bricks
setblock 112 61 -5 minecraft:deepslate_bricks
setblock 144 61 -5 minecraft:deepslate_bricks
setblock 112 61 -4 minecraft:deepslate_bricks
setblock 144 61 -4 minecraft:deepslate_bricks
fill 128 61 -4 129 61 -4 minecraft:polished_deepslate
setblock 112 61 -3 minecraft:deepslate_bricks
setblock 144 61 -3 minecraft:deepslate_bricks
fill 128 61 -3 129 61 -3 minecraft:polished_deepslate
setblock 112 61 -2 minecraft:deepslate_bricks
setblock 144 61 -2 minecraft:deepslate_bricks
setblock 112 61 -1 minecraft:deepslate_bricks
setblock 144 61 -1 minecraft:deepslate_bricks
setblock 112 61 0 minecraft:deepslate_bricks
setblock 144 61 0 minecraft:deepslate_bricks
setblock 112 61 1 minecraft:deepslate_bricks
setblock 144 61 1 minecraft:deepslate_bricks
setblock 112 61 2 minecraft:deepslate_bricks
setblock 144 61 2 minecraft:deepslate_bricks
setblock 112 61 3 minecraft:deepslate_bricks
setblock 144 61 3 minecraft:deepslate_bricks
setblock 112 61 4 minecraft:deepslate_bricks
setblock 144 61 4 minecraft:deepslate_bricks
setblock 112 61 5 minecraft:deepslate_bricks
setblock 144 61 5 minecraft:deepslate_bricks
fill 125 61 5 126 61 5 minecraft:polished_deepslate
setblock 112 61 6 minecraft:deepslate_bricks
setblock 144 61 6 minecraft:deepslate_bricks
fill 125 61 6 126 61 6 minecraft:polished_deepslate
setblock 112 61 7 minecraft:deepslate_bricks
setblock 144 61 7 minecraft:deepslate_bricks
setblock 112 61 8 minecraft:deepslate_bricks
setblock 144 61 8 minecraft:deepslate_bricks
fill 128 61 8 129 61 8 minecraft:polished_deepslate
setblock 112 61 9 minecraft:deepslate_bricks
setblock 144 61 9 minecraft:deepslate_bricks
fill 128 61 9 129 61 9 minecraft:polished_deepslate
fill 112 61 10 144 61 10 minecraft:deepslate_bricks
fill 112 61 11 144 61 11 minecraft:deepslate_bricks
fill 112 61 12 144 61 12 minecraft:deepslate_bricks
fill 112 61 13 144 61 13 minecraft:deepslate_bricks
fill 112 61 14 144 61 14 minecraft:deepslate_bricks
fill 112 61 15 144 61 15 minecraft:deepslate_bricks
fill 112 61 16 144 61 16 minecraft:deepslate_bricks
fill 112 62 -16 144 62 -16 minecraft:deepslate_bricks
fill 112 62 -15 144 62 -15 minecraft:deepslate_bricks
fill 112 62 -14 144 62 -14 minecraft:deepslate_bricks
fill 112 62 -13 144 62 -13 minecraft:deepslate_bricks
fill 112 62 -12 144 62 -12 minecraft:deepslate_bricks
fill 112 62 -11 144 62 -11 minecraft:deepslate_bricks
fill 112 62 -10 127 62 -10 minecraft:deepslate_bricks
fill 130 62 -10 144 62 -10 minecraft:deepslate_bricks
setblock 129 62 -10 minecraft:polished_deepslate
setblock 128 62 -10 minecraft:sea_lantern
setblock 112 62 -9 minecraft:deepslate_bricks
setblock 144 62 -9 minecraft:deepslate_bricks
fill 128 62 -9 129 62 -9 minecraft:polished_deepslate
setblock 112 62 -8 minecraft:deepslate_bricks
setblock 144 62 -8 minecraft:deepslate_bricks
setblock 112 62 -7 minecraft:deepslate_bricks
setblock 144 62 -7 minecraft:deepslate_bricks
fill 125 62 -7 126 62 -7 minecraft:polished_deepslate
setblock 112 62 -6 minecraft:deepslate_bricks
setblock 144 62 -6 minecraft:deepslate_bricks
fill 125 62 -6 126 62 -6 minecraft:polished_deepslate
setblock 112 62 -5 minecraft:deepslate_bricks
setblock 144 62 -5 minecraft:deepslate_bricks
setblock 112 62 -4 minecraft:deepslate_bricks
setblock 144 62 -4 minecraft:deepslate_bricks
setblock 129 62 -4 minecraft:polished_deepslate
setblock 128 62 -4 minecraft:sea_lantern
setblock 112 62 -3 minecraft:deepslate_bricks
setblock 144 62 -3 minecraft:deepslate_bricks
fill 128 62 -3 129 62 -3 minecraft:polished_deepslate
setblock 112 62 -2 minecraft:deepslate_bricks
setblock 144 62 -2 minecraft:deepslate_bricks
setblock 112 62 -1 minecraft:deepslate_bricks
setblock 144 62 -1 minecraft:deepslate_bricks
fill 131 62 -1 132 62 -1 minecraft:polished_deepslate
setblock 112 62 0 minecraft:deepslate_bricks
setblock 144 62 0 minecraft:deepslate_bricks
fill 131 62 0 132 62 0 minecraft:polished_deepslate
setblock 112 62 1 minecraft:deepslate_bricks
setblock 144 62 1 minecraft:deepslate_bricks
setblock 112 62 2 minecraft:deepslate_bricks
setblock 144 62 2 minecraft:deepslate_bricks
fill 128 62 2 129 62 2 minecraft:polished_deepslate
setblock 112 62 3 minecraft:deepslate_bricks
setblock 144 62 3 minecraft:deepslate_bricks
fill 128 62 3 129 62 3 minecraft:polished_deepslate
setblock 112 62 4 minecraft:deepslate_bricks
setblock 144 62 4 minecraft:deepslate_bricks
setblock 112 62 5 minecraft:deepslate_bricks
setblock 144 62 5 minecraft:deepslate_bricks
setblock 126 62 5 minecraft:polished_deepslate
setblock 125 62 5 minecraft:sea_lantern
setblock 112 62 6 minecraft:deepslate_bricks
setblock 144 62 6 minecraft:deepslate_bricks
fill 125 62 6 126 62 6 minecraft:polished_deepslate
setblock 112 62 7 minecraft:deepslate_bricks
setblock 144 62 7 minecraft:deepslate_bricks
setblock 112 62 8 minecraft:deepslate_bricks
setblock 144 62 8 minecraft:deepslate_bricks
setblock 129 62 8 minecraft:polished_deepslate
setblock 128 62 8 minecraft:sea_lantern
setblock 112 62 9 minecraft:deepslate_bricks
setblock 144 62 9 minecraft:deepslate_bricks
fill 128 62 9 129 62 9 minecraft:polished_deepslate
fill 112 62 10 144 62 10 minecraft:deepslate_bricks
fill 112 62 11 144 62 11 minecraft:deepslate_bricks
fill 112 62 12 144 62 12 minecraft:deepslate_bricks
fill 112 62 13 144 62 13 minecraft:deepslate_bricks
fill 112 62 14 144 62 14 minecraft:deepslate_bricks
fill 112 62 15 144 62 15 minecraft:deepslate_bricks
fill 112 62 16 144 62 16 minecraft:deepslate_bricks
fill 112 63 -16 144 63 -16 minecraft:deepslate_bricks
setblock 112 63 -15 minecraft:deepslate_bricks
setblock 144 63 -15 minecraft:deepslate_bricks
fill 113 63 -15 143 63 -15 minecraft:polished_deepslate
setblock 112 63 -14 minecraft:deepslate_bricks
setblock 144 63 -14 minecraft:deepslate_bricks
fill 113 63 -14 143 63 -14 minecraft:polished_deepslate
setblock 112 63 -13 minecraft:deepslate_bricks
setblock 144 63 -13 minecraft:deepslate_bricks
fill 113 63 -13 115 63 -13 minecraft:polished_deepslate
fill 117 63 -13 119 63 -13 minecraft:polished_deepslate
fill 121 63 -13 123 63 -13 minecraft:polished_deepslate
fill 125 63 -13 127 63 -13 minecraft:polished_deepslate
fill 129 63 -13 131 63 -13 minecraft:polished_deepslate
fill 133 63 -13 135 63 -13 minecraft:polished_deepslate
fill 137 63 -13 139 63 -13 minecraft:polished_deepslate
fill 141 63 -13 143 63 -13 minecraft:polished_deepslate
setblock 116 63 -13 minecraft:sea_lantern
setblock 120 63 -13 minecraft:sea_lantern
setblock 124 63 -13 minecraft:sea_lantern
setblock 128 63 -13 minecraft:sea_lantern
setblock 132 63 -13 minecraft:sea_lantern
setblock 136 63 -13 minecraft:sea_lantern
setblock 140 63 -13 minecraft:sea_lantern
setblock 112 63 -12 minecraft:deepslate_bricks
setblock 144 63 -12 minecraft:deepslate_bricks
fill 113 63 -12 127 63 -12 minecraft:polished_deepslate
fill 130 63 -12 143 63 -12 minecraft:polished_deepslate
fill 128 63 -12 129 63 -12 minecraft:yellow_concrete
setblock 112 63 -11 minecraft:deepslate_bricks
setblock 144 63 -11 minecraft:deepslate_bricks
fill 113 63 -11 127 63 -11 minecraft:polished_deepslate
fill 130 63 -11 143 63 -11 minecraft:polished_deepslate
fill 128 63 -11 129 63 -11 minecraft:yellow_concrete
setblock 112 63 -10 minecraft:deepslate_bricks
setblock 144 63 -10 minecraft:deepslate_bricks
fill 128 63 -10 129 63 -10 minecraft:waxed_oxidized_cut_copper
fill 113 63 -10 127 63 -10 minecraft:waxed_weathered_cut_copper
fill 130 63 -10 143 63 -10 minecraft:waxed_weathered_cut_copper
setblock 112 63 -9 minecraft:deepslate_bricks
setblock 144 63 -9 minecraft:deepslate_bricks
fill 128 63 -9 129 63 -9 minecraft:waxed_oxidized_cut_copper
setblock 112 63 -8 minecraft:deepslate_bricks
setblock 144 63 -8 minecraft:deepslate_bricks
setblock 112 63 -7 minecraft:deepslate_bricks
setblock 144 63 -7 minecraft:deepslate_bricks
setblock 126 63 -7 minecraft:polished_deepslate
setblock 125 63 -7 minecraft:sea_lantern
setblock 112 63 -6 minecraft:deepslate_bricks
setblock 144 63 -6 minecraft:deepslate_bricks
fill 125 63 -6 126 63 -6 minecraft:polished_deepslate
setblock 112 63 -5 minecraft:deepslate_bricks
setblock 144 63 -5 minecraft:deepslate_bricks
setblock 112 63 -4 minecraft:deepslate_bricks
setblock 144 63 -4 minecraft:deepslate_bricks
fill 128 63 -4 129 63 -4 minecraft:lime_concrete
setblock 112 63 -3 minecraft:deepslate_bricks
setblock 144 63 -3 minecraft:deepslate_bricks
fill 128 63 -3 129 63 -3 minecraft:lime_concrete
setblock 112 63 -2 minecraft:deepslate_bricks
setblock 144 63 -2 minecraft:deepslate_bricks
setblock 112 63 -1 minecraft:deepslate_bricks
setblock 144 63 -1 minecraft:deepslate_bricks
setblock 132 63 -1 minecraft:polished_deepslate
setblock 131 63 -1 minecraft:sea_lantern
setblock 112 63 0 minecraft:deepslate_bricks
setblock 144 63 0 minecraft:deepslate_bricks
fill 131 63 0 132 63 0 minecraft:polished_deepslate
setblock 112 63 1 minecraft:deepslate_bricks
setblock 144 63 1 minecraft:deepslate_bricks
setblock 112 63 2 minecraft:deepslate_bricks
setblock 144 63 2 minecraft:deepslate_bricks
setblock 129 63 2 minecraft:polished_deepslate
setblock 128 63 2 minecraft:sea_lantern
setblock 112 63 3 minecraft:deepslate_bricks
setblock 144 63 3 minecraft:deepslate_bricks
fill 128 63 3 129 63 3 minecraft:polished_deepslate
setblock 112 63 4 minecraft:deepslate_bricks
setblock 144 63 4 minecraft:deepslate_bricks
setblock 112 63 5 minecraft:deepslate_bricks
setblock 144 63 5 minecraft:deepslate_bricks
fill 125 63 5 126 63 5 minecraft:waxed_oxidized_cut_copper
setblock 112 63 6 minecraft:deepslate_bricks
setblock 144 63 6 minecraft:deepslate_bricks
fill 125 63 6 126 63 6 minecraft:waxed_oxidized_cut_copper
setblock 112 63 7 minecraft:deepslate_bricks
setblock 144 63 7 minecraft:deepslate_bricks
setblock 112 63 8 minecraft:deepslate_bricks
setblock 144 63 8 minecraft:deepslate_bricks
fill 128 63 8 129 63 8 minecraft:waxed_oxidized_cut_copper
setblock 112 63 9 minecraft:deepslate_bricks
setblock 144 63 9 minecraft:deepslate_bricks
fill 128 63 9 129 63 9 minecraft:waxed_oxidized_cut_copper
setblock 112 63 10 minecraft:deepslate_bricks
setblock 144 63 10 minecraft:deepslate_bricks
fill 113 63 10 143 63 10 minecraft:waxed_weathered_cut_copper
setblock 112 63 11 minecraft:deepslate_bricks
setblock 144 63 11 minecraft:deepslate_bricks
fill 113 63 11 143 63 11 minecraft:polished_deepslate
setblock 140 63 12 minecraft:chiseled_quartz_block
setblock 112 63 12 minecraft:deepslate_bricks
setblock 144 63 12 minecraft:deepslate_bricks
fill 113 63 12 115 63 12 minecraft:polished_deepslate
fill 117 63 12 119 63 12 minecraft:polished_deepslate
fill 121 63 12 123 63 12 minecraft:polished_deepslate
fill 125 63 12 127 63 12 minecraft:polished_deepslate
fill 130 63 12 131 63 12 minecraft:polished_deepslate
fill 133 63 12 135 63 12 minecraft:polished_deepslate
fill 137 63 12 139 63 12 minecraft:polished_deepslate
fill 141 63 12 143 63 12 minecraft:polished_deepslate
fill 128 63 12 129 63 12 minecraft:quartz_block
setblock 116 63 12 minecraft:sea_lantern
setblock 120 63 12 minecraft:sea_lantern
setblock 124 63 12 minecraft:sea_lantern
setblock 132 63 12 minecraft:sea_lantern
setblock 136 63 12 minecraft:sea_lantern
setblock 112 63 13 minecraft:deepslate_bricks
setblock 144 63 13 minecraft:deepslate_bricks
fill 113 63 13 127 63 13 minecraft:polished_deepslate
fill 130 63 13 143 63 13 minecraft:polished_deepslate
fill 128 63 13 129 63 13 minecraft:quartz_block
setblock 112 63 14 minecraft:deepslate_bricks
setblock 144 63 14 minecraft:deepslate_bricks
fill 113 63 14 143 63 14 minecraft:polished_deepslate
setblock 112 63 15 minecraft:deepslate_bricks
setblock 144 63 15 minecraft:deepslate_bricks
fill 113 63 15 143 63 15 minecraft:polished_deepslate
fill 112 63 16 144 63 16 minecraft:deepslate_bricks
fill 112 64 -16 144 64 -16 minecraft:deepslate_bricks
setblock 112 64 -15 minecraft:deepslate_bricks
setblock 144 64 -15 minecraft:deepslate_bricks
setblock 116 64 -15 minecraft:waxed_weathered_cut_copper
setblock 122 64 -15 minecraft:waxed_weathered_cut_copper
setblock 128 64 -15 minecraft:waxed_weathered_cut_copper
setblock 134 64 -15 minecraft:waxed_weathered_cut_copper
setblock 140 64 -15 minecraft:waxed_weathered_cut_copper
setblock 112 64 -14 minecraft:deepslate_bricks
setblock 144 64 -14 minecraft:deepslate_bricks
setblock 112 64 -13 minecraft:deepslate_bricks
setblock 144 64 -13 minecraft:deepslate_bricks
setblock 112 64 -12 minecraft:deepslate_bricks
setblock 144 64 -12 minecraft:deepslate_bricks
setblock 113 64 -12 minecraft:waxed_weathered_cut_copper
setblock 143 64 -12 minecraft:waxed_weathered_cut_copper
setblock 112 64 -11 minecraft:deepslate_bricks
setblock 144 64 -11 minecraft:deepslate_bricks
setblock 112 64 -10 minecraft:deepslate_bricks
setblock 144 64 -10 minecraft:deepslate_bricks
setblock 112 64 -9 minecraft:deepslate_bricks
setblock 144 64 -9 minecraft:deepslate_bricks
setblock 112 64 -8 minecraft:deepslate_bricks
setblock 144 64 -8 minecraft:deepslate_bricks
setblock 112 64 -7 minecraft:deepslate_bricks
setblock 144 64 -7 minecraft:deepslate_bricks
fill 125 64 -7 126 64 -7 minecraft:waxed_oxidized_cut_copper
setblock 112 64 -6 minecraft:deepslate_bricks
setblock 144 64 -6 minecraft:deepslate_bricks
fill 125 64 -6 126 64 -6 minecraft:waxed_oxidized_cut_copper
setblock 113 64 -6 minecraft:waxed_weathered_cut_copper
setblock 143 64 -6 minecraft:waxed_weathered_cut_copper
setblock 112 64 -5 minecraft:deepslate_bricks
setblock 144 64 -5 minecraft:deepslate_bricks
setblock 112 64 -4 minecraft:deepslate_bricks
setblock 144 64 -4 minecraft:deepslate_bricks
setblock 112 64 -3 minecraft:deepslate_bricks
setblock 144 64 -3 minecraft:deepslate_bricks
setblock 112 64 -2 minecraft:deepslate_bricks
setblock 144 64 -2 minecraft:deepslate_bricks
setblock 112 64 -1 minecraft:deepslate_bricks
setblock 144 64 -1 minecraft:deepslate_bricks
fill 131 64 -1 132 64 -1 minecraft:waxed_oxidized_cut_copper
setblock 112 64 0 minecraft:deepslate_bricks
setblock 144 64 0 minecraft:deepslate_bricks
fill 131 64 0 132 64 0 minecraft:waxed_oxidized_cut_copper
setblock 113 64 0 minecraft:waxed_weathered_cut_copper
setblock 143 64 0 minecraft:waxed_weathered_cut_copper
setblock 112 64 1 minecraft:deepslate_bricks
setblock 144 64 1 minecraft:deepslate_bricks
setblock 112 64 2 minecraft:deepslate_bricks
setblock 144 64 2 minecraft:deepslate_bricks
fill 128 64 2 129 64 2 minecraft:waxed_oxidized_cut_copper
setblock 112 64 3 minecraft:deepslate_bricks
setblock 144 64 3 minecraft:deepslate_bricks
fill 128 64 3 129 64 3 minecraft:waxed_oxidized_cut_copper
setblock 112 64 4 minecraft:deepslate_bricks
setblock 144 64 4 minecraft:deepslate_bricks
setblock 112 64 5 minecraft:deepslate_bricks
setblock 144 64 5 minecraft:deepslate_bricks
setblock 112 64 6 minecraft:deepslate_bricks
setblock 144 64 6 minecraft:deepslate_bricks
setblock 113 64 6 minecraft:waxed_weathered_cut_copper
setblock 143 64 6 minecraft:waxed_weathered_cut_copper
setblock 112 64 7 minecraft:deepslate_bricks
setblock 144 64 7 minecraft:deepslate_bricks
setblock 112 64 8 minecraft:deepslate_bricks
setblock 144 64 8 minecraft:deepslate_bricks
setblock 112 64 9 minecraft:deepslate_bricks
setblock 144 64 9 minecraft:deepslate_bricks
setblock 112 64 10 minecraft:deepslate_bricks
setblock 144 64 10 minecraft:deepslate_bricks
setblock 112 64 11 minecraft:deepslate_bricks
setblock 144 64 11 minecraft:deepslate_bricks
setblock 142 64 11 minecraft:polished_blackstone_bricks
setblock 112 64 12 minecraft:deepslate_bricks
setblock 144 64 12 minecraft:deepslate_bricks
setblock 142 64 12 minecraft:polished_blackstone_bricks
setblock 113 64 12 minecraft:waxed_weathered_cut_copper
setblock 143 64 12 minecraft:waxed_weathered_cut_copper
setblock 112 64 13 minecraft:deepslate_bricks
setblock 144 64 13 minecraft:deepslate_bricks
setblock 142 64 13 minecraft:polished_blackstone_bricks
setblock 112 64 14 minecraft:deepslate_bricks
setblock 144 64 14 minecraft:deepslate_bricks
setblock 112 64 15 minecraft:deepslate_bricks
setblock 144 64 15 minecraft:deepslate_bricks
setblock 116 64 15 minecraft:waxed_weathered_cut_copper
setblock 122 64 15 minecraft:waxed_weathered_cut_copper
setblock 128 64 15 minecraft:waxed_weathered_cut_copper
setblock 134 64 15 minecraft:waxed_weathered_cut_copper
setblock 140 64 15 minecraft:waxed_weathered_cut_copper
fill 112 64 16 144 64 16 minecraft:deepslate_bricks
fill 112 65 -16 144 65 -16 minecraft:deepslate_bricks
setblock 112 65 -15 minecraft:deepslate_bricks
setblock 144 65 -15 minecraft:deepslate_bricks
setblock 116 65 -15 minecraft:waxed_weathered_cut_copper
setblock 122 65 -15 minecraft:waxed_weathered_cut_copper
setblock 128 65 -15 minecraft:waxed_weathered_cut_copper
setblock 134 65 -15 minecraft:waxed_weathered_cut_copper
setblock 140 65 -15 minecraft:waxed_weathered_cut_copper
setblock 112 65 -14 minecraft:deepslate_bricks
setblock 144 65 -14 minecraft:deepslate_bricks
setblock 112 65 -13 minecraft:deepslate_bricks
setblock 144 65 -13 minecraft:deepslate_bricks
setblock 112 65 -12 minecraft:deepslate_bricks
setblock 144 65 -12 minecraft:deepslate_bricks
setblock 113 65 -12 minecraft:waxed_weathered_cut_copper
setblock 143 65 -12 minecraft:waxed_weathered_cut_copper
setblock 112 65 -11 minecraft:deepslate_bricks
setblock 144 65 -11 minecraft:deepslate_bricks
setblock 112 65 -10 minecraft:deepslate_bricks
setblock 144 65 -10 minecraft:deepslate_bricks
setblock 112 65 -9 minecraft:deepslate_bricks
setblock 144 65 -9 minecraft:deepslate_bricks
setblock 112 65 -8 minecraft:deepslate_bricks
setblock 144 65 -8 minecraft:deepslate_bricks
setblock 112 65 -7 minecraft:deepslate_bricks
setblock 144 65 -7 minecraft:deepslate_bricks
setblock 112 65 -6 minecraft:deepslate_bricks
setblock 144 65 -6 minecraft:deepslate_bricks
setblock 113 65 -6 minecraft:waxed_weathered_cut_copper
setblock 143 65 -6 minecraft:waxed_weathered_cut_copper
setblock 112 65 -5 minecraft:deepslate_bricks
setblock 144 65 -5 minecraft:deepslate_bricks
setblock 112 65 -4 minecraft:deepslate_bricks
setblock 144 65 -4 minecraft:deepslate_bricks
setblock 112 65 -3 minecraft:deepslate_bricks
setblock 144 65 -3 minecraft:deepslate_bricks
setblock 112 65 -2 minecraft:deepslate_bricks
setblock 144 65 -2 minecraft:deepslate_bricks
setblock 112 65 -1 minecraft:deepslate_bricks
setblock 144 65 -1 minecraft:deepslate_bricks
setblock 112 65 0 minecraft:deepslate_bricks
setblock 144 65 0 minecraft:deepslate_bricks
setblock 113 65 0 minecraft:waxed_weathered_cut_copper
setblock 143 65 0 minecraft:waxed_weathered_cut_copper
setblock 112 65 1 minecraft:deepslate_bricks
setblock 144 65 1 minecraft:deepslate_bricks
setblock 112 65 2 minecraft:deepslate_bricks
setblock 144 65 2 minecraft:deepslate_bricks
setblock 112 65 3 minecraft:deepslate_bricks
setblock 144 65 3 minecraft:deepslate_bricks
setblock 112 65 4 minecraft:deepslate_bricks
setblock 144 65 4 minecraft:deepslate_bricks
setblock 112 65 5 minecraft:deepslate_bricks
setblock 144 65 5 minecraft:deepslate_bricks
setblock 112 65 6 minecraft:deepslate_bricks
setblock 144 65 6 minecraft:deepslate_bricks
setblock 113 65 6 minecraft:waxed_weathered_cut_copper
setblock 143 65 6 minecraft:waxed_weathered_cut_copper
setblock 112 65 7 minecraft:deepslate_bricks
setblock 144 65 7 minecraft:deepslate_bricks
setblock 112 65 8 minecraft:deepslate_bricks
setblock 144 65 8 minecraft:deepslate_bricks
setblock 112 65 9 minecraft:deepslate_bricks
setblock 144 65 9 minecraft:deepslate_bricks
setblock 112 65 10 minecraft:deepslate_bricks
setblock 144 65 10 minecraft:deepslate_bricks
setblock 112 65 11 minecraft:deepslate_bricks
setblock 144 65 11 minecraft:deepslate_bricks
setblock 142 65 11 minecraft:polished_blackstone_bricks
setblock 112 65 12 minecraft:deepslate_bricks
setblock 144 65 12 minecraft:deepslate_bricks
setblock 142 65 12 minecraft:polished_blackstone_bricks
setblock 113 65 12 minecraft:waxed_weathered_cut_copper
setblock 143 65 12 minecraft:waxed_weathered_cut_copper
setblock 112 65 13 minecraft:deepslate_bricks
setblock 144 65 13 minecraft:deepslate_bricks
setblock 142 65 13 minecraft:polished_blackstone_bricks
setblock 112 65 14 minecraft:deepslate_bricks
setblock 144 65 14 minecraft:deepslate_bricks
setblock 112 65 15 minecraft:deepslate_bricks
setblock 144 65 15 minecraft:deepslate_bricks
setblock 116 65 15 minecraft:waxed_weathered_cut_copper
setblock 122 65 15 minecraft:waxed_weathered_cut_copper
setblock 128 65 15 minecraft:waxed_weathered_cut_copper
setblock 134 65 15 minecraft:waxed_weathered_cut_copper
setblock 140 65 15 minecraft:waxed_weathered_cut_copper
fill 112 65 16 144 65 16 minecraft:deepslate_bricks
fill 112 66 -16 144 66 -16 minecraft:deepslate_bricks
setblock 112 66 -15 minecraft:deepslate_bricks
setblock 144 66 -15 minecraft:deepslate_bricks
fill 113 66 -15 143 66 -15 minecraft:waxed_weathered_cut_copper
setblock 112 66 -14 minecraft:deepslate_bricks
setblock 144 66 -14 minecraft:deepslate_bricks
setblock 113 66 -14 minecraft:waxed_weathered_cut_copper
setblock 143 66 -14 minecraft:waxed_weathered_cut_copper
setblock 112 66 -13 minecraft:deepslate_bricks
setblock 144 66 -13 minecraft:deepslate_bricks
setblock 113 66 -13 minecraft:waxed_weathered_cut_copper
setblock 143 66 -13 minecraft:waxed_weathered_cut_copper
setblock 112 66 -12 minecraft:deepslate_bricks
setblock 144 66 -12 minecraft:deepslate_bricks
setblock 113 66 -12 minecraft:waxed_weathered_cut_copper
setblock 143 66 -12 minecraft:waxed_weathered_cut_copper
setblock 112 66 -11 minecraft:deepslate_bricks
setblock 144 66 -11 minecraft:deepslate_bricks
setblock 113 66 -11 minecraft:waxed_weathered_cut_copper
setblock 143 66 -11 minecraft:waxed_weathered_cut_copper
setblock 112 66 -10 minecraft:deepslate_bricks
setblock 144 66 -10 minecraft:deepslate_bricks
setblock 113 66 -10 minecraft:waxed_weathered_cut_copper
setblock 143 66 -10 minecraft:waxed_weathered_cut_copper
setblock 112 66 -9 minecraft:deepslate_bricks
setblock 144 66 -9 minecraft:deepslate_bricks
setblock 113 66 -9 minecraft:waxed_weathered_cut_copper
setblock 143 66 -9 minecraft:waxed_weathered_cut_copper
setblock 112 66 -8 minecraft:deepslate_bricks
setblock 144 66 -8 minecraft:deepslate_bricks
setblock 113 66 -8 minecraft:waxed_weathered_cut_copper
setblock 143 66 -8 minecraft:waxed_weathered_cut_copper
setblock 112 66 -7 minecraft:deepslate_bricks
setblock 144 66 -7 minecraft:deepslate_bricks
setblock 113 66 -7 minecraft:waxed_weathered_cut_copper
setblock 143 66 -7 minecraft:waxed_weathered_cut_copper
setblock 112 66 -6 minecraft:deepslate_bricks
setblock 144 66 -6 minecraft:deepslate_bricks
setblock 113 66 -6 minecraft:waxed_weathered_cut_copper
setblock 143 66 -6 minecraft:waxed_weathered_cut_copper
setblock 112 66 -5 minecraft:deepslate_bricks
setblock 144 66 -5 minecraft:deepslate_bricks
setblock 113 66 -5 minecraft:waxed_weathered_cut_copper
setblock 143 66 -5 minecraft:waxed_weathered_cut_copper
setblock 112 66 -4 minecraft:deepslate_bricks
setblock 144 66 -4 minecraft:deepslate_bricks
setblock 113 66 -4 minecraft:waxed_weathered_cut_copper
setblock 143 66 -4 minecraft:waxed_weathered_cut_copper
setblock 112 66 -3 minecraft:deepslate_bricks
setblock 144 66 -3 minecraft:deepslate_bricks
setblock 113 66 -3 minecraft:waxed_weathered_cut_copper
setblock 143 66 -3 minecraft:waxed_weathered_cut_copper
setblock 112 66 -2 minecraft:deepslate_bricks
setblock 144 66 -2 minecraft:deepslate_bricks
setblock 113 66 -2 minecraft:waxed_weathered_cut_copper
setblock 143 66 -2 minecraft:waxed_weathered_cut_copper
setblock 112 66 -1 minecraft:deepslate_bricks
setblock 144 66 -1 minecraft:deepslate_bricks
setblock 113 66 -1 minecraft:waxed_weathered_cut_copper
setblock 143 66 -1 minecraft:waxed_weathered_cut_copper
setblock 112 66 0 minecraft:deepslate_bricks
setblock 144 66 0 minecraft:deepslate_bricks
setblock 113 66 0 minecraft:waxed_weathered_cut_copper
setblock 143 66 0 minecraft:waxed_weathered_cut_copper
setblock 112 66 1 minecraft:deepslate_bricks
setblock 144 66 1 minecraft:deepslate_bricks
setblock 113 66 1 minecraft:waxed_weathered_cut_copper
setblock 143 66 1 minecraft:waxed_weathered_cut_copper
setblock 112 66 2 minecraft:deepslate_bricks
setblock 144 66 2 minecraft:deepslate_bricks
setblock 113 66 2 minecraft:waxed_weathered_cut_copper
setblock 143 66 2 minecraft:waxed_weathered_cut_copper
setblock 112 66 3 minecraft:deepslate_bricks
setblock 144 66 3 minecraft:deepslate_bricks
setblock 113 66 3 minecraft:waxed_weathered_cut_copper
setblock 143 66 3 minecraft:waxed_weathered_cut_copper
setblock 112 66 4 minecraft:deepslate_bricks
setblock 144 66 4 minecraft:deepslate_bricks
setblock 113 66 4 minecraft:waxed_weathered_cut_copper
setblock 143 66 4 minecraft:waxed_weathered_cut_copper
setblock 112 66 5 minecraft:deepslate_bricks
setblock 144 66 5 minecraft:deepslate_bricks
setblock 113 66 5 minecraft:waxed_weathered_cut_copper
setblock 143 66 5 minecraft:waxed_weathered_cut_copper
setblock 112 66 6 minecraft:deepslate_bricks
setblock 144 66 6 minecraft:deepslate_bricks
setblock 113 66 6 minecraft:waxed_weathered_cut_copper
setblock 143 66 6 minecraft:waxed_weathered_cut_copper
setblock 112 66 7 minecraft:deepslate_bricks
setblock 144 66 7 minecraft:deepslate_bricks
setblock 113 66 7 minecraft:waxed_weathered_cut_copper
setblock 143 66 7 minecraft:waxed_weathered_cut_copper
setblock 112 66 8 minecraft:deepslate_bricks
setblock 144 66 8 minecraft:deepslate_bricks
setblock 113 66 8 minecraft:waxed_weathered_cut_copper
setblock 143 66 8 minecraft:waxed_weathered_cut_copper
setblock 112 66 9 minecraft:deepslate_bricks
setblock 144 66 9 minecraft:deepslate_bricks
setblock 113 66 9 minecraft:waxed_weathered_cut_copper
setblock 143 66 9 minecraft:waxed_weathered_cut_copper
setblock 112 66 10 minecraft:deepslate_bricks
setblock 144 66 10 minecraft:deepslate_bricks
setblock 113 66 10 minecraft:waxed_weathered_cut_copper
setblock 143 66 10 minecraft:waxed_weathered_cut_copper
setblock 112 66 11 minecraft:deepslate_bricks
setblock 144 66 11 minecraft:deepslate_bricks
setblock 142 66 11 minecraft:polished_blackstone_bricks
setblock 113 66 11 minecraft:waxed_weathered_cut_copper
setblock 143 66 11 minecraft:waxed_weathered_cut_copper
setblock 141 66 12 minecraft:amethyst_block
setblock 112 66 12 minecraft:deepslate_bricks
setblock 144 66 12 minecraft:deepslate_bricks
setblock 142 66 12 minecraft:sea_lantern
setblock 113 66 12 minecraft:waxed_weathered_cut_copper
setblock 143 66 12 minecraft:waxed_weathered_cut_copper
setblock 112 66 13 minecraft:deepslate_bricks
setblock 144 66 13 minecraft:deepslate_bricks
setblock 142 66 13 minecraft:polished_blackstone_bricks
setblock 113 66 13 minecraft:waxed_weathered_cut_copper
setblock 143 66 13 minecraft:waxed_weathered_cut_copper
setblock 112 66 14 minecraft:deepslate_bricks
setblock 144 66 14 minecraft:deepslate_bricks
setblock 113 66 14 minecraft:waxed_weathered_cut_copper
setblock 143 66 14 minecraft:waxed_weathered_cut_copper
setblock 112 66 15 minecraft:deepslate_bricks
setblock 144 66 15 minecraft:deepslate_bricks
fill 113 66 15 143 66 15 minecraft:waxed_weathered_cut_copper
fill 112 66 16 144 66 16 minecraft:deepslate_bricks
fill 112 67 -16 115 67 -16 minecraft:deepslate_bricks
fill 117 67 -16 121 67 -16 minecraft:deepslate_bricks
fill 123 67 -16 127 67 -16 minecraft:deepslate_bricks
fill 129 67 -16 133 67 -16 minecraft:deepslate_bricks
fill 135 67 -16 139 67 -16 minecraft:deepslate_bricks
fill 141 67 -16 144 67 -16 minecraft:deepslate_bricks
setblock 116 67 -16 minecraft:sea_lantern
setblock 122 67 -16 minecraft:sea_lantern
setblock 128 67 -16 minecraft:sea_lantern
setblock 134 67 -16 minecraft:sea_lantern
setblock 140 67 -16 minecraft:sea_lantern
setblock 116 67 -15 minecraft:cyan_stained_glass
setblock 122 67 -15 minecraft:cyan_stained_glass
setblock 128 67 -15 minecraft:cyan_stained_glass
setblock 134 67 -15 minecraft:cyan_stained_glass
setblock 140 67 -15 minecraft:cyan_stained_glass
setblock 112 67 -15 minecraft:deepslate_bricks
setblock 144 67 -15 minecraft:deepslate_bricks
setblock 112 67 -14 minecraft:deepslate_bricks
setblock 144 67 -14 minecraft:deepslate_bricks
setblock 112 67 -13 minecraft:deepslate_bricks
setblock 144 67 -13 minecraft:deepslate_bricks
setblock 113 67 -12 minecraft:cyan_stained_glass
setblock 143 67 -12 minecraft:cyan_stained_glass
setblock 112 67 -12 minecraft:sea_lantern
setblock 144 67 -12 minecraft:sea_lantern
setblock 112 67 -11 minecraft:deepslate_bricks
setblock 144 67 -11 minecraft:deepslate_bricks
setblock 112 67 -10 minecraft:deepslate_bricks
setblock 144 67 -10 minecraft:deepslate_bricks
setblock 112 67 -9 minecraft:deepslate_bricks
setblock 144 67 -9 minecraft:deepslate_bricks
setblock 112 67 -8 minecraft:deepslate_bricks
setblock 144 67 -8 minecraft:deepslate_bricks
setblock 112 67 -7 minecraft:deepslate_bricks
setblock 144 67 -7 minecraft:deepslate_bricks
setblock 113 67 -6 minecraft:cyan_stained_glass
setblock 143 67 -6 minecraft:cyan_stained_glass
setblock 112 67 -6 minecraft:sea_lantern
setblock 144 67 -6 minecraft:sea_lantern
setblock 112 67 -5 minecraft:deepslate_bricks
setblock 144 67 -5 minecraft:deepslate_bricks
setblock 112 67 -4 minecraft:deepslate_bricks
setblock 144 67 -4 minecraft:deepslate_bricks
setblock 112 67 -3 minecraft:deepslate_bricks
setblock 144 67 -3 minecraft:deepslate_bricks
setblock 112 67 -2 minecraft:deepslate_bricks
setblock 144 67 -2 minecraft:deepslate_bricks
setblock 112 67 -1 minecraft:deepslate_bricks
setblock 144 67 -1 minecraft:deepslate_bricks
setblock 113 67 0 minecraft:cyan_stained_glass
setblock 143 67 0 minecraft:cyan_stained_glass
setblock 112 67 0 minecraft:sea_lantern
setblock 144 67 0 minecraft:sea_lantern
setblock 112 67 1 minecraft:deepslate_bricks
setblock 144 67 1 minecraft:deepslate_bricks
setblock 112 67 2 minecraft:deepslate_bricks
setblock 144 67 2 minecraft:deepslate_bricks
setblock 112 67 3 minecraft:deepslate_bricks
setblock 144 67 3 minecraft:deepslate_bricks
setblock 112 67 4 minecraft:deepslate_bricks
setblock 144 67 4 minecraft:deepslate_bricks
setblock 112 67 5 minecraft:deepslate_bricks
setblock 144 67 5 minecraft:deepslate_bricks
setblock 113 67 6 minecraft:cyan_stained_glass
setblock 143 67 6 minecraft:cyan_stained_glass
setblock 112 67 6 minecraft:sea_lantern
setblock 144 67 6 minecraft:sea_lantern
setblock 112 67 7 minecraft:deepslate_bricks
setblock 144 67 7 minecraft:deepslate_bricks
setblock 112 67 8 minecraft:deepslate_bricks
setblock 144 67 8 minecraft:deepslate_bricks
setblock 112 67 9 minecraft:deepslate_bricks
setblock 144 67 9 minecraft:deepslate_bricks
setblock 112 67 10 minecraft:deepslate_bricks
setblock 144 67 10 minecraft:deepslate_bricks
setblock 112 67 11 minecraft:deepslate_bricks
setblock 144 67 11 minecraft:deepslate_bricks
setblock 142 67 11 minecraft:polished_blackstone_bricks
setblock 113 67 12 minecraft:cyan_stained_glass
setblock 143 67 12 minecraft:cyan_stained_glass
setblock 142 67 12 minecraft:polished_blackstone_bricks
setblock 112 67 12 minecraft:sea_lantern
setblock 144 67 12 minecraft:sea_lantern
setblock 141 67 12 minecraft:small_amethyst_bud[facing=up,waterlogged=false]
setblock 112 67 13 minecraft:deepslate_bricks
setblock 144 67 13 minecraft:deepslate_bricks
setblock 142 67 13 minecraft:polished_blackstone_bricks
setblock 112 67 14 minecraft:deepslate_bricks
setblock 144 67 14 minecraft:deepslate_bricks
setblock 116 67 15 minecraft:cyan_stained_glass
setblock 122 67 15 minecraft:cyan_stained_glass
setblock 128 67 15 minecraft:cyan_stained_glass
setblock 134 67 15 minecraft:cyan_stained_glass
setblock 140 67 15 minecraft:cyan_stained_glass
setblock 112 67 15 minecraft:deepslate_bricks
setblock 144 67 15 minecraft:deepslate_bricks
fill 112 67 16 115 67 16 minecraft:deepslate_bricks
fill 117 67 16 121 67 16 minecraft:deepslate_bricks
fill 123 67 16 127 67 16 minecraft:deepslate_bricks
fill 129 67 16 133 67 16 minecraft:deepslate_bricks
fill 135 67 16 139 67 16 minecraft:deepslate_bricks
fill 141 67 16 144 67 16 minecraft:deepslate_bricks
setblock 116 67 16 minecraft:sea_lantern
setblock 122 67 16 minecraft:sea_lantern
setblock 128 67 16 minecraft:sea_lantern
setblock 134 67 16 minecraft:sea_lantern
setblock 140 67 16 minecraft:sea_lantern
fill 112 68 -16 115 68 -16 minecraft:deepslate_bricks
fill 117 68 -16 121 68 -16 minecraft:deepslate_bricks
fill 123 68 -16 127 68 -16 minecraft:deepslate_bricks
fill 129 68 -16 133 68 -16 minecraft:deepslate_bricks
fill 135 68 -16 139 68 -16 minecraft:deepslate_bricks
fill 141 68 -16 144 68 -16 minecraft:deepslate_bricks
setblock 116 68 -16 minecraft:sea_lantern
setblock 122 68 -16 minecraft:sea_lantern
setblock 128 68 -16 minecraft:sea_lantern
setblock 134 68 -16 minecraft:sea_lantern
setblock 140 68 -16 minecraft:sea_lantern
setblock 116 68 -15 minecraft:cyan_stained_glass
setblock 122 68 -15 minecraft:cyan_stained_glass
setblock 128 68 -15 minecraft:cyan_stained_glass
setblock 134 68 -15 minecraft:cyan_stained_glass
setblock 140 68 -15 minecraft:cyan_stained_glass
setblock 112 68 -15 minecraft:deepslate_bricks
setblock 144 68 -15 minecraft:deepslate_bricks
setblock 112 68 -14 minecraft:deepslate_bricks
setblock 144 68 -14 minecraft:deepslate_bricks
setblock 112 68 -13 minecraft:deepslate_bricks
setblock 144 68 -13 minecraft:deepslate_bricks
setblock 113 68 -12 minecraft:cyan_stained_glass
setblock 143 68 -12 minecraft:cyan_stained_glass
setblock 112 68 -12 minecraft:sea_lantern
setblock 144 68 -12 minecraft:sea_lantern
setblock 112 68 -11 minecraft:deepslate_bricks
setblock 144 68 -11 minecraft:deepslate_bricks
setblock 112 68 -10 minecraft:deepslate_bricks
setblock 144 68 -10 minecraft:deepslate_bricks
setblock 112 68 -9 minecraft:deepslate_bricks
setblock 144 68 -9 minecraft:deepslate_bricks
setblock 112 68 -8 minecraft:deepslate_bricks
setblock 144 68 -8 minecraft:deepslate_bricks
setblock 112 68 -7 minecraft:deepslate_bricks
setblock 144 68 -7 minecraft:deepslate_bricks
setblock 113 68 -6 minecraft:cyan_stained_glass
setblock 143 68 -6 minecraft:cyan_stained_glass
setblock 112 68 -6 minecraft:sea_lantern
setblock 144 68 -6 minecraft:sea_lantern
setblock 112 68 -5 minecraft:deepslate_bricks
setblock 144 68 -5 minecraft:deepslate_bricks
setblock 112 68 -4 minecraft:deepslate_bricks
setblock 144 68 -4 minecraft:deepslate_bricks
setblock 112 68 -3 minecraft:deepslate_bricks
setblock 144 68 -3 minecraft:deepslate_bricks
setblock 112 68 -2 minecraft:deepslate_bricks
setblock 144 68 -2 minecraft:deepslate_bricks
setblock 112 68 -1 minecraft:deepslate_bricks
setblock 144 68 -1 minecraft:deepslate_bricks
setblock 113 68 0 minecraft:cyan_stained_glass
setblock 143 68 0 minecraft:cyan_stained_glass
setblock 112 68 0 minecraft:sea_lantern
setblock 144 68 0 minecraft:sea_lantern
setblock 112 68 1 minecraft:deepslate_bricks
setblock 144 68 1 minecraft:deepslate_bricks
setblock 112 68 2 minecraft:deepslate_bricks
setblock 144 68 2 minecraft:deepslate_bricks
setblock 112 68 3 minecraft:deepslate_bricks
setblock 144 68 3 minecraft:deepslate_bricks
setblock 112 68 4 minecraft:deepslate_bricks
setblock 144 68 4 minecraft:deepslate_bricks
setblock 112 68 5 minecraft:deepslate_bricks
setblock 144 68 5 minecraft:deepslate_bricks
setblock 113 68 6 minecraft:cyan_stained_glass
setblock 143 68 6 minecraft:cyan_stained_glass
setblock 112 68 6 minecraft:sea_lantern
setblock 144 68 6 minecraft:sea_lantern
setblock 112 68 7 minecraft:deepslate_bricks
setblock 144 68 7 minecraft:deepslate_bricks
setblock 112 68 8 minecraft:deepslate_bricks
setblock 144 68 8 minecraft:deepslate_bricks
setblock 112 68 9 minecraft:deepslate_bricks
setblock 144 68 9 minecraft:deepslate_bricks
setblock 112 68 10 minecraft:deepslate_bricks
setblock 144 68 10 minecraft:deepslate_bricks
setblock 112 68 11 minecraft:deepslate_bricks
setblock 144 68 11 minecraft:deepslate_bricks
setblock 142 68 11 minecraft:polished_blackstone_bricks
setblock 113 68 12 minecraft:cyan_stained_glass
setblock 143 68 12 minecraft:cyan_stained_glass
setblock 142 68 12 minecraft:polished_blackstone_bricks
setblock 112 68 12 minecraft:sea_lantern
setblock 144 68 12 minecraft:sea_lantern
setblock 112 68 13 minecraft:deepslate_bricks
setblock 144 68 13 minecraft:deepslate_bricks
setblock 142 68 13 minecraft:polished_blackstone_bricks
setblock 112 68 14 minecraft:deepslate_bricks
setblock 144 68 14 minecraft:deepslate_bricks
setblock 116 68 15 minecraft:cyan_stained_glass
setblock 122 68 15 minecraft:cyan_stained_glass
setblock 128 68 15 minecraft:cyan_stained_glass
setblock 134 68 15 minecraft:cyan_stained_glass
setblock 140 68 15 minecraft:cyan_stained_glass
setblock 112 68 15 minecraft:deepslate_bricks
setblock 144 68 15 minecraft:deepslate_bricks
fill 112 68 16 115 68 16 minecraft:deepslate_bricks
fill 117 68 16 121 68 16 minecraft:deepslate_bricks
fill 123 68 16 127 68 16 minecraft:deepslate_bricks
fill 129 68 16 133 68 16 minecraft:deepslate_bricks
fill 135 68 16 139 68 16 minecraft:deepslate_bricks
fill 141 68 16 144 68 16 minecraft:deepslate_bricks
setblock 116 68 16 minecraft:sea_lantern
setblock 122 68 16 minecraft:sea_lantern
setblock 128 68 16 minecraft:sea_lantern
setblock 134 68 16 minecraft:sea_lantern
setblock 140 68 16 minecraft:sea_lantern
fill 112 69 -16 115 69 -16 minecraft:deepslate_bricks
fill 117 69 -16 121 69 -16 minecraft:deepslate_bricks
fill 123 69 -16 127 69 -16 minecraft:deepslate_bricks
fill 129 69 -16 133 69 -16 minecraft:deepslate_bricks
fill 135 69 -16 139 69 -16 minecraft:deepslate_bricks
fill 141 69 -16 144 69 -16 minecraft:deepslate_bricks
setblock 116 69 -16 minecraft:sea_lantern
setblock 122 69 -16 minecraft:sea_lantern
setblock 128 69 -16 minecraft:sea_lantern
setblock 134 69 -16 minecraft:sea_lantern
setblock 140 69 -16 minecraft:sea_lantern
setblock 116 69 -15 minecraft:cyan_stained_glass
setblock 122 69 -15 minecraft:cyan_stained_glass
setblock 128 69 -15 minecraft:cyan_stained_glass
setblock 134 69 -15 minecraft:cyan_stained_glass
setblock 140 69 -15 minecraft:cyan_stained_glass
setblock 112 69 -15 minecraft:deepslate_bricks
setblock 144 69 -15 minecraft:deepslate_bricks
setblock 112 69 -14 minecraft:deepslate_bricks
setblock 144 69 -14 minecraft:deepslate_bricks
setblock 112 69 -13 minecraft:deepslate_bricks
setblock 144 69 -13 minecraft:deepslate_bricks
setblock 113 69 -12 minecraft:cyan_stained_glass
setblock 143 69 -12 minecraft:cyan_stained_glass
setblock 112 69 -12 minecraft:sea_lantern
setblock 144 69 -12 minecraft:sea_lantern
setblock 112 69 -11 minecraft:deepslate_bricks
setblock 144 69 -11 minecraft:deepslate_bricks
setblock 112 69 -10 minecraft:deepslate_bricks
setblock 144 69 -10 minecraft:deepslate_bricks
setblock 112 69 -9 minecraft:deepslate_bricks
setblock 144 69 -9 minecraft:deepslate_bricks
setblock 112 69 -8 minecraft:deepslate_bricks
setblock 144 69 -8 minecraft:deepslate_bricks
setblock 112 69 -7 minecraft:deepslate_bricks
setblock 144 69 -7 minecraft:deepslate_bricks
setblock 113 69 -6 minecraft:cyan_stained_glass
setblock 143 69 -6 minecraft:cyan_stained_glass
setblock 112 69 -6 minecraft:sea_lantern
setblock 144 69 -6 minecraft:sea_lantern
setblock 112 69 -5 minecraft:deepslate_bricks
setblock 144 69 -5 minecraft:deepslate_bricks
setblock 112 69 -4 minecraft:deepslate_bricks
setblock 144 69 -4 minecraft:deepslate_bricks
setblock 112 69 -3 minecraft:deepslate_bricks
setblock 144 69 -3 minecraft:deepslate_bricks
setblock 112 69 -2 minecraft:deepslate_bricks
setblock 144 69 -2 minecraft:deepslate_bricks
setblock 112 69 -1 minecraft:deepslate_bricks
setblock 144 69 -1 minecraft:deepslate_bricks
setblock 113 69 0 minecraft:cyan_stained_glass
setblock 143 69 0 minecraft:cyan_stained_glass
setblock 112 69 0 minecraft:sea_lantern
setblock 144 69 0 minecraft:sea_lantern
setblock 112 69 1 minecraft:deepslate_bricks
setblock 144 69 1 minecraft:deepslate_bricks
setblock 112 69 2 minecraft:deepslate_bricks
setblock 144 69 2 minecraft:deepslate_bricks
setblock 112 69 3 minecraft:deepslate_bricks
setblock 144 69 3 minecraft:deepslate_bricks
setblock 112 69 4 minecraft:deepslate_bricks
setblock 144 69 4 minecraft:deepslate_bricks
setblock 112 69 5 minecraft:deepslate_bricks
setblock 144 69 5 minecraft:deepslate_bricks
setblock 113 69 6 minecraft:cyan_stained_glass
setblock 143 69 6 minecraft:cyan_stained_glass
setblock 112 69 6 minecraft:sea_lantern
setblock 144 69 6 minecraft:sea_lantern
setblock 112 69 7 minecraft:deepslate_bricks
setblock 144 69 7 minecraft:deepslate_bricks
setblock 112 69 8 minecraft:deepslate_bricks
setblock 144 69 8 minecraft:deepslate_bricks
setblock 112 69 9 minecraft:deepslate_bricks
setblock 144 69 9 minecraft:deepslate_bricks
setblock 112 69 10 minecraft:deepslate_bricks
setblock 144 69 10 minecraft:deepslate_bricks
setblock 112 69 11 minecraft:deepslate_bricks
setblock 144 69 11 minecraft:deepslate_bricks
setblock 113 69 12 minecraft:cyan_stained_glass
setblock 143 69 12 minecraft:cyan_stained_glass
setblock 112 69 12 minecraft:sea_lantern
setblock 144 69 12 minecraft:sea_lantern
setblock 112 69 13 minecraft:deepslate_bricks
setblock 144 69 13 minecraft:deepslate_bricks
setblock 112 69 14 minecraft:deepslate_bricks
setblock 144 69 14 minecraft:deepslate_bricks
setblock 116 69 15 minecraft:cyan_stained_glass
setblock 122 69 15 minecraft:cyan_stained_glass
setblock 128 69 15 minecraft:cyan_stained_glass
setblock 134 69 15 minecraft:cyan_stained_glass
setblock 140 69 15 minecraft:cyan_stained_glass
setblock 112 69 15 minecraft:deepslate_bricks
setblock 144 69 15 minecraft:deepslate_bricks
fill 112 69 16 115 69 16 minecraft:deepslate_bricks
fill 117 69 16 121 69 16 minecraft:deepslate_bricks
fill 123 69 16 127 69 16 minecraft:deepslate_bricks
fill 129 69 16 133 69 16 minecraft:deepslate_bricks
fill 135 69 16 139 69 16 minecraft:deepslate_bricks
fill 141 69 16 144 69 16 minecraft:deepslate_bricks
setblock 116 69 16 minecraft:sea_lantern
setblock 122 69 16 minecraft:sea_lantern
setblock 128 69 16 minecraft:sea_lantern
setblock 134 69 16 minecraft:sea_lantern
setblock 140 69 16 minecraft:sea_lantern
fill 112 70 -16 115 70 -16 minecraft:deepslate_bricks
fill 117 70 -16 121 70 -16 minecraft:deepslate_bricks
fill 123 70 -16 127 70 -16 minecraft:deepslate_bricks
fill 129 70 -16 133 70 -16 minecraft:deepslate_bricks
fill 135 70 -16 139 70 -16 minecraft:deepslate_bricks
fill 141 70 -16 144 70 -16 minecraft:deepslate_bricks
setblock 116 70 -16 minecraft:sea_lantern
setblock 122 70 -16 minecraft:sea_lantern
setblock 128 70 -16 minecraft:sea_lantern
setblock 134 70 -16 minecraft:sea_lantern
setblock 140 70 -16 minecraft:sea_lantern
setblock 116 70 -15 minecraft:cyan_stained_glass
setblock 122 70 -15 minecraft:cyan_stained_glass
setblock 128 70 -15 minecraft:cyan_stained_glass
setblock 134 70 -15 minecraft:cyan_stained_glass
setblock 140 70 -15 minecraft:cyan_stained_glass
setblock 112 70 -15 minecraft:deepslate_bricks
setblock 144 70 -15 minecraft:deepslate_bricks
setblock 112 70 -14 minecraft:deepslate_bricks
setblock 144 70 -14 minecraft:deepslate_bricks
setblock 112 70 -13 minecraft:deepslate_bricks
setblock 144 70 -13 minecraft:deepslate_bricks
setblock 113 70 -12 minecraft:cyan_stained_glass
setblock 143 70 -12 minecraft:cyan_stained_glass
setblock 112 70 -12 minecraft:sea_lantern
setblock 144 70 -12 minecraft:sea_lantern
setblock 112 70 -11 minecraft:deepslate_bricks
setblock 144 70 -11 minecraft:deepslate_bricks
setblock 112 70 -10 minecraft:deepslate_bricks
setblock 144 70 -10 minecraft:deepslate_bricks
setblock 112 70 -9 minecraft:deepslate_bricks
setblock 144 70 -9 minecraft:deepslate_bricks
setblock 112 70 -8 minecraft:deepslate_bricks
setblock 144 70 -8 minecraft:deepslate_bricks
setblock 112 70 -7 minecraft:deepslate_bricks
setblock 144 70 -7 minecraft:deepslate_bricks
setblock 113 70 -6 minecraft:cyan_stained_glass
setblock 143 70 -6 minecraft:cyan_stained_glass
setblock 112 70 -6 minecraft:sea_lantern
setblock 144 70 -6 minecraft:sea_lantern
setblock 112 70 -5 minecraft:deepslate_bricks
setblock 144 70 -5 minecraft:deepslate_bricks
setblock 112 70 -4 minecraft:deepslate_bricks
setblock 144 70 -4 minecraft:deepslate_bricks
setblock 112 70 -3 minecraft:deepslate_bricks
setblock 144 70 -3 minecraft:deepslate_bricks
setblock 112 70 -2 minecraft:deepslate_bricks
setblock 144 70 -2 minecraft:deepslate_bricks
setblock 112 70 -1 minecraft:deepslate_bricks
setblock 144 70 -1 minecraft:deepslate_bricks
setblock 113 70 0 minecraft:cyan_stained_glass
setblock 143 70 0 minecraft:cyan_stained_glass
setblock 112 70 0 minecraft:sea_lantern
setblock 144 70 0 minecraft:sea_lantern
setblock 112 70 1 minecraft:deepslate_bricks
setblock 144 70 1 minecraft:deepslate_bricks
setblock 112 70 2 minecraft:deepslate_bricks
setblock 144 70 2 minecraft:deepslate_bricks
setblock 112 70 3 minecraft:deepslate_bricks
setblock 144 70 3 minecraft:deepslate_bricks
setblock 112 70 4 minecraft:deepslate_bricks
setblock 144 70 4 minecraft:deepslate_bricks
setblock 112 70 5 minecraft:deepslate_bricks
setblock 144 70 5 minecraft:deepslate_bricks
setblock 113 70 6 minecraft:cyan_stained_glass
setblock 143 70 6 minecraft:cyan_stained_glass
setblock 112 70 6 minecraft:sea_lantern
setblock 144 70 6 minecraft:sea_lantern
setblock 112 70 7 minecraft:deepslate_bricks
setblock 144 70 7 minecraft:deepslate_bricks
setblock 112 70 8 minecraft:deepslate_bricks
setblock 144 70 8 minecraft:deepslate_bricks
setblock 112 70 9 minecraft:deepslate_bricks
setblock 144 70 9 minecraft:deepslate_bricks
setblock 112 70 10 minecraft:deepslate_bricks
setblock 144 70 10 minecraft:deepslate_bricks
setblock 112 70 11 minecraft:deepslate_bricks
setblock 144 70 11 minecraft:deepslate_bricks
setblock 113 70 12 minecraft:cyan_stained_glass
setblock 143 70 12 minecraft:cyan_stained_glass
setblock 112 70 12 minecraft:sea_lantern
setblock 144 70 12 minecraft:sea_lantern
setblock 112 70 13 minecraft:deepslate_bricks
setblock 144 70 13 minecraft:deepslate_bricks
setblock 112 70 14 minecraft:deepslate_bricks
setblock 144 70 14 minecraft:deepslate_bricks
setblock 116 70 15 minecraft:cyan_stained_glass
setblock 122 70 15 minecraft:cyan_stained_glass
setblock 128 70 15 minecraft:cyan_stained_glass
setblock 134 70 15 minecraft:cyan_stained_glass
setblock 140 70 15 minecraft:cyan_stained_glass
setblock 112 70 15 minecraft:deepslate_bricks
setblock 144 70 15 minecraft:deepslate_bricks
fill 112 70 16 115 70 16 minecraft:deepslate_bricks
fill 117 70 16 121 70 16 minecraft:deepslate_bricks
fill 123 70 16 127 70 16 minecraft:deepslate_bricks
fill 129 70 16 133 70 16 minecraft:deepslate_bricks
fill 135 70 16 139 70 16 minecraft:deepslate_bricks
fill 141 70 16 144 70 16 minecraft:deepslate_bricks
setblock 116 70 16 minecraft:sea_lantern
setblock 122 70 16 minecraft:sea_lantern
setblock 128 70 16 minecraft:sea_lantern
setblock 134 70 16 minecraft:sea_lantern
setblock 140 70 16 minecraft:sea_lantern
fill 112 71 -16 115 71 -16 minecraft:deepslate_bricks
fill 117 71 -16 121 71 -16 minecraft:deepslate_bricks
fill 123 71 -16 127 71 -16 minecraft:deepslate_bricks
fill 129 71 -16 133 71 -16 minecraft:deepslate_bricks
fill 135 71 -16 139 71 -16 minecraft:deepslate_bricks
fill 141 71 -16 144 71 -16 minecraft:deepslate_bricks
setblock 116 71 -16 minecraft:sea_lantern
setblock 122 71 -16 minecraft:sea_lantern
setblock 128 71 -16 minecraft:sea_lantern
setblock 134 71 -16 minecraft:sea_lantern
setblock 140 71 -16 minecraft:sea_lantern
setblock 116 71 -15 minecraft:cyan_stained_glass
setblock 122 71 -15 minecraft:cyan_stained_glass
setblock 128 71 -15 minecraft:cyan_stained_glass
setblock 134 71 -15 minecraft:cyan_stained_glass
setblock 140 71 -15 minecraft:cyan_stained_glass
setblock 112 71 -15 minecraft:deepslate_bricks
setblock 144 71 -15 minecraft:deepslate_bricks
setblock 112 71 -14 minecraft:deepslate_bricks
setblock 144 71 -14 minecraft:deepslate_bricks
setblock 112 71 -13 minecraft:deepslate_bricks
setblock 144 71 -13 minecraft:deepslate_bricks
setblock 113 71 -12 minecraft:cyan_stained_glass
setblock 143 71 -12 minecraft:cyan_stained_glass
setblock 112 71 -12 minecraft:sea_lantern
setblock 144 71 -12 minecraft:sea_lantern
setblock 112 71 -11 minecraft:deepslate_bricks
setblock 144 71 -11 minecraft:deepslate_bricks
setblock 112 71 -10 minecraft:deepslate_bricks
setblock 144 71 -10 minecraft:deepslate_bricks
setblock 112 71 -9 minecraft:deepslate_bricks
setblock 144 71 -9 minecraft:deepslate_bricks
setblock 112 71 -8 minecraft:deepslate_bricks
setblock 144 71 -8 minecraft:deepslate_bricks
setblock 112 71 -7 minecraft:deepslate_bricks
setblock 144 71 -7 minecraft:deepslate_bricks
setblock 113 71 -6 minecraft:cyan_stained_glass
setblock 143 71 -6 minecraft:cyan_stained_glass
setblock 112 71 -6 minecraft:sea_lantern
setblock 144 71 -6 minecraft:sea_lantern
setblock 112 71 -5 minecraft:deepslate_bricks
setblock 144 71 -5 minecraft:deepslate_bricks
setblock 112 71 -4 minecraft:deepslate_bricks
setblock 144 71 -4 minecraft:deepslate_bricks
setblock 112 71 -3 minecraft:deepslate_bricks
setblock 144 71 -3 minecraft:deepslate_bricks
setblock 112 71 -2 minecraft:deepslate_bricks
setblock 144 71 -2 minecraft:deepslate_bricks
setblock 112 71 -1 minecraft:deepslate_bricks
setblock 144 71 -1 minecraft:deepslate_bricks
setblock 113 71 0 minecraft:cyan_stained_glass
setblock 143 71 0 minecraft:cyan_stained_glass
setblock 112 71 0 minecraft:sea_lantern
setblock 144 71 0 minecraft:sea_lantern
setblock 112 71 1 minecraft:deepslate_bricks
setblock 144 71 1 minecraft:deepslate_bricks
setblock 112 71 2 minecraft:deepslate_bricks
setblock 144 71 2 minecraft:deepslate_bricks
setblock 112 71 3 minecraft:deepslate_bricks
setblock 144 71 3 minecraft:deepslate_bricks
setblock 112 71 4 minecraft:deepslate_bricks
setblock 144 71 4 minecraft:deepslate_bricks
setblock 112 71 5 minecraft:deepslate_bricks
setblock 144 71 5 minecraft:deepslate_bricks
setblock 113 71 6 minecraft:cyan_stained_glass
setblock 143 71 6 minecraft:cyan_stained_glass
setblock 112 71 6 minecraft:sea_lantern
setblock 144 71 6 minecraft:sea_lantern
setblock 112 71 7 minecraft:deepslate_bricks
setblock 144 71 7 minecraft:deepslate_bricks
setblock 112 71 8 minecraft:deepslate_bricks
setblock 144 71 8 minecraft:deepslate_bricks
setblock 112 71 9 minecraft:deepslate_bricks
setblock 144 71 9 minecraft:deepslate_bricks
setblock 112 71 10 minecraft:deepslate_bricks
setblock 144 71 10 minecraft:deepslate_bricks
setblock 112 71 11 minecraft:deepslate_bricks
setblock 144 71 11 minecraft:deepslate_bricks
setblock 113 71 12 minecraft:cyan_stained_glass
setblock 143 71 12 minecraft:cyan_stained_glass
setblock 112 71 12 minecraft:sea_lantern
setblock 144 71 12 minecraft:sea_lantern
setblock 112 71 13 minecraft:deepslate_bricks
setblock 144 71 13 minecraft:deepslate_bricks
setblock 112 71 14 minecraft:deepslate_bricks
setblock 144 71 14 minecraft:deepslate_bricks
setblock 116 71 15 minecraft:cyan_stained_glass
setblock 122 71 15 minecraft:cyan_stained_glass
setblock 128 71 15 minecraft:cyan_stained_glass
setblock 134 71 15 minecraft:cyan_stained_glass
setblock 140 71 15 minecraft:cyan_stained_glass
setblock 112 71 15 minecraft:deepslate_bricks
setblock 144 71 15 minecraft:deepslate_bricks
fill 112 71 16 115 71 16 minecraft:deepslate_bricks
fill 117 71 16 121 71 16 minecraft:deepslate_bricks
fill 123 71 16 127 71 16 minecraft:deepslate_bricks
fill 129 71 16 133 71 16 minecraft:deepslate_bricks
fill 135 71 16 139 71 16 minecraft:deepslate_bricks
fill 141 71 16 144 71 16 minecraft:deepslate_bricks
setblock 116 71 16 minecraft:sea_lantern
setblock 122 71 16 minecraft:sea_lantern
setblock 128 71 16 minecraft:sea_lantern
setblock 134 71 16 minecraft:sea_lantern
setblock 140 71 16 minecraft:sea_lantern
fill 112 72 -16 115 72 -16 minecraft:deepslate_bricks
fill 117 72 -16 121 72 -16 minecraft:deepslate_bricks
fill 123 72 -16 127 72 -16 minecraft:deepslate_bricks
fill 129 72 -16 133 72 -16 minecraft:deepslate_bricks
fill 135 72 -16 139 72 -16 minecraft:deepslate_bricks
fill 141 72 -16 144 72 -16 minecraft:deepslate_bricks
setblock 116 72 -16 minecraft:sea_lantern
setblock 122 72 -16 minecraft:sea_lantern
setblock 128 72 -16 minecraft:sea_lantern
setblock 134 72 -16 minecraft:sea_lantern
setblock 140 72 -16 minecraft:sea_lantern
setblock 116 72 -15 minecraft:cyan_stained_glass
setblock 122 72 -15 minecraft:cyan_stained_glass
setblock 128 72 -15 minecraft:cyan_stained_glass
setblock 134 72 -15 minecraft:cyan_stained_glass
setblock 140 72 -15 minecraft:cyan_stained_glass
setblock 112 72 -15 minecraft:deepslate_bricks
setblock 144 72 -15 minecraft:deepslate_bricks
setblock 112 72 -14 minecraft:deepslate_bricks
setblock 144 72 -14 minecraft:deepslate_bricks
setblock 112 72 -13 minecraft:deepslate_bricks
setblock 144 72 -13 minecraft:deepslate_bricks
setblock 113 72 -12 minecraft:cyan_stained_glass
setblock 143 72 -12 minecraft:cyan_stained_glass
setblock 112 72 -12 minecraft:sea_lantern
setblock 144 72 -12 minecraft:sea_lantern
setblock 112 72 -11 minecraft:deepslate_bricks
setblock 144 72 -11 minecraft:deepslate_bricks
setblock 112 72 -10 minecraft:deepslate_bricks
setblock 144 72 -10 minecraft:deepslate_bricks
setblock 112 72 -9 minecraft:deepslate_bricks
setblock 144 72 -9 minecraft:deepslate_bricks
setblock 112 72 -8 minecraft:deepslate_bricks
setblock 144 72 -8 minecraft:deepslate_bricks
setblock 112 72 -7 minecraft:deepslate_bricks
setblock 144 72 -7 minecraft:deepslate_bricks
setblock 113 72 -6 minecraft:cyan_stained_glass
setblock 143 72 -6 minecraft:cyan_stained_glass
setblock 112 72 -6 minecraft:sea_lantern
setblock 144 72 -6 minecraft:sea_lantern
setblock 112 72 -5 minecraft:deepslate_bricks
setblock 144 72 -5 minecraft:deepslate_bricks
setblock 112 72 -4 minecraft:deepslate_bricks
setblock 144 72 -4 minecraft:deepslate_bricks
setblock 112 72 -3 minecraft:deepslate_bricks
setblock 144 72 -3 minecraft:deepslate_bricks
setblock 112 72 -2 minecraft:deepslate_bricks
setblock 144 72 -2 minecraft:deepslate_bricks
setblock 112 72 -1 minecraft:deepslate_bricks
setblock 144 72 -1 minecraft:deepslate_bricks
setblock 113 72 0 minecraft:cyan_stained_glass
setblock 143 72 0 minecraft:cyan_stained_glass
setblock 112 72 0 minecraft:sea_lantern
setblock 144 72 0 minecraft:sea_lantern
setblock 112 72 1 minecraft:deepslate_bricks
setblock 144 72 1 minecraft:deepslate_bricks
setblock 112 72 2 minecraft:deepslate_bricks
setblock 144 72 2 minecraft:deepslate_bricks
setblock 112 72 3 minecraft:deepslate_bricks
setblock 144 72 3 minecraft:deepslate_bricks
setblock 112 72 4 minecraft:deepslate_bricks
setblock 144 72 4 minecraft:deepslate_bricks
setblock 112 72 5 minecraft:deepslate_bricks
setblock 144 72 5 minecraft:deepslate_bricks
setblock 113 72 6 minecraft:cyan_stained_glass
setblock 143 72 6 minecraft:cyan_stained_glass
setblock 112 72 6 minecraft:sea_lantern
setblock 144 72 6 minecraft:sea_lantern
setblock 112 72 7 minecraft:deepslate_bricks
setblock 144 72 7 minecraft:deepslate_bricks
setblock 112 72 8 minecraft:deepslate_bricks
setblock 144 72 8 minecraft:deepslate_bricks
setblock 112 72 9 minecraft:deepslate_bricks
setblock 144 72 9 minecraft:deepslate_bricks
setblock 112 72 10 minecraft:deepslate_bricks
setblock 144 72 10 minecraft:deepslate_bricks
setblock 112 72 11 minecraft:deepslate_bricks
setblock 144 72 11 minecraft:deepslate_bricks
setblock 113 72 12 minecraft:cyan_stained_glass
setblock 143 72 12 minecraft:cyan_stained_glass
setblock 112 72 12 minecraft:sea_lantern
setblock 144 72 12 minecraft:sea_lantern
setblock 112 72 13 minecraft:deepslate_bricks
setblock 144 72 13 minecraft:deepslate_bricks
setblock 112 72 14 minecraft:deepslate_bricks
setblock 144 72 14 minecraft:deepslate_bricks
setblock 116 72 15 minecraft:cyan_stained_glass
setblock 122 72 15 minecraft:cyan_stained_glass
setblock 128 72 15 minecraft:cyan_stained_glass
setblock 134 72 15 minecraft:cyan_stained_glass
setblock 140 72 15 minecraft:cyan_stained_glass
setblock 112 72 15 minecraft:deepslate_bricks
setblock 144 72 15 minecraft:deepslate_bricks
fill 112 72 16 115 72 16 minecraft:deepslate_bricks
fill 117 72 16 121 72 16 minecraft:deepslate_bricks
fill 123 72 16 127 72 16 minecraft:deepslate_bricks
fill 129 72 16 133 72 16 minecraft:deepslate_bricks
fill 135 72 16 139 72 16 minecraft:deepslate_bricks
fill 141 72 16 144 72 16 minecraft:deepslate_bricks
setblock 116 72 16 minecraft:sea_lantern
setblock 122 72 16 minecraft:sea_lantern
setblock 128 72 16 minecraft:sea_lantern
setblock 134 72 16 minecraft:sea_lantern
setblock 140 72 16 minecraft:sea_lantern
fill 112 73 -16 115 73 -16 minecraft:deepslate_bricks
fill 117 73 -16 121 73 -16 minecraft:deepslate_bricks
fill 123 73 -16 127 73 -16 minecraft:deepslate_bricks
fill 129 73 -16 133 73 -16 minecraft:deepslate_bricks
fill 135 73 -16 139 73 -16 minecraft:deepslate_bricks
fill 141 73 -16 144 73 -16 minecraft:deepslate_bricks
setblock 116 73 -16 minecraft:sea_lantern
setblock 122 73 -16 minecraft:sea_lantern
setblock 128 73 -16 minecraft:sea_lantern
setblock 134 73 -16 minecraft:sea_lantern
setblock 140 73 -16 minecraft:sea_lantern
setblock 116 73 -15 minecraft:cyan_stained_glass
setblock 122 73 -15 minecraft:cyan_stained_glass
setblock 128 73 -15 minecraft:cyan_stained_glass
setblock 134 73 -15 minecraft:cyan_stained_glass
setblock 140 73 -15 minecraft:cyan_stained_glass
setblock 112 73 -15 minecraft:deepslate_bricks
setblock 144 73 -15 minecraft:deepslate_bricks
setblock 112 73 -14 minecraft:deepslate_bricks
setblock 144 73 -14 minecraft:deepslate_bricks
setblock 112 73 -13 minecraft:deepslate_bricks
setblock 144 73 -13 minecraft:deepslate_bricks
setblock 113 73 -12 minecraft:cyan_stained_glass
setblock 143 73 -12 minecraft:cyan_stained_glass
setblock 112 73 -12 minecraft:sea_lantern
setblock 144 73 -12 minecraft:sea_lantern
setblock 112 73 -11 minecraft:deepslate_bricks
setblock 144 73 -11 minecraft:deepslate_bricks
setblock 112 73 -10 minecraft:deepslate_bricks
setblock 144 73 -10 minecraft:deepslate_bricks
setblock 112 73 -9 minecraft:deepslate_bricks
setblock 144 73 -9 minecraft:deepslate_bricks
setblock 112 73 -8 minecraft:deepslate_bricks
setblock 144 73 -8 minecraft:deepslate_bricks
setblock 112 73 -7 minecraft:deepslate_bricks
setblock 144 73 -7 minecraft:deepslate_bricks
setblock 113 73 -6 minecraft:cyan_stained_glass
setblock 143 73 -6 minecraft:cyan_stained_glass
setblock 112 73 -6 minecraft:sea_lantern
setblock 144 73 -6 minecraft:sea_lantern
setblock 112 73 -5 minecraft:deepslate_bricks
setblock 144 73 -5 minecraft:deepslate_bricks
setblock 112 73 -4 minecraft:deepslate_bricks
setblock 144 73 -4 minecraft:deepslate_bricks
setblock 112 73 -3 minecraft:deepslate_bricks
setblock 144 73 -3 minecraft:deepslate_bricks
setblock 112 73 -2 minecraft:deepslate_bricks
setblock 144 73 -2 minecraft:deepslate_bricks
setblock 112 73 -1 minecraft:deepslate_bricks
setblock 144 73 -1 minecraft:deepslate_bricks
setblock 113 73 0 minecraft:cyan_stained_glass
setblock 143 73 0 minecraft:cyan_stained_glass
setblock 112 73 0 minecraft:sea_lantern
setblock 144 73 0 minecraft:sea_lantern
setblock 112 73 1 minecraft:deepslate_bricks
setblock 144 73 1 minecraft:deepslate_bricks
setblock 112 73 2 minecraft:deepslate_bricks
setblock 144 73 2 minecraft:deepslate_bricks
setblock 112 73 3 minecraft:deepslate_bricks
setblock 144 73 3 minecraft:deepslate_bricks
setblock 112 73 4 minecraft:deepslate_bricks
setblock 144 73 4 minecraft:deepslate_bricks
setblock 112 73 5 minecraft:deepslate_bricks
setblock 144 73 5 minecraft:deepslate_bricks
setblock 113 73 6 minecraft:cyan_stained_glass
setblock 143 73 6 minecraft:cyan_stained_glass
setblock 112 73 6 minecraft:sea_lantern
setblock 144 73 6 minecraft:sea_lantern
setblock 112 73 7 minecraft:deepslate_bricks
setblock 144 73 7 minecraft:deepslate_bricks
setblock 112 73 8 minecraft:deepslate_bricks
setblock 144 73 8 minecraft:deepslate_bricks
setblock 112 73 9 minecraft:deepslate_bricks
setblock 144 73 9 minecraft:deepslate_bricks
setblock 112 73 10 minecraft:deepslate_bricks
setblock 144 73 10 minecraft:deepslate_bricks
setblock 112 73 11 minecraft:deepslate_bricks
setblock 144 73 11 minecraft:deepslate_bricks
setblock 113 73 12 minecraft:cyan_stained_glass
setblock 143 73 12 minecraft:cyan_stained_glass
setblock 112 73 12 minecraft:sea_lantern
setblock 144 73 12 minecraft:sea_lantern
setblock 112 73 13 minecraft:deepslate_bricks
setblock 144 73 13 minecraft:deepslate_bricks
setblock 112 73 14 minecraft:deepslate_bricks
setblock 144 73 14 minecraft:deepslate_bricks
setblock 116 73 15 minecraft:cyan_stained_glass
setblock 122 73 15 minecraft:cyan_stained_glass
setblock 128 73 15 minecraft:cyan_stained_glass
setblock 134 73 15 minecraft:cyan_stained_glass
setblock 140 73 15 minecraft:cyan_stained_glass
setblock 112 73 15 minecraft:deepslate_bricks
setblock 144 73 15 minecraft:deepslate_bricks
fill 112 73 16 115 73 16 minecraft:deepslate_bricks
fill 117 73 16 121 73 16 minecraft:deepslate_bricks
fill 123 73 16 127 73 16 minecraft:deepslate_bricks
fill 129 73 16 133 73 16 minecraft:deepslate_bricks
fill 135 73 16 139 73 16 minecraft:deepslate_bricks
fill 141 73 16 144 73 16 minecraft:deepslate_bricks
setblock 116 73 16 minecraft:sea_lantern
setblock 122 73 16 minecraft:sea_lantern
setblock 128 73 16 minecraft:sea_lantern
setblock 134 73 16 minecraft:sea_lantern
setblock 140 73 16 minecraft:sea_lantern
fill 112 74 -16 115 74 -16 minecraft:deepslate_bricks
fill 117 74 -16 121 74 -16 minecraft:deepslate_bricks
fill 123 74 -16 127 74 -16 minecraft:deepslate_bricks
fill 129 74 -16 133 74 -16 minecraft:deepslate_bricks
fill 135 74 -16 139 74 -16 minecraft:deepslate_bricks
fill 141 74 -16 144 74 -16 minecraft:deepslate_bricks
setblock 116 74 -16 minecraft:sea_lantern
setblock 122 74 -16 minecraft:sea_lantern
setblock 128 74 -16 minecraft:sea_lantern
setblock 134 74 -16 minecraft:sea_lantern
setblock 140 74 -16 minecraft:sea_lantern
setblock 116 74 -15 minecraft:cyan_stained_glass
setblock 122 74 -15 minecraft:cyan_stained_glass
setblock 128 74 -15 minecraft:cyan_stained_glass
setblock 134 74 -15 minecraft:cyan_stained_glass
setblock 140 74 -15 minecraft:cyan_stained_glass
setblock 112 74 -15 minecraft:deepslate_bricks
setblock 144 74 -15 minecraft:deepslate_bricks
setblock 112 74 -14 minecraft:deepslate_bricks
setblock 144 74 -14 minecraft:deepslate_bricks
setblock 112 74 -13 minecraft:deepslate_bricks
setblock 144 74 -13 minecraft:deepslate_bricks
setblock 113 74 -12 minecraft:cyan_stained_glass
setblock 143 74 -12 minecraft:cyan_stained_glass
setblock 112 74 -12 minecraft:sea_lantern
setblock 144 74 -12 minecraft:sea_lantern
setblock 112 74 -11 minecraft:deepslate_bricks
setblock 144 74 -11 minecraft:deepslate_bricks
setblock 112 74 -10 minecraft:deepslate_bricks
setblock 144 74 -10 minecraft:deepslate_bricks
setblock 112 74 -9 minecraft:deepslate_bricks
setblock 144 74 -9 minecraft:deepslate_bricks
setblock 112 74 -8 minecraft:deepslate_bricks
setblock 144 74 -8 minecraft:deepslate_bricks
setblock 112 74 -7 minecraft:deepslate_bricks
setblock 144 74 -7 minecraft:deepslate_bricks
setblock 115 74 -7 minecraft:sea_lantern
setblock 113 74 -6 minecraft:cyan_stained_glass
setblock 143 74 -6 minecraft:cyan_stained_glass
setblock 112 74 -6 minecraft:sea_lantern
setblock 144 74 -6 minecraft:sea_lantern
setblock 112 74 -5 minecraft:deepslate_bricks
setblock 144 74 -5 minecraft:deepslate_bricks
setblock 112 74 -4 minecraft:deepslate_bricks
setblock 144 74 -4 minecraft:deepslate_bricks
setblock 141 74 -4 minecraft:sea_lantern
setblock 112 74 -3 minecraft:deepslate_bricks
setblock 144 74 -3 minecraft:deepslate_bricks
setblock 112 74 -2 minecraft:deepslate_bricks
setblock 144 74 -2 minecraft:deepslate_bricks
setblock 112 74 -1 minecraft:deepslate_bricks
setblock 144 74 -1 minecraft:deepslate_bricks
setblock 113 74 0 minecraft:cyan_stained_glass
setblock 143 74 0 minecraft:cyan_stained_glass
setblock 112 74 0 minecraft:sea_lantern
setblock 144 74 0 minecraft:sea_lantern
setblock 112 74 1 minecraft:deepslate_bricks
setblock 144 74 1 minecraft:deepslate_bricks
setblock 112 74 2 minecraft:deepslate_bricks
setblock 144 74 2 minecraft:deepslate_bricks
setblock 112 74 3 minecraft:deepslate_bricks
setblock 144 74 3 minecraft:deepslate_bricks
setblock 112 74 4 minecraft:deepslate_bricks
setblock 144 74 4 minecraft:deepslate_bricks
setblock 115 74 4 minecraft:sea_lantern
setblock 112 74 5 minecraft:deepslate_bricks
setblock 144 74 5 minecraft:deepslate_bricks
setblock 113 74 6 minecraft:cyan_stained_glass
setblock 143 74 6 minecraft:cyan_stained_glass
setblock 112 74 6 minecraft:sea_lantern
setblock 144 74 6 minecraft:sea_lantern
setblock 112 74 7 minecraft:deepslate_bricks
setblock 144 74 7 minecraft:deepslate_bricks
setblock 141 74 7 minecraft:sea_lantern
setblock 112 74 8 minecraft:deepslate_bricks
setblock 144 74 8 minecraft:deepslate_bricks
setblock 112 74 9 minecraft:deepslate_bricks
setblock 144 74 9 minecraft:deepslate_bricks
setblock 112 74 10 minecraft:deepslate_bricks
setblock 144 74 10 minecraft:deepslate_bricks
setblock 112 74 11 minecraft:deepslate_bricks
setblock 144 74 11 minecraft:deepslate_bricks
setblock 113 74 12 minecraft:cyan_stained_glass
setblock 143 74 12 minecraft:cyan_stained_glass
setblock 112 74 12 minecraft:sea_lantern
setblock 144 74 12 minecraft:sea_lantern
setblock 112 74 13 minecraft:deepslate_bricks
setblock 144 74 13 minecraft:deepslate_bricks
setblock 112 74 14 minecraft:deepslate_bricks
setblock 144 74 14 minecraft:deepslate_bricks
setblock 116 74 15 minecraft:cyan_stained_glass
setblock 122 74 15 minecraft:cyan_stained_glass
setblock 128 74 15 minecraft:cyan_stained_glass
setblock 134 74 15 minecraft:cyan_stained_glass
setblock 140 74 15 minecraft:cyan_stained_glass
setblock 112 74 15 minecraft:deepslate_bricks
setblock 144 74 15 minecraft:deepslate_bricks
fill 112 74 16 115 74 16 minecraft:deepslate_bricks
fill 117 74 16 121 74 16 minecraft:deepslate_bricks
fill 123 74 16 127 74 16 minecraft:deepslate_bricks
fill 129 74 16 133 74 16 minecraft:deepslate_bricks
fill 135 74 16 139 74 16 minecraft:deepslate_bricks
fill 141 74 16 144 74 16 minecraft:deepslate_bricks
setblock 116 74 16 minecraft:sea_lantern
setblock 122 74 16 minecraft:sea_lantern
setblock 128 74 16 minecraft:sea_lantern
setblock 134 74 16 minecraft:sea_lantern
setblock 140 74 16 minecraft:sea_lantern
fill 112 75 -16 115 75 -16 minecraft:deepslate_bricks
fill 117 75 -16 121 75 -16 minecraft:deepslate_bricks
fill 123 75 -16 127 75 -16 minecraft:deepslate_bricks
fill 129 75 -16 133 75 -16 minecraft:deepslate_bricks
fill 135 75 -16 139 75 -16 minecraft:deepslate_bricks
fill 141 75 -16 144 75 -16 minecraft:deepslate_bricks
setblock 116 75 -16 minecraft:sea_lantern
setblock 122 75 -16 minecraft:sea_lantern
setblock 128 75 -16 minecraft:sea_lantern
setblock 134 75 -16 minecraft:sea_lantern
setblock 140 75 -16 minecraft:sea_lantern
setblock 116 75 -15 minecraft:cyan_stained_glass
setblock 122 75 -15 minecraft:cyan_stained_glass
setblock 128 75 -15 minecraft:cyan_stained_glass
setblock 134 75 -15 minecraft:cyan_stained_glass
setblock 140 75 -15 minecraft:cyan_stained_glass
setblock 112 75 -15 minecraft:deepslate_bricks
setblock 144 75 -15 minecraft:deepslate_bricks
setblock 112 75 -14 minecraft:deepslate_bricks
setblock 144 75 -14 minecraft:deepslate_bricks
setblock 112 75 -13 minecraft:deepslate_bricks
setblock 144 75 -13 minecraft:deepslate_bricks
setblock 113 75 -12 minecraft:cyan_stained_glass
setblock 143 75 -12 minecraft:cyan_stained_glass
setblock 112 75 -12 minecraft:sea_lantern
setblock 144 75 -12 minecraft:sea_lantern
setblock 112 75 -11 minecraft:deepslate_bricks
setblock 144 75 -11 minecraft:deepslate_bricks
setblock 112 75 -10 minecraft:deepslate_bricks
setblock 144 75 -10 minecraft:deepslate_bricks
setblock 112 75 -9 minecraft:deepslate_bricks
setblock 144 75 -9 minecraft:deepslate_bricks
setblock 112 75 -8 minecraft:deepslate_bricks
setblock 144 75 -8 minecraft:deepslate_bricks
setblock 115 75 -7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 75 -7 minecraft:deepslate_bricks
setblock 144 75 -7 minecraft:deepslate_bricks
setblock 113 75 -6 minecraft:cyan_stained_glass
setblock 143 75 -6 minecraft:cyan_stained_glass
setblock 112 75 -6 minecraft:sea_lantern
setblock 144 75 -6 minecraft:sea_lantern
setblock 112 75 -5 minecraft:deepslate_bricks
setblock 144 75 -5 minecraft:deepslate_bricks
setblock 141 75 -4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 75 -4 minecraft:deepslate_bricks
setblock 144 75 -4 minecraft:deepslate_bricks
setblock 112 75 -3 minecraft:deepslate_bricks
setblock 144 75 -3 minecraft:deepslate_bricks
setblock 112 75 -2 minecraft:deepslate_bricks
setblock 144 75 -2 minecraft:deepslate_bricks
setblock 112 75 -1 minecraft:deepslate_bricks
setblock 144 75 -1 minecraft:deepslate_bricks
setblock 113 75 0 minecraft:cyan_stained_glass
setblock 143 75 0 minecraft:cyan_stained_glass
setblock 112 75 0 minecraft:sea_lantern
setblock 144 75 0 minecraft:sea_lantern
setblock 112 75 1 minecraft:deepslate_bricks
setblock 144 75 1 minecraft:deepslate_bricks
setblock 112 75 2 minecraft:deepslate_bricks
setblock 144 75 2 minecraft:deepslate_bricks
setblock 112 75 3 minecraft:deepslate_bricks
setblock 144 75 3 minecraft:deepslate_bricks
setblock 115 75 4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 75 4 minecraft:deepslate_bricks
setblock 144 75 4 minecraft:deepslate_bricks
setblock 112 75 5 minecraft:deepslate_bricks
setblock 144 75 5 minecraft:deepslate_bricks
setblock 113 75 6 minecraft:cyan_stained_glass
setblock 143 75 6 minecraft:cyan_stained_glass
setblock 112 75 6 minecraft:sea_lantern
setblock 144 75 6 minecraft:sea_lantern
setblock 141 75 7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 75 7 minecraft:deepslate_bricks
setblock 144 75 7 minecraft:deepslate_bricks
setblock 112 75 8 minecraft:deepslate_bricks
setblock 144 75 8 minecraft:deepslate_bricks
setblock 112 75 9 minecraft:deepslate_bricks
setblock 144 75 9 minecraft:deepslate_bricks
setblock 112 75 10 minecraft:deepslate_bricks
setblock 144 75 10 minecraft:deepslate_bricks
setblock 112 75 11 minecraft:deepslate_bricks
setblock 144 75 11 minecraft:deepslate_bricks
setblock 113 75 12 minecraft:cyan_stained_glass
setblock 143 75 12 minecraft:cyan_stained_glass
setblock 112 75 12 minecraft:sea_lantern
setblock 144 75 12 minecraft:sea_lantern
setblock 112 75 13 minecraft:deepslate_bricks
setblock 144 75 13 minecraft:deepslate_bricks
setblock 112 75 14 minecraft:deepslate_bricks
setblock 144 75 14 minecraft:deepslate_bricks
setblock 116 75 15 minecraft:cyan_stained_glass
setblock 122 75 15 minecraft:cyan_stained_glass
setblock 128 75 15 minecraft:cyan_stained_glass
setblock 134 75 15 minecraft:cyan_stained_glass
setblock 140 75 15 minecraft:cyan_stained_glass
setblock 112 75 15 minecraft:deepslate_bricks
setblock 144 75 15 minecraft:deepslate_bricks
fill 112 75 16 115 75 16 minecraft:deepslate_bricks
fill 117 75 16 121 75 16 minecraft:deepslate_bricks
fill 123 75 16 127 75 16 minecraft:deepslate_bricks
fill 129 75 16 133 75 16 minecraft:deepslate_bricks
fill 135 75 16 139 75 16 minecraft:deepslate_bricks
fill 141 75 16 144 75 16 minecraft:deepslate_bricks
setblock 116 75 16 minecraft:sea_lantern
setblock 122 75 16 minecraft:sea_lantern
setblock 128 75 16 minecraft:sea_lantern
setblock 134 75 16 minecraft:sea_lantern
setblock 140 75 16 minecraft:sea_lantern
fill 112 76 -16 115 76 -16 minecraft:deepslate_bricks
fill 117 76 -16 121 76 -16 minecraft:deepslate_bricks
fill 123 76 -16 127 76 -16 minecraft:deepslate_bricks
fill 129 76 -16 133 76 -16 minecraft:deepslate_bricks
fill 135 76 -16 139 76 -16 minecraft:deepslate_bricks
fill 141 76 -16 144 76 -16 minecraft:deepslate_bricks
setblock 116 76 -16 minecraft:sea_lantern
setblock 122 76 -16 minecraft:sea_lantern
setblock 128 76 -16 minecraft:sea_lantern
setblock 134 76 -16 minecraft:sea_lantern
setblock 140 76 -16 minecraft:sea_lantern
setblock 116 76 -15 minecraft:cyan_stained_glass
setblock 122 76 -15 minecraft:cyan_stained_glass
setblock 128 76 -15 minecraft:cyan_stained_glass
setblock 134 76 -15 minecraft:cyan_stained_glass
setblock 140 76 -15 minecraft:cyan_stained_glass
setblock 112 76 -15 minecraft:deepslate_bricks
setblock 144 76 -15 minecraft:deepslate_bricks
setblock 112 76 -14 minecraft:deepslate_bricks
setblock 144 76 -14 minecraft:deepslate_bricks
setblock 112 76 -13 minecraft:deepslate_bricks
setblock 144 76 -13 minecraft:deepslate_bricks
setblock 113 76 -12 minecraft:cyan_stained_glass
setblock 143 76 -12 minecraft:cyan_stained_glass
setblock 112 76 -12 minecraft:sea_lantern
setblock 144 76 -12 minecraft:sea_lantern
setblock 112 76 -11 minecraft:deepslate_bricks
setblock 144 76 -11 minecraft:deepslate_bricks
setblock 112 76 -10 minecraft:deepslate_bricks
setblock 144 76 -10 minecraft:deepslate_bricks
setblock 112 76 -9 minecraft:deepslate_bricks
setblock 144 76 -9 minecraft:deepslate_bricks
setblock 112 76 -8 minecraft:deepslate_bricks
setblock 144 76 -8 minecraft:deepslate_bricks
setblock 115 76 -7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 76 -7 minecraft:deepslate_bricks
setblock 144 76 -7 minecraft:deepslate_bricks
setblock 113 76 -6 minecraft:cyan_stained_glass
setblock 143 76 -6 minecraft:cyan_stained_glass
setblock 112 76 -6 minecraft:sea_lantern
setblock 144 76 -6 minecraft:sea_lantern
setblock 112 76 -5 minecraft:deepslate_bricks
setblock 144 76 -5 minecraft:deepslate_bricks
setblock 141 76 -4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 76 -4 minecraft:deepslate_bricks
setblock 144 76 -4 minecraft:deepslate_bricks
setblock 112 76 -3 minecraft:deepslate_bricks
setblock 144 76 -3 minecraft:deepslate_bricks
setblock 112 76 -2 minecraft:deepslate_bricks
setblock 144 76 -2 minecraft:deepslate_bricks
setblock 112 76 -1 minecraft:deepslate_bricks
setblock 144 76 -1 minecraft:deepslate_bricks
setblock 113 76 0 minecraft:cyan_stained_glass
setblock 143 76 0 minecraft:cyan_stained_glass
setblock 112 76 0 minecraft:sea_lantern
setblock 144 76 0 minecraft:sea_lantern
setblock 112 76 1 minecraft:deepslate_bricks
setblock 144 76 1 minecraft:deepslate_bricks
setblock 112 76 2 minecraft:deepslate_bricks
setblock 144 76 2 minecraft:deepslate_bricks
setblock 112 76 3 minecraft:deepslate_bricks
setblock 144 76 3 minecraft:deepslate_bricks
setblock 115 76 4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 76 4 minecraft:deepslate_bricks
setblock 144 76 4 minecraft:deepslate_bricks
setblock 112 76 5 minecraft:deepslate_bricks
setblock 144 76 5 minecraft:deepslate_bricks
setblock 113 76 6 minecraft:cyan_stained_glass
setblock 143 76 6 minecraft:cyan_stained_glass
setblock 112 76 6 minecraft:sea_lantern
setblock 144 76 6 minecraft:sea_lantern
setblock 141 76 7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 76 7 minecraft:deepslate_bricks
setblock 144 76 7 minecraft:deepslate_bricks
setblock 112 76 8 minecraft:deepslate_bricks
setblock 144 76 8 minecraft:deepslate_bricks
setblock 112 76 9 minecraft:deepslate_bricks
setblock 144 76 9 minecraft:deepslate_bricks
setblock 112 76 10 minecraft:deepslate_bricks
setblock 144 76 10 minecraft:deepslate_bricks
setblock 112 76 11 minecraft:deepslate_bricks
setblock 144 76 11 minecraft:deepslate_bricks
setblock 113 76 12 minecraft:cyan_stained_glass
setblock 143 76 12 minecraft:cyan_stained_glass
setblock 112 76 12 minecraft:sea_lantern
setblock 144 76 12 minecraft:sea_lantern
setblock 112 76 13 minecraft:deepslate_bricks
setblock 144 76 13 minecraft:deepslate_bricks
setblock 112 76 14 minecraft:deepslate_bricks
setblock 144 76 14 minecraft:deepslate_bricks
setblock 116 76 15 minecraft:cyan_stained_glass
setblock 122 76 15 minecraft:cyan_stained_glass
setblock 128 76 15 minecraft:cyan_stained_glass
setblock 134 76 15 minecraft:cyan_stained_glass
setblock 140 76 15 minecraft:cyan_stained_glass
setblock 112 76 15 minecraft:deepslate_bricks
setblock 144 76 15 minecraft:deepslate_bricks
fill 112 76 16 115 76 16 minecraft:deepslate_bricks
fill 117 76 16 121 76 16 minecraft:deepslate_bricks
fill 123 76 16 127 76 16 minecraft:deepslate_bricks
fill 129 76 16 133 76 16 minecraft:deepslate_bricks
fill 135 76 16 139 76 16 minecraft:deepslate_bricks
fill 141 76 16 144 76 16 minecraft:deepslate_bricks
setblock 116 76 16 minecraft:sea_lantern
setblock 122 76 16 minecraft:sea_lantern
setblock 128 76 16 minecraft:sea_lantern
setblock 134 76 16 minecraft:sea_lantern
setblock 140 76 16 minecraft:sea_lantern
fill 112 77 -16 115 77 -16 minecraft:deepslate_bricks
fill 117 77 -16 121 77 -16 minecraft:deepslate_bricks
fill 123 77 -16 127 77 -16 minecraft:deepslate_bricks
fill 129 77 -16 133 77 -16 minecraft:deepslate_bricks
fill 135 77 -16 139 77 -16 minecraft:deepslate_bricks
fill 141 77 -16 144 77 -16 minecraft:deepslate_bricks
setblock 116 77 -16 minecraft:sea_lantern
setblock 122 77 -16 minecraft:sea_lantern
setblock 128 77 -16 minecraft:sea_lantern
setblock 134 77 -16 minecraft:sea_lantern
setblock 140 77 -16 minecraft:sea_lantern
setblock 116 77 -15 minecraft:cyan_stained_glass
setblock 122 77 -15 minecraft:cyan_stained_glass
setblock 128 77 -15 minecraft:cyan_stained_glass
setblock 134 77 -15 minecraft:cyan_stained_glass
setblock 140 77 -15 minecraft:cyan_stained_glass
setblock 112 77 -15 minecraft:deepslate_bricks
setblock 144 77 -15 minecraft:deepslate_bricks
setblock 112 77 -14 minecraft:deepslate_bricks
setblock 144 77 -14 minecraft:deepslate_bricks
setblock 112 77 -13 minecraft:deepslate_bricks
setblock 144 77 -13 minecraft:deepslate_bricks
setblock 113 77 -12 minecraft:cyan_stained_glass
setblock 143 77 -12 minecraft:cyan_stained_glass
setblock 112 77 -12 minecraft:sea_lantern
setblock 144 77 -12 minecraft:sea_lantern
setblock 112 77 -11 minecraft:deepslate_bricks
setblock 144 77 -11 minecraft:deepslate_bricks
setblock 112 77 -10 minecraft:deepslate_bricks
setblock 144 77 -10 minecraft:deepslate_bricks
setblock 112 77 -9 minecraft:deepslate_bricks
setblock 144 77 -9 minecraft:deepslate_bricks
setblock 112 77 -8 minecraft:deepslate_bricks
setblock 144 77 -8 minecraft:deepslate_bricks
setblock 115 77 -7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 77 -7 minecraft:deepslate_bricks
setblock 144 77 -7 minecraft:deepslate_bricks
setblock 113 77 -6 minecraft:cyan_stained_glass
setblock 143 77 -6 minecraft:cyan_stained_glass
setblock 112 77 -6 minecraft:sea_lantern
setblock 144 77 -6 minecraft:sea_lantern
setblock 112 77 -5 minecraft:deepslate_bricks
setblock 144 77 -5 minecraft:deepslate_bricks
setblock 141 77 -4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 77 -4 minecraft:deepslate_bricks
setblock 144 77 -4 minecraft:deepslate_bricks
setblock 112 77 -3 minecraft:deepslate_bricks
setblock 144 77 -3 minecraft:deepslate_bricks
setblock 112 77 -2 minecraft:deepslate_bricks
setblock 144 77 -2 minecraft:deepslate_bricks
setblock 112 77 -1 minecraft:deepslate_bricks
setblock 144 77 -1 minecraft:deepslate_bricks
setblock 113 77 0 minecraft:cyan_stained_glass
setblock 143 77 0 minecraft:cyan_stained_glass
setblock 112 77 0 minecraft:sea_lantern
setblock 144 77 0 minecraft:sea_lantern
setblock 112 77 1 minecraft:deepslate_bricks
setblock 144 77 1 minecraft:deepslate_bricks
setblock 112 77 2 minecraft:deepslate_bricks
setblock 144 77 2 minecraft:deepslate_bricks
setblock 112 77 3 minecraft:deepslate_bricks
setblock 144 77 3 minecraft:deepslate_bricks
setblock 115 77 4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 77 4 minecraft:deepslate_bricks
setblock 144 77 4 minecraft:deepslate_bricks
setblock 112 77 5 minecraft:deepslate_bricks
setblock 144 77 5 minecraft:deepslate_bricks
setblock 113 77 6 minecraft:cyan_stained_glass
setblock 143 77 6 minecraft:cyan_stained_glass
setblock 112 77 6 minecraft:sea_lantern
setblock 144 77 6 minecraft:sea_lantern
setblock 141 77 7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 77 7 minecraft:deepslate_bricks
setblock 144 77 7 minecraft:deepslate_bricks
setblock 112 77 8 minecraft:deepslate_bricks
setblock 144 77 8 minecraft:deepslate_bricks
setblock 112 77 9 minecraft:deepslate_bricks
setblock 144 77 9 minecraft:deepslate_bricks
setblock 112 77 10 minecraft:deepslate_bricks
setblock 144 77 10 minecraft:deepslate_bricks
setblock 112 77 11 minecraft:deepslate_bricks
setblock 144 77 11 minecraft:deepslate_bricks
setblock 113 77 12 minecraft:cyan_stained_glass
setblock 143 77 12 minecraft:cyan_stained_glass
setblock 112 77 12 minecraft:sea_lantern
setblock 144 77 12 minecraft:sea_lantern
setblock 112 77 13 minecraft:deepslate_bricks
setblock 144 77 13 minecraft:deepslate_bricks
setblock 112 77 14 minecraft:deepslate_bricks
setblock 144 77 14 minecraft:deepslate_bricks
setblock 116 77 15 minecraft:cyan_stained_glass
setblock 122 77 15 minecraft:cyan_stained_glass
setblock 128 77 15 minecraft:cyan_stained_glass
setblock 134 77 15 minecraft:cyan_stained_glass
setblock 140 77 15 minecraft:cyan_stained_glass
setblock 112 77 15 minecraft:deepslate_bricks
setblock 144 77 15 minecraft:deepslate_bricks
fill 112 77 16 115 77 16 minecraft:deepslate_bricks
fill 117 77 16 121 77 16 minecraft:deepslate_bricks
fill 123 77 16 127 77 16 minecraft:deepslate_bricks
fill 129 77 16 133 77 16 minecraft:deepslate_bricks
fill 135 77 16 139 77 16 minecraft:deepslate_bricks
fill 141 77 16 144 77 16 minecraft:deepslate_bricks
setblock 116 77 16 minecraft:sea_lantern
setblock 122 77 16 minecraft:sea_lantern
setblock 128 77 16 minecraft:sea_lantern
setblock 134 77 16 minecraft:sea_lantern
setblock 140 77 16 minecraft:sea_lantern
fill 112 78 -16 115 78 -16 minecraft:deepslate_bricks
fill 117 78 -16 121 78 -16 minecraft:deepslate_bricks
fill 123 78 -16 127 78 -16 minecraft:deepslate_bricks
fill 129 78 -16 133 78 -16 minecraft:deepslate_bricks
fill 135 78 -16 139 78 -16 minecraft:deepslate_bricks
fill 141 78 -16 144 78 -16 minecraft:deepslate_bricks
setblock 116 78 -16 minecraft:sea_lantern
setblock 122 78 -16 minecraft:sea_lantern
setblock 128 78 -16 minecraft:sea_lantern
setblock 134 78 -16 minecraft:sea_lantern
setblock 140 78 -16 minecraft:sea_lantern
setblock 116 78 -15 minecraft:cyan_stained_glass
setblock 122 78 -15 minecraft:cyan_stained_glass
setblock 128 78 -15 minecraft:cyan_stained_glass
setblock 134 78 -15 minecraft:cyan_stained_glass
setblock 140 78 -15 minecraft:cyan_stained_glass
setblock 112 78 -15 minecraft:deepslate_bricks
setblock 144 78 -15 minecraft:deepslate_bricks
setblock 112 78 -14 minecraft:deepslate_bricks
setblock 144 78 -14 minecraft:deepslate_bricks
setblock 112 78 -13 minecraft:deepslate_bricks
setblock 144 78 -13 minecraft:deepslate_bricks
setblock 113 78 -12 minecraft:cyan_stained_glass
setblock 143 78 -12 minecraft:cyan_stained_glass
setblock 112 78 -12 minecraft:sea_lantern
setblock 144 78 -12 minecraft:sea_lantern
setblock 112 78 -11 minecraft:deepslate_bricks
setblock 144 78 -11 minecraft:deepslate_bricks
setblock 112 78 -10 minecraft:deepslate_bricks
setblock 144 78 -10 minecraft:deepslate_bricks
setblock 112 78 -9 minecraft:deepslate_bricks
setblock 144 78 -9 minecraft:deepslate_bricks
setblock 112 78 -8 minecraft:deepslate_bricks
setblock 144 78 -8 minecraft:deepslate_bricks
setblock 115 78 -7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 78 -7 minecraft:deepslate_bricks
setblock 144 78 -7 minecraft:deepslate_bricks
setblock 113 78 -6 minecraft:cyan_stained_glass
setblock 143 78 -6 minecraft:cyan_stained_glass
setblock 112 78 -6 minecraft:sea_lantern
setblock 144 78 -6 minecraft:sea_lantern
setblock 112 78 -5 minecraft:deepslate_bricks
setblock 144 78 -5 minecraft:deepslate_bricks
setblock 141 78 -4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 78 -4 minecraft:deepslate_bricks
setblock 144 78 -4 minecraft:deepslate_bricks
setblock 112 78 -3 minecraft:deepslate_bricks
setblock 144 78 -3 minecraft:deepslate_bricks
setblock 112 78 -2 minecraft:deepslate_bricks
setblock 144 78 -2 minecraft:deepslate_bricks
setblock 112 78 -1 minecraft:deepslate_bricks
setblock 144 78 -1 minecraft:deepslate_bricks
setblock 113 78 0 minecraft:cyan_stained_glass
setblock 143 78 0 minecraft:cyan_stained_glass
setblock 112 78 0 minecraft:sea_lantern
setblock 144 78 0 minecraft:sea_lantern
setblock 112 78 1 minecraft:deepslate_bricks
setblock 144 78 1 minecraft:deepslate_bricks
setblock 112 78 2 minecraft:deepslate_bricks
setblock 144 78 2 minecraft:deepslate_bricks
setblock 112 78 3 minecraft:deepslate_bricks
setblock 144 78 3 minecraft:deepslate_bricks
setblock 115 78 4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 78 4 minecraft:deepslate_bricks
setblock 144 78 4 minecraft:deepslate_bricks
setblock 112 78 5 minecraft:deepslate_bricks
setblock 144 78 5 minecraft:deepslate_bricks
setblock 113 78 6 minecraft:cyan_stained_glass
setblock 143 78 6 minecraft:cyan_stained_glass
setblock 112 78 6 minecraft:sea_lantern
setblock 144 78 6 minecraft:sea_lantern
setblock 141 78 7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 78 7 minecraft:deepslate_bricks
setblock 144 78 7 minecraft:deepslate_bricks
setblock 112 78 8 minecraft:deepslate_bricks
setblock 144 78 8 minecraft:deepslate_bricks
setblock 112 78 9 minecraft:deepslate_bricks
setblock 144 78 9 minecraft:deepslate_bricks
setblock 112 78 10 minecraft:deepslate_bricks
setblock 144 78 10 minecraft:deepslate_bricks
setblock 112 78 11 minecraft:deepslate_bricks
setblock 144 78 11 minecraft:deepslate_bricks
setblock 113 78 12 minecraft:cyan_stained_glass
setblock 143 78 12 minecraft:cyan_stained_glass
setblock 112 78 12 minecraft:sea_lantern
setblock 144 78 12 minecraft:sea_lantern
setblock 112 78 13 minecraft:deepslate_bricks
setblock 144 78 13 minecraft:deepslate_bricks
setblock 112 78 14 minecraft:deepslate_bricks
setblock 144 78 14 minecraft:deepslate_bricks
setblock 116 78 15 minecraft:cyan_stained_glass
setblock 122 78 15 minecraft:cyan_stained_glass
setblock 128 78 15 minecraft:cyan_stained_glass
setblock 134 78 15 minecraft:cyan_stained_glass
setblock 140 78 15 minecraft:cyan_stained_glass
setblock 112 78 15 minecraft:deepslate_bricks
setblock 144 78 15 minecraft:deepslate_bricks
fill 112 78 16 115 78 16 minecraft:deepslate_bricks
fill 117 78 16 121 78 16 minecraft:deepslate_bricks
fill 123 78 16 127 78 16 minecraft:deepslate_bricks
fill 129 78 16 133 78 16 minecraft:deepslate_bricks
fill 135 78 16 139 78 16 minecraft:deepslate_bricks
fill 141 78 16 144 78 16 minecraft:deepslate_bricks
setblock 116 78 16 minecraft:sea_lantern
setblock 122 78 16 minecraft:sea_lantern
setblock 128 78 16 minecraft:sea_lantern
setblock 134 78 16 minecraft:sea_lantern
setblock 140 78 16 minecraft:sea_lantern
fill 112 79 -16 144 79 -16 minecraft:deepslate_bricks
setblock 112 79 -15 minecraft:deepslate_bricks
setblock 144 79 -15 minecraft:deepslate_bricks
setblock 116 79 -15 minecraft:polished_deepslate
setblock 122 79 -15 minecraft:polished_deepslate
setblock 128 79 -15 minecraft:polished_deepslate
setblock 134 79 -15 minecraft:polished_deepslate
setblock 140 79 -15 minecraft:polished_deepslate
setblock 112 79 -14 minecraft:deepslate_bricks
setblock 144 79 -14 minecraft:deepslate_bricks
setblock 112 79 -13 minecraft:deepslate_bricks
setblock 144 79 -13 minecraft:deepslate_bricks
setblock 112 79 -12 minecraft:deepslate_bricks
setblock 144 79 -12 minecraft:deepslate_bricks
setblock 113 79 -12 minecraft:polished_deepslate
setblock 143 79 -12 minecraft:polished_deepslate
setblock 112 79 -11 minecraft:deepslate_bricks
setblock 144 79 -11 minecraft:deepslate_bricks
setblock 112 79 -10 minecraft:deepslate_bricks
setblock 144 79 -10 minecraft:deepslate_bricks
setblock 112 79 -9 minecraft:deepslate_bricks
setblock 144 79 -9 minecraft:deepslate_bricks
setblock 112 79 -8 minecraft:deepslate_bricks
setblock 144 79 -8 minecraft:deepslate_bricks
setblock 115 79 -7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 79 -7 minecraft:deepslate_bricks
setblock 144 79 -7 minecraft:deepslate_bricks
setblock 112 79 -6 minecraft:deepslate_bricks
setblock 144 79 -6 minecraft:deepslate_bricks
setblock 113 79 -6 minecraft:polished_deepslate
setblock 143 79 -6 minecraft:polished_deepslate
setblock 112 79 -5 minecraft:deepslate_bricks
setblock 144 79 -5 minecraft:deepslate_bricks
setblock 141 79 -4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 79 -4 minecraft:deepslate_bricks
setblock 144 79 -4 minecraft:deepslate_bricks
setblock 112 79 -3 minecraft:deepslate_bricks
setblock 144 79 -3 minecraft:deepslate_bricks
setblock 112 79 -2 minecraft:deepslate_bricks
setblock 144 79 -2 minecraft:deepslate_bricks
setblock 112 79 -1 minecraft:deepslate_bricks
setblock 144 79 -1 minecraft:deepslate_bricks
setblock 112 79 0 minecraft:deepslate_bricks
setblock 144 79 0 minecraft:deepslate_bricks
setblock 113 79 0 minecraft:polished_deepslate
setblock 143 79 0 minecraft:polished_deepslate
setblock 112 79 1 minecraft:deepslate_bricks
setblock 144 79 1 minecraft:deepslate_bricks
setblock 112 79 2 minecraft:deepslate_bricks
setblock 144 79 2 minecraft:deepslate_bricks
setblock 112 79 3 minecraft:deepslate_bricks
setblock 144 79 3 minecraft:deepslate_bricks
setblock 115 79 4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 79 4 minecraft:deepslate_bricks
setblock 144 79 4 minecraft:deepslate_bricks
setblock 112 79 5 minecraft:deepslate_bricks
setblock 144 79 5 minecraft:deepslate_bricks
setblock 112 79 6 minecraft:deepslate_bricks
setblock 144 79 6 minecraft:deepslate_bricks
setblock 113 79 6 minecraft:polished_deepslate
setblock 143 79 6 minecraft:polished_deepslate
setblock 141 79 7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 79 7 minecraft:deepslate_bricks
setblock 144 79 7 minecraft:deepslate_bricks
setblock 112 79 8 minecraft:deepslate_bricks
setblock 144 79 8 minecraft:deepslate_bricks
setblock 112 79 9 minecraft:deepslate_bricks
setblock 144 79 9 minecraft:deepslate_bricks
setblock 112 79 10 minecraft:deepslate_bricks
setblock 144 79 10 minecraft:deepslate_bricks
setblock 112 79 11 minecraft:deepslate_bricks
setblock 144 79 11 minecraft:deepslate_bricks
setblock 112 79 12 minecraft:deepslate_bricks
setblock 144 79 12 minecraft:deepslate_bricks
setblock 113 79 12 minecraft:polished_deepslate
setblock 143 79 12 minecraft:polished_deepslate
setblock 112 79 13 minecraft:deepslate_bricks
setblock 144 79 13 minecraft:deepslate_bricks
setblock 112 79 14 minecraft:deepslate_bricks
setblock 144 79 14 minecraft:deepslate_bricks
setblock 112 79 15 minecraft:deepslate_bricks
setblock 144 79 15 minecraft:deepslate_bricks
setblock 116 79 15 minecraft:polished_deepslate
setblock 122 79 15 minecraft:polished_deepslate
setblock 128 79 15 minecraft:polished_deepslate
setblock 134 79 15 minecraft:polished_deepslate
setblock 140 79 15 minecraft:polished_deepslate
fill 112 79 16 144 79 16 minecraft:deepslate_bricks
fill 112 80 -16 144 80 -16 minecraft:deepslate_bricks
setblock 112 80 -15 minecraft:deepslate_bricks
setblock 144 80 -15 minecraft:deepslate_bricks
fill 113 80 -15 143 80 -15 minecraft:waxed_weathered_cut_copper
setblock 112 80 -14 minecraft:deepslate_bricks
setblock 144 80 -14 minecraft:deepslate_bricks
setblock 113 80 -14 minecraft:waxed_weathered_cut_copper
setblock 143 80 -14 minecraft:waxed_weathered_cut_copper
setblock 112 80 -13 minecraft:deepslate_bricks
setblock 144 80 -13 minecraft:deepslate_bricks
setblock 113 80 -13 minecraft:waxed_weathered_cut_copper
setblock 143 80 -13 minecraft:waxed_weathered_cut_copper
setblock 112 80 -12 minecraft:deepslate_bricks
setblock 144 80 -12 minecraft:deepslate_bricks
setblock 116 80 -12 minecraft:sea_lantern
setblock 140 80 -12 minecraft:sea_lantern
fill 113 80 -12 114 80 -12 minecraft:waxed_weathered_cut_copper
fill 142 80 -12 143 80 -12 minecraft:waxed_weathered_cut_copper
setblock 112 80 -11 minecraft:deepslate_bricks
setblock 144 80 -11 minecraft:deepslate_bricks
setblock 113 80 -11 minecraft:waxed_weathered_cut_copper
setblock 143 80 -11 minecraft:waxed_weathered_cut_copper
setblock 112 80 -10 minecraft:deepslate_bricks
setblock 144 80 -10 minecraft:deepslate_bricks
setblock 113 80 -10 minecraft:waxed_weathered_cut_copper
setblock 143 80 -10 minecraft:waxed_weathered_cut_copper
setblock 112 80 -9 minecraft:deepslate_bricks
setblock 144 80 -9 minecraft:deepslate_bricks
setblock 113 80 -9 minecraft:waxed_weathered_cut_copper
setblock 143 80 -9 minecraft:waxed_weathered_cut_copper
setblock 112 80 -8 minecraft:deepslate_bricks
setblock 144 80 -8 minecraft:deepslate_bricks
setblock 113 80 -8 minecraft:waxed_weathered_cut_copper
setblock 143 80 -8 minecraft:waxed_weathered_cut_copper
setblock 115 80 -7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 80 -7 minecraft:deepslate_bricks
setblock 144 80 -7 minecraft:deepslate_bricks
setblock 113 80 -7 minecraft:waxed_weathered_cut_copper
setblock 143 80 -7 minecraft:waxed_weathered_cut_copper
setblock 112 80 -6 minecraft:deepslate_bricks
setblock 144 80 -6 minecraft:deepslate_bricks
setblock 113 80 -6 minecraft:waxed_weathered_cut_copper
setblock 143 80 -6 minecraft:waxed_weathered_cut_copper
setblock 112 80 -5 minecraft:deepslate_bricks
setblock 144 80 -5 minecraft:deepslate_bricks
setblock 113 80 -5 minecraft:waxed_weathered_cut_copper
setblock 143 80 -5 minecraft:waxed_weathered_cut_copper
setblock 141 80 -4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 80 -4 minecraft:deepslate_bricks
setblock 144 80 -4 minecraft:deepslate_bricks
setblock 113 80 -4 minecraft:waxed_weathered_cut_copper
setblock 143 80 -4 minecraft:waxed_weathered_cut_copper
setblock 112 80 -3 minecraft:deepslate_bricks
setblock 144 80 -3 minecraft:deepslate_bricks
setblock 113 80 -3 minecraft:waxed_weathered_cut_copper
setblock 143 80 -3 minecraft:waxed_weathered_cut_copper
setblock 112 80 -2 minecraft:deepslate_bricks
setblock 144 80 -2 minecraft:deepslate_bricks
setblock 113 80 -2 minecraft:waxed_weathered_cut_copper
setblock 143 80 -2 minecraft:waxed_weathered_cut_copper
setblock 112 80 -1 minecraft:deepslate_bricks
setblock 144 80 -1 minecraft:deepslate_bricks
setblock 113 80 -1 minecraft:waxed_weathered_cut_copper
setblock 143 80 -1 minecraft:waxed_weathered_cut_copper
setblock 112 80 0 minecraft:deepslate_bricks
setblock 144 80 0 minecraft:deepslate_bricks
setblock 116 80 0 minecraft:sea_lantern
setblock 140 80 0 minecraft:sea_lantern
fill 113 80 0 114 80 0 minecraft:waxed_weathered_cut_copper
fill 142 80 0 143 80 0 minecraft:waxed_weathered_cut_copper
setblock 112 80 1 minecraft:deepslate_bricks
setblock 144 80 1 minecraft:deepslate_bricks
setblock 113 80 1 minecraft:waxed_weathered_cut_copper
setblock 143 80 1 minecraft:waxed_weathered_cut_copper
setblock 112 80 2 minecraft:deepslate_bricks
setblock 144 80 2 minecraft:deepslate_bricks
setblock 113 80 2 minecraft:waxed_weathered_cut_copper
setblock 143 80 2 minecraft:waxed_weathered_cut_copper
setblock 112 80 3 minecraft:deepslate_bricks
setblock 144 80 3 minecraft:deepslate_bricks
setblock 113 80 3 minecraft:waxed_weathered_cut_copper
setblock 143 80 3 minecraft:waxed_weathered_cut_copper
setblock 115 80 4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 80 4 minecraft:deepslate_bricks
setblock 144 80 4 minecraft:deepslate_bricks
setblock 113 80 4 minecraft:waxed_weathered_cut_copper
setblock 143 80 4 minecraft:waxed_weathered_cut_copper
setblock 112 80 5 minecraft:deepslate_bricks
setblock 144 80 5 minecraft:deepslate_bricks
setblock 113 80 5 minecraft:waxed_weathered_cut_copper
setblock 143 80 5 minecraft:waxed_weathered_cut_copper
setblock 112 80 6 minecraft:deepslate_bricks
setblock 144 80 6 minecraft:deepslate_bricks
setblock 113 80 6 minecraft:waxed_weathered_cut_copper
setblock 143 80 6 minecraft:waxed_weathered_cut_copper
setblock 141 80 7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 80 7 minecraft:deepslate_bricks
setblock 144 80 7 minecraft:deepslate_bricks
setblock 113 80 7 minecraft:waxed_weathered_cut_copper
setblock 143 80 7 minecraft:waxed_weathered_cut_copper
setblock 112 80 8 minecraft:deepslate_bricks
setblock 144 80 8 minecraft:deepslate_bricks
setblock 113 80 8 minecraft:waxed_weathered_cut_copper
setblock 143 80 8 minecraft:waxed_weathered_cut_copper
setblock 112 80 9 minecraft:deepslate_bricks
setblock 144 80 9 minecraft:deepslate_bricks
setblock 113 80 9 minecraft:waxed_weathered_cut_copper
setblock 143 80 9 minecraft:waxed_weathered_cut_copper
setblock 112 80 10 minecraft:deepslate_bricks
setblock 144 80 10 minecraft:deepslate_bricks
setblock 113 80 10 minecraft:waxed_weathered_cut_copper
setblock 143 80 10 minecraft:waxed_weathered_cut_copper
setblock 112 80 11 minecraft:deepslate_bricks
setblock 144 80 11 minecraft:deepslate_bricks
setblock 113 80 11 minecraft:waxed_weathered_cut_copper
setblock 143 80 11 minecraft:waxed_weathered_cut_copper
setblock 112 80 12 minecraft:deepslate_bricks
setblock 144 80 12 minecraft:deepslate_bricks
setblock 116 80 12 minecraft:sea_lantern
setblock 140 80 12 minecraft:sea_lantern
fill 113 80 12 114 80 12 minecraft:waxed_weathered_cut_copper
fill 142 80 12 143 80 12 minecraft:waxed_weathered_cut_copper
setblock 112 80 13 minecraft:deepslate_bricks
setblock 144 80 13 minecraft:deepslate_bricks
setblock 113 80 13 minecraft:waxed_weathered_cut_copper
setblock 143 80 13 minecraft:waxed_weathered_cut_copper
setblock 112 80 14 minecraft:deepslate_bricks
setblock 144 80 14 minecraft:deepslate_bricks
setblock 113 80 14 minecraft:waxed_weathered_cut_copper
setblock 143 80 14 minecraft:waxed_weathered_cut_copper
setblock 112 80 15 minecraft:deepslate_bricks
setblock 144 80 15 minecraft:deepslate_bricks
fill 113 80 15 143 80 15 minecraft:waxed_weathered_cut_copper
fill 112 80 16 144 80 16 minecraft:deepslate_bricks
fill 112 81 -16 144 81 -16 minecraft:deepslate_bricks
setblock 112 81 -15 minecraft:deepslate_bricks
setblock 144 81 -15 minecraft:deepslate_bricks
setblock 116 81 -15 minecraft:waxed_weathered_cut_copper
setblock 122 81 -15 minecraft:waxed_weathered_cut_copper
setblock 128 81 -15 minecraft:waxed_weathered_cut_copper
setblock 134 81 -15 minecraft:waxed_weathered_cut_copper
setblock 140 81 -15 minecraft:waxed_weathered_cut_copper
setblock 112 81 -14 minecraft:deepslate_bricks
setblock 144 81 -14 minecraft:deepslate_bricks
setblock 112 81 -13 minecraft:deepslate_bricks
setblock 144 81 -13 minecraft:deepslate_bricks
setblock 112 81 -12 minecraft:deepslate_bricks
setblock 144 81 -12 minecraft:deepslate_bricks
setblock 122 81 -12 minecraft:sea_lantern
setblock 128 81 -12 minecraft:sea_lantern
setblock 134 81 -12 minecraft:sea_lantern
setblock 113 81 -12 minecraft:waxed_weathered_cut_copper
fill 115 81 -12 117 81 -12 minecraft:waxed_weathered_cut_copper
fill 139 81 -12 141 81 -12 minecraft:waxed_weathered_cut_copper
setblock 143 81 -12 minecraft:waxed_weathered_cut_copper
setblock 112 81 -11 minecraft:deepslate_bricks
setblock 144 81 -11 minecraft:deepslate_bricks
setblock 112 81 -10 minecraft:deepslate_bricks
setblock 144 81 -10 minecraft:deepslate_bricks
setblock 112 81 -9 minecraft:deepslate_bricks
setblock 144 81 -9 minecraft:deepslate_bricks
setblock 112 81 -8 minecraft:deepslate_bricks
setblock 144 81 -8 minecraft:deepslate_bricks
setblock 115 81 -7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 81 -7 minecraft:deepslate_bricks
setblock 144 81 -7 minecraft:deepslate_bricks
setblock 112 81 -6 minecraft:deepslate_bricks
setblock 144 81 -6 minecraft:deepslate_bricks
setblock 113 81 -6 minecraft:waxed_weathered_cut_copper
setblock 143 81 -6 minecraft:waxed_weathered_cut_copper
setblock 112 81 -5 minecraft:deepslate_bricks
setblock 144 81 -5 minecraft:deepslate_bricks
setblock 141 81 -4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 81 -4 minecraft:deepslate_bricks
setblock 144 81 -4 minecraft:deepslate_bricks
setblock 112 81 -3 minecraft:deepslate_bricks
setblock 144 81 -3 minecraft:deepslate_bricks
setblock 112 81 -2 minecraft:deepslate_bricks
setblock 144 81 -2 minecraft:deepslate_bricks
setblock 112 81 -1 minecraft:deepslate_bricks
setblock 144 81 -1 minecraft:deepslate_bricks
setblock 112 81 0 minecraft:deepslate_bricks
setblock 144 81 0 minecraft:deepslate_bricks
setblock 122 81 0 minecraft:sea_lantern
setblock 128 81 0 minecraft:sea_lantern
setblock 134 81 0 minecraft:sea_lantern
setblock 113 81 0 minecraft:waxed_weathered_cut_copper
fill 115 81 0 117 81 0 minecraft:waxed_weathered_cut_copper
fill 139 81 0 141 81 0 minecraft:waxed_weathered_cut_copper
setblock 143 81 0 minecraft:waxed_weathered_cut_copper
setblock 112 81 1 minecraft:deepslate_bricks
setblock 144 81 1 minecraft:deepslate_bricks
setblock 112 81 2 minecraft:deepslate_bricks
setblock 144 81 2 minecraft:deepslate_bricks
setblock 112 81 3 minecraft:deepslate_bricks
setblock 144 81 3 minecraft:deepslate_bricks
setblock 115 81 4 minecraft:chain[axis=y,waterlogged=false]
setblock 112 81 4 minecraft:deepslate_bricks
setblock 144 81 4 minecraft:deepslate_bricks
setblock 112 81 5 minecraft:deepslate_bricks
setblock 144 81 5 minecraft:deepslate_bricks
setblock 112 81 6 minecraft:deepslate_bricks
setblock 144 81 6 minecraft:deepslate_bricks
setblock 113 81 6 minecraft:waxed_weathered_cut_copper
setblock 143 81 6 minecraft:waxed_weathered_cut_copper
setblock 141 81 7 minecraft:chain[axis=y,waterlogged=false]
setblock 112 81 7 minecraft:deepslate_bricks
setblock 144 81 7 minecraft:deepslate_bricks
setblock 112 81 8 minecraft:deepslate_bricks
setblock 144 81 8 minecraft:deepslate_bricks
setblock 112 81 9 minecraft:deepslate_bricks
setblock 144 81 9 minecraft:deepslate_bricks
setblock 112 81 10 minecraft:deepslate_bricks
setblock 144 81 10 minecraft:deepslate_bricks
setblock 112 81 11 minecraft:deepslate_bricks
setblock 144 81 11 minecraft:deepslate_bricks
setblock 112 81 12 minecraft:deepslate_bricks
setblock 144 81 12 minecraft:deepslate_bricks
setblock 122 81 12 minecraft:sea_lantern
setblock 128 81 12 minecraft:sea_lantern
setblock 134 81 12 minecraft:sea_lantern
setblock 113 81 12 minecraft:waxed_weathered_cut_copper
fill 115 81 12 117 81 12 minecraft:waxed_weathered_cut_copper
fill 139 81 12 141 81 12 minecraft:waxed_weathered_cut_copper
setblock 143 81 12 minecraft:waxed_weathered_cut_copper
setblock 112 81 13 minecraft:deepslate_bricks
setblock 144 81 13 minecraft:deepslate_bricks
setblock 112 81 14 minecraft:deepslate_bricks
setblock 144 81 14 minecraft:deepslate_bricks
setblock 112 81 15 minecraft:deepslate_bricks
setblock 144 81 15 minecraft:deepslate_bricks
setblock 116 81 15 minecraft:waxed_weathered_cut_copper
setblock 122 81 15 minecraft:waxed_weathered_cut_copper
setblock 128 81 15 minecraft:waxed_weathered_cut_copper
setblock 134 81 15 minecraft:waxed_weathered_cut_copper
setblock 140 81 15 minecraft:waxed_weathered_cut_copper
fill 112 81 16 144 81 16 minecraft:deepslate_bricks
fill 112 82 -16 144 82 -16 minecraft:deepslate_bricks
setblock 112 82 -15 minecraft:deepslate_bricks
setblock 144 82 -15 minecraft:deepslate_bricks
setblock 116 82 -15 minecraft:waxed_weathered_cut_copper
setblock 122 82 -15 minecraft:waxed_weathered_cut_copper
setblock 128 82 -15 minecraft:waxed_weathered_cut_copper
setblock 134 82 -15 minecraft:waxed_weathered_cut_copper
setblock 140 82 -15 minecraft:waxed_weathered_cut_copper
setblock 112 82 -14 minecraft:deepslate_bricks
setblock 144 82 -14 minecraft:deepslate_bricks
setblock 112 82 -13 minecraft:deepslate_bricks
setblock 144 82 -13 minecraft:deepslate_bricks
setblock 112 82 -12 minecraft:deepslate_bricks
setblock 144 82 -12 minecraft:deepslate_bricks
setblock 113 82 -12 minecraft:waxed_weathered_cut_copper
fill 118 82 -12 138 82 -12 minecraft:waxed_weathered_cut_copper
setblock 143 82 -12 minecraft:waxed_weathered_cut_copper
setblock 112 82 -11 minecraft:deepslate_bricks
setblock 144 82 -11 minecraft:deepslate_bricks
setblock 112 82 -10 minecraft:deepslate_bricks
setblock 144 82 -10 minecraft:deepslate_bricks
setblock 112 82 -9 minecraft:deepslate_bricks
setblock 144 82 -9 minecraft:deepslate_bricks
setblock 112 82 -8 minecraft:deepslate_bricks
setblock 144 82 -8 minecraft:deepslate_bricks
setblock 112 82 -7 minecraft:deepslate_bricks
setblock 144 82 -7 minecraft:deepslate_bricks
setblock 112 82 -6 minecraft:deepslate_bricks
setblock 144 82 -6 minecraft:deepslate_bricks
setblock 113 82 -6 minecraft:waxed_weathered_cut_copper
setblock 143 82 -6 minecraft:waxed_weathered_cut_copper
setblock 112 82 -5 minecraft:deepslate_bricks
setblock 144 82 -5 minecraft:deepslate_bricks
setblock 112 82 -4 minecraft:deepslate_bricks
setblock 144 82 -4 minecraft:deepslate_bricks
setblock 112 82 -3 minecraft:deepslate_bricks
setblock 144 82 -3 minecraft:deepslate_bricks
setblock 112 82 -2 minecraft:deepslate_bricks
setblock 144 82 -2 minecraft:deepslate_bricks
setblock 112 82 -1 minecraft:deepslate_bricks
setblock 144 82 -1 minecraft:deepslate_bricks
setblock 112 82 0 minecraft:deepslate_bricks
setblock 144 82 0 minecraft:deepslate_bricks
setblock 113 82 0 minecraft:waxed_weathered_cut_copper
fill 118 82 0 138 82 0 minecraft:waxed_weathered_cut_copper
setblock 143 82 0 minecraft:waxed_weathered_cut_copper
setblock 112 82 1 minecraft:deepslate_bricks
setblock 144 82 1 minecraft:deepslate_bricks
setblock 112 82 2 minecraft:deepslate_bricks
setblock 144 82 2 minecraft:deepslate_bricks
setblock 112 82 3 minecraft:deepslate_bricks
setblock 144 82 3 minecraft:deepslate_bricks
setblock 112 82 4 minecraft:deepslate_bricks
setblock 144 82 4 minecraft:deepslate_bricks
setblock 112 82 5 minecraft:deepslate_bricks
setblock 144 82 5 minecraft:deepslate_bricks
setblock 112 82 6 minecraft:deepslate_bricks
setblock 144 82 6 minecraft:deepslate_bricks
setblock 113 82 6 minecraft:waxed_weathered_cut_copper
setblock 143 82 6 minecraft:waxed_weathered_cut_copper
setblock 112 82 7 minecraft:deepslate_bricks
setblock 144 82 7 minecraft:deepslate_bricks
setblock 112 82 8 minecraft:deepslate_bricks
setblock 144 82 8 minecraft:deepslate_bricks
setblock 112 82 9 minecraft:deepslate_bricks
setblock 144 82 9 minecraft:deepslate_bricks
setblock 112 82 10 minecraft:deepslate_bricks
setblock 144 82 10 minecraft:deepslate_bricks
setblock 112 82 11 minecraft:deepslate_bricks
setblock 144 82 11 minecraft:deepslate_bricks
setblock 112 82 12 minecraft:deepslate_bricks
setblock 144 82 12 minecraft:deepslate_bricks
setblock 113 82 12 minecraft:waxed_weathered_cut_copper
fill 118 82 12 138 82 12 minecraft:waxed_weathered_cut_copper
setblock 143 82 12 minecraft:waxed_weathered_cut_copper
setblock 112 82 13 minecraft:deepslate_bricks
setblock 144 82 13 minecraft:deepslate_bricks
setblock 112 82 14 minecraft:deepslate_bricks
setblock 144 82 14 minecraft:deepslate_bricks
setblock 112 82 15 minecraft:deepslate_bricks
setblock 144 82 15 minecraft:deepslate_bricks
setblock 116 82 15 minecraft:waxed_weathered_cut_copper
setblock 122 82 15 minecraft:waxed_weathered_cut_copper
setblock 128 82 15 minecraft:waxed_weathered_cut_copper
setblock 134 82 15 minecraft:waxed_weathered_cut_copper
setblock 140 82 15 minecraft:waxed_weathered_cut_copper
fill 112 82 16 144 82 16 minecraft:deepslate_bricks
fill 112 83 -16 144 83 -16 minecraft:deepslate_bricks
setblock 112 83 -15 minecraft:deepslate_bricks
setblock 144 83 -15 minecraft:deepslate_bricks
fill 113 83 -15 143 83 -15 minecraft:waxed_weathered_cut_copper
setblock 112 83 -14 minecraft:deepslate_bricks
setblock 144 83 -14 minecraft:deepslate_bricks
setblock 113 83 -14 minecraft:waxed_weathered_cut_copper
setblock 143 83 -14 minecraft:waxed_weathered_cut_copper
setblock 112 83 -13 minecraft:deepslate_bricks
setblock 144 83 -13 minecraft:deepslate_bricks
setblock 113 83 -13 minecraft:waxed_weathered_cut_copper
setblock 143 83 -13 minecraft:waxed_weathered_cut_copper
setblock 112 83 -12 minecraft:deepslate_bricks
setblock 144 83 -12 minecraft:deepslate_bricks
setblock 113 83 -12 minecraft:waxed_weathered_cut_copper
setblock 143 83 -12 minecraft:waxed_weathered_cut_copper
setblock 112 83 -11 minecraft:deepslate_bricks
setblock 144 83 -11 minecraft:deepslate_bricks
setblock 113 83 -11 minecraft:waxed_weathered_cut_copper
setblock 143 83 -11 minecraft:waxed_weathered_cut_copper
setblock 112 83 -10 minecraft:deepslate_bricks
setblock 144 83 -10 minecraft:deepslate_bricks
setblock 113 83 -10 minecraft:waxed_weathered_cut_copper
setblock 143 83 -10 minecraft:waxed_weathered_cut_copper
setblock 112 83 -9 minecraft:deepslate_bricks
setblock 144 83 -9 minecraft:deepslate_bricks
setblock 118 83 -9 minecraft:light_blue_stained_glass
setblock 135 83 -9 minecraft:light_blue_stained_glass
setblock 113 83 -9 minecraft:waxed_weathered_cut_copper
setblock 143 83 -9 minecraft:waxed_weathered_cut_copper
setblock 112 83 -8 minecraft:deepslate_bricks
setblock 144 83 -8 minecraft:deepslate_bricks
setblock 125 83 -8 minecraft:light_blue_stained_glass
setblock 113 83 -8 minecraft:waxed_weathered_cut_copper
setblock 143 83 -8 minecraft:waxed_weathered_cut_copper
setblock 112 83 -7 minecraft:deepslate_bricks
setblock 144 83 -7 minecraft:deepslate_bricks
setblock 113 83 -7 minecraft:waxed_weathered_cut_copper
setblock 143 83 -7 minecraft:waxed_weathered_cut_copper
setblock 112 83 -6 minecraft:deepslate_bricks
setblock 144 83 -6 minecraft:deepslate_bricks
setblock 113 83 -6 minecraft:waxed_weathered_cut_copper
setblock 143 83 -6 minecraft:waxed_weathered_cut_copper
setblock 112 83 -5 minecraft:deepslate_bricks
setblock 144 83 -5 minecraft:deepslate_bricks
setblock 113 83 -5 minecraft:waxed_weathered_cut_copper
setblock 143 83 -5 minecraft:waxed_weathered_cut_copper
setblock 112 83 -4 minecraft:deepslate_bricks
setblock 144 83 -4 minecraft:deepslate_bricks
setblock 138 83 -4 minecraft:light_blue_stained_glass
setblock 113 83 -4 minecraft:waxed_weathered_cut_copper
setblock 143 83 -4 minecraft:waxed_weathered_cut_copper
setblock 112 83 -3 minecraft:deepslate_bricks
setblock 144 83 -3 minecraft:deepslate_bricks
setblock 113 83 -3 minecraft:waxed_weathered_cut_copper
setblock 143 83 -3 minecraft:waxed_weathered_cut_copper
setblock 112 83 -2 minecraft:deepslate_bricks
setblock 144 83 -2 minecraft:deepslate_bricks
setblock 113 83 -2 minecraft:waxed_weathered_cut_copper
setblock 143 83 -2 minecraft:waxed_weathered_cut_copper
setblock 112 83 -1 minecraft:deepslate_bricks
setblock 144 83 -1 minecraft:deepslate_bricks
setblock 113 83 -1 minecraft:waxed_weathered_cut_copper
setblock 143 83 -1 minecraft:waxed_weathered_cut_copper
setblock 112 83 0 minecraft:deepslate_bricks
setblock 144 83 0 minecraft:deepslate_bricks
setblock 113 83 0 minecraft:waxed_weathered_cut_copper
setblock 143 83 0 minecraft:waxed_weathered_cut_copper
setblock 112 83 1 minecraft:deepslate_bricks
setblock 144 83 1 minecraft:deepslate_bricks
setblock 113 83 1 minecraft:waxed_weathered_cut_copper
setblock 143 83 1 minecraft:waxed_weathered_cut_copper
setblock 112 83 2 minecraft:deepslate_bricks
setblock 144 83 2 minecraft:deepslate_bricks
setblock 113 83 2 minecraft:waxed_weathered_cut_copper
setblock 143 83 2 minecraft:waxed_weathered_cut_copper
setblock 112 83 3 minecraft:deepslate_bricks
setblock 144 83 3 minecraft:deepslate_bricks
setblock 113 83 3 minecraft:waxed_weathered_cut_copper
setblock 143 83 3 minecraft:waxed_weathered_cut_copper
setblock 112 83 4 minecraft:deepslate_bricks
setblock 144 83 4 minecraft:deepslate_bricks
setblock 131 83 4 minecraft:light_blue_stained_glass
setblock 113 83 4 minecraft:waxed_weathered_cut_copper
setblock 143 83 4 minecraft:waxed_weathered_cut_copper
setblock 112 83 5 minecraft:deepslate_bricks
setblock 144 83 5 minecraft:deepslate_bricks
setblock 117 83 5 minecraft:light_blue_stained_glass
setblock 113 83 5 minecraft:waxed_weathered_cut_copper
setblock 143 83 5 minecraft:waxed_weathered_cut_copper
setblock 112 83 6 minecraft:deepslate_bricks
setblock 144 83 6 minecraft:deepslate_bricks
setblock 113 83 6 minecraft:waxed_weathered_cut_copper
setblock 143 83 6 minecraft:waxed_weathered_cut_copper
setblock 112 83 7 minecraft:deepslate_bricks
setblock 144 83 7 minecraft:deepslate_bricks
setblock 123 83 7 minecraft:light_blue_stained_glass
setblock 113 83 7 minecraft:waxed_weathered_cut_copper
setblock 143 83 7 minecraft:waxed_weathered_cut_copper
setblock 112 83 8 minecraft:deepslate_bricks
setblock 144 83 8 minecraft:deepslate_bricks
setblock 113 83 8 minecraft:waxed_weathered_cut_copper
setblock 143 83 8 minecraft:waxed_weathered_cut_copper
setblock 112 83 9 minecraft:deepslate_bricks
setblock 144 83 9 minecraft:deepslate_bricks
setblock 113 83 9 minecraft:waxed_weathered_cut_copper
setblock 143 83 9 minecraft:waxed_weathered_cut_copper
setblock 112 83 10 minecraft:deepslate_bricks
setblock 144 83 10 minecraft:deepslate_bricks
setblock 137 83 10 minecraft:light_blue_stained_glass
setblock 113 83 10 minecraft:waxed_weathered_cut_copper
setblock 143 83 10 minecraft:waxed_weathered_cut_copper
setblock 112 83 11 minecraft:deepslate_bricks
setblock 144 83 11 minecraft:deepslate_bricks
setblock 113 83 11 minecraft:waxed_weathered_cut_copper
setblock 143 83 11 minecraft:waxed_weathered_cut_copper
setblock 112 83 12 minecraft:deepslate_bricks
setblock 144 83 12 minecraft:deepslate_bricks
setblock 113 83 12 minecraft:waxed_weathered_cut_copper
setblock 143 83 12 minecraft:waxed_weathered_cut_copper
setblock 112 83 13 minecraft:deepslate_bricks
setblock 144 83 13 minecraft:deepslate_bricks
setblock 113 83 13 minecraft:waxed_weathered_cut_copper
setblock 143 83 13 minecraft:waxed_weathered_cut_copper
setblock 112 83 14 minecraft:deepslate_bricks
setblock 144 83 14 minecraft:deepslate_bricks
setblock 113 83 14 minecraft:waxed_weathered_cut_copper
setblock 143 83 14 minecraft:waxed_weathered_cut_copper
setblock 112 83 15 minecraft:deepslate_bricks
setblock 144 83 15 minecraft:deepslate_bricks
fill 113 83 15 143 83 15 minecraft:waxed_weathered_cut_copper
fill 112 83 16 144 83 16 minecraft:deepslate_bricks
fill 112 84 -16 144 84 -16 minecraft:black_concrete
fill 112 84 -15 144 84 -15 minecraft:black_concrete
fill 112 84 -14 144 84 -14 minecraft:black_concrete
fill 112 84 -13 144 84 -13 minecraft:black_concrete
fill 112 84 -12 144 84 -12 minecraft:black_concrete
fill 112 84 -11 144 84 -11 minecraft:black_concrete
fill 112 84 -10 144 84 -10 minecraft:black_concrete
fill 112 84 -9 117 84 -9 minecraft:black_concrete
fill 119 84 -9 134 84 -9 minecraft:black_concrete
fill 136 84 -9 144 84 -9 minecraft:black_concrete
setblock 118 84 -9 minecraft:sea_lantern
setblock 135 84 -9 minecraft:sea_lantern
fill 112 84 -8 124 84 -8 minecraft:black_concrete
fill 126 84 -8 144 84 -8 minecraft:black_concrete
setblock 125 84 -8 minecraft:sea_lantern
fill 112 84 -7 144 84 -7 minecraft:black_concrete
fill 112 84 -6 144 84 -6 minecraft:black_concrete
fill 112 84 -5 144 84 -5 minecraft:black_concrete
fill 112 84 -4 137 84 -4 minecraft:black_concrete
fill 139 84 -4 144 84 -4 minecraft:black_concrete
setblock 138 84 -4 minecraft:sea_lantern
fill 112 84 -3 144 84 -3 minecraft:black_concrete
fill 112 84 -2 144 84 -2 minecraft:black_concrete
fill 112 84 -1 144 84 -1 minecraft:black_concrete
fill 112 84 0 144 84 0 minecraft:black_concrete
fill 112 84 1 144 84 1 minecraft:black_concrete
fill 112 84 2 144 84 2 minecraft:black_concrete
fill 112 84 3 144 84 3 minecraft:black_concrete
fill 112 84 4 130 84 4 minecraft:black_concrete
fill 132 84 4 144 84 4 minecraft:black_concrete
setblock 131 84 4 minecraft:sea_lantern
fill 112 84 5 116 84 5 minecraft:black_concrete
fill 118 84 5 144 84 5 minecraft:black_concrete
setblock 117 84 5 minecraft:sea_lantern
fill 112 84 6 144 84 6 minecraft:black_concrete
fill 112 84 7 122 84 7 minecraft:black_concrete
fill 124 84 7 144 84 7 minecraft:black_concrete
setblock 123 84 7 minecraft:sea_lantern
fill 112 84 8 144 84 8 minecraft:black_concrete
fill 112 84 9 144 84 9 minecraft:black_concrete
fill 112 84 10 136 84 10 minecraft:black_concrete
fill 138 84 10 144 84 10 minecraft:black_concrete
setblock 137 84 10 minecraft:sea_lantern
fill 112 84 11 144 84 11 minecraft:black_concrete
fill 112 84 12 144 84 12 minecraft:black_concrete
fill 112 84 13 144 84 13 minecraft:black_concrete
fill 112 84 14 144 84 14 minecraft:black_concrete
fill 112 84 15 144 84 15 minecraft:black_concrete
fill 112 84 16 144 84 16 minecraft:black_concrete
schedule function signal:world/build_3 1t replace
