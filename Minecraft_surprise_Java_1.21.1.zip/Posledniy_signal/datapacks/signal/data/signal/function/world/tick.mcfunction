execute if data storage signal:world {ready:1b} run function signal:tick
