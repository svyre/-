fill 48 55 -16 80 84 16 minecraft:air
fill 48 61 -16 80 61 -16 minecraft:bedrock
fill 48 61 -15 80 61 -15 minecraft:bedrock
fill 48 61 -14 80 61 -14 minecraft:bedrock
fill 48 61 -13 80 61 -13 minecraft:bedrock
fill 48 61 -12 80 61 -12 minecraft:bedrock
fill 48 61 -11 80 61 -11 minecraft:bedrock
fill 48 61 -10 80 61 -10 minecraft:bedrock
fill 48 61 -9 80 61 -9 minecraft:bedrock
fill 48 61 -8 80 61 -8 minecraft:bedrock
fill 48 61 -7 80 61 -7 minecraft:bedrock
fill 48 61 -6 80 61 -6 minecraft:bedrock
fill 48 61 -5 80 61 -5 minecraft:bedrock
fill 48 61 -4 80 61 -4 minecraft:bedrock
fill 48 61 -3 80 61 -3 minecraft:bedrock
fill 48 61 -2 80 61 -2 minecraft:bedrock
fill 48 61 -1 80 61 -1 minecraft:bedrock
fill 48 61 0 80 61 0 minecraft:bedrock
fill 48 61 1 80 61 1 minecraft:bedrock
fill 48 61 2 80 61 2 minecraft:bedrock
fill 48 61 3 80 61 3 minecraft:bedrock
fill 48 61 4 80 61 4 minecraft:bedrock
fill 48 61 5 80 61 5 minecraft:bedrock
fill 48 61 6 80 61 6 minecraft:bedrock
fill 48 61 7 80 61 7 minecraft:bedrock
fill 48 61 8 80 61 8 minecraft:bedrock
fill 48 61 9 80 61 9 minecraft:bedrock
fill 48 61 10 80 61 10 minecraft:bedrock
fill 48 61 11 80 61 11 minecraft:bedrock
fill 48 61 12 80 61 12 minecraft:bedrock
fill 48 61 13 80 61 13 minecraft:bedrock
fill 48 61 14 80 61 14 minecraft:bedrock
fill 48 61 15 80 61 15 minecraft:bedrock
fill 48 61 16 80 61 16 minecraft:bedrock
fill 48 62 -16 80 62 -16 minecraft:bedrock
fill 48 62 -15 80 62 -15 minecraft:bedrock
fill 48 62 -14 80 62 -14 minecraft:bedrock
fill 48 62 -13 80 62 -13 minecraft:bedrock
fill 48 62 -12 80 62 -12 minecraft:bedrock
fill 48 62 -11 80 62 -11 minecraft:bedrock
fill 48 62 -10 80 62 -10 minecraft:bedrock
fill 48 62 -9 80 62 -9 minecraft:bedrock
fill 48 62 -8 80 62 -8 minecraft:bedrock
fill 48 62 -7 80 62 -7 minecraft:bedrock
fill 48 62 -6 80 62 -6 minecraft:bedrock
fill 48 62 -5 80 62 -5 minecraft:bedrock
fill 48 62 -4 80 62 -4 minecraft:bedrock
fill 48 62 -3 80 62 -3 minecraft:bedrock
fill 48 62 -2 80 62 -2 minecraft:bedrock
fill 48 62 -1 80 62 -1 minecraft:bedrock
fill 48 62 0 80 62 0 minecraft:bedrock
fill 48 62 1 80 62 1 minecraft:bedrock
fill 48 62 2 80 62 2 minecraft:bedrock
fill 48 62 3 80 62 3 minecraft:bedrock
fill 48 62 4 80 62 4 minecraft:bedrock
fill 48 62 5 80 62 5 minecraft:bedrock
fill 48 62 6 80 62 6 minecraft:bedrock
fill 48 62 7 80 62 7 minecraft:bedrock
fill 48 62 8 80 62 8 minecraft:bedrock
fill 48 62 9 80 62 9 minecraft:bedrock
fill 48 62 10 80 62 10 minecraft:bedrock
fill 48 62 11 80 62 11 minecraft:bedrock
fill 48 62 12 80 62 12 minecraft:bedrock
fill 48 62 13 80 62 13 minecraft:bedrock
fill 48 62 14 80 62 14 minecraft:bedrock
fill 48 62 15 80 62 15 minecraft:bedrock
fill 48 62 16 80 62 16 minecraft:bedrock
fill 48 63 -16 80 63 -16 minecraft:deepslate_tiles
fill 49 63 -15 79 63 -15 minecraft:amethyst_block
setblock 48 63 -15 minecraft:deepslate_tiles
setblock 80 63 -15 minecraft:deepslate_tiles
setblock 49 63 -14 minecraft:amethyst_block
setblock 79 63 -14 minecraft:amethyst_block
setblock 48 63 -14 minecraft:deepslate_tiles
setblock 80 63 -14 minecraft:deepslate_tiles
fill 50 63 -14 78 63 -14 minecraft:smooth_basalt
setblock 49 63 -13 minecraft:amethyst_block
setblock 79 63 -13 minecraft:amethyst_block
setblock 48 63 -13 minecraft:deepslate_tiles
setblock 51 63 -13 minecraft:deepslate_tiles
setblock 53 63 -13 minecraft:deepslate_tiles
setblock 55 63 -13 minecraft:deepslate_tiles
setblock 57 63 -13 minecraft:deepslate_tiles
setblock 59 63 -13 minecraft:deepslate_tiles
setblock 61 63 -13 minecraft:deepslate_tiles
setblock 63 63 -13 minecraft:deepslate_tiles
setblock 65 63 -13 minecraft:deepslate_tiles
setblock 67 63 -13 minecraft:deepslate_tiles
setblock 69 63 -13 minecraft:deepslate_tiles
setblock 71 63 -13 minecraft:deepslate_tiles
setblock 73 63 -13 minecraft:deepslate_tiles
setblock 75 63 -13 minecraft:deepslate_tiles
setblock 77 63 -13 minecraft:deepslate_tiles
setblock 80 63 -13 minecraft:deepslate_tiles
setblock 52 63 -13 minecraft:polished_deepslate
setblock 54 63 -13 minecraft:polished_deepslate
setblock 56 63 -13 minecraft:polished_deepslate
setblock 58 63 -13 minecraft:polished_deepslate
setblock 60 63 -13 minecraft:polished_deepslate
setblock 62 63 -13 minecraft:polished_deepslate
setblock 64 63 -13 minecraft:polished_deepslate
setblock 66 63 -13 minecraft:polished_deepslate
setblock 68 63 -13 minecraft:polished_deepslate
setblock 70 63 -13 minecraft:polished_deepslate
setblock 72 63 -13 minecraft:polished_deepslate
setblock 74 63 -13 minecraft:polished_deepslate
setblock 76 63 -13 minecraft:polished_deepslate
setblock 50 63 -13 minecraft:smooth_basalt
setblock 78 63 -13 minecraft:smooth_basalt
setblock 49 63 -12 minecraft:amethyst_block
setblock 53 63 -12 minecraft:amethyst_block
setblock 75 63 -12 minecraft:amethyst_block
setblock 79 63 -12 minecraft:amethyst_block
setblock 48 63 -12 minecraft:deepslate_tiles
setblock 52 63 -12 minecraft:deepslate_tiles
setblock 54 63 -12 minecraft:deepslate_tiles
setblock 56 63 -12 minecraft:deepslate_tiles
setblock 58 63 -12 minecraft:deepslate_tiles
setblock 60 63 -12 minecraft:deepslate_tiles
setblock 62 63 -12 minecraft:deepslate_tiles
setblock 64 63 -12 minecraft:deepslate_tiles
setblock 66 63 -12 minecraft:deepslate_tiles
setblock 68 63 -12 minecraft:deepslate_tiles
setblock 70 63 -12 minecraft:deepslate_tiles
setblock 72 63 -12 minecraft:deepslate_tiles
setblock 74 63 -12 minecraft:deepslate_tiles
setblock 76 63 -12 minecraft:deepslate_tiles
setblock 80 63 -12 minecraft:deepslate_tiles
setblock 51 63 -12 minecraft:polished_deepslate
setblock 55 63 -12 minecraft:polished_deepslate
setblock 57 63 -12 minecraft:polished_deepslate
setblock 59 63 -12 minecraft:polished_deepslate
setblock 61 63 -12 minecraft:polished_deepslate
setblock 63 63 -12 minecraft:polished_deepslate
setblock 65 63 -12 minecraft:polished_deepslate
setblock 67 63 -12 minecraft:polished_deepslate
setblock 69 63 -12 minecraft:polished_deepslate
setblock 71 63 -12 minecraft:polished_deepslate
setblock 73 63 -12 minecraft:polished_deepslate
setblock 77 63 -12 minecraft:polished_deepslate
setblock 50 63 -12 minecraft:smooth_basalt
setblock 78 63 -12 minecraft:smooth_basalt
setblock 49 63 -11 minecraft:amethyst_block
setblock 52 63 -11 minecraft:amethyst_block
setblock 54 63 -11 minecraft:amethyst_block
setblock 74 63 -11 minecraft:amethyst_block
setblock 76 63 -11 minecraft:amethyst_block
setblock 79 63 -11 minecraft:amethyst_block
setblock 48 63 -11 minecraft:deepslate_tiles
setblock 51 63 -11 minecraft:deepslate_tiles
setblock 55 63 -11 minecraft:deepslate_tiles
setblock 57 63 -11 minecraft:deepslate_tiles
setblock 59 63 -11 minecraft:deepslate_tiles
setblock 61 63 -11 minecraft:deepslate_tiles
setblock 63 63 -11 minecraft:deepslate_tiles
setblock 65 63 -11 minecraft:deepslate_tiles
setblock 67 63 -11 minecraft:deepslate_tiles
setblock 69 63 -11 minecraft:deepslate_tiles
setblock 71 63 -11 minecraft:deepslate_tiles
setblock 73 63 -11 minecraft:deepslate_tiles
setblock 77 63 -11 minecraft:deepslate_tiles
setblock 80 63 -11 minecraft:deepslate_tiles
setblock 56 63 -11 minecraft:polished_deepslate
setblock 58 63 -11 minecraft:polished_deepslate
setblock 60 63 -11 minecraft:polished_deepslate
setblock 62 63 -11 minecraft:polished_deepslate
setblock 64 63 -11 minecraft:polished_deepslate
setblock 66 63 -11 minecraft:polished_deepslate
setblock 68 63 -11 minecraft:polished_deepslate
setblock 70 63 -11 minecraft:polished_deepslate
setblock 72 63 -11 minecraft:polished_deepslate
setblock 53 63 -11 minecraft:sea_lantern
setblock 75 63 -11 minecraft:sea_lantern
setblock 50 63 -11 minecraft:smooth_basalt
setblock 78 63 -11 minecraft:smooth_basalt
setblock 49 63 -10 minecraft:amethyst_block
setblock 53 63 -10 minecraft:amethyst_block
setblock 75 63 -10 minecraft:amethyst_block
setblock 79 63 -10 minecraft:amethyst_block
setblock 54 63 -10 minecraft:chiseled_deepslate
setblock 59 63 -10 minecraft:chiseled_deepslate
setblock 64 63 -10 minecraft:chiseled_deepslate
setblock 69 63 -10 minecraft:chiseled_deepslate
setblock 74 63 -10 minecraft:chiseled_deepslate
setblock 48 63 -10 minecraft:deepslate_tiles
setblock 52 63 -10 minecraft:deepslate_tiles
setblock 56 63 -10 minecraft:deepslate_tiles
setblock 58 63 -10 minecraft:deepslate_tiles
setblock 60 63 -10 minecraft:deepslate_tiles
setblock 62 63 -10 minecraft:deepslate_tiles
setblock 66 63 -10 minecraft:deepslate_tiles
setblock 68 63 -10 minecraft:deepslate_tiles
setblock 70 63 -10 minecraft:deepslate_tiles
setblock 72 63 -10 minecraft:deepslate_tiles
setblock 76 63 -10 minecraft:deepslate_tiles
setblock 80 63 -10 minecraft:deepslate_tiles
setblock 51 63 -10 minecraft:polished_deepslate
setblock 55 63 -10 minecraft:polished_deepslate
setblock 57 63 -10 minecraft:polished_deepslate
setblock 61 63 -10 minecraft:polished_deepslate
setblock 63 63 -10 minecraft:polished_deepslate
setblock 65 63 -10 minecraft:polished_deepslate
setblock 67 63 -10 minecraft:polished_deepslate
setblock 71 63 -10 minecraft:polished_deepslate
setblock 73 63 -10 minecraft:polished_deepslate
setblock 77 63 -10 minecraft:polished_deepslate
setblock 50 63 -10 minecraft:smooth_basalt
setblock 78 63 -10 minecraft:smooth_basalt
setblock 49 63 -9 minecraft:amethyst_block
setblock 79 63 -9 minecraft:amethyst_block
setblock 48 63 -9 minecraft:deepslate_tiles
setblock 51 63 -9 minecraft:deepslate_tiles
setblock 53 63 -9 minecraft:deepslate_tiles
setblock 55 63 -9 minecraft:deepslate_tiles
setblock 57 63 -9 minecraft:deepslate_tiles
setblock 59 63 -9 minecraft:deepslate_tiles
setblock 61 63 -9 minecraft:deepslate_tiles
setblock 63 63 -9 minecraft:deepslate_tiles
setblock 65 63 -9 minecraft:deepslate_tiles
setblock 67 63 -9 minecraft:deepslate_tiles
setblock 69 63 -9 minecraft:deepslate_tiles
setblock 71 63 -9 minecraft:deepslate_tiles
setblock 73 63 -9 minecraft:deepslate_tiles
setblock 75 63 -9 minecraft:deepslate_tiles
setblock 77 63 -9 minecraft:deepslate_tiles
setblock 80 63 -9 minecraft:deepslate_tiles
setblock 52 63 -9 minecraft:polished_deepslate
setblock 54 63 -9 minecraft:polished_deepslate
setblock 56 63 -9 minecraft:polished_deepslate
setblock 58 63 -9 minecraft:polished_deepslate
setblock 60 63 -9 minecraft:polished_deepslate
setblock 62 63 -9 minecraft:polished_deepslate
setblock 64 63 -9 minecraft:polished_deepslate
setblock 66 63 -9 minecraft:polished_deepslate
setblock 68 63 -9 minecraft:polished_deepslate
setblock 70 63 -9 minecraft:polished_deepslate
setblock 72 63 -9 minecraft:polished_deepslate
setblock 74 63 -9 minecraft:polished_deepslate
setblock 76 63 -9 minecraft:polished_deepslate
setblock 50 63 -9 minecraft:smooth_basalt
setblock 78 63 -9 minecraft:smooth_basalt
setblock 49 63 -8 minecraft:amethyst_block
setblock 79 63 -8 minecraft:amethyst_block
setblock 48 63 -8 minecraft:deepslate_tiles
setblock 52 63 -8 minecraft:deepslate_tiles
setblock 54 63 -8 minecraft:deepslate_tiles
setblock 56 63 -8 minecraft:deepslate_tiles
setblock 58 63 -8 minecraft:deepslate_tiles
setblock 60 63 -8 minecraft:deepslate_tiles
setblock 62 63 -8 minecraft:deepslate_tiles
setblock 64 63 -8 minecraft:deepslate_tiles
setblock 66 63 -8 minecraft:deepslate_tiles
setblock 68 63 -8 minecraft:deepslate_tiles
setblock 70 63 -8 minecraft:deepslate_tiles
setblock 72 63 -8 minecraft:deepslate_tiles
setblock 74 63 -8 minecraft:deepslate_tiles
setblock 76 63 -8 minecraft:deepslate_tiles
setblock 80 63 -8 minecraft:deepslate_tiles
setblock 51 63 -8 minecraft:polished_deepslate
setblock 53 63 -8 minecraft:polished_deepslate
setblock 55 63 -8 minecraft:polished_deepslate
setblock 57 63 -8 minecraft:polished_deepslate
setblock 59 63 -8 minecraft:polished_deepslate
setblock 61 63 -8 minecraft:polished_deepslate
setblock 63 63 -8 minecraft:polished_deepslate
setblock 65 63 -8 minecraft:polished_deepslate
setblock 67 63 -8 minecraft:polished_deepslate
setblock 69 63 -8 minecraft:polished_deepslate
setblock 71 63 -8 minecraft:polished_deepslate
setblock 73 63 -8 minecraft:polished_deepslate
setblock 75 63 -8 minecraft:polished_deepslate
setblock 77 63 -8 minecraft:polished_deepslate
setblock 50 63 -8 minecraft:smooth_basalt
setblock 78 63 -8 minecraft:smooth_basalt
setblock 49 63 -7 minecraft:amethyst_block
setblock 79 63 -7 minecraft:amethyst_block
setblock 48 63 -7 minecraft:deepslate_tiles
setblock 51 63 -7 minecraft:deepslate_tiles
setblock 53 63 -7 minecraft:deepslate_tiles
setblock 55 63 -7 minecraft:deepslate_tiles
setblock 57 63 -7 minecraft:deepslate_tiles
setblock 59 63 -7 minecraft:deepslate_tiles
setblock 61 63 -7 minecraft:deepslate_tiles
setblock 63 63 -7 minecraft:deepslate_tiles
setblock 65 63 -7 minecraft:deepslate_tiles
setblock 67 63 -7 minecraft:deepslate_tiles
setblock 69 63 -7 minecraft:deepslate_tiles
setblock 71 63 -7 minecraft:deepslate_tiles
setblock 73 63 -7 minecraft:deepslate_tiles
setblock 75 63 -7 minecraft:deepslate_tiles
setblock 77 63 -7 minecraft:deepslate_tiles
setblock 80 63 -7 minecraft:deepslate_tiles
setblock 52 63 -7 minecraft:polished_deepslate
setblock 54 63 -7 minecraft:polished_deepslate
setblock 56 63 -7 minecraft:polished_deepslate
setblock 58 63 -7 minecraft:polished_deepslate
setblock 60 63 -7 minecraft:polished_deepslate
setblock 62 63 -7 minecraft:polished_deepslate
setblock 64 63 -7 minecraft:polished_deepslate
setblock 66 63 -7 minecraft:polished_deepslate
setblock 68 63 -7 minecraft:polished_deepslate
setblock 70 63 -7 minecraft:polished_deepslate
setblock 72 63 -7 minecraft:polished_deepslate
setblock 74 63 -7 minecraft:polished_deepslate
setblock 76 63 -7 minecraft:polished_deepslate
setblock 50 63 -7 minecraft:smooth_basalt
setblock 78 63 -7 minecraft:smooth_basalt
setblock 49 63 -6 minecraft:amethyst_block
setblock 64 63 -6 minecraft:amethyst_block
setblock 79 63 -6 minecraft:amethyst_block
setblock 48 63 -6 minecraft:deepslate_tiles
setblock 52 63 -6 minecraft:deepslate_tiles
setblock 54 63 -6 minecraft:deepslate_tiles
setblock 56 63 -6 minecraft:deepslate_tiles
setblock 58 63 -6 minecraft:deepslate_tiles
setblock 60 63 -6 minecraft:deepslate_tiles
setblock 62 63 -6 minecraft:deepslate_tiles
setblock 66 63 -6 minecraft:deepslate_tiles
setblock 68 63 -6 minecraft:deepslate_tiles
setblock 70 63 -6 minecraft:deepslate_tiles
setblock 72 63 -6 minecraft:deepslate_tiles
setblock 74 63 -6 minecraft:deepslate_tiles
setblock 76 63 -6 minecraft:deepslate_tiles
setblock 80 63 -6 minecraft:deepslate_tiles
setblock 51 63 -6 minecraft:polished_deepslate
setblock 53 63 -6 minecraft:polished_deepslate
setblock 55 63 -6 minecraft:polished_deepslate
setblock 57 63 -6 minecraft:polished_deepslate
setblock 59 63 -6 minecraft:polished_deepslate
setblock 61 63 -6 minecraft:polished_deepslate
setblock 63 63 -6 minecraft:polished_deepslate
setblock 65 63 -6 minecraft:polished_deepslate
setblock 67 63 -6 minecraft:polished_deepslate
setblock 69 63 -6 minecraft:polished_deepslate
setblock 71 63 -6 minecraft:polished_deepslate
setblock 73 63 -6 minecraft:polished_deepslate
setblock 75 63 -6 minecraft:polished_deepslate
setblock 77 63 -6 minecraft:polished_deepslate
setblock 50 63 -6 minecraft:smooth_basalt
setblock 78 63 -6 minecraft:smooth_basalt
setblock 49 63 -5 minecraft:amethyst_block
setblock 63 63 -5 minecraft:amethyst_block
setblock 65 63 -5 minecraft:amethyst_block
setblock 79 63 -5 minecraft:amethyst_block
setblock 54 63 -5 minecraft:chiseled_deepslate
setblock 59 63 -5 minecraft:chiseled_deepslate
setblock 69 63 -5 minecraft:chiseled_deepslate
setblock 74 63 -5 minecraft:chiseled_deepslate
setblock 48 63 -5 minecraft:deepslate_tiles
setblock 51 63 -5 minecraft:deepslate_tiles
setblock 53 63 -5 minecraft:deepslate_tiles
setblock 55 63 -5 minecraft:deepslate_tiles
setblock 57 63 -5 minecraft:deepslate_tiles
setblock 61 63 -5 minecraft:deepslate_tiles
setblock 67 63 -5 minecraft:deepslate_tiles
setblock 71 63 -5 minecraft:deepslate_tiles
setblock 73 63 -5 minecraft:deepslate_tiles
setblock 75 63 -5 minecraft:deepslate_tiles
setblock 77 63 -5 minecraft:deepslate_tiles
setblock 80 63 -5 minecraft:deepslate_tiles
setblock 52 63 -5 minecraft:polished_deepslate
setblock 56 63 -5 minecraft:polished_deepslate
setblock 58 63 -5 minecraft:polished_deepslate
setblock 60 63 -5 minecraft:polished_deepslate
setblock 62 63 -5 minecraft:polished_deepslate
setblock 66 63 -5 minecraft:polished_deepslate
setblock 68 63 -5 minecraft:polished_deepslate
setblock 70 63 -5 minecraft:polished_deepslate
setblock 72 63 -5 minecraft:polished_deepslate
setblock 76 63 -5 minecraft:polished_deepslate
setblock 64 63 -5 minecraft:sea_lantern
setblock 50 63 -5 minecraft:smooth_basalt
setblock 78 63 -5 minecraft:smooth_basalt
setblock 49 63 -4 minecraft:amethyst_block
setblock 64 63 -4 minecraft:amethyst_block
setblock 79 63 -4 minecraft:amethyst_block
setblock 48 63 -4 minecraft:deepslate_tiles
setblock 52 63 -4 minecraft:deepslate_tiles
setblock 54 63 -4 minecraft:deepslate_tiles
setblock 56 63 -4 minecraft:deepslate_tiles
setblock 58 63 -4 minecraft:deepslate_tiles
setblock 60 63 -4 minecraft:deepslate_tiles
setblock 62 63 -4 minecraft:deepslate_tiles
setblock 66 63 -4 minecraft:deepslate_tiles
setblock 68 63 -4 minecraft:deepslate_tiles
setblock 70 63 -4 minecraft:deepslate_tiles
setblock 72 63 -4 minecraft:deepslate_tiles
setblock 74 63 -4 minecraft:deepslate_tiles
setblock 76 63 -4 minecraft:deepslate_tiles
setblock 80 63 -4 minecraft:deepslate_tiles
setblock 51 63 -4 minecraft:polished_deepslate
setblock 53 63 -4 minecraft:polished_deepslate
setblock 55 63 -4 minecraft:polished_deepslate
setblock 57 63 -4 minecraft:polished_deepslate
setblock 59 63 -4 minecraft:polished_deepslate
setblock 61 63 -4 minecraft:polished_deepslate
setblock 63 63 -4 minecraft:polished_deepslate
setblock 65 63 -4 minecraft:polished_deepslate
setblock 67 63 -4 minecraft:polished_deepslate
setblock 69 63 -4 minecraft:polished_deepslate
setblock 71 63 -4 minecraft:polished_deepslate
setblock 73 63 -4 minecraft:polished_deepslate
setblock 75 63 -4 minecraft:polished_deepslate
setblock 77 63 -4 minecraft:polished_deepslate
setblock 50 63 -4 minecraft:smooth_basalt
setblock 78 63 -4 minecraft:smooth_basalt
setblock 49 63 -3 minecraft:amethyst_block
setblock 79 63 -3 minecraft:amethyst_block
setblock 48 63 -3 minecraft:deepslate_tiles
setblock 51 63 -3 minecraft:deepslate_tiles
setblock 53 63 -3 minecraft:deepslate_tiles
setblock 55 63 -3 minecraft:deepslate_tiles
setblock 57 63 -3 minecraft:deepslate_tiles
setblock 59 63 -3 minecraft:deepslate_tiles
setblock 61 63 -3 minecraft:deepslate_tiles
setblock 63 63 -3 minecraft:deepslate_tiles
setblock 65 63 -3 minecraft:deepslate_tiles
setblock 67 63 -3 minecraft:deepslate_tiles
setblock 69 63 -3 minecraft:deepslate_tiles
setblock 71 63 -3 minecraft:deepslate_tiles
setblock 73 63 -3 minecraft:deepslate_tiles
setblock 75 63 -3 minecraft:deepslate_tiles
setblock 77 63 -3 minecraft:deepslate_tiles
setblock 80 63 -3 minecraft:deepslate_tiles
setblock 52 63 -3 minecraft:polished_deepslate
setblock 54 63 -3 minecraft:polished_deepslate
setblock 56 63 -3 minecraft:polished_deepslate
setblock 58 63 -3 minecraft:polished_deepslate
setblock 60 63 -3 minecraft:polished_deepslate
setblock 62 63 -3 minecraft:polished_deepslate
setblock 64 63 -3 minecraft:polished_deepslate
setblock 66 63 -3 minecraft:polished_deepslate
setblock 68 63 -3 minecraft:polished_deepslate
setblock 70 63 -3 minecraft:polished_deepslate
setblock 72 63 -3 minecraft:polished_deepslate
setblock 74 63 -3 minecraft:polished_deepslate
setblock 76 63 -3 minecraft:polished_deepslate
setblock 50 63 -3 minecraft:smooth_basalt
setblock 78 63 -3 minecraft:smooth_basalt
setblock 49 63 -2 minecraft:amethyst_block
setblock 79 63 -2 minecraft:amethyst_block
fill 56 63 -2 57 63 -2 minecraft:cyan_concrete
setblock 48 63 -2 minecraft:deepslate_tiles
setblock 52 63 -2 minecraft:deepslate_tiles
setblock 54 63 -2 minecraft:deepslate_tiles
setblock 58 63 -2 minecraft:deepslate_tiles
setblock 60 63 -2 minecraft:deepslate_tiles
setblock 64 63 -2 minecraft:deepslate_tiles
setblock 66 63 -2 minecraft:deepslate_tiles
setblock 70 63 -2 minecraft:deepslate_tiles
setblock 74 63 -2 minecraft:deepslate_tiles
setblock 76 63 -2 minecraft:deepslate_tiles
setblock 80 63 -2 minecraft:deepslate_tiles
fill 72 63 -2 73 63 -2 minecraft:lime_concrete
fill 67 63 -2 68 63 -2 minecraft:orange_concrete
setblock 51 63 -2 minecraft:polished_deepslate
setblock 53 63 -2 minecraft:polished_deepslate
setblock 55 63 -2 minecraft:polished_deepslate
setblock 59 63 -2 minecraft:polished_deepslate
setblock 63 63 -2 minecraft:polished_deepslate
setblock 65 63 -2 minecraft:polished_deepslate
setblock 69 63 -2 minecraft:polished_deepslate
setblock 71 63 -2 minecraft:polished_deepslate
setblock 75 63 -2 minecraft:polished_deepslate
setblock 77 63 -2 minecraft:polished_deepslate
fill 61 63 -2 62 63 -2 minecraft:purple_concrete
setblock 50 63 -2 minecraft:smooth_basalt
setblock 78 63 -2 minecraft:smooth_basalt
setblock 49 63 -1 minecraft:amethyst_block
setblock 79 63 -1 minecraft:amethyst_block
fill 56 63 -1 57 63 -1 minecraft:cyan_concrete
setblock 48 63 -1 minecraft:deepslate_tiles
setblock 51 63 -1 minecraft:deepslate_tiles
setblock 53 63 -1 minecraft:deepslate_tiles
setblock 55 63 -1 minecraft:deepslate_tiles
setblock 59 63 -1 minecraft:deepslate_tiles
setblock 63 63 -1 minecraft:deepslate_tiles
setblock 65 63 -1 minecraft:deepslate_tiles
setblock 69 63 -1 minecraft:deepslate_tiles
setblock 71 63 -1 minecraft:deepslate_tiles
setblock 75 63 -1 minecraft:deepslate_tiles
setblock 77 63 -1 minecraft:deepslate_tiles
setblock 80 63 -1 minecraft:deepslate_tiles
fill 72 63 -1 73 63 -1 minecraft:lime_concrete
fill 67 63 -1 68 63 -1 minecraft:orange_concrete
setblock 52 63 -1 minecraft:polished_deepslate
setblock 54 63 -1 minecraft:polished_deepslate
setblock 58 63 -1 minecraft:polished_deepslate
setblock 60 63 -1 minecraft:polished_deepslate
setblock 64 63 -1 minecraft:polished_deepslate
setblock 66 63 -1 minecraft:polished_deepslate
setblock 70 63 -1 minecraft:polished_deepslate
setblock 74 63 -1 minecraft:polished_deepslate
setblock 76 63 -1 minecraft:polished_deepslate
fill 61 63 -1 62 63 -1 minecraft:purple_concrete
setblock 50 63 -1 minecraft:smooth_basalt
setblock 78 63 -1 minecraft:smooth_basalt
setblock 49 63 0 minecraft:amethyst_block
setblock 79 63 0 minecraft:amethyst_block
setblock 54 63 0 minecraft:chiseled_deepslate
setblock 59 63 0 minecraft:chiseled_deepslate
setblock 64 63 0 minecraft:chiseled_deepslate
setblock 69 63 0 minecraft:chiseled_deepslate
setblock 74 63 0 minecraft:chiseled_deepslate
setblock 48 63 0 minecraft:deepslate_tiles
setblock 52 63 0 minecraft:deepslate_tiles
setblock 56 63 0 minecraft:deepslate_tiles
setblock 58 63 0 minecraft:deepslate_tiles
setblock 60 63 0 minecraft:deepslate_tiles
setblock 62 63 0 minecraft:deepslate_tiles
setblock 66 63 0 minecraft:deepslate_tiles
setblock 68 63 0 minecraft:deepslate_tiles
setblock 70 63 0 minecraft:deepslate_tiles
setblock 72 63 0 minecraft:deepslate_tiles
setblock 76 63 0 minecraft:deepslate_tiles
setblock 80 63 0 minecraft:deepslate_tiles
setblock 51 63 0 minecraft:polished_deepslate
setblock 53 63 0 minecraft:polished_deepslate
setblock 55 63 0 minecraft:polished_deepslate
setblock 57 63 0 minecraft:polished_deepslate
setblock 61 63 0 minecraft:polished_deepslate
setblock 63 63 0 minecraft:polished_deepslate
setblock 65 63 0 minecraft:polished_deepslate
setblock 67 63 0 minecraft:polished_deepslate
setblock 71 63 0 minecraft:polished_deepslate
setblock 73 63 0 minecraft:polished_deepslate
setblock 75 63 0 minecraft:polished_deepslate
setblock 77 63 0 minecraft:polished_deepslate
setblock 50 63 0 minecraft:smooth_basalt
setblock 78 63 0 minecraft:smooth_basalt
setblock 49 63 1 minecraft:amethyst_block
setblock 79 63 1 minecraft:amethyst_block
setblock 48 63 1 minecraft:deepslate_tiles
setblock 51 63 1 minecraft:deepslate_tiles
setblock 53 63 1 minecraft:deepslate_tiles
setblock 55 63 1 minecraft:deepslate_tiles
setblock 57 63 1 minecraft:deepslate_tiles
setblock 59 63 1 minecraft:deepslate_tiles
setblock 61 63 1 minecraft:deepslate_tiles
setblock 63 63 1 minecraft:deepslate_tiles
setblock 65 63 1 minecraft:deepslate_tiles
setblock 67 63 1 minecraft:deepslate_tiles
setblock 69 63 1 minecraft:deepslate_tiles
setblock 71 63 1 minecraft:deepslate_tiles
setblock 73 63 1 minecraft:deepslate_tiles
setblock 75 63 1 minecraft:deepslate_tiles
setblock 77 63 1 minecraft:deepslate_tiles
setblock 80 63 1 minecraft:deepslate_tiles
setblock 52 63 1 minecraft:polished_deepslate
setblock 54 63 1 minecraft:polished_deepslate
setblock 56 63 1 minecraft:polished_deepslate
setblock 58 63 1 minecraft:polished_deepslate
setblock 60 63 1 minecraft:polished_deepslate
setblock 62 63 1 minecraft:polished_deepslate
setblock 64 63 1 minecraft:polished_deepslate
setblock 66 63 1 minecraft:polished_deepslate
setblock 68 63 1 minecraft:polished_deepslate
setblock 70 63 1 minecraft:polished_deepslate
setblock 72 63 1 minecraft:polished_deepslate
setblock 74 63 1 minecraft:polished_deepslate
setblock 76 63 1 minecraft:polished_deepslate
setblock 50 63 1 minecraft:smooth_basalt
setblock 78 63 1 minecraft:smooth_basalt
setblock 49 63 2 minecraft:amethyst_block
setblock 79 63 2 minecraft:amethyst_block
setblock 48 63 2 minecraft:deepslate_tiles
setblock 52 63 2 minecraft:deepslate_tiles
setblock 54 63 2 minecraft:deepslate_tiles
setblock 56 63 2 minecraft:deepslate_tiles
setblock 58 63 2 minecraft:deepslate_tiles
setblock 60 63 2 minecraft:deepslate_tiles
setblock 62 63 2 minecraft:deepslate_tiles
setblock 64 63 2 minecraft:deepslate_tiles
setblock 66 63 2 minecraft:deepslate_tiles
setblock 68 63 2 minecraft:deepslate_tiles
setblock 70 63 2 minecraft:deepslate_tiles
setblock 72 63 2 minecraft:deepslate_tiles
setblock 74 63 2 minecraft:deepslate_tiles
setblock 76 63 2 minecraft:deepslate_tiles
setblock 80 63 2 minecraft:deepslate_tiles
setblock 51 63 2 minecraft:polished_deepslate
setblock 53 63 2 minecraft:polished_deepslate
setblock 55 63 2 minecraft:polished_deepslate
setblock 57 63 2 minecraft:polished_deepslate
setblock 59 63 2 minecraft:polished_deepslate
setblock 61 63 2 minecraft:polished_deepslate
setblock 63 63 2 minecraft:polished_deepslate
setblock 65 63 2 minecraft:polished_deepslate
setblock 67 63 2 minecraft:polished_deepslate
setblock 69 63 2 minecraft:polished_deepslate
setblock 71 63 2 minecraft:polished_deepslate
setblock 73 63 2 minecraft:polished_deepslate
setblock 75 63 2 minecraft:polished_deepslate
setblock 77 63 2 minecraft:polished_deepslate
setblock 50 63 2 minecraft:smooth_basalt
setblock 78 63 2 minecraft:smooth_basalt
setblock 49 63 3 minecraft:amethyst_block
setblock 79 63 3 minecraft:amethyst_block
setblock 48 63 3 minecraft:deepslate_tiles
setblock 51 63 3 minecraft:deepslate_tiles
setblock 53 63 3 minecraft:deepslate_tiles
setblock 55 63 3 minecraft:deepslate_tiles
setblock 57 63 3 minecraft:deepslate_tiles
setblock 59 63 3 minecraft:deepslate_tiles
setblock 61 63 3 minecraft:deepslate_tiles
setblock 63 63 3 minecraft:deepslate_tiles
setblock 65 63 3 minecraft:deepslate_tiles
setblock 67 63 3 minecraft:deepslate_tiles
setblock 69 63 3 minecraft:deepslate_tiles
setblock 71 63 3 minecraft:deepslate_tiles
setblock 73 63 3 minecraft:deepslate_tiles
setblock 75 63 3 minecraft:deepslate_tiles
setblock 77 63 3 minecraft:deepslate_tiles
setblock 80 63 3 minecraft:deepslate_tiles
setblock 52 63 3 minecraft:polished_deepslate
setblock 54 63 3 minecraft:polished_deepslate
setblock 56 63 3 minecraft:polished_deepslate
setblock 58 63 3 minecraft:polished_deepslate
setblock 60 63 3 minecraft:polished_deepslate
setblock 62 63 3 minecraft:polished_deepslate
setblock 64 63 3 minecraft:polished_deepslate
setblock 66 63 3 minecraft:polished_deepslate
setblock 68 63 3 minecraft:polished_deepslate
setblock 70 63 3 minecraft:polished_deepslate
setblock 72 63 3 minecraft:polished_deepslate
setblock 74 63 3 minecraft:polished_deepslate
setblock 76 63 3 minecraft:polished_deepslate
setblock 50 63 3 minecraft:smooth_basalt
setblock 78 63 3 minecraft:smooth_basalt
setblock 49 63 4 minecraft:amethyst_block
setblock 64 63 4 minecraft:amethyst_block
setblock 79 63 4 minecraft:amethyst_block
setblock 48 63 4 minecraft:deepslate_tiles
setblock 52 63 4 minecraft:deepslate_tiles
setblock 54 63 4 minecraft:deepslate_tiles
setblock 56 63 4 minecraft:deepslate_tiles
setblock 58 63 4 minecraft:deepslate_tiles
setblock 60 63 4 minecraft:deepslate_tiles
setblock 62 63 4 minecraft:deepslate_tiles
setblock 66 63 4 minecraft:deepslate_tiles
setblock 68 63 4 minecraft:deepslate_tiles
setblock 70 63 4 minecraft:deepslate_tiles
setblock 72 63 4 minecraft:deepslate_tiles
setblock 74 63 4 minecraft:deepslate_tiles
setblock 76 63 4 minecraft:deepslate_tiles
setblock 80 63 4 minecraft:deepslate_tiles
setblock 51 63 4 minecraft:polished_deepslate
setblock 53 63 4 minecraft:polished_deepslate
setblock 55 63 4 minecraft:polished_deepslate
setblock 57 63 4 minecraft:polished_deepslate
setblock 59 63 4 minecraft:polished_deepslate
setblock 61 63 4 minecraft:polished_deepslate
setblock 63 63 4 minecraft:polished_deepslate
setblock 65 63 4 minecraft:polished_deepslate
setblock 67 63 4 minecraft:polished_deepslate
setblock 69 63 4 minecraft:polished_deepslate
setblock 71 63 4 minecraft:polished_deepslate
setblock 73 63 4 minecraft:polished_deepslate
setblock 75 63 4 minecraft:polished_deepslate
setblock 77 63 4 minecraft:polished_deepslate
setblock 50 63 4 minecraft:smooth_basalt
setblock 78 63 4 minecraft:smooth_basalt
setblock 49 63 5 minecraft:amethyst_block
setblock 63 63 5 minecraft:amethyst_block
setblock 79 63 5 minecraft:amethyst_block
setblock 54 63 5 minecraft:chiseled_deepslate
setblock 59 63 5 minecraft:chiseled_deepslate
setblock 69 63 5 minecraft:chiseled_deepslate
setblock 74 63 5 minecraft:chiseled_deepslate
setblock 48 63 5 minecraft:deepslate_tiles
setblock 51 63 5 minecraft:deepslate_tiles
setblock 53 63 5 minecraft:deepslate_tiles
setblock 55 63 5 minecraft:deepslate_tiles
setblock 57 63 5 minecraft:deepslate_tiles
setblock 61 63 5 minecraft:deepslate_tiles
setblock 67 63 5 minecraft:deepslate_tiles
setblock 71 63 5 minecraft:deepslate_tiles
setblock 73 63 5 minecraft:deepslate_tiles
setblock 75 63 5 minecraft:deepslate_tiles
setblock 77 63 5 minecraft:deepslate_tiles
setblock 80 63 5 minecraft:deepslate_tiles
setblock 52 63 5 minecraft:polished_deepslate
setblock 56 63 5 minecraft:polished_deepslate
setblock 58 63 5 minecraft:polished_deepslate
setblock 60 63 5 minecraft:polished_deepslate
setblock 62 63 5 minecraft:polished_deepslate
setblock 66 63 5 minecraft:polished_deepslate
setblock 68 63 5 minecraft:polished_deepslate
setblock 70 63 5 minecraft:polished_deepslate
setblock 72 63 5 minecraft:polished_deepslate
setblock 76 63 5 minecraft:polished_deepslate
setblock 50 63 5 minecraft:smooth_basalt
setblock 78 63 5 minecraft:smooth_basalt
fill 64 63 5 65 63 5 minecraft:white_concrete
setblock 49 63 6 minecraft:amethyst_block
setblock 79 63 6 minecraft:amethyst_block
setblock 48 63 6 minecraft:deepslate_tiles
setblock 52 63 6 minecraft:deepslate_tiles
setblock 54 63 6 minecraft:deepslate_tiles
setblock 56 63 6 minecraft:deepslate_tiles
setblock 58 63 6 minecraft:deepslate_tiles
setblock 60 63 6 minecraft:deepslate_tiles
setblock 62 63 6 minecraft:deepslate_tiles
setblock 66 63 6 minecraft:deepslate_tiles
setblock 68 63 6 minecraft:deepslate_tiles
setblock 70 63 6 minecraft:deepslate_tiles
setblock 72 63 6 minecraft:deepslate_tiles
setblock 74 63 6 minecraft:deepslate_tiles
setblock 76 63 6 minecraft:deepslate_tiles
setblock 80 63 6 minecraft:deepslate_tiles
setblock 51 63 6 minecraft:polished_deepslate
setblock 53 63 6 minecraft:polished_deepslate
setblock 55 63 6 minecraft:polished_deepslate
setblock 57 63 6 minecraft:polished_deepslate
setblock 59 63 6 minecraft:polished_deepslate
setblock 61 63 6 minecraft:polished_deepslate
setblock 63 63 6 minecraft:polished_deepslate
setblock 67 63 6 minecraft:polished_deepslate
setblock 69 63 6 minecraft:polished_deepslate
setblock 71 63 6 minecraft:polished_deepslate
setblock 73 63 6 minecraft:polished_deepslate
setblock 75 63 6 minecraft:polished_deepslate
setblock 77 63 6 minecraft:polished_deepslate
setblock 50 63 6 minecraft:smooth_basalt
setblock 78 63 6 minecraft:smooth_basalt
fill 64 63 6 65 63 6 minecraft:white_concrete
setblock 49 63 7 minecraft:amethyst_block
setblock 79 63 7 minecraft:amethyst_block
setblock 48 63 7 minecraft:deepslate_tiles
setblock 51 63 7 minecraft:deepslate_tiles
setblock 53 63 7 minecraft:deepslate_tiles
setblock 55 63 7 minecraft:deepslate_tiles
setblock 57 63 7 minecraft:deepslate_tiles
setblock 59 63 7 minecraft:deepslate_tiles
setblock 61 63 7 minecraft:deepslate_tiles
setblock 63 63 7 minecraft:deepslate_tiles
setblock 65 63 7 minecraft:deepslate_tiles
setblock 67 63 7 minecraft:deepslate_tiles
setblock 69 63 7 minecraft:deepslate_tiles
setblock 71 63 7 minecraft:deepslate_tiles
setblock 73 63 7 minecraft:deepslate_tiles
setblock 75 63 7 minecraft:deepslate_tiles
setblock 77 63 7 minecraft:deepslate_tiles
setblock 80 63 7 minecraft:deepslate_tiles
setblock 52 63 7 minecraft:polished_deepslate
setblock 54 63 7 minecraft:polished_deepslate
setblock 56 63 7 minecraft:polished_deepslate
setblock 58 63 7 minecraft:polished_deepslate
setblock 60 63 7 minecraft:polished_deepslate
setblock 62 63 7 minecraft:polished_deepslate
setblock 64 63 7 minecraft:polished_deepslate
setblock 66 63 7 minecraft:polished_deepslate
setblock 68 63 7 minecraft:polished_deepslate
setblock 70 63 7 minecraft:polished_deepslate
setblock 72 63 7 minecraft:polished_deepslate
setblock 74 63 7 minecraft:polished_deepslate
setblock 76 63 7 minecraft:polished_deepslate
setblock 50 63 7 minecraft:smooth_basalt
setblock 78 63 7 minecraft:smooth_basalt
setblock 49 63 8 minecraft:amethyst_block
setblock 79 63 8 minecraft:amethyst_block
setblock 76 63 8 minecraft:chiseled_quartz_block
setblock 48 63 8 minecraft:deepslate_tiles
setblock 52 63 8 minecraft:deepslate_tiles
setblock 54 63 8 minecraft:deepslate_tiles
setblock 56 63 8 minecraft:deepslate_tiles
setblock 58 63 8 minecraft:deepslate_tiles
setblock 60 63 8 minecraft:deepslate_tiles
setblock 62 63 8 minecraft:deepslate_tiles
setblock 64 63 8 minecraft:deepslate_tiles
setblock 66 63 8 minecraft:deepslate_tiles
setblock 68 63 8 minecraft:deepslate_tiles
setblock 70 63 8 minecraft:deepslate_tiles
setblock 72 63 8 minecraft:deepslate_tiles
setblock 74 63 8 minecraft:deepslate_tiles
setblock 80 63 8 minecraft:deepslate_tiles
setblock 51 63 8 minecraft:polished_deepslate
setblock 53 63 8 minecraft:polished_deepslate
setblock 55 63 8 minecraft:polished_deepslate
setblock 57 63 8 minecraft:polished_deepslate
setblock 59 63 8 minecraft:polished_deepslate
setblock 61 63 8 minecraft:polished_deepslate
setblock 63 63 8 minecraft:polished_deepslate
setblock 65 63 8 minecraft:polished_deepslate
setblock 67 63 8 minecraft:polished_deepslate
setblock 69 63 8 minecraft:polished_deepslate
setblock 71 63 8 minecraft:polished_deepslate
setblock 73 63 8 minecraft:polished_deepslate
setblock 75 63 8 minecraft:polished_deepslate
setblock 77 63 8 minecraft:polished_deepslate
setblock 50 63 8 minecraft:smooth_basalt
setblock 78 63 8 minecraft:smooth_basalt
setblock 49 63 9 minecraft:amethyst_block
setblock 79 63 9 minecraft:amethyst_block
setblock 48 63 9 minecraft:deepslate_tiles
setblock 51 63 9 minecraft:deepslate_tiles
setblock 53 63 9 minecraft:deepslate_tiles
setblock 55 63 9 minecraft:deepslate_tiles
setblock 57 63 9 minecraft:deepslate_tiles
setblock 59 63 9 minecraft:deepslate_tiles
setblock 61 63 9 minecraft:deepslate_tiles
setblock 63 63 9 minecraft:deepslate_tiles
setblock 65 63 9 minecraft:deepslate_tiles
setblock 67 63 9 minecraft:deepslate_tiles
setblock 69 63 9 minecraft:deepslate_tiles
setblock 71 63 9 minecraft:deepslate_tiles
setblock 73 63 9 minecraft:deepslate_tiles
setblock 75 63 9 minecraft:deepslate_tiles
setblock 77 63 9 minecraft:deepslate_tiles
setblock 80 63 9 minecraft:deepslate_tiles
setblock 52 63 9 minecraft:polished_deepslate
setblock 54 63 9 minecraft:polished_deepslate
setblock 56 63 9 minecraft:polished_deepslate
setblock 58 63 9 minecraft:polished_deepslate
setblock 60 63 9 minecraft:polished_deepslate
setblock 62 63 9 minecraft:polished_deepslate
setblock 64 63 9 minecraft:polished_deepslate
setblock 66 63 9 minecraft:polished_deepslate
setblock 68 63 9 minecraft:polished_deepslate
setblock 70 63 9 minecraft:polished_deepslate
setblock 72 63 9 minecraft:polished_deepslate
setblock 74 63 9 minecraft:polished_deepslate
setblock 76 63 9 minecraft:polished_deepslate
setblock 50 63 9 minecraft:smooth_basalt
setblock 78 63 9 minecraft:smooth_basalt
setblock 49 63 10 minecraft:amethyst_block
setblock 53 63 10 minecraft:amethyst_block
setblock 75 63 10 minecraft:amethyst_block
setblock 79 63 10 minecraft:amethyst_block
setblock 54 63 10 minecraft:chiseled_deepslate
setblock 59 63 10 minecraft:chiseled_deepslate
setblock 64 63 10 minecraft:chiseled_deepslate
setblock 69 63 10 minecraft:chiseled_deepslate
setblock 74 63 10 minecraft:chiseled_deepslate
setblock 48 63 10 minecraft:deepslate_tiles
setblock 52 63 10 minecraft:deepslate_tiles
setblock 56 63 10 minecraft:deepslate_tiles
setblock 58 63 10 minecraft:deepslate_tiles
setblock 60 63 10 minecraft:deepslate_tiles
setblock 62 63 10 minecraft:deepslate_tiles
setblock 66 63 10 minecraft:deepslate_tiles
setblock 68 63 10 minecraft:deepslate_tiles
setblock 70 63 10 minecraft:deepslate_tiles
setblock 72 63 10 minecraft:deepslate_tiles
setblock 76 63 10 minecraft:deepslate_tiles
setblock 80 63 10 minecraft:deepslate_tiles
setblock 51 63 10 minecraft:polished_deepslate
setblock 55 63 10 minecraft:polished_deepslate
setblock 57 63 10 minecraft:polished_deepslate
setblock 61 63 10 minecraft:polished_deepslate
setblock 63 63 10 minecraft:polished_deepslate
setblock 65 63 10 minecraft:polished_deepslate
setblock 67 63 10 minecraft:polished_deepslate
setblock 71 63 10 minecraft:polished_deepslate
setblock 73 63 10 minecraft:polished_deepslate
setblock 77 63 10 minecraft:polished_deepslate
setblock 50 63 10 minecraft:smooth_basalt
setblock 78 63 10 minecraft:smooth_basalt
setblock 49 63 11 minecraft:amethyst_block
setblock 52 63 11 minecraft:amethyst_block
setblock 54 63 11 minecraft:amethyst_block
setblock 74 63 11 minecraft:amethyst_block
setblock 76 63 11 minecraft:amethyst_block
setblock 79 63 11 minecraft:amethyst_block
setblock 48 63 11 minecraft:deepslate_tiles
setblock 51 63 11 minecraft:deepslate_tiles
setblock 55 63 11 minecraft:deepslate_tiles
setblock 57 63 11 minecraft:deepslate_tiles
setblock 59 63 11 minecraft:deepslate_tiles
setblock 61 63 11 minecraft:deepslate_tiles
setblock 63 63 11 minecraft:deepslate_tiles
setblock 65 63 11 minecraft:deepslate_tiles
setblock 67 63 11 minecraft:deepslate_tiles
setblock 69 63 11 minecraft:deepslate_tiles
setblock 71 63 11 minecraft:deepslate_tiles
setblock 73 63 11 minecraft:deepslate_tiles
setblock 77 63 11 minecraft:deepslate_tiles
setblock 80 63 11 minecraft:deepslate_tiles
setblock 56 63 11 minecraft:polished_deepslate
setblock 58 63 11 minecraft:polished_deepslate
setblock 60 63 11 minecraft:polished_deepslate
setblock 62 63 11 minecraft:polished_deepslate
setblock 64 63 11 minecraft:polished_deepslate
setblock 66 63 11 minecraft:polished_deepslate
setblock 68 63 11 minecraft:polished_deepslate
setblock 70 63 11 minecraft:polished_deepslate
setblock 72 63 11 minecraft:polished_deepslate
setblock 53 63 11 minecraft:sea_lantern
setblock 75 63 11 minecraft:sea_lantern
setblock 50 63 11 minecraft:smooth_basalt
setblock 78 63 11 minecraft:smooth_basalt
setblock 49 63 12 minecraft:amethyst_block
setblock 53 63 12 minecraft:amethyst_block
setblock 75 63 12 minecraft:amethyst_block
setblock 79 63 12 minecraft:amethyst_block
setblock 48 63 12 minecraft:deepslate_tiles
setblock 52 63 12 minecraft:deepslate_tiles
setblock 54 63 12 minecraft:deepslate_tiles
setblock 56 63 12 minecraft:deepslate_tiles
setblock 58 63 12 minecraft:deepslate_tiles
setblock 60 63 12 minecraft:deepslate_tiles
setblock 62 63 12 minecraft:deepslate_tiles
setblock 66 63 12 minecraft:deepslate_tiles
setblock 68 63 12 minecraft:deepslate_tiles
setblock 70 63 12 minecraft:deepslate_tiles
setblock 72 63 12 minecraft:deepslate_tiles
setblock 74 63 12 minecraft:deepslate_tiles
setblock 76 63 12 minecraft:deepslate_tiles
setblock 80 63 12 minecraft:deepslate_tiles
setblock 51 63 12 minecraft:polished_deepslate
setblock 55 63 12 minecraft:polished_deepslate
setblock 57 63 12 minecraft:polished_deepslate
setblock 59 63 12 minecraft:polished_deepslate
setblock 61 63 12 minecraft:polished_deepslate
setblock 63 63 12 minecraft:polished_deepslate
setblock 67 63 12 minecraft:polished_deepslate
setblock 69 63 12 minecraft:polished_deepslate
setblock 71 63 12 minecraft:polished_deepslate
setblock 73 63 12 minecraft:polished_deepslate
setblock 77 63 12 minecraft:polished_deepslate
fill 64 63 12 65 63 12 minecraft:quartz_block
setblock 50 63 12 minecraft:smooth_basalt
setblock 78 63 12 minecraft:smooth_basalt
setblock 49 63 13 minecraft:amethyst_block
setblock 79 63 13 minecraft:amethyst_block
setblock 48 63 13 minecraft:deepslate_tiles
setblock 51 63 13 minecraft:deepslate_tiles
setblock 53 63 13 minecraft:deepslate_tiles
setblock 55 63 13 minecraft:deepslate_tiles
setblock 57 63 13 minecraft:deepslate_tiles
setblock 59 63 13 minecraft:deepslate_tiles
setblock 61 63 13 minecraft:deepslate_tiles
setblock 63 63 13 minecraft:deepslate_tiles
setblock 67 63 13 minecraft:deepslate_tiles
setblock 69 63 13 minecraft:deepslate_tiles
setblock 71 63 13 minecraft:deepslate_tiles
setblock 73 63 13 minecraft:deepslate_tiles
setblock 75 63 13 minecraft:deepslate_tiles
setblock 77 63 13 minecraft:deepslate_tiles
setblock 80 63 13 minecraft:deepslate_tiles
setblock 52 63 13 minecraft:polished_deepslate
setblock 54 63 13 minecraft:polished_deepslate
setblock 56 63 13 minecraft:polished_deepslate
setblock 58 63 13 minecraft:polished_deepslate
setblock 60 63 13 minecraft:polished_deepslate
setblock 62 63 13 minecraft:polished_deepslate
setblock 66 63 13 minecraft:polished_deepslate
setblock 68 63 13 minecraft:polished_deepslate
setblock 70 63 13 minecraft:polished_deepslate
setblock 72 63 13 minecraft:polished_deepslate
setblock 74 63 13 minecraft:polished_deepslate
setblock 76 63 13 minecraft:polished_deepslate
fill 64 63 13 65 63 13 minecraft:quartz_block
setblock 50 63 13 minecraft:smooth_basalt
setblock 78 63 13 minecraft:smooth_basalt
setblock 49 63 14 minecraft:amethyst_block
setblock 79 63 14 minecraft:amethyst_block
setblock 48 63 14 minecraft:deepslate_tiles
setblock 80 63 14 minecraft:deepslate_tiles
fill 50 63 14 78 63 14 minecraft:smooth_basalt
fill 49 63 15 79 63 15 minecraft:amethyst_block
setblock 48 63 15 minecraft:deepslate_tiles
setblock 80 63 15 minecraft:deepslate_tiles
fill 48 63 16 80 63 16 minecraft:deepslate_tiles
fill 48 64 -16 80 64 -16 minecraft:polished_blackstone_bricks
setblock 52 64 -15 minecraft:amethyst_block
setblock 58 64 -15 minecraft:amethyst_block
setblock 64 64 -15 minecraft:amethyst_block
setblock 70 64 -15 minecraft:amethyst_block
setblock 76 64 -15 minecraft:amethyst_block
setblock 48 64 -15 minecraft:polished_blackstone_bricks
setblock 80 64 -15 minecraft:polished_blackstone_bricks
setblock 48 64 -14 minecraft:polished_blackstone_bricks
setblock 80 64 -14 minecraft:polished_blackstone_bricks
setblock 48 64 -13 minecraft:polished_blackstone_bricks
setblock 80 64 -13 minecraft:polished_blackstone_bricks
setblock 49 64 -12 minecraft:amethyst_block
setblock 79 64 -12 minecraft:amethyst_block
setblock 48 64 -12 minecraft:polished_blackstone_bricks
setblock 80 64 -12 minecraft:polished_blackstone_bricks
setblock 52 64 -11 minecraft:chiseled_bookshelf[facing=east]
setblock 76 64 -11 minecraft:chiseled_bookshelf[facing=west]
setblock 48 64 -11 minecraft:polished_blackstone_bricks
setblock 80 64 -11 minecraft:polished_blackstone_bricks
setblock 52 64 -10 minecraft:chiseled_bookshelf[facing=east]
setblock 76 64 -10 minecraft:chiseled_bookshelf[facing=west]
setblock 48 64 -10 minecraft:polished_blackstone_bricks
fill 55 64 -10 57 64 -10 minecraft:polished_blackstone_bricks
fill 60 64 -10 62 64 -10 minecraft:polished_blackstone_bricks
fill 66 64 -10 68 64 -10 minecraft:polished_blackstone_bricks
fill 71 64 -10 73 64 -10 minecraft:polished_blackstone_bricks
setblock 80 64 -10 minecraft:polished_blackstone_bricks
setblock 52 64 -9 minecraft:chiseled_bookshelf[facing=east]
setblock 76 64 -9 minecraft:chiseled_bookshelf[facing=west]
setblock 48 64 -9 minecraft:polished_blackstone_bricks
fill 55 64 -9 57 64 -9 minecraft:polished_blackstone_bricks
fill 60 64 -9 62 64 -9 minecraft:polished_blackstone_bricks
fill 66 64 -9 68 64 -9 minecraft:polished_blackstone_bricks
fill 71 64 -9 73 64 -9 minecraft:polished_blackstone_bricks
setblock 80 64 -9 minecraft:polished_blackstone_bricks
setblock 48 64 -8 minecraft:polished_blackstone_bricks
fill 55 64 -8 57 64 -8 minecraft:polished_blackstone_bricks
fill 60 64 -8 62 64 -8 minecraft:polished_blackstone_bricks
fill 66 64 -8 68 64 -8 minecraft:polished_blackstone_bricks
fill 71 64 -8 73 64 -8 minecraft:polished_blackstone_bricks
setblock 80 64 -8 minecraft:polished_blackstone_bricks
setblock 48 64 -7 minecraft:polished_blackstone_bricks
setblock 80 64 -7 minecraft:polished_blackstone_bricks
setblock 49 64 -6 minecraft:amethyst_block
setblock 79 64 -6 minecraft:amethyst_block
setblock 48 64 -6 minecraft:polished_blackstone_bricks
setblock 80 64 -6 minecraft:polished_blackstone_bricks
setblock 48 64 -5 minecraft:polished_blackstone_bricks
setblock 80 64 -5 minecraft:polished_blackstone_bricks
setblock 48 64 -4 minecraft:polished_blackstone_bricks
setblock 80 64 -4 minecraft:polished_blackstone_bricks
setblock 48 64 -3 minecraft:polished_blackstone_bricks
setblock 80 64 -3 minecraft:polished_blackstone_bricks
setblock 52 64 -2 minecraft:chiseled_bookshelf[facing=east]
setblock 76 64 -2 minecraft:chiseled_bookshelf[facing=west]
setblock 48 64 -2 minecraft:polished_blackstone_bricks
setblock 80 64 -2 minecraft:polished_blackstone_bricks
setblock 52 64 -1 minecraft:chiseled_bookshelf[facing=east]
setblock 76 64 -1 minecraft:chiseled_bookshelf[facing=west]
setblock 48 64 -1 minecraft:polished_blackstone_bricks
setblock 80 64 -1 minecraft:polished_blackstone_bricks
setblock 49 64 0 minecraft:amethyst_block
setblock 79 64 0 minecraft:amethyst_block
setblock 52 64 0 minecraft:chiseled_bookshelf[facing=east]
setblock 76 64 0 minecraft:chiseled_bookshelf[facing=west]
setblock 48 64 0 minecraft:polished_blackstone_bricks
setblock 80 64 0 minecraft:polished_blackstone_bricks
setblock 48 64 1 minecraft:polished_blackstone_bricks
setblock 80 64 1 minecraft:polished_blackstone_bricks
setblock 48 64 2 minecraft:polished_blackstone_bricks
setblock 80 64 2 minecraft:polished_blackstone_bricks
setblock 48 64 3 minecraft:polished_blackstone_bricks
setblock 80 64 3 minecraft:polished_blackstone_bricks
setblock 48 64 4 minecraft:polished_blackstone_bricks
setblock 80 64 4 minecraft:polished_blackstone_bricks
setblock 52 64 5 minecraft:chiseled_bookshelf[facing=east]
setblock 76 64 5 minecraft:chiseled_bookshelf[facing=west]
setblock 48 64 5 minecraft:polished_blackstone_bricks
setblock 80 64 5 minecraft:polished_blackstone_bricks
setblock 49 64 6 minecraft:amethyst_block
setblock 79 64 6 minecraft:amethyst_block
setblock 52 64 6 minecraft:chiseled_bookshelf[facing=east]
setblock 76 64 6 minecraft:chiseled_bookshelf[facing=west]
setblock 48 64 6 minecraft:polished_blackstone_bricks
setblock 80 64 6 minecraft:polished_blackstone_bricks
setblock 52 64 7 minecraft:chiseled_bookshelf[facing=east]
setblock 76 64 7 minecraft:chiseled_bookshelf[facing=west]
setblock 48 64 7 minecraft:polished_blackstone_bricks
setblock 78 64 7 minecraft:polished_blackstone_bricks
setblock 80 64 7 minecraft:polished_blackstone_bricks
setblock 48 64 8 minecraft:polished_blackstone_bricks
setblock 78 64 8 minecraft:polished_blackstone_bricks
setblock 80 64 8 minecraft:polished_blackstone_bricks
setblock 48 64 9 minecraft:polished_blackstone_bricks
setblock 78 64 9 minecraft:polished_blackstone_bricks
setblock 80 64 9 minecraft:polished_blackstone_bricks
setblock 48 64 10 minecraft:polished_blackstone_bricks
setblock 80 64 10 minecraft:polished_blackstone_bricks
setblock 48 64 11 minecraft:polished_blackstone_bricks
setblock 80 64 11 minecraft:polished_blackstone_bricks
setblock 49 64 12 minecraft:amethyst_block
setblock 79 64 12 minecraft:amethyst_block
setblock 48 64 12 minecraft:polished_blackstone_bricks
setblock 80 64 12 minecraft:polished_blackstone_bricks
setblock 48 64 13 minecraft:polished_blackstone_bricks
setblock 80 64 13 minecraft:polished_blackstone_bricks
setblock 48 64 14 minecraft:polished_blackstone_bricks
setblock 80 64 14 minecraft:polished_blackstone_bricks
setblock 52 64 15 minecraft:amethyst_block
setblock 58 64 15 minecraft:amethyst_block
setblock 64 64 15 minecraft:amethyst_block
setblock 70 64 15 minecraft:amethyst_block
setblock 76 64 15 minecraft:amethyst_block
setblock 48 64 15 minecraft:polished_blackstone_bricks
setblock 80 64 15 minecraft:polished_blackstone_bricks
fill 48 64 16 80 64 16 minecraft:polished_blackstone_bricks
fill 48 65 -16 80 65 -16 minecraft:polished_blackstone_bricks
setblock 52 65 -15 minecraft:amethyst_block
setblock 58 65 -15 minecraft:amethyst_block
setblock 64 65 -15 minecraft:amethyst_block
setblock 70 65 -15 minecraft:amethyst_block
setblock 76 65 -15 minecraft:amethyst_block
setblock 48 65 -15 minecraft:polished_blackstone_bricks
setblock 80 65 -15 minecraft:polished_blackstone_bricks
setblock 48 65 -14 minecraft:polished_blackstone_bricks
setblock 80 65 -14 minecraft:polished_blackstone_bricks
setblock 48 65 -13 minecraft:polished_blackstone_bricks
setblock 80 65 -13 minecraft:polished_blackstone_bricks
setblock 49 65 -12 minecraft:amethyst_block
setblock 79 65 -12 minecraft:amethyst_block
setblock 48 65 -12 minecraft:polished_blackstone_bricks
setblock 80 65 -12 minecraft:polished_blackstone_bricks
setblock 52 65 -11 minecraft:chiseled_bookshelf[facing=east]
setblock 76 65 -11 minecraft:chiseled_bookshelf[facing=west]
setblock 48 65 -11 minecraft:polished_blackstone_bricks
setblock 80 65 -11 minecraft:polished_blackstone_bricks
setblock 52 65 -10 minecraft:chiseled_bookshelf[facing=east]
setblock 76 65 -10 minecraft:chiseled_bookshelf[facing=west]
setblock 48 65 -10 minecraft:polished_blackstone_bricks
fill 55 65 -10 57 65 -10 minecraft:polished_blackstone_bricks
fill 60 65 -10 62 65 -10 minecraft:polished_blackstone_bricks
fill 66 65 -10 68 65 -10 minecraft:polished_blackstone_bricks
fill 71 65 -10 73 65 -10 minecraft:polished_blackstone_bricks
setblock 80 65 -10 minecraft:polished_blackstone_bricks
setblock 52 65 -9 minecraft:chiseled_bookshelf[facing=east]
setblock 76 65 -9 minecraft:chiseled_bookshelf[facing=west]
setblock 48 65 -9 minecraft:polished_blackstone_bricks
fill 55 65 -9 57 65 -9 minecraft:polished_blackstone_bricks
fill 60 65 -9 62 65 -9 minecraft:polished_blackstone_bricks
fill 66 65 -9 68 65 -9 minecraft:polished_blackstone_bricks
fill 71 65 -9 73 65 -9 minecraft:polished_blackstone_bricks
setblock 80 65 -9 minecraft:polished_blackstone_bricks
setblock 48 65 -8 minecraft:polished_blackstone_bricks
fill 55 65 -8 57 65 -8 minecraft:polished_blackstone_bricks
fill 60 65 -8 62 65 -8 minecraft:polished_blackstone_bricks
fill 66 65 -8 68 65 -8 minecraft:polished_blackstone_bricks
fill 71 65 -8 73 65 -8 minecraft:polished_blackstone_bricks
setblock 80 65 -8 minecraft:polished_blackstone_bricks
setblock 56 65 -7 minecraft:dark_prismarine
setblock 61 65 -7 minecraft:dark_prismarine
setblock 67 65 -7 minecraft:dark_prismarine
setblock 72 65 -7 minecraft:dark_prismarine
setblock 48 65 -7 minecraft:polished_blackstone_bricks
setblock 80 65 -7 minecraft:polished_blackstone_bricks
setblock 49 65 -6 minecraft:amethyst_block
setblock 79 65 -6 minecraft:amethyst_block
setblock 48 65 -6 minecraft:polished_blackstone_bricks
setblock 80 65 -6 minecraft:polished_blackstone_bricks
setblock 48 65 -5 minecraft:polished_blackstone_bricks
setblock 80 65 -5 minecraft:polished_blackstone_bricks
setblock 48 65 -4 minecraft:polished_blackstone_bricks
setblock 80 65 -4 minecraft:polished_blackstone_bricks
setblock 48 65 -3 minecraft:polished_blackstone_bricks
setblock 80 65 -3 minecraft:polished_blackstone_bricks
setblock 52 65 -2 minecraft:chiseled_bookshelf[facing=east]
setblock 76 65 -2 minecraft:chiseled_bookshelf[facing=west]
setblock 48 65 -2 minecraft:polished_blackstone_bricks
setblock 80 65 -2 minecraft:polished_blackstone_bricks
setblock 52 65 -1 minecraft:chiseled_bookshelf[facing=east]
setblock 76 65 -1 minecraft:chiseled_bookshelf[facing=west]
setblock 48 65 -1 minecraft:polished_blackstone_bricks
setblock 80 65 -1 minecraft:polished_blackstone_bricks
setblock 49 65 0 minecraft:amethyst_block
setblock 79 65 0 minecraft:amethyst_block
setblock 52 65 0 minecraft:chiseled_bookshelf[facing=east]
setblock 76 65 0 minecraft:chiseled_bookshelf[facing=west]
setblock 48 65 0 minecraft:polished_blackstone_bricks
setblock 80 65 0 minecraft:polished_blackstone_bricks
setblock 48 65 1 minecraft:polished_blackstone_bricks
setblock 80 65 1 minecraft:polished_blackstone_bricks
setblock 48 65 2 minecraft:polished_blackstone_bricks
setblock 80 65 2 minecraft:polished_blackstone_bricks
setblock 48 65 3 minecraft:polished_blackstone_bricks
setblock 80 65 3 minecraft:polished_blackstone_bricks
setblock 48 65 4 minecraft:polished_blackstone_bricks
setblock 80 65 4 minecraft:polished_blackstone_bricks
setblock 52 65 5 minecraft:chiseled_bookshelf[facing=east]
setblock 76 65 5 minecraft:chiseled_bookshelf[facing=west]
setblock 48 65 5 minecraft:polished_blackstone_bricks
setblock 80 65 5 minecraft:polished_blackstone_bricks
setblock 49 65 6 minecraft:amethyst_block
setblock 79 65 6 minecraft:amethyst_block
setblock 52 65 6 minecraft:chiseled_bookshelf[facing=east]
setblock 76 65 6 minecraft:chiseled_bookshelf[facing=west]
setblock 48 65 6 minecraft:polished_blackstone_bricks
setblock 80 65 6 minecraft:polished_blackstone_bricks
setblock 52 65 7 minecraft:chiseled_bookshelf[facing=east]
setblock 76 65 7 minecraft:chiseled_bookshelf[facing=west]
setblock 48 65 7 minecraft:polished_blackstone_bricks
setblock 78 65 7 minecraft:polished_blackstone_bricks
setblock 80 65 7 minecraft:polished_blackstone_bricks
setblock 48 65 8 minecraft:polished_blackstone_bricks
setblock 78 65 8 minecraft:polished_blackstone_bricks
setblock 80 65 8 minecraft:polished_blackstone_bricks
setblock 48 65 9 minecraft:polished_blackstone_bricks
setblock 78 65 9 minecraft:polished_blackstone_bricks
setblock 80 65 9 minecraft:polished_blackstone_bricks
setblock 48 65 10 minecraft:polished_blackstone_bricks
setblock 80 65 10 minecraft:polished_blackstone_bricks
setblock 48 65 11 minecraft:polished_blackstone_bricks
setblock 80 65 11 minecraft:polished_blackstone_bricks
setblock 49 65 12 minecraft:amethyst_block
setblock 79 65 12 minecraft:amethyst_block
setblock 48 65 12 minecraft:polished_blackstone_bricks
setblock 80 65 12 minecraft:polished_blackstone_bricks
setblock 48 65 13 minecraft:polished_blackstone_bricks
setblock 80 65 13 minecraft:polished_blackstone_bricks
setblock 48 65 14 minecraft:polished_blackstone_bricks
setblock 80 65 14 minecraft:polished_blackstone_bricks
setblock 52 65 15 minecraft:amethyst_block
setblock 58 65 15 minecraft:amethyst_block
setblock 64 65 15 minecraft:amethyst_block
setblock 70 65 15 minecraft:amethyst_block
setblock 76 65 15 minecraft:amethyst_block
setblock 48 65 15 minecraft:polished_blackstone_bricks
setblock 80 65 15 minecraft:polished_blackstone_bricks
fill 48 65 16 80 65 16 minecraft:polished_blackstone_bricks
fill 48 66 -16 80 66 -16 minecraft:polished_blackstone_bricks
fill 49 66 -15 79 66 -15 minecraft:amethyst_block
setblock 48 66 -15 minecraft:polished_blackstone_bricks
setblock 80 66 -15 minecraft:polished_blackstone_bricks
setblock 49 66 -14 minecraft:amethyst_block
setblock 79 66 -14 minecraft:amethyst_block
setblock 48 66 -14 minecraft:polished_blackstone_bricks
setblock 80 66 -14 minecraft:polished_blackstone_bricks
setblock 49 66 -13 minecraft:amethyst_block
setblock 79 66 -13 minecraft:amethyst_block
setblock 48 66 -13 minecraft:polished_blackstone_bricks
setblock 80 66 -13 minecraft:polished_blackstone_bricks
setblock 49 66 -12 minecraft:amethyst_block
setblock 79 66 -12 minecraft:amethyst_block
setblock 48 66 -12 minecraft:polished_blackstone_bricks
setblock 80 66 -12 minecraft:polished_blackstone_bricks
setblock 49 66 -11 minecraft:amethyst_block
setblock 79 66 -11 minecraft:amethyst_block
setblock 52 66 -11 minecraft:chiseled_bookshelf[facing=east]
setblock 76 66 -11 minecraft:chiseled_bookshelf[facing=west]
setblock 48 66 -11 minecraft:polished_blackstone_bricks
setblock 80 66 -11 minecraft:polished_blackstone_bricks
setblock 49 66 -10 minecraft:amethyst_block
setblock 79 66 -10 minecraft:amethyst_block
setblock 56 66 -10 minecraft:blue_stained_glass
setblock 52 66 -10 minecraft:chiseled_bookshelf[facing=east]
setblock 76 66 -10 minecraft:chiseled_bookshelf[facing=west]
setblock 72 66 -10 minecraft:green_stained_glass
setblock 67 66 -10 minecraft:orange_stained_glass
setblock 48 66 -10 minecraft:polished_blackstone_bricks
setblock 80 66 -10 minecraft:polished_blackstone_bricks
setblock 61 66 -10 minecraft:purple_stained_glass
setblock 49 66 -9 minecraft:amethyst_block
setblock 79 66 -9 minecraft:amethyst_block
setblock 55 66 -9 minecraft:blue_stained_glass
setblock 57 66 -9 minecraft:blue_stained_glass
setblock 52 66 -9 minecraft:chiseled_bookshelf[facing=east]
setblock 76 66 -9 minecraft:chiseled_bookshelf[facing=west]
setblock 71 66 -9 minecraft:green_stained_glass
setblock 73 66 -9 minecraft:green_stained_glass
setblock 66 66 -9 minecraft:orange_stained_glass
setblock 68 66 -9 minecraft:orange_stained_glass
setblock 48 66 -9 minecraft:polished_blackstone_bricks
setblock 80 66 -9 minecraft:polished_blackstone_bricks
setblock 60 66 -9 minecraft:purple_stained_glass
setblock 62 66 -9 minecraft:purple_stained_glass
setblock 56 66 -9 minecraft:sea_lantern
setblock 61 66 -9 minecraft:sea_lantern
setblock 67 66 -9 minecraft:sea_lantern
setblock 72 66 -9 minecraft:sea_lantern
setblock 49 66 -8 minecraft:amethyst_block
setblock 79 66 -8 minecraft:amethyst_block
setblock 56 66 -8 minecraft:blue_stained_glass
setblock 72 66 -8 minecraft:green_stained_glass
setblock 67 66 -8 minecraft:orange_stained_glass
setblock 48 66 -8 minecraft:polished_blackstone_bricks
setblock 80 66 -8 minecraft:polished_blackstone_bricks
setblock 61 66 -8 minecraft:purple_stained_glass
setblock 49 66 -7 minecraft:amethyst_block
setblock 79 66 -7 minecraft:amethyst_block
setblock 48 66 -7 minecraft:polished_blackstone_bricks
setblock 80 66 -7 minecraft:polished_blackstone_bricks
setblock 49 66 -6 minecraft:amethyst_block
setblock 79 66 -6 minecraft:amethyst_block
setblock 48 66 -6 minecraft:polished_blackstone_bricks
setblock 80 66 -6 minecraft:polished_blackstone_bricks
setblock 49 66 -5 minecraft:amethyst_block
setblock 79 66 -5 minecraft:amethyst_block
setblock 48 66 -5 minecraft:polished_blackstone_bricks
setblock 80 66 -5 minecraft:polished_blackstone_bricks
setblock 49 66 -4 minecraft:amethyst_block
setblock 79 66 -4 minecraft:amethyst_block
setblock 48 66 -4 minecraft:polished_blackstone_bricks
setblock 80 66 -4 minecraft:polished_blackstone_bricks
setblock 49 66 -3 minecraft:amethyst_block
setblock 79 66 -3 minecraft:amethyst_block
setblock 48 66 -3 minecraft:polished_blackstone_bricks
setblock 80 66 -3 minecraft:polished_blackstone_bricks
setblock 49 66 -2 minecraft:amethyst_block
setblock 79 66 -2 minecraft:amethyst_block
setblock 52 66 -2 minecraft:chiseled_bookshelf[facing=east]
setblock 76 66 -2 minecraft:chiseled_bookshelf[facing=west]
setblock 48 66 -2 minecraft:polished_blackstone_bricks
setblock 80 66 -2 minecraft:polished_blackstone_bricks
setblock 49 66 -1 minecraft:amethyst_block
setblock 79 66 -1 minecraft:amethyst_block
setblock 52 66 -1 minecraft:chiseled_bookshelf[facing=east]
setblock 76 66 -1 minecraft:chiseled_bookshelf[facing=west]
setblock 48 66 -1 minecraft:polished_blackstone_bricks
setblock 80 66 -1 minecraft:polished_blackstone_bricks
setblock 49 66 0 minecraft:amethyst_block
setblock 79 66 0 minecraft:amethyst_block
setblock 52 66 0 minecraft:chiseled_bookshelf[facing=east]
setblock 76 66 0 minecraft:chiseled_bookshelf[facing=west]
setblock 48 66 0 minecraft:polished_blackstone_bricks
setblock 80 66 0 minecraft:polished_blackstone_bricks
setblock 49 66 1 minecraft:amethyst_block
setblock 79 66 1 minecraft:amethyst_block
setblock 48 66 1 minecraft:polished_blackstone_bricks
setblock 80 66 1 minecraft:polished_blackstone_bricks
setblock 49 66 2 minecraft:amethyst_block
setblock 79 66 2 minecraft:amethyst_block
setblock 48 66 2 minecraft:polished_blackstone_bricks
setblock 80 66 2 minecraft:polished_blackstone_bricks
setblock 49 66 3 minecraft:amethyst_block
setblock 79 66 3 minecraft:amethyst_block
setblock 48 66 3 minecraft:polished_blackstone_bricks
setblock 80 66 3 minecraft:polished_blackstone_bricks
setblock 49 66 4 minecraft:amethyst_block
setblock 79 66 4 minecraft:amethyst_block
setblock 48 66 4 minecraft:polished_blackstone_bricks
setblock 80 66 4 minecraft:polished_blackstone_bricks
setblock 49 66 5 minecraft:amethyst_block
setblock 79 66 5 minecraft:amethyst_block
setblock 52 66 5 minecraft:chiseled_bookshelf[facing=east]
setblock 76 66 5 minecraft:chiseled_bookshelf[facing=west]
setblock 48 66 5 minecraft:polished_blackstone_bricks
setblock 80 66 5 minecraft:polished_blackstone_bricks
setblock 49 66 6 minecraft:amethyst_block
setblock 79 66 6 minecraft:amethyst_block
setblock 52 66 6 minecraft:chiseled_bookshelf[facing=east]
setblock 76 66 6 minecraft:chiseled_bookshelf[facing=west]
setblock 48 66 6 minecraft:polished_blackstone_bricks
setblock 80 66 6 minecraft:polished_blackstone_bricks
setblock 49 66 7 minecraft:amethyst_block
setblock 79 66 7 minecraft:amethyst_block
setblock 52 66 7 minecraft:chiseled_bookshelf[facing=east]
setblock 76 66 7 minecraft:chiseled_bookshelf[facing=west]
setblock 48 66 7 minecraft:polished_blackstone_bricks
setblock 78 66 7 minecraft:polished_blackstone_bricks
setblock 80 66 7 minecraft:polished_blackstone_bricks
setblock 49 66 8 minecraft:amethyst_block
setblock 77 66 8 minecraft:amethyst_block
setblock 79 66 8 minecraft:amethyst_block
setblock 48 66 8 minecraft:polished_blackstone_bricks
setblock 80 66 8 minecraft:polished_blackstone_bricks
setblock 78 66 8 minecraft:sea_lantern
setblock 49 66 9 minecraft:amethyst_block
setblock 79 66 9 minecraft:amethyst_block
setblock 48 66 9 minecraft:polished_blackstone_bricks
setblock 78 66 9 minecraft:polished_blackstone_bricks
setblock 80 66 9 minecraft:polished_blackstone_bricks
setblock 49 66 10 minecraft:amethyst_block
setblock 79 66 10 minecraft:amethyst_block
setblock 48 66 10 minecraft:polished_blackstone_bricks
setblock 80 66 10 minecraft:polished_blackstone_bricks
setblock 49 66 11 minecraft:amethyst_block
setblock 79 66 11 minecraft:amethyst_block
setblock 48 66 11 minecraft:polished_blackstone_bricks
setblock 80 66 11 minecraft:polished_blackstone_bricks
setblock 49 66 12 minecraft:amethyst_block
setblock 79 66 12 minecraft:amethyst_block
setblock 48 66 12 minecraft:polished_blackstone_bricks
setblock 80 66 12 minecraft:polished_blackstone_bricks
setblock 49 66 13 minecraft:amethyst_block
setblock 79 66 13 minecraft:amethyst_block
setblock 48 66 13 minecraft:polished_blackstone_bricks
setblock 80 66 13 minecraft:polished_blackstone_bricks
setblock 49 66 14 minecraft:amethyst_block
setblock 79 66 14 minecraft:amethyst_block
setblock 48 66 14 minecraft:polished_blackstone_bricks
setblock 80 66 14 minecraft:polished_blackstone_bricks
fill 49 66 15 79 66 15 minecraft:amethyst_block
setblock 48 66 15 minecraft:polished_blackstone_bricks
setblock 80 66 15 minecraft:polished_blackstone_bricks
fill 48 66 16 80 66 16 minecraft:polished_blackstone_bricks
fill 48 67 -16 51 67 -16 minecraft:polished_blackstone_bricks
fill 53 67 -16 57 67 -16 minecraft:polished_blackstone_bricks
fill 59 67 -16 63 67 -16 minecraft:polished_blackstone_bricks
fill 65 67 -16 69 67 -16 minecraft:polished_blackstone_bricks
fill 71 67 -16 75 67 -16 minecraft:polished_blackstone_bricks
fill 77 67 -16 80 67 -16 minecraft:polished_blackstone_bricks
setblock 52 67 -16 minecraft:sea_lantern
setblock 58 67 -16 minecraft:sea_lantern
setblock 64 67 -16 minecraft:sea_lantern
setblock 70 67 -16 minecraft:sea_lantern
setblock 76 67 -16 minecraft:sea_lantern
setblock 48 67 -15 minecraft:polished_blackstone_bricks
setblock 80 67 -15 minecraft:polished_blackstone_bricks
setblock 52 67 -15 minecraft:purple_stained_glass
setblock 58 67 -15 minecraft:purple_stained_glass
setblock 64 67 -15 minecraft:purple_stained_glass
setblock 70 67 -15 minecraft:purple_stained_glass
setblock 76 67 -15 minecraft:purple_stained_glass
setblock 48 67 -14 minecraft:polished_blackstone_bricks
setblock 80 67 -14 minecraft:polished_blackstone_bricks
setblock 48 67 -13 minecraft:polished_blackstone_bricks
setblock 80 67 -13 minecraft:polished_blackstone_bricks
setblock 49 67 -12 minecraft:purple_stained_glass
setblock 79 67 -12 minecraft:purple_stained_glass
setblock 48 67 -12 minecraft:sea_lantern
setblock 80 67 -12 minecraft:sea_lantern
setblock 52 67 -11 minecraft:chiseled_bookshelf[facing=east]
setblock 76 67 -11 minecraft:chiseled_bookshelf[facing=west]
setblock 48 67 -11 minecraft:polished_blackstone_bricks
setblock 80 67 -11 minecraft:polished_blackstone_bricks
setblock 56 67 -10 minecraft:blue_stained_glass
setblock 52 67 -10 minecraft:chiseled_bookshelf[facing=east]
setblock 76 67 -10 minecraft:chiseled_bookshelf[facing=west]
setblock 72 67 -10 minecraft:green_stained_glass
setblock 67 67 -10 minecraft:orange_stained_glass
setblock 48 67 -10 minecraft:polished_blackstone_bricks
setblock 80 67 -10 minecraft:polished_blackstone_bricks
setblock 61 67 -10 minecraft:purple_stained_glass
setblock 55 67 -9 minecraft:blue_stained_glass
setblock 57 67 -9 minecraft:blue_stained_glass
setblock 52 67 -9 minecraft:chiseled_bookshelf[facing=east]
setblock 76 67 -9 minecraft:chiseled_bookshelf[facing=west]
setblock 71 67 -9 minecraft:green_stained_glass
setblock 73 67 -9 minecraft:green_stained_glass
setblock 66 67 -9 minecraft:orange_stained_glass
setblock 68 67 -9 minecraft:orange_stained_glass
setblock 48 67 -9 minecraft:polished_blackstone_bricks
setblock 80 67 -9 minecraft:polished_blackstone_bricks
setblock 60 67 -9 minecraft:purple_stained_glass
setblock 62 67 -9 minecraft:purple_stained_glass
setblock 56 67 -9 minecraft:sea_lantern
setblock 61 67 -9 minecraft:sea_lantern
setblock 67 67 -9 minecraft:sea_lantern
setblock 72 67 -9 minecraft:sea_lantern
setblock 56 67 -8 minecraft:blue_stained_glass
setblock 72 67 -8 minecraft:green_stained_glass
setblock 67 67 -8 minecraft:orange_stained_glass
setblock 48 67 -8 minecraft:polished_blackstone_bricks
setblock 80 67 -8 minecraft:polished_blackstone_bricks
setblock 61 67 -8 minecraft:purple_stained_glass
setblock 48 67 -7 minecraft:polished_blackstone_bricks
setblock 80 67 -7 minecraft:polished_blackstone_bricks
setblock 49 67 -6 minecraft:purple_stained_glass
setblock 79 67 -6 minecraft:purple_stained_glass
setblock 48 67 -6 minecraft:sea_lantern
setblock 80 67 -6 minecraft:sea_lantern
setblock 48 67 -5 minecraft:polished_blackstone_bricks
setblock 80 67 -5 minecraft:polished_blackstone_bricks
setblock 48 67 -4 minecraft:polished_blackstone_bricks
setblock 80 67 -4 minecraft:polished_blackstone_bricks
setblock 48 67 -3 minecraft:polished_blackstone_bricks
setblock 80 67 -3 minecraft:polished_blackstone_bricks
setblock 52 67 -2 minecraft:chiseled_bookshelf[facing=east]
setblock 76 67 -2 minecraft:chiseled_bookshelf[facing=west]
setblock 48 67 -2 minecraft:polished_blackstone_bricks
setblock 80 67 -2 minecraft:polished_blackstone_bricks
setblock 52 67 -1 minecraft:chiseled_bookshelf[facing=east]
setblock 76 67 -1 minecraft:chiseled_bookshelf[facing=west]
setblock 48 67 -1 minecraft:polished_blackstone_bricks
setblock 80 67 -1 minecraft:polished_blackstone_bricks
setblock 52 67 0 minecraft:chiseled_bookshelf[facing=east]
setblock 76 67 0 minecraft:chiseled_bookshelf[facing=west]
setblock 49 67 0 minecraft:purple_stained_glass
setblock 79 67 0 minecraft:purple_stained_glass
setblock 48 67 0 minecraft:sea_lantern
setblock 80 67 0 minecraft:sea_lantern
setblock 48 67 1 minecraft:polished_blackstone_bricks
setblock 80 67 1 minecraft:polished_blackstone_bricks
setblock 48 67 2 minecraft:polished_blackstone_bricks
setblock 80 67 2 minecraft:polished_blackstone_bricks
setblock 48 67 3 minecraft:polished_blackstone_bricks
setblock 80 67 3 minecraft:polished_blackstone_bricks
setblock 48 67 4 minecraft:polished_blackstone_bricks
setblock 80 67 4 minecraft:polished_blackstone_bricks
setblock 52 67 5 minecraft:chiseled_bookshelf[facing=east]
setblock 76 67 5 minecraft:chiseled_bookshelf[facing=west]
setblock 48 67 5 minecraft:polished_blackstone_bricks
setblock 80 67 5 minecraft:polished_blackstone_bricks
setblock 52 67 6 minecraft:chiseled_bookshelf[facing=east]
setblock 76 67 6 minecraft:chiseled_bookshelf[facing=west]
setblock 49 67 6 minecraft:purple_stained_glass
setblock 79 67 6 minecraft:purple_stained_glass
setblock 48 67 6 minecraft:sea_lantern
setblock 80 67 6 minecraft:sea_lantern
setblock 52 67 7 minecraft:chiseled_bookshelf[facing=east]
setblock 76 67 7 minecraft:chiseled_bookshelf[facing=west]
setblock 48 67 7 minecraft:polished_blackstone_bricks
setblock 78 67 7 minecraft:polished_blackstone_bricks
setblock 80 67 7 minecraft:polished_blackstone_bricks
setblock 48 67 8 minecraft:polished_blackstone_bricks
setblock 78 67 8 minecraft:polished_blackstone_bricks
setblock 80 67 8 minecraft:polished_blackstone_bricks
setblock 77 67 8 minecraft:small_amethyst_bud[facing=up,waterlogged=false]
setblock 48 67 9 minecraft:polished_blackstone_bricks
setblock 78 67 9 minecraft:polished_blackstone_bricks
setblock 80 67 9 minecraft:polished_blackstone_bricks
setblock 48 67 10 minecraft:polished_blackstone_bricks
setblock 80 67 10 minecraft:polished_blackstone_bricks
setblock 48 67 11 minecraft:polished_blackstone_bricks
setblock 80 67 11 minecraft:polished_blackstone_bricks
setblock 49 67 12 minecraft:purple_stained_glass
setblock 79 67 12 minecraft:purple_stained_glass
setblock 48 67 12 minecraft:sea_lantern
setblock 80 67 12 minecraft:sea_lantern
setblock 48 67 13 minecraft:polished_blackstone_bricks
setblock 80 67 13 minecraft:polished_blackstone_bricks
setblock 48 67 14 minecraft:polished_blackstone_bricks
setblock 80 67 14 minecraft:polished_blackstone_bricks
setblock 48 67 15 minecraft:polished_blackstone_bricks
setblock 80 67 15 minecraft:polished_blackstone_bricks
setblock 52 67 15 minecraft:purple_stained_glass
setblock 58 67 15 minecraft:purple_stained_glass
setblock 64 67 15 minecraft:purple_stained_glass
setblock 70 67 15 minecraft:purple_stained_glass
setblock 76 67 15 minecraft:purple_stained_glass
fill 48 67 16 51 67 16 minecraft:polished_blackstone_bricks
fill 53 67 16 57 67 16 minecraft:polished_blackstone_bricks
fill 59 67 16 63 67 16 minecraft:polished_blackstone_bricks
fill 65 67 16 69 67 16 minecraft:polished_blackstone_bricks
fill 71 67 16 75 67 16 minecraft:polished_blackstone_bricks
fill 77 67 16 80 67 16 minecraft:polished_blackstone_bricks
setblock 52 67 16 minecraft:sea_lantern
setblock 58 67 16 minecraft:sea_lantern
setblock 64 67 16 minecraft:sea_lantern
setblock 70 67 16 minecraft:sea_lantern
setblock 76 67 16 minecraft:sea_lantern
fill 48 68 -16 51 68 -16 minecraft:polished_blackstone_bricks
fill 53 68 -16 57 68 -16 minecraft:polished_blackstone_bricks
fill 59 68 -16 63 68 -16 minecraft:polished_blackstone_bricks
fill 65 68 -16 69 68 -16 minecraft:polished_blackstone_bricks
fill 71 68 -16 75 68 -16 minecraft:polished_blackstone_bricks
fill 77 68 -16 80 68 -16 minecraft:polished_blackstone_bricks
setblock 52 68 -16 minecraft:sea_lantern
setblock 58 68 -16 minecraft:sea_lantern
setblock 64 68 -16 minecraft:sea_lantern
setblock 70 68 -16 minecraft:sea_lantern
setblock 76 68 -16 minecraft:sea_lantern
setblock 48 68 -15 minecraft:polished_blackstone_bricks
setblock 80 68 -15 minecraft:polished_blackstone_bricks
setblock 52 68 -15 minecraft:purple_stained_glass
setblock 58 68 -15 minecraft:purple_stained_glass
setblock 64 68 -15 minecraft:purple_stained_glass
setblock 70 68 -15 minecraft:purple_stained_glass
setblock 76 68 -15 minecraft:purple_stained_glass
setblock 48 68 -14 minecraft:polished_blackstone_bricks
setblock 80 68 -14 minecraft:polished_blackstone_bricks
setblock 48 68 -13 minecraft:polished_blackstone_bricks
setblock 80 68 -13 minecraft:polished_blackstone_bricks
setblock 49 68 -12 minecraft:purple_stained_glass
setblock 79 68 -12 minecraft:purple_stained_glass
setblock 48 68 -12 minecraft:sea_lantern
setblock 80 68 -12 minecraft:sea_lantern
setblock 52 68 -11 minecraft:chiseled_bookshelf[facing=east]
setblock 76 68 -11 minecraft:chiseled_bookshelf[facing=west]
setblock 48 68 -11 minecraft:polished_blackstone_bricks
setblock 80 68 -11 minecraft:polished_blackstone_bricks
setblock 56 68 -10 minecraft:blue_stained_glass
setblock 52 68 -10 minecraft:chiseled_bookshelf[facing=east]
setblock 76 68 -10 minecraft:chiseled_bookshelf[facing=west]
setblock 72 68 -10 minecraft:green_stained_glass
setblock 67 68 -10 minecraft:orange_stained_glass
setblock 48 68 -10 minecraft:polished_blackstone_bricks
setblock 80 68 -10 minecraft:polished_blackstone_bricks
setblock 61 68 -10 minecraft:purple_stained_glass
setblock 55 68 -9 minecraft:blue_stained_glass
setblock 57 68 -9 minecraft:blue_stained_glass
setblock 52 68 -9 minecraft:chiseled_bookshelf[facing=east]
setblock 76 68 -9 minecraft:chiseled_bookshelf[facing=west]
setblock 71 68 -9 minecraft:green_stained_glass
setblock 73 68 -9 minecraft:green_stained_glass
setblock 66 68 -9 minecraft:orange_stained_glass
setblock 68 68 -9 minecraft:orange_stained_glass
setblock 48 68 -9 minecraft:polished_blackstone_bricks
setblock 80 68 -9 minecraft:polished_blackstone_bricks
setblock 60 68 -9 minecraft:purple_stained_glass
setblock 62 68 -9 minecraft:purple_stained_glass
setblock 56 68 -9 minecraft:sea_lantern
setblock 61 68 -9 minecraft:sea_lantern
setblock 67 68 -9 minecraft:sea_lantern
setblock 72 68 -9 minecraft:sea_lantern
setblock 56 68 -8 minecraft:blue_stained_glass
setblock 72 68 -8 minecraft:green_stained_glass
setblock 67 68 -8 minecraft:orange_stained_glass
setblock 48 68 -8 minecraft:polished_blackstone_bricks
setblock 80 68 -8 minecraft:polished_blackstone_bricks
setblock 61 68 -8 minecraft:purple_stained_glass
setblock 48 68 -7 minecraft:polished_blackstone_bricks
setblock 80 68 -7 minecraft:polished_blackstone_bricks
setblock 49 68 -6 minecraft:purple_stained_glass
setblock 79 68 -6 minecraft:purple_stained_glass
setblock 48 68 -6 minecraft:sea_lantern
setblock 80 68 -6 minecraft:sea_lantern
setblock 48 68 -5 minecraft:polished_blackstone_bricks
setblock 80 68 -5 minecraft:polished_blackstone_bricks
setblock 48 68 -4 minecraft:polished_blackstone_bricks
setblock 80 68 -4 minecraft:polished_blackstone_bricks
setblock 48 68 -3 minecraft:polished_blackstone_bricks
setblock 80 68 -3 minecraft:polished_blackstone_bricks
setblock 52 68 -2 minecraft:chiseled_bookshelf[facing=east]
setblock 76 68 -2 minecraft:chiseled_bookshelf[facing=west]
setblock 48 68 -2 minecraft:polished_blackstone_bricks
setblock 80 68 -2 minecraft:polished_blackstone_bricks
setblock 52 68 -1 minecraft:chiseled_bookshelf[facing=east]
setblock 76 68 -1 minecraft:chiseled_bookshelf[facing=west]
setblock 48 68 -1 minecraft:polished_blackstone_bricks
setblock 80 68 -1 minecraft:polished_blackstone_bricks
setblock 52 68 0 minecraft:chiseled_bookshelf[facing=east]
setblock 76 68 0 minecraft:chiseled_bookshelf[facing=west]
setblock 49 68 0 minecraft:purple_stained_glass
setblock 79 68 0 minecraft:purple_stained_glass
setblock 48 68 0 minecraft:sea_lantern
setblock 80 68 0 minecraft:sea_lantern
setblock 48 68 1 minecraft:polished_blackstone_bricks
setblock 80 68 1 minecraft:polished_blackstone_bricks
setblock 48 68 2 minecraft:polished_blackstone_bricks
setblock 80 68 2 minecraft:polished_blackstone_bricks
setblock 48 68 3 minecraft:polished_blackstone_bricks
setblock 80 68 3 minecraft:polished_blackstone_bricks
setblock 48 68 4 minecraft:polished_blackstone_bricks
setblock 80 68 4 minecraft:polished_blackstone_bricks
setblock 52 68 5 minecraft:chiseled_bookshelf[facing=east]
setblock 76 68 5 minecraft:chiseled_bookshelf[facing=west]
setblock 48 68 5 minecraft:polished_blackstone_bricks
setblock 80 68 5 minecraft:polished_blackstone_bricks
setblock 52 68 6 minecraft:chiseled_bookshelf[facing=east]
setblock 76 68 6 minecraft:chiseled_bookshelf[facing=west]
setblock 49 68 6 minecraft:purple_stained_glass
setblock 79 68 6 minecraft:purple_stained_glass
setblock 48 68 6 minecraft:sea_lantern
setblock 80 68 6 minecraft:sea_lantern
setblock 52 68 7 minecraft:chiseled_bookshelf[facing=east]
setblock 76 68 7 minecraft:chiseled_bookshelf[facing=west]
setblock 48 68 7 minecraft:polished_blackstone_bricks
setblock 78 68 7 minecraft:polished_blackstone_bricks
setblock 80 68 7 minecraft:polished_blackstone_bricks
setblock 48 68 8 minecraft:polished_blackstone_bricks
setblock 78 68 8 minecraft:polished_blackstone_bricks
setblock 80 68 8 minecraft:polished_blackstone_bricks
setblock 48 68 9 minecraft:polished_blackstone_bricks
setblock 78 68 9 minecraft:polished_blackstone_bricks
setblock 80 68 9 minecraft:polished_blackstone_bricks
setblock 48 68 10 minecraft:polished_blackstone_bricks
setblock 80 68 10 minecraft:polished_blackstone_bricks
setblock 48 68 11 minecraft:polished_blackstone_bricks
setblock 80 68 11 minecraft:polished_blackstone_bricks
setblock 49 68 12 minecraft:purple_stained_glass
setblock 79 68 12 minecraft:purple_stained_glass
setblock 48 68 12 minecraft:sea_lantern
setblock 80 68 12 minecraft:sea_lantern
setblock 48 68 13 minecraft:polished_blackstone_bricks
setblock 80 68 13 minecraft:polished_blackstone_bricks
setblock 48 68 14 minecraft:polished_blackstone_bricks
setblock 80 68 14 minecraft:polished_blackstone_bricks
setblock 48 68 15 minecraft:polished_blackstone_bricks
setblock 80 68 15 minecraft:polished_blackstone_bricks
setblock 52 68 15 minecraft:purple_stained_glass
setblock 58 68 15 minecraft:purple_stained_glass
setblock 64 68 15 minecraft:purple_stained_glass
setblock 70 68 15 minecraft:purple_stained_glass
setblock 76 68 15 minecraft:purple_stained_glass
fill 48 68 16 51 68 16 minecraft:polished_blackstone_bricks
fill 53 68 16 57 68 16 minecraft:polished_blackstone_bricks
fill 59 68 16 63 68 16 minecraft:polished_blackstone_bricks
fill 65 68 16 69 68 16 minecraft:polished_blackstone_bricks
fill 71 68 16 75 68 16 minecraft:polished_blackstone_bricks
fill 77 68 16 80 68 16 minecraft:polished_blackstone_bricks
setblock 52 68 16 minecraft:sea_lantern
setblock 58 68 16 minecraft:sea_lantern
setblock 64 68 16 minecraft:sea_lantern
setblock 70 68 16 minecraft:sea_lantern
setblock 76 68 16 minecraft:sea_lantern
fill 48 69 -16 51 69 -16 minecraft:polished_blackstone_bricks
fill 53 69 -16 57 69 -16 minecraft:polished_blackstone_bricks
fill 59 69 -16 63 69 -16 minecraft:polished_blackstone_bricks
fill 65 69 -16 69 69 -16 minecraft:polished_blackstone_bricks
fill 71 69 -16 75 69 -16 minecraft:polished_blackstone_bricks
fill 77 69 -16 80 69 -16 minecraft:polished_blackstone_bricks
setblock 52 69 -16 minecraft:sea_lantern
setblock 58 69 -16 minecraft:sea_lantern
setblock 64 69 -16 minecraft:sea_lantern
setblock 70 69 -16 minecraft:sea_lantern
setblock 76 69 -16 minecraft:sea_lantern
setblock 48 69 -15 minecraft:polished_blackstone_bricks
setblock 80 69 -15 minecraft:polished_blackstone_bricks
setblock 52 69 -15 minecraft:purple_stained_glass
setblock 58 69 -15 minecraft:purple_stained_glass
setblock 64 69 -15 minecraft:purple_stained_glass
setblock 70 69 -15 minecraft:purple_stained_glass
setblock 76 69 -15 minecraft:purple_stained_glass
setblock 48 69 -14 minecraft:polished_blackstone_bricks
setblock 80 69 -14 minecraft:polished_blackstone_bricks
setblock 48 69 -13 minecraft:polished_blackstone_bricks
setblock 80 69 -13 minecraft:polished_blackstone_bricks
setblock 49 69 -12 minecraft:purple_stained_glass
setblock 79 69 -12 minecraft:purple_stained_glass
setblock 48 69 -12 minecraft:sea_lantern
setblock 80 69 -12 minecraft:sea_lantern
setblock 48 69 -11 minecraft:polished_blackstone_bricks
setblock 80 69 -11 minecraft:polished_blackstone_bricks
fill 51 69 -11 53 69 -11 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 75 69 -11 77 69 -11 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock 56 69 -10 minecraft:blue_stained_glass
setblock 72 69 -10 minecraft:green_stained_glass
setblock 67 69 -10 minecraft:orange_stained_glass
setblock 48 69 -10 minecraft:polished_blackstone_bricks
setblock 80 69 -10 minecraft:polished_blackstone_bricks
fill 51 69 -10 53 69 -10 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 75 69 -10 77 69 -10 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock 61 69 -10 minecraft:purple_stained_glass
setblock 55 69 -9 minecraft:blue_stained_glass
setblock 57 69 -9 minecraft:blue_stained_glass
setblock 71 69 -9 minecraft:green_stained_glass
setblock 73 69 -9 minecraft:green_stained_glass
setblock 66 69 -9 minecraft:orange_stained_glass
setblock 68 69 -9 minecraft:orange_stained_glass
setblock 48 69 -9 minecraft:polished_blackstone_bricks
setblock 80 69 -9 minecraft:polished_blackstone_bricks
fill 51 69 -9 53 69 -9 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 75 69 -9 77 69 -9 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock 60 69 -9 minecraft:purple_stained_glass
setblock 62 69 -9 minecraft:purple_stained_glass
setblock 56 69 -9 minecraft:sea_lantern
setblock 61 69 -9 minecraft:sea_lantern
setblock 67 69 -9 minecraft:sea_lantern
setblock 72 69 -9 minecraft:sea_lantern
setblock 56 69 -8 minecraft:blue_stained_glass
setblock 72 69 -8 minecraft:green_stained_glass
setblock 67 69 -8 minecraft:orange_stained_glass
setblock 48 69 -8 minecraft:polished_blackstone_bricks
setblock 80 69 -8 minecraft:polished_blackstone_bricks
setblock 61 69 -8 minecraft:purple_stained_glass
setblock 48 69 -7 minecraft:polished_blackstone_bricks
setblock 80 69 -7 minecraft:polished_blackstone_bricks
setblock 49 69 -6 minecraft:purple_stained_glass
setblock 79 69 -6 minecraft:purple_stained_glass
setblock 48 69 -6 minecraft:sea_lantern
setblock 80 69 -6 minecraft:sea_lantern
setblock 48 69 -5 minecraft:polished_blackstone_bricks
setblock 80 69 -5 minecraft:polished_blackstone_bricks
setblock 48 69 -4 minecraft:polished_blackstone_bricks
setblock 80 69 -4 minecraft:polished_blackstone_bricks
setblock 48 69 -3 minecraft:polished_blackstone_bricks
setblock 80 69 -3 minecraft:polished_blackstone_bricks
setblock 48 69 -2 minecraft:polished_blackstone_bricks
setblock 80 69 -2 minecraft:polished_blackstone_bricks
fill 51 69 -2 53 69 -2 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 75 69 -2 77 69 -2 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock 48 69 -1 minecraft:polished_blackstone_bricks
setblock 80 69 -1 minecraft:polished_blackstone_bricks
fill 51 69 -1 53 69 -1 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 75 69 -1 77 69 -1 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 51 69 0 53 69 0 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 75 69 0 77 69 0 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock 49 69 0 minecraft:purple_stained_glass
setblock 79 69 0 minecraft:purple_stained_glass
setblock 48 69 0 minecraft:sea_lantern
setblock 80 69 0 minecraft:sea_lantern
setblock 48 69 1 minecraft:polished_blackstone_bricks
setblock 80 69 1 minecraft:polished_blackstone_bricks
setblock 48 69 2 minecraft:polished_blackstone_bricks
setblock 80 69 2 minecraft:polished_blackstone_bricks
setblock 48 69 3 minecraft:polished_blackstone_bricks
setblock 80 69 3 minecraft:polished_blackstone_bricks
setblock 48 69 4 minecraft:polished_blackstone_bricks
setblock 80 69 4 minecraft:polished_blackstone_bricks
setblock 48 69 5 minecraft:polished_blackstone_bricks
setblock 80 69 5 minecraft:polished_blackstone_bricks
fill 51 69 5 53 69 5 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 75 69 5 77 69 5 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 51 69 6 53 69 6 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 75 69 6 77 69 6 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock 49 69 6 minecraft:purple_stained_glass
setblock 79 69 6 minecraft:purple_stained_glass
setblock 48 69 6 minecraft:sea_lantern
setblock 80 69 6 minecraft:sea_lantern
setblock 48 69 7 minecraft:polished_blackstone_bricks
setblock 80 69 7 minecraft:polished_blackstone_bricks
fill 51 69 7 53 69 7 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
fill 75 69 7 77 69 7 minecraft:polished_blackstone_slab[type=bottom,waterlogged=false]
setblock 48 69 8 minecraft:polished_blackstone_bricks
setblock 80 69 8 minecraft:polished_blackstone_bricks
setblock 48 69 9 minecraft:polished_blackstone_bricks
setblock 80 69 9 minecraft:polished_blackstone_bricks
setblock 48 69 10 minecraft:polished_blackstone_bricks
setblock 80 69 10 minecraft:polished_blackstone_bricks
setblock 48 69 11 minecraft:polished_blackstone_bricks
setblock 80 69 11 minecraft:polished_blackstone_bricks
setblock 49 69 12 minecraft:purple_stained_glass
setblock 79 69 12 minecraft:purple_stained_glass
setblock 48 69 12 minecraft:sea_lantern
setblock 80 69 12 minecraft:sea_lantern
setblock 48 69 13 minecraft:polished_blackstone_bricks
setblock 80 69 13 minecraft:polished_blackstone_bricks
setblock 48 69 14 minecraft:polished_blackstone_bricks
setblock 80 69 14 minecraft:polished_blackstone_bricks
setblock 48 69 15 minecraft:polished_blackstone_bricks
setblock 80 69 15 minecraft:polished_blackstone_bricks
setblock 52 69 15 minecraft:purple_stained_glass
setblock 58 69 15 minecraft:purple_stained_glass
setblock 64 69 15 minecraft:purple_stained_glass
setblock 70 69 15 minecraft:purple_stained_glass
setblock 76 69 15 minecraft:purple_stained_glass
fill 48 69 16 51 69 16 minecraft:polished_blackstone_bricks
fill 53 69 16 57 69 16 minecraft:polished_blackstone_bricks
fill 59 69 16 63 69 16 minecraft:polished_blackstone_bricks
fill 65 69 16 69 69 16 minecraft:polished_blackstone_bricks
fill 71 69 16 75 69 16 minecraft:polished_blackstone_bricks
fill 77 69 16 80 69 16 minecraft:polished_blackstone_bricks
setblock 52 69 16 minecraft:sea_lantern
setblock 58 69 16 minecraft:sea_lantern
setblock 64 69 16 minecraft:sea_lantern
setblock 70 69 16 minecraft:sea_lantern
setblock 76 69 16 minecraft:sea_lantern
fill 48 70 -16 51 70 -16 minecraft:polished_blackstone_bricks
fill 53 70 -16 57 70 -16 minecraft:polished_blackstone_bricks
fill 59 70 -16 63 70 -16 minecraft:polished_blackstone_bricks
fill 65 70 -16 69 70 -16 minecraft:polished_blackstone_bricks
fill 71 70 -16 75 70 -16 minecraft:polished_blackstone_bricks
fill 77 70 -16 80 70 -16 minecraft:polished_blackstone_bricks
setblock 52 70 -16 minecraft:sea_lantern
setblock 58 70 -16 minecraft:sea_lantern
setblock 64 70 -16 minecraft:sea_lantern
setblock 70 70 -16 minecraft:sea_lantern
setblock 76 70 -16 minecraft:sea_lantern
setblock 48 70 -15 minecraft:polished_blackstone_bricks
setblock 80 70 -15 minecraft:polished_blackstone_bricks
setblock 52 70 -15 minecraft:purple_stained_glass
setblock 58 70 -15 minecraft:purple_stained_glass
setblock 64 70 -15 minecraft:purple_stained_glass
setblock 70 70 -15 minecraft:purple_stained_glass
setblock 76 70 -15 minecraft:purple_stained_glass
setblock 48 70 -14 minecraft:polished_blackstone_bricks
setblock 80 70 -14 minecraft:polished_blackstone_bricks
setblock 48 70 -13 minecraft:polished_blackstone_bricks
setblock 80 70 -13 minecraft:polished_blackstone_bricks
setblock 49 70 -12 minecraft:purple_stained_glass
setblock 79 70 -12 minecraft:purple_stained_glass
setblock 48 70 -12 minecraft:sea_lantern
setblock 80 70 -12 minecraft:sea_lantern
setblock 48 70 -11 minecraft:polished_blackstone_bricks
setblock 80 70 -11 minecraft:polished_blackstone_bricks
setblock 56 70 -10 minecraft:blue_stained_glass
setblock 72 70 -10 minecraft:green_stained_glass
setblock 67 70 -10 minecraft:orange_stained_glass
setblock 48 70 -10 minecraft:polished_blackstone_bricks
setblock 80 70 -10 minecraft:polished_blackstone_bricks
setblock 61 70 -10 minecraft:purple_stained_glass
setblock 55 70 -9 minecraft:blue_stained_glass
setblock 57 70 -9 minecraft:blue_stained_glass
setblock 71 70 -9 minecraft:green_stained_glass
setblock 73 70 -9 minecraft:green_stained_glass
setblock 66 70 -9 minecraft:orange_stained_glass
setblock 68 70 -9 minecraft:orange_stained_glass
setblock 48 70 -9 minecraft:polished_blackstone_bricks
setblock 80 70 -9 minecraft:polished_blackstone_bricks
setblock 60 70 -9 minecraft:purple_stained_glass
setblock 62 70 -9 minecraft:purple_stained_glass
setblock 56 70 -9 minecraft:sea_lantern
setblock 61 70 -9 minecraft:sea_lantern
setblock 67 70 -9 minecraft:sea_lantern
setblock 72 70 -9 minecraft:sea_lantern
setblock 56 70 -8 minecraft:blue_stained_glass
setblock 72 70 -8 minecraft:green_stained_glass
setblock 67 70 -8 minecraft:orange_stained_glass
setblock 48 70 -8 minecraft:polished_blackstone_bricks
setblock 80 70 -8 minecraft:polished_blackstone_bricks
setblock 61 70 -8 minecraft:purple_stained_glass
setblock 48 70 -7 minecraft:polished_blackstone_bricks
setblock 80 70 -7 minecraft:polished_blackstone_bricks
setblock 49 70 -6 minecraft:purple_stained_glass
setblock 79 70 -6 minecraft:purple_stained_glass
setblock 48 70 -6 minecraft:sea_lantern
setblock 80 70 -6 minecraft:sea_lantern
setblock 48 70 -5 minecraft:polished_blackstone_bricks
setblock 80 70 -5 minecraft:polished_blackstone_bricks
setblock 48 70 -4 minecraft:polished_blackstone_bricks
setblock 80 70 -4 minecraft:polished_blackstone_bricks
setblock 48 70 -3 minecraft:polished_blackstone_bricks
setblock 80 70 -3 minecraft:polished_blackstone_bricks
setblock 48 70 -2 minecraft:polished_blackstone_bricks
setblock 80 70 -2 minecraft:polished_blackstone_bricks
setblock 48 70 -1 minecraft:polished_blackstone_bricks
setblock 80 70 -1 minecraft:polished_blackstone_bricks
setblock 49 70 0 minecraft:purple_stained_glass
setblock 79 70 0 minecraft:purple_stained_glass
setblock 48 70 0 minecraft:sea_lantern
setblock 80 70 0 minecraft:sea_lantern
setblock 48 70 1 minecraft:polished_blackstone_bricks
setblock 80 70 1 minecraft:polished_blackstone_bricks
setblock 48 70 2 minecraft:polished_blackstone_bricks
setblock 80 70 2 minecraft:polished_blackstone_bricks
setblock 48 70 3 minecraft:polished_blackstone_bricks
setblock 80 70 3 minecraft:polished_blackstone_bricks
setblock 48 70 4 minecraft:polished_blackstone_bricks
setblock 80 70 4 minecraft:polished_blackstone_bricks
setblock 48 70 5 minecraft:polished_blackstone_bricks
setblock 80 70 5 minecraft:polished_blackstone_bricks
setblock 49 70 6 minecraft:purple_stained_glass
setblock 79 70 6 minecraft:purple_stained_glass
setblock 48 70 6 minecraft:sea_lantern
setblock 80 70 6 minecraft:sea_lantern
setblock 48 70 7 minecraft:polished_blackstone_bricks
setblock 80 70 7 minecraft:polished_blackstone_bricks
setblock 48 70 8 minecraft:polished_blackstone_bricks
setblock 80 70 8 minecraft:polished_blackstone_bricks
setblock 48 70 9 minecraft:polished_blackstone_bricks
setblock 80 70 9 minecraft:polished_blackstone_bricks
setblock 48 70 10 minecraft:polished_blackstone_bricks
setblock 80 70 10 minecraft:polished_blackstone_bricks
setblock 48 70 11 minecraft:polished_blackstone_bricks
setblock 80 70 11 minecraft:polished_blackstone_bricks
setblock 49 70 12 minecraft:purple_stained_glass
setblock 79 70 12 minecraft:purple_stained_glass
setblock 48 70 12 minecraft:sea_lantern
setblock 80 70 12 minecraft:sea_lantern
setblock 48 70 13 minecraft:polished_blackstone_bricks
setblock 80 70 13 minecraft:polished_blackstone_bricks
setblock 48 70 14 minecraft:polished_blackstone_bricks
setblock 80 70 14 minecraft:polished_blackstone_bricks
setblock 48 70 15 minecraft:polished_blackstone_bricks
setblock 80 70 15 minecraft:polished_blackstone_bricks
setblock 52 70 15 minecraft:purple_stained_glass
setblock 58 70 15 minecraft:purple_stained_glass
setblock 64 70 15 minecraft:purple_stained_glass
setblock 70 70 15 minecraft:purple_stained_glass
setblock 76 70 15 minecraft:purple_stained_glass
fill 48 70 16 51 70 16 minecraft:polished_blackstone_bricks
fill 53 70 16 57 70 16 minecraft:polished_blackstone_bricks
fill 59 70 16 63 70 16 minecraft:polished_blackstone_bricks
fill 65 70 16 69 70 16 minecraft:polished_blackstone_bricks
fill 71 70 16 75 70 16 minecraft:polished_blackstone_bricks
fill 77 70 16 80 70 16 minecraft:polished_blackstone_bricks
setblock 52 70 16 minecraft:sea_lantern
setblock 58 70 16 minecraft:sea_lantern
setblock 64 70 16 minecraft:sea_lantern
setblock 70 70 16 minecraft:sea_lantern
setblock 76 70 16 minecraft:sea_lantern
fill 48 71 -16 51 71 -16 minecraft:polished_blackstone_bricks
fill 53 71 -16 57 71 -16 minecraft:polished_blackstone_bricks
fill 59 71 -16 63 71 -16 minecraft:polished_blackstone_bricks
fill 65 71 -16 69 71 -16 minecraft:polished_blackstone_bricks
fill 71 71 -16 75 71 -16 minecraft:polished_blackstone_bricks
fill 77 71 -16 80 71 -16 minecraft:polished_blackstone_bricks
setblock 52 71 -16 minecraft:sea_lantern
setblock 58 71 -16 minecraft:sea_lantern
setblock 64 71 -16 minecraft:sea_lantern
setblock 70 71 -16 minecraft:sea_lantern
setblock 76 71 -16 minecraft:sea_lantern
setblock 48 71 -15 minecraft:polished_blackstone_bricks
setblock 80 71 -15 minecraft:polished_blackstone_bricks
setblock 52 71 -15 minecraft:purple_stained_glass
setblock 58 71 -15 minecraft:purple_stained_glass
setblock 64 71 -15 minecraft:purple_stained_glass
setblock 70 71 -15 minecraft:purple_stained_glass
setblock 76 71 -15 minecraft:purple_stained_glass
setblock 48 71 -14 minecraft:polished_blackstone_bricks
setblock 80 71 -14 minecraft:polished_blackstone_bricks
setblock 48 71 -13 minecraft:polished_blackstone_bricks
setblock 80 71 -13 minecraft:polished_blackstone_bricks
setblock 49 71 -12 minecraft:purple_stained_glass
setblock 79 71 -12 minecraft:purple_stained_glass
setblock 48 71 -12 minecraft:sea_lantern
setblock 80 71 -12 minecraft:sea_lantern
setblock 48 71 -11 minecraft:polished_blackstone_bricks
setblock 80 71 -11 minecraft:polished_blackstone_bricks
setblock 56 71 -10 minecraft:blue_stained_glass
setblock 72 71 -10 minecraft:green_stained_glass
setblock 67 71 -10 minecraft:orange_stained_glass
setblock 48 71 -10 minecraft:polished_blackstone_bricks
setblock 80 71 -10 minecraft:polished_blackstone_bricks
setblock 61 71 -10 minecraft:purple_stained_glass
setblock 55 71 -9 minecraft:blue_stained_glass
setblock 57 71 -9 minecraft:blue_stained_glass
setblock 71 71 -9 minecraft:green_stained_glass
setblock 73 71 -9 minecraft:green_stained_glass
setblock 66 71 -9 minecraft:orange_stained_glass
setblock 68 71 -9 minecraft:orange_stained_glass
setblock 48 71 -9 minecraft:polished_blackstone_bricks
setblock 80 71 -9 minecraft:polished_blackstone_bricks
setblock 60 71 -9 minecraft:purple_stained_glass
setblock 62 71 -9 minecraft:purple_stained_glass
setblock 56 71 -9 minecraft:sea_lantern
setblock 61 71 -9 minecraft:sea_lantern
setblock 67 71 -9 minecraft:sea_lantern
setblock 72 71 -9 minecraft:sea_lantern
setblock 56 71 -8 minecraft:blue_stained_glass
setblock 72 71 -8 minecraft:green_stained_glass
setblock 67 71 -8 minecraft:orange_stained_glass
setblock 48 71 -8 minecraft:polished_blackstone_bricks
setblock 80 71 -8 minecraft:polished_blackstone_bricks
setblock 61 71 -8 minecraft:purple_stained_glass
setblock 48 71 -7 minecraft:polished_blackstone_bricks
setblock 80 71 -7 minecraft:polished_blackstone_bricks
setblock 49 71 -6 minecraft:purple_stained_glass
setblock 79 71 -6 minecraft:purple_stained_glass
setblock 48 71 -6 minecraft:sea_lantern
setblock 80 71 -6 minecraft:sea_lantern
setblock 48 71 -5 minecraft:polished_blackstone_bricks
setblock 80 71 -5 minecraft:polished_blackstone_bricks
setblock 48 71 -4 minecraft:polished_blackstone_bricks
setblock 80 71 -4 minecraft:polished_blackstone_bricks
setblock 48 71 -3 minecraft:polished_blackstone_bricks
setblock 80 71 -3 minecraft:polished_blackstone_bricks
setblock 48 71 -2 minecraft:polished_blackstone_bricks
setblock 80 71 -2 minecraft:polished_blackstone_bricks
setblock 48 71 -1 minecraft:polished_blackstone_bricks
setblock 80 71 -1 minecraft:polished_blackstone_bricks
setblock 49 71 0 minecraft:purple_stained_glass
setblock 79 71 0 minecraft:purple_stained_glass
setblock 48 71 0 minecraft:sea_lantern
setblock 80 71 0 minecraft:sea_lantern
setblock 48 71 1 minecraft:polished_blackstone_bricks
setblock 80 71 1 minecraft:polished_blackstone_bricks
setblock 48 71 2 minecraft:polished_blackstone_bricks
setblock 80 71 2 minecraft:polished_blackstone_bricks
setblock 48 71 3 minecraft:polished_blackstone_bricks
setblock 80 71 3 minecraft:polished_blackstone_bricks
setblock 48 71 4 minecraft:polished_blackstone_bricks
setblock 80 71 4 minecraft:polished_blackstone_bricks
setblock 48 71 5 minecraft:polished_blackstone_bricks
setblock 80 71 5 minecraft:polished_blackstone_bricks
setblock 49 71 6 minecraft:purple_stained_glass
setblock 79 71 6 minecraft:purple_stained_glass
setblock 48 71 6 minecraft:sea_lantern
setblock 80 71 6 minecraft:sea_lantern
setblock 48 71 7 minecraft:polished_blackstone_bricks
setblock 80 71 7 minecraft:polished_blackstone_bricks
setblock 48 71 8 minecraft:polished_blackstone_bricks
setblock 80 71 8 minecraft:polished_blackstone_bricks
setblock 48 71 9 minecraft:polished_blackstone_bricks
setblock 80 71 9 minecraft:polished_blackstone_bricks
setblock 48 71 10 minecraft:polished_blackstone_bricks
setblock 80 71 10 minecraft:polished_blackstone_bricks
setblock 48 71 11 minecraft:polished_blackstone_bricks
setblock 80 71 11 minecraft:polished_blackstone_bricks
setblock 49 71 12 minecraft:purple_stained_glass
setblock 79 71 12 minecraft:purple_stained_glass
setblock 48 71 12 minecraft:sea_lantern
setblock 80 71 12 minecraft:sea_lantern
setblock 48 71 13 minecraft:polished_blackstone_bricks
setblock 80 71 13 minecraft:polished_blackstone_bricks
setblock 48 71 14 minecraft:polished_blackstone_bricks
setblock 80 71 14 minecraft:polished_blackstone_bricks
setblock 48 71 15 minecraft:polished_blackstone_bricks
setblock 80 71 15 minecraft:polished_blackstone_bricks
setblock 52 71 15 minecraft:purple_stained_glass
setblock 58 71 15 minecraft:purple_stained_glass
setblock 64 71 15 minecraft:purple_stained_glass
setblock 70 71 15 minecraft:purple_stained_glass
setblock 76 71 15 minecraft:purple_stained_glass
fill 48 71 16 51 71 16 minecraft:polished_blackstone_bricks
fill 53 71 16 57 71 16 minecraft:polished_blackstone_bricks
fill 59 71 16 63 71 16 minecraft:polished_blackstone_bricks
fill 65 71 16 69 71 16 minecraft:polished_blackstone_bricks
fill 71 71 16 75 71 16 minecraft:polished_blackstone_bricks
fill 77 71 16 80 71 16 minecraft:polished_blackstone_bricks
setblock 52 71 16 minecraft:sea_lantern
setblock 58 71 16 minecraft:sea_lantern
setblock 64 71 16 minecraft:sea_lantern
setblock 70 71 16 minecraft:sea_lantern
setblock 76 71 16 minecraft:sea_lantern
fill 48 72 -16 51 72 -16 minecraft:polished_blackstone_bricks
fill 53 72 -16 57 72 -16 minecraft:polished_blackstone_bricks
fill 59 72 -16 63 72 -16 minecraft:polished_blackstone_bricks
fill 65 72 -16 69 72 -16 minecraft:polished_blackstone_bricks
fill 71 72 -16 75 72 -16 minecraft:polished_blackstone_bricks
fill 77 72 -16 80 72 -16 minecraft:polished_blackstone_bricks
setblock 52 72 -16 minecraft:sea_lantern
setblock 58 72 -16 minecraft:sea_lantern
setblock 64 72 -16 minecraft:sea_lantern
setblock 70 72 -16 minecraft:sea_lantern
setblock 76 72 -16 minecraft:sea_lantern
setblock 48 72 -15 minecraft:polished_blackstone_bricks
setblock 80 72 -15 minecraft:polished_blackstone_bricks
setblock 52 72 -15 minecraft:purple_stained_glass
setblock 58 72 -15 minecraft:purple_stained_glass
setblock 64 72 -15 minecraft:purple_stained_glass
setblock 70 72 -15 minecraft:purple_stained_glass
setblock 76 72 -15 minecraft:purple_stained_glass
setblock 48 72 -14 minecraft:polished_blackstone_bricks
setblock 80 72 -14 minecraft:polished_blackstone_bricks
setblock 48 72 -13 minecraft:polished_blackstone_bricks
setblock 80 72 -13 minecraft:polished_blackstone_bricks
setblock 49 72 -12 minecraft:purple_stained_glass
setblock 79 72 -12 minecraft:purple_stained_glass
setblock 48 72 -12 minecraft:sea_lantern
setblock 80 72 -12 minecraft:sea_lantern
setblock 48 72 -11 minecraft:polished_blackstone_bricks
setblock 80 72 -11 minecraft:polished_blackstone_bricks
setblock 56 72 -10 minecraft:blue_stained_glass
setblock 72 72 -10 minecraft:green_stained_glass
setblock 67 72 -10 minecraft:orange_stained_glass
setblock 48 72 -10 minecraft:polished_blackstone_bricks
setblock 80 72 -10 minecraft:polished_blackstone_bricks
setblock 61 72 -10 minecraft:purple_stained_glass
setblock 55 72 -9 minecraft:blue_stained_glass
setblock 57 72 -9 minecraft:blue_stained_glass
setblock 71 72 -9 minecraft:green_stained_glass
setblock 73 72 -9 minecraft:green_stained_glass
setblock 66 72 -9 minecraft:orange_stained_glass
setblock 68 72 -9 minecraft:orange_stained_glass
setblock 48 72 -9 minecraft:polished_blackstone_bricks
setblock 80 72 -9 minecraft:polished_blackstone_bricks
setblock 60 72 -9 minecraft:purple_stained_glass
setblock 62 72 -9 minecraft:purple_stained_glass
setblock 56 72 -9 minecraft:sea_lantern
setblock 61 72 -9 minecraft:sea_lantern
setblock 67 72 -9 minecraft:sea_lantern
setblock 72 72 -9 minecraft:sea_lantern
setblock 56 72 -8 minecraft:blue_stained_glass
setblock 72 72 -8 minecraft:green_stained_glass
setblock 67 72 -8 minecraft:orange_stained_glass
setblock 48 72 -8 minecraft:polished_blackstone_bricks
setblock 80 72 -8 minecraft:polished_blackstone_bricks
setblock 61 72 -8 minecraft:purple_stained_glass
setblock 48 72 -7 minecraft:polished_blackstone_bricks
setblock 80 72 -7 minecraft:polished_blackstone_bricks
setblock 49 72 -6 minecraft:purple_stained_glass
setblock 79 72 -6 minecraft:purple_stained_glass
setblock 48 72 -6 minecraft:sea_lantern
setblock 80 72 -6 minecraft:sea_lantern
setblock 48 72 -5 minecraft:polished_blackstone_bricks
setblock 80 72 -5 minecraft:polished_blackstone_bricks
setblock 48 72 -4 minecraft:polished_blackstone_bricks
setblock 80 72 -4 minecraft:polished_blackstone_bricks
setblock 48 72 -3 minecraft:polished_blackstone_bricks
setblock 80 72 -3 minecraft:polished_blackstone_bricks
setblock 48 72 -2 minecraft:polished_blackstone_bricks
setblock 80 72 -2 minecraft:polished_blackstone_bricks
setblock 48 72 -1 minecraft:polished_blackstone_bricks
setblock 80 72 -1 minecraft:polished_blackstone_bricks
setblock 49 72 0 minecraft:purple_stained_glass
setblock 79 72 0 minecraft:purple_stained_glass
setblock 48 72 0 minecraft:sea_lantern
setblock 80 72 0 minecraft:sea_lantern
setblock 48 72 1 minecraft:polished_blackstone_bricks
setblock 80 72 1 minecraft:polished_blackstone_bricks
setblock 48 72 2 minecraft:polished_blackstone_bricks
setblock 80 72 2 minecraft:polished_blackstone_bricks
setblock 48 72 3 minecraft:polished_blackstone_bricks
setblock 80 72 3 minecraft:polished_blackstone_bricks
setblock 48 72 4 minecraft:polished_blackstone_bricks
setblock 80 72 4 minecraft:polished_blackstone_bricks
setblock 48 72 5 minecraft:polished_blackstone_bricks
setblock 80 72 5 minecraft:polished_blackstone_bricks
setblock 49 72 6 minecraft:purple_stained_glass
setblock 79 72 6 minecraft:purple_stained_glass
setblock 48 72 6 minecraft:sea_lantern
setblock 80 72 6 minecraft:sea_lantern
setblock 48 72 7 minecraft:polished_blackstone_bricks
setblock 80 72 7 minecraft:polished_blackstone_bricks
setblock 48 72 8 minecraft:polished_blackstone_bricks
setblock 80 72 8 minecraft:polished_blackstone_bricks
setblock 48 72 9 minecraft:polished_blackstone_bricks
setblock 80 72 9 minecraft:polished_blackstone_bricks
setblock 48 72 10 minecraft:polished_blackstone_bricks
setblock 80 72 10 minecraft:polished_blackstone_bricks
setblock 48 72 11 minecraft:polished_blackstone_bricks
setblock 80 72 11 minecraft:polished_blackstone_bricks
setblock 49 72 12 minecraft:purple_stained_glass
setblock 79 72 12 minecraft:purple_stained_glass
setblock 48 72 12 minecraft:sea_lantern
setblock 80 72 12 minecraft:sea_lantern
setblock 48 72 13 minecraft:polished_blackstone_bricks
setblock 80 72 13 minecraft:polished_blackstone_bricks
setblock 48 72 14 minecraft:polished_blackstone_bricks
setblock 80 72 14 minecraft:polished_blackstone_bricks
setblock 48 72 15 minecraft:polished_blackstone_bricks
setblock 80 72 15 minecraft:polished_blackstone_bricks
setblock 52 72 15 minecraft:purple_stained_glass
setblock 58 72 15 minecraft:purple_stained_glass
setblock 64 72 15 minecraft:purple_stained_glass
setblock 70 72 15 minecraft:purple_stained_glass
setblock 76 72 15 minecraft:purple_stained_glass
fill 48 72 16 51 72 16 minecraft:polished_blackstone_bricks
fill 53 72 16 57 72 16 minecraft:polished_blackstone_bricks
fill 59 72 16 63 72 16 minecraft:polished_blackstone_bricks
fill 65 72 16 69 72 16 minecraft:polished_blackstone_bricks
fill 71 72 16 75 72 16 minecraft:polished_blackstone_bricks
fill 77 72 16 80 72 16 minecraft:polished_blackstone_bricks
setblock 52 72 16 minecraft:sea_lantern
setblock 58 72 16 minecraft:sea_lantern
setblock 64 72 16 minecraft:sea_lantern
setblock 70 72 16 minecraft:sea_lantern
setblock 76 72 16 minecraft:sea_lantern
fill 48 73 -16 51 73 -16 minecraft:polished_blackstone_bricks
fill 53 73 -16 57 73 -16 minecraft:polished_blackstone_bricks
fill 59 73 -16 63 73 -16 minecraft:polished_blackstone_bricks
fill 65 73 -16 69 73 -16 minecraft:polished_blackstone_bricks
fill 71 73 -16 75 73 -16 minecraft:polished_blackstone_bricks
fill 77 73 -16 80 73 -16 minecraft:polished_blackstone_bricks
setblock 52 73 -16 minecraft:sea_lantern
setblock 58 73 -16 minecraft:sea_lantern
setblock 64 73 -16 minecraft:sea_lantern
setblock 70 73 -16 minecraft:sea_lantern
setblock 76 73 -16 minecraft:sea_lantern
setblock 48 73 -15 minecraft:polished_blackstone_bricks
setblock 80 73 -15 minecraft:polished_blackstone_bricks
setblock 52 73 -15 minecraft:purple_stained_glass
setblock 58 73 -15 minecraft:purple_stained_glass
setblock 64 73 -15 minecraft:purple_stained_glass
setblock 70 73 -15 minecraft:purple_stained_glass
setblock 76 73 -15 minecraft:purple_stained_glass
setblock 48 73 -14 minecraft:polished_blackstone_bricks
setblock 80 73 -14 minecraft:polished_blackstone_bricks
setblock 48 73 -13 minecraft:polished_blackstone_bricks
setblock 80 73 -13 minecraft:polished_blackstone_bricks
setblock 49 73 -12 minecraft:purple_stained_glass
setblock 79 73 -12 minecraft:purple_stained_glass
setblock 48 73 -12 minecraft:sea_lantern
setblock 80 73 -12 minecraft:sea_lantern
setblock 48 73 -11 minecraft:polished_blackstone_bricks
setblock 80 73 -11 minecraft:polished_blackstone_bricks
setblock 56 73 -10 minecraft:blue_stained_glass
setblock 72 73 -10 minecraft:green_stained_glass
setblock 67 73 -10 minecraft:orange_stained_glass
setblock 48 73 -10 minecraft:polished_blackstone_bricks
setblock 80 73 -10 minecraft:polished_blackstone_bricks
setblock 61 73 -10 minecraft:purple_stained_glass
setblock 55 73 -9 minecraft:blue_stained_glass
setblock 57 73 -9 minecraft:blue_stained_glass
setblock 71 73 -9 minecraft:green_stained_glass
setblock 73 73 -9 minecraft:green_stained_glass
setblock 66 73 -9 minecraft:orange_stained_glass
setblock 68 73 -9 minecraft:orange_stained_glass
setblock 48 73 -9 minecraft:polished_blackstone_bricks
setblock 80 73 -9 minecraft:polished_blackstone_bricks
setblock 60 73 -9 minecraft:purple_stained_glass
setblock 62 73 -9 minecraft:purple_stained_glass
setblock 56 73 -9 minecraft:sea_lantern
setblock 61 73 -9 minecraft:sea_lantern
setblock 67 73 -9 minecraft:sea_lantern
setblock 72 73 -9 minecraft:sea_lantern
setblock 56 73 -8 minecraft:blue_stained_glass
setblock 72 73 -8 minecraft:green_stained_glass
setblock 67 73 -8 minecraft:orange_stained_glass
setblock 48 73 -8 minecraft:polished_blackstone_bricks
setblock 80 73 -8 minecraft:polished_blackstone_bricks
setblock 61 73 -8 minecraft:purple_stained_glass
setblock 48 73 -7 minecraft:polished_blackstone_bricks
setblock 80 73 -7 minecraft:polished_blackstone_bricks
setblock 49 73 -6 minecraft:purple_stained_glass
setblock 79 73 -6 minecraft:purple_stained_glass
setblock 48 73 -6 minecraft:sea_lantern
setblock 80 73 -6 minecraft:sea_lantern
setblock 48 73 -5 minecraft:polished_blackstone_bricks
setblock 80 73 -5 minecraft:polished_blackstone_bricks
setblock 48 73 -4 minecraft:polished_blackstone_bricks
setblock 80 73 -4 minecraft:polished_blackstone_bricks
setblock 48 73 -3 minecraft:polished_blackstone_bricks
setblock 80 73 -3 minecraft:polished_blackstone_bricks
setblock 48 73 -2 minecraft:polished_blackstone_bricks
setblock 80 73 -2 minecraft:polished_blackstone_bricks
setblock 48 73 -1 minecraft:polished_blackstone_bricks
setblock 80 73 -1 minecraft:polished_blackstone_bricks
setblock 49 73 0 minecraft:purple_stained_glass
setblock 79 73 0 minecraft:purple_stained_glass
setblock 48 73 0 minecraft:sea_lantern
setblock 80 73 0 minecraft:sea_lantern
setblock 48 73 1 minecraft:polished_blackstone_bricks
setblock 80 73 1 minecraft:polished_blackstone_bricks
setblock 48 73 2 minecraft:polished_blackstone_bricks
setblock 80 73 2 minecraft:polished_blackstone_bricks
setblock 48 73 3 minecraft:polished_blackstone_bricks
setblock 80 73 3 minecraft:polished_blackstone_bricks
setblock 48 73 4 minecraft:polished_blackstone_bricks
setblock 80 73 4 minecraft:polished_blackstone_bricks
setblock 48 73 5 minecraft:polished_blackstone_bricks
setblock 80 73 5 minecraft:polished_blackstone_bricks
setblock 49 73 6 minecraft:purple_stained_glass
setblock 79 73 6 minecraft:purple_stained_glass
setblock 48 73 6 minecraft:sea_lantern
setblock 80 73 6 minecraft:sea_lantern
setblock 48 73 7 minecraft:polished_blackstone_bricks
setblock 80 73 7 minecraft:polished_blackstone_bricks
setblock 48 73 8 minecraft:polished_blackstone_bricks
setblock 80 73 8 minecraft:polished_blackstone_bricks
setblock 48 73 9 minecraft:polished_blackstone_bricks
setblock 80 73 9 minecraft:polished_blackstone_bricks
setblock 48 73 10 minecraft:polished_blackstone_bricks
setblock 80 73 10 minecraft:polished_blackstone_bricks
setblock 48 73 11 minecraft:polished_blackstone_bricks
setblock 80 73 11 minecraft:polished_blackstone_bricks
setblock 49 73 12 minecraft:purple_stained_glass
setblock 79 73 12 minecraft:purple_stained_glass
setblock 48 73 12 minecraft:sea_lantern
setblock 80 73 12 minecraft:sea_lantern
setblock 48 73 13 minecraft:polished_blackstone_bricks
setblock 80 73 13 minecraft:polished_blackstone_bricks
setblock 48 73 14 minecraft:polished_blackstone_bricks
setblock 80 73 14 minecraft:polished_blackstone_bricks
setblock 48 73 15 minecraft:polished_blackstone_bricks
setblock 80 73 15 minecraft:polished_blackstone_bricks
setblock 52 73 15 minecraft:purple_stained_glass
setblock 58 73 15 minecraft:purple_stained_glass
setblock 64 73 15 minecraft:purple_stained_glass
setblock 70 73 15 minecraft:purple_stained_glass
setblock 76 73 15 minecraft:purple_stained_glass
fill 48 73 16 51 73 16 minecraft:polished_blackstone_bricks
fill 53 73 16 57 73 16 minecraft:polished_blackstone_bricks
fill 59 73 16 63 73 16 minecraft:polished_blackstone_bricks
fill 65 73 16 69 73 16 minecraft:polished_blackstone_bricks
fill 71 73 16 75 73 16 minecraft:polished_blackstone_bricks
fill 77 73 16 80 73 16 minecraft:polished_blackstone_bricks
setblock 52 73 16 minecraft:sea_lantern
setblock 58 73 16 minecraft:sea_lantern
setblock 64 73 16 minecraft:sea_lantern
setblock 70 73 16 minecraft:sea_lantern
setblock 76 73 16 minecraft:sea_lantern
fill 48 74 -16 51 74 -16 minecraft:polished_blackstone_bricks
fill 53 74 -16 57 74 -16 minecraft:polished_blackstone_bricks
fill 59 74 -16 63 74 -16 minecraft:polished_blackstone_bricks
fill 65 74 -16 69 74 -16 minecraft:polished_blackstone_bricks
fill 71 74 -16 75 74 -16 minecraft:polished_blackstone_bricks
fill 77 74 -16 80 74 -16 minecraft:polished_blackstone_bricks
setblock 52 74 -16 minecraft:sea_lantern
setblock 58 74 -16 minecraft:sea_lantern
setblock 64 74 -16 minecraft:sea_lantern
setblock 70 74 -16 minecraft:sea_lantern
setblock 76 74 -16 minecraft:sea_lantern
setblock 48 74 -15 minecraft:polished_blackstone_bricks
setblock 80 74 -15 minecraft:polished_blackstone_bricks
setblock 52 74 -15 minecraft:purple_stained_glass
setblock 58 74 -15 minecraft:purple_stained_glass
setblock 64 74 -15 minecraft:purple_stained_glass
setblock 70 74 -15 minecraft:purple_stained_glass
setblock 76 74 -15 minecraft:purple_stained_glass
setblock 48 74 -14 minecraft:polished_blackstone_bricks
setblock 80 74 -14 minecraft:polished_blackstone_bricks
setblock 48 74 -13 minecraft:polished_blackstone_bricks
setblock 80 74 -13 minecraft:polished_blackstone_bricks
setblock 49 74 -12 minecraft:purple_stained_glass
setblock 79 74 -12 minecraft:purple_stained_glass
setblock 48 74 -12 minecraft:sea_lantern
setblock 80 74 -12 minecraft:sea_lantern
setblock 48 74 -11 minecraft:polished_blackstone_bricks
setblock 80 74 -11 minecraft:polished_blackstone_bricks
fill 55 74 -10 57 74 -10 minecraft:amethyst_block
fill 60 74 -10 62 74 -10 minecraft:amethyst_block
fill 66 74 -10 68 74 -10 minecraft:amethyst_block
fill 71 74 -10 73 74 -10 minecraft:amethyst_block
setblock 48 74 -10 minecraft:polished_blackstone_bricks
setblock 80 74 -10 minecraft:polished_blackstone_bricks
fill 55 74 -9 57 74 -9 minecraft:amethyst_block
fill 60 74 -9 62 74 -9 minecraft:amethyst_block
fill 66 74 -9 68 74 -9 minecraft:amethyst_block
fill 71 74 -9 73 74 -9 minecraft:amethyst_block
setblock 48 74 -9 minecraft:polished_blackstone_bricks
setblock 80 74 -9 minecraft:polished_blackstone_bricks
fill 55 74 -8 57 74 -8 minecraft:amethyst_block
fill 60 74 -8 62 74 -8 minecraft:amethyst_block
fill 66 74 -8 68 74 -8 minecraft:amethyst_block
fill 71 74 -8 73 74 -8 minecraft:amethyst_block
setblock 48 74 -8 minecraft:polished_blackstone_bricks
setblock 80 74 -8 minecraft:polished_blackstone_bricks
setblock 48 74 -7 minecraft:polished_blackstone_bricks
setblock 80 74 -7 minecraft:polished_blackstone_bricks
setblock 49 74 -6 minecraft:purple_stained_glass
setblock 79 74 -6 minecraft:purple_stained_glass
setblock 48 74 -6 minecraft:sea_lantern
setblock 80 74 -6 minecraft:sea_lantern
setblock 48 74 -5 minecraft:polished_blackstone_bricks
setblock 80 74 -5 minecraft:polished_blackstone_bricks
setblock 48 74 -4 minecraft:polished_blackstone_bricks
setblock 80 74 -4 minecraft:polished_blackstone_bricks
setblock 48 74 -3 minecraft:polished_blackstone_bricks
setblock 80 74 -3 minecraft:polished_blackstone_bricks
setblock 48 74 -2 minecraft:polished_blackstone_bricks
setblock 80 74 -2 minecraft:polished_blackstone_bricks
setblock 48 74 -1 minecraft:polished_blackstone_bricks
setblock 80 74 -1 minecraft:polished_blackstone_bricks
setblock 49 74 0 minecraft:purple_stained_glass
setblock 79 74 0 minecraft:purple_stained_glass
setblock 48 74 0 minecraft:sea_lantern
setblock 80 74 0 minecraft:sea_lantern
setblock 48 74 1 minecraft:polished_blackstone_bricks
setblock 80 74 1 minecraft:polished_blackstone_bricks
setblock 48 74 2 minecraft:polished_blackstone_bricks
setblock 80 74 2 minecraft:polished_blackstone_bricks
setblock 48 74 3 minecraft:polished_blackstone_bricks
setblock 80 74 3 minecraft:polished_blackstone_bricks
setblock 48 74 4 minecraft:polished_blackstone_bricks
setblock 80 74 4 minecraft:polished_blackstone_bricks
setblock 48 74 5 minecraft:polished_blackstone_bricks
setblock 80 74 5 minecraft:polished_blackstone_bricks
setblock 49 74 6 minecraft:purple_stained_glass
setblock 79 74 6 minecraft:purple_stained_glass
setblock 48 74 6 minecraft:sea_lantern
setblock 80 74 6 minecraft:sea_lantern
setblock 48 74 7 minecraft:polished_blackstone_bricks
setblock 80 74 7 minecraft:polished_blackstone_bricks
setblock 48 74 8 minecraft:polished_blackstone_bricks
setblock 80 74 8 minecraft:polished_blackstone_bricks
setblock 48 74 9 minecraft:polished_blackstone_bricks
setblock 80 74 9 minecraft:polished_blackstone_bricks
setblock 48 74 10 minecraft:polished_blackstone_bricks
setblock 80 74 10 minecraft:polished_blackstone_bricks
setblock 48 74 11 minecraft:polished_blackstone_bricks
setblock 80 74 11 minecraft:polished_blackstone_bricks
setblock 49 74 12 minecraft:purple_stained_glass
setblock 79 74 12 minecraft:purple_stained_glass
setblock 48 74 12 minecraft:sea_lantern
setblock 80 74 12 minecraft:sea_lantern
setblock 48 74 13 minecraft:polished_blackstone_bricks
setblock 80 74 13 minecraft:polished_blackstone_bricks
setblock 48 74 14 minecraft:polished_blackstone_bricks
setblock 80 74 14 minecraft:polished_blackstone_bricks
setblock 48 74 15 minecraft:polished_blackstone_bricks
setblock 80 74 15 minecraft:polished_blackstone_bricks
setblock 52 74 15 minecraft:purple_stained_glass
setblock 58 74 15 minecraft:purple_stained_glass
setblock 64 74 15 minecraft:purple_stained_glass
setblock 70 74 15 minecraft:purple_stained_glass
setblock 76 74 15 minecraft:purple_stained_glass
fill 48 74 16 51 74 16 minecraft:polished_blackstone_bricks
fill 53 74 16 57 74 16 minecraft:polished_blackstone_bricks
fill 59 74 16 63 74 16 minecraft:polished_blackstone_bricks
fill 65 74 16 69 74 16 minecraft:polished_blackstone_bricks
fill 71 74 16 75 74 16 minecraft:polished_blackstone_bricks
fill 77 74 16 80 74 16 minecraft:polished_blackstone_bricks
setblock 52 74 16 minecraft:sea_lantern
setblock 58 74 16 minecraft:sea_lantern
setblock 64 74 16 minecraft:sea_lantern
setblock 70 74 16 minecraft:sea_lantern
setblock 76 74 16 minecraft:sea_lantern
fill 48 75 -16 51 75 -16 minecraft:polished_blackstone_bricks
fill 53 75 -16 57 75 -16 minecraft:polished_blackstone_bricks
fill 59 75 -16 63 75 -16 minecraft:polished_blackstone_bricks
fill 65 75 -16 69 75 -16 minecraft:polished_blackstone_bricks
fill 71 75 -16 75 75 -16 minecraft:polished_blackstone_bricks
fill 77 75 -16 80 75 -16 minecraft:polished_blackstone_bricks
setblock 52 75 -16 minecraft:sea_lantern
setblock 58 75 -16 minecraft:sea_lantern
setblock 64 75 -16 minecraft:sea_lantern
setblock 70 75 -16 minecraft:sea_lantern
setblock 76 75 -16 minecraft:sea_lantern
setblock 48 75 -15 minecraft:polished_blackstone_bricks
setblock 80 75 -15 minecraft:polished_blackstone_bricks
setblock 52 75 -15 minecraft:purple_stained_glass
setblock 58 75 -15 minecraft:purple_stained_glass
setblock 64 75 -15 minecraft:purple_stained_glass
setblock 70 75 -15 minecraft:purple_stained_glass
setblock 76 75 -15 minecraft:purple_stained_glass
setblock 48 75 -14 minecraft:polished_blackstone_bricks
setblock 80 75 -14 minecraft:polished_blackstone_bricks
setblock 48 75 -13 minecraft:polished_blackstone_bricks
setblock 80 75 -13 minecraft:polished_blackstone_bricks
setblock 49 75 -12 minecraft:purple_stained_glass
setblock 79 75 -12 minecraft:purple_stained_glass
setblock 48 75 -12 minecraft:sea_lantern
setblock 80 75 -12 minecraft:sea_lantern
setblock 48 75 -11 minecraft:polished_blackstone_bricks
setblock 80 75 -11 minecraft:polished_blackstone_bricks
setblock 48 75 -10 minecraft:polished_blackstone_bricks
setblock 80 75 -10 minecraft:polished_blackstone_bricks
setblock 56 75 -9 minecraft:large_amethyst_bud[facing=up,waterlogged=false]
setblock 61 75 -9 minecraft:large_amethyst_bud[facing=up,waterlogged=false]
setblock 67 75 -9 minecraft:large_amethyst_bud[facing=up,waterlogged=false]
setblock 72 75 -9 minecraft:large_amethyst_bud[facing=up,waterlogged=false]
setblock 48 75 -9 minecraft:polished_blackstone_bricks
setblock 80 75 -9 minecraft:polished_blackstone_bricks
setblock 48 75 -8 minecraft:polished_blackstone_bricks
setblock 80 75 -8 minecraft:polished_blackstone_bricks
setblock 48 75 -7 minecraft:polished_blackstone_bricks
setblock 80 75 -7 minecraft:polished_blackstone_bricks
setblock 49 75 -6 minecraft:purple_stained_glass
setblock 79 75 -6 minecraft:purple_stained_glass
setblock 48 75 -6 minecraft:sea_lantern
setblock 80 75 -6 minecraft:sea_lantern
setblock 48 75 -5 minecraft:polished_blackstone_bricks
setblock 80 75 -5 minecraft:polished_blackstone_bricks
setblock 48 75 -4 minecraft:polished_blackstone_bricks
setblock 80 75 -4 minecraft:polished_blackstone_bricks
setblock 48 75 -3 minecraft:polished_blackstone_bricks
setblock 80 75 -3 minecraft:polished_blackstone_bricks
setblock 48 75 -2 minecraft:polished_blackstone_bricks
setblock 80 75 -2 minecraft:polished_blackstone_bricks
setblock 48 75 -1 minecraft:polished_blackstone_bricks
setblock 80 75 -1 minecraft:polished_blackstone_bricks
setblock 49 75 0 minecraft:purple_stained_glass
setblock 79 75 0 minecraft:purple_stained_glass
setblock 48 75 0 minecraft:sea_lantern
setblock 80 75 0 minecraft:sea_lantern
setblock 48 75 1 minecraft:polished_blackstone_bricks
setblock 80 75 1 minecraft:polished_blackstone_bricks
setblock 48 75 2 minecraft:polished_blackstone_bricks
setblock 80 75 2 minecraft:polished_blackstone_bricks
setblock 48 75 3 minecraft:polished_blackstone_bricks
setblock 80 75 3 minecraft:polished_blackstone_bricks
setblock 48 75 4 minecraft:polished_blackstone_bricks
setblock 80 75 4 minecraft:polished_blackstone_bricks
setblock 48 75 5 minecraft:polished_blackstone_bricks
setblock 80 75 5 minecraft:polished_blackstone_bricks
setblock 49 75 6 minecraft:purple_stained_glass
setblock 79 75 6 minecraft:purple_stained_glass
setblock 48 75 6 minecraft:sea_lantern
setblock 80 75 6 minecraft:sea_lantern
setblock 48 75 7 minecraft:polished_blackstone_bricks
setblock 80 75 7 minecraft:polished_blackstone_bricks
setblock 48 75 8 minecraft:polished_blackstone_bricks
setblock 80 75 8 minecraft:polished_blackstone_bricks
setblock 48 75 9 minecraft:polished_blackstone_bricks
setblock 80 75 9 minecraft:polished_blackstone_bricks
setblock 48 75 10 minecraft:polished_blackstone_bricks
setblock 80 75 10 minecraft:polished_blackstone_bricks
setblock 48 75 11 minecraft:polished_blackstone_bricks
setblock 80 75 11 minecraft:polished_blackstone_bricks
setblock 49 75 12 minecraft:purple_stained_glass
setblock 79 75 12 minecraft:purple_stained_glass
setblock 48 75 12 minecraft:sea_lantern
setblock 80 75 12 minecraft:sea_lantern
setblock 48 75 13 minecraft:polished_blackstone_bricks
setblock 80 75 13 minecraft:polished_blackstone_bricks
setblock 48 75 14 minecraft:polished_blackstone_bricks
setblock 80 75 14 minecraft:polished_blackstone_bricks
setblock 48 75 15 minecraft:polished_blackstone_bricks
setblock 80 75 15 minecraft:polished_blackstone_bricks
setblock 52 75 15 minecraft:purple_stained_glass
setblock 58 75 15 minecraft:purple_stained_glass
setblock 64 75 15 minecraft:purple_stained_glass
setblock 70 75 15 minecraft:purple_stained_glass
setblock 76 75 15 minecraft:purple_stained_glass
fill 48 75 16 51 75 16 minecraft:polished_blackstone_bricks
fill 53 75 16 57 75 16 minecraft:polished_blackstone_bricks
fill 59 75 16 63 75 16 minecraft:polished_blackstone_bricks
fill 65 75 16 69 75 16 minecraft:polished_blackstone_bricks
fill 71 75 16 75 75 16 minecraft:polished_blackstone_bricks
fill 77 75 16 80 75 16 minecraft:polished_blackstone_bricks
setblock 52 75 16 minecraft:sea_lantern
setblock 58 75 16 minecraft:sea_lantern
setblock 64 75 16 minecraft:sea_lantern
setblock 70 75 16 minecraft:sea_lantern
setblock 76 75 16 minecraft:sea_lantern
fill 48 76 -16 51 76 -16 minecraft:polished_blackstone_bricks
fill 53 76 -16 57 76 -16 minecraft:polished_blackstone_bricks
fill 59 76 -16 63 76 -16 minecraft:polished_blackstone_bricks
fill 65 76 -16 69 76 -16 minecraft:polished_blackstone_bricks
fill 71 76 -16 75 76 -16 minecraft:polished_blackstone_bricks
fill 77 76 -16 80 76 -16 minecraft:polished_blackstone_bricks
setblock 52 76 -16 minecraft:sea_lantern
setblock 58 76 -16 minecraft:sea_lantern
setblock 64 76 -16 minecraft:sea_lantern
setblock 70 76 -16 minecraft:sea_lantern
setblock 76 76 -16 minecraft:sea_lantern
setblock 48 76 -15 minecraft:polished_blackstone_bricks
setblock 80 76 -15 minecraft:polished_blackstone_bricks
setblock 52 76 -15 minecraft:purple_stained_glass
setblock 58 76 -15 minecraft:purple_stained_glass
setblock 64 76 -15 minecraft:purple_stained_glass
setblock 70 76 -15 minecraft:purple_stained_glass
setblock 76 76 -15 minecraft:purple_stained_glass
setblock 48 76 -14 minecraft:polished_blackstone_bricks
setblock 80 76 -14 minecraft:polished_blackstone_bricks
setblock 48 76 -13 minecraft:polished_blackstone_bricks
setblock 80 76 -13 minecraft:polished_blackstone_bricks
setblock 49 76 -12 minecraft:purple_stained_glass
setblock 79 76 -12 minecraft:purple_stained_glass
setblock 48 76 -12 minecraft:sea_lantern
setblock 80 76 -12 minecraft:sea_lantern
setblock 48 76 -11 minecraft:polished_blackstone_bricks
setblock 80 76 -11 minecraft:polished_blackstone_bricks
setblock 48 76 -10 minecraft:polished_blackstone_bricks
setblock 80 76 -10 minecraft:polished_blackstone_bricks
setblock 48 76 -9 minecraft:polished_blackstone_bricks
setblock 80 76 -9 minecraft:polished_blackstone_bricks
setblock 48 76 -8 minecraft:polished_blackstone_bricks
setblock 80 76 -8 minecraft:polished_blackstone_bricks
setblock 48 76 -7 minecraft:polished_blackstone_bricks
setblock 80 76 -7 minecraft:polished_blackstone_bricks
setblock 49 76 -6 minecraft:purple_stained_glass
setblock 79 76 -6 minecraft:purple_stained_glass
setblock 48 76 -6 minecraft:sea_lantern
setblock 80 76 -6 minecraft:sea_lantern
setblock 48 76 -5 minecraft:polished_blackstone_bricks
setblock 80 76 -5 minecraft:polished_blackstone_bricks
setblock 48 76 -4 minecraft:polished_blackstone_bricks
setblock 80 76 -4 minecraft:polished_blackstone_bricks
setblock 48 76 -3 minecraft:polished_blackstone_bricks
setblock 80 76 -3 minecraft:polished_blackstone_bricks
setblock 48 76 -2 minecraft:polished_blackstone_bricks
setblock 80 76 -2 minecraft:polished_blackstone_bricks
setblock 48 76 -1 minecraft:polished_blackstone_bricks
setblock 80 76 -1 minecraft:polished_blackstone_bricks
setblock 49 76 0 minecraft:purple_stained_glass
setblock 79 76 0 minecraft:purple_stained_glass
setblock 48 76 0 minecraft:sea_lantern
setblock 80 76 0 minecraft:sea_lantern
setblock 48 76 1 minecraft:polished_blackstone_bricks
setblock 80 76 1 minecraft:polished_blackstone_bricks
setblock 48 76 2 minecraft:polished_blackstone_bricks
setblock 80 76 2 minecraft:polished_blackstone_bricks
setblock 48 76 3 minecraft:polished_blackstone_bricks
setblock 80 76 3 minecraft:polished_blackstone_bricks
setblock 48 76 4 minecraft:polished_blackstone_bricks
setblock 80 76 4 minecraft:polished_blackstone_bricks
setblock 48 76 5 minecraft:polished_blackstone_bricks
setblock 80 76 5 minecraft:polished_blackstone_bricks
setblock 49 76 6 minecraft:purple_stained_glass
setblock 79 76 6 minecraft:purple_stained_glass
setblock 48 76 6 minecraft:sea_lantern
setblock 80 76 6 minecraft:sea_lantern
setblock 48 76 7 minecraft:polished_blackstone_bricks
setblock 80 76 7 minecraft:polished_blackstone_bricks
setblock 48 76 8 minecraft:polished_blackstone_bricks
setblock 80 76 8 minecraft:polished_blackstone_bricks
setblock 48 76 9 minecraft:polished_blackstone_bricks
setblock 80 76 9 minecraft:polished_blackstone_bricks
setblock 48 76 10 minecraft:polished_blackstone_bricks
setblock 80 76 10 minecraft:polished_blackstone_bricks
setblock 48 76 11 minecraft:polished_blackstone_bricks
setblock 80 76 11 minecraft:polished_blackstone_bricks
setblock 49 76 12 minecraft:purple_stained_glass
setblock 79 76 12 minecraft:purple_stained_glass
setblock 48 76 12 minecraft:sea_lantern
setblock 80 76 12 minecraft:sea_lantern
setblock 48 76 13 minecraft:polished_blackstone_bricks
setblock 80 76 13 minecraft:polished_blackstone_bricks
setblock 48 76 14 minecraft:polished_blackstone_bricks
setblock 80 76 14 minecraft:polished_blackstone_bricks
setblock 48 76 15 minecraft:polished_blackstone_bricks
setblock 80 76 15 minecraft:polished_blackstone_bricks
setblock 52 76 15 minecraft:purple_stained_glass
setblock 58 76 15 minecraft:purple_stained_glass
setblock 64 76 15 minecraft:purple_stained_glass
setblock 70 76 15 minecraft:purple_stained_glass
setblock 76 76 15 minecraft:purple_stained_glass
fill 48 76 16 51 76 16 minecraft:polished_blackstone_bricks
fill 53 76 16 57 76 16 minecraft:polished_blackstone_bricks
fill 59 76 16 63 76 16 minecraft:polished_blackstone_bricks
fill 65 76 16 69 76 16 minecraft:polished_blackstone_bricks
fill 71 76 16 75 76 16 minecraft:polished_blackstone_bricks
fill 77 76 16 80 76 16 minecraft:polished_blackstone_bricks
setblock 52 76 16 minecraft:sea_lantern
setblock 58 76 16 minecraft:sea_lantern
setblock 64 76 16 minecraft:sea_lantern
setblock 70 76 16 minecraft:sea_lantern
setblock 76 76 16 minecraft:sea_lantern
fill 48 77 -16 51 77 -16 minecraft:polished_blackstone_bricks
fill 53 77 -16 57 77 -16 minecraft:polished_blackstone_bricks
fill 59 77 -16 63 77 -16 minecraft:polished_blackstone_bricks
fill 65 77 -16 69 77 -16 minecraft:polished_blackstone_bricks
fill 71 77 -16 75 77 -16 minecraft:polished_blackstone_bricks
fill 77 77 -16 80 77 -16 minecraft:polished_blackstone_bricks
setblock 52 77 -16 minecraft:sea_lantern
setblock 58 77 -16 minecraft:sea_lantern
setblock 64 77 -16 minecraft:sea_lantern
setblock 70 77 -16 minecraft:sea_lantern
setblock 76 77 -16 minecraft:sea_lantern
setblock 48 77 -15 minecraft:polished_blackstone_bricks
setblock 80 77 -15 minecraft:polished_blackstone_bricks
setblock 52 77 -15 minecraft:purple_stained_glass
setblock 58 77 -15 minecraft:purple_stained_glass
setblock 64 77 -15 minecraft:purple_stained_glass
setblock 70 77 -15 minecraft:purple_stained_glass
setblock 76 77 -15 minecraft:purple_stained_glass
setblock 48 77 -14 minecraft:polished_blackstone_bricks
setblock 80 77 -14 minecraft:polished_blackstone_bricks
setblock 48 77 -13 minecraft:polished_blackstone_bricks
setblock 80 77 -13 minecraft:polished_blackstone_bricks
setblock 49 77 -12 minecraft:purple_stained_glass
setblock 79 77 -12 minecraft:purple_stained_glass
setblock 48 77 -12 minecraft:sea_lantern
setblock 80 77 -12 minecraft:sea_lantern
setblock 48 77 -11 minecraft:polished_blackstone_bricks
setblock 80 77 -11 minecraft:polished_blackstone_bricks
setblock 48 77 -10 minecraft:polished_blackstone_bricks
setblock 80 77 -10 minecraft:polished_blackstone_bricks
setblock 48 77 -9 minecraft:polished_blackstone_bricks
setblock 80 77 -9 minecraft:polished_blackstone_bricks
setblock 48 77 -8 minecraft:polished_blackstone_bricks
setblock 80 77 -8 minecraft:polished_blackstone_bricks
setblock 48 77 -7 minecraft:polished_blackstone_bricks
setblock 80 77 -7 minecraft:polished_blackstone_bricks
setblock 49 77 -6 minecraft:purple_stained_glass
setblock 79 77 -6 minecraft:purple_stained_glass
setblock 48 77 -6 minecraft:sea_lantern
setblock 80 77 -6 minecraft:sea_lantern
setblock 48 77 -5 minecraft:polished_blackstone_bricks
setblock 80 77 -5 minecraft:polished_blackstone_bricks
setblock 48 77 -4 minecraft:polished_blackstone_bricks
setblock 80 77 -4 minecraft:polished_blackstone_bricks
setblock 48 77 -3 minecraft:polished_blackstone_bricks
setblock 80 77 -3 minecraft:polished_blackstone_bricks
setblock 48 77 -2 minecraft:polished_blackstone_bricks
setblock 80 77 -2 minecraft:polished_blackstone_bricks
setblock 48 77 -1 minecraft:polished_blackstone_bricks
setblock 80 77 -1 minecraft:polished_blackstone_bricks
setblock 49 77 0 minecraft:purple_stained_glass
setblock 79 77 0 minecraft:purple_stained_glass
setblock 48 77 0 minecraft:sea_lantern
setblock 80 77 0 minecraft:sea_lantern
setblock 48 77 1 minecraft:polished_blackstone_bricks
setblock 80 77 1 minecraft:polished_blackstone_bricks
setblock 48 77 2 minecraft:polished_blackstone_bricks
setblock 80 77 2 minecraft:polished_blackstone_bricks
setblock 48 77 3 minecraft:polished_blackstone_bricks
setblock 80 77 3 minecraft:polished_blackstone_bricks
setblock 48 77 4 minecraft:polished_blackstone_bricks
setblock 80 77 4 minecraft:polished_blackstone_bricks
setblock 48 77 5 minecraft:polished_blackstone_bricks
setblock 80 77 5 minecraft:polished_blackstone_bricks
setblock 49 77 6 minecraft:purple_stained_glass
setblock 79 77 6 minecraft:purple_stained_glass
setblock 48 77 6 minecraft:sea_lantern
setblock 80 77 6 minecraft:sea_lantern
setblock 48 77 7 minecraft:polished_blackstone_bricks
setblock 80 77 7 minecraft:polished_blackstone_bricks
setblock 48 77 8 minecraft:polished_blackstone_bricks
setblock 80 77 8 minecraft:polished_blackstone_bricks
setblock 48 77 9 minecraft:polished_blackstone_bricks
setblock 80 77 9 minecraft:polished_blackstone_bricks
setblock 48 77 10 minecraft:polished_blackstone_bricks
setblock 80 77 10 minecraft:polished_blackstone_bricks
setblock 48 77 11 minecraft:polished_blackstone_bricks
setblock 80 77 11 minecraft:polished_blackstone_bricks
setblock 49 77 12 minecraft:purple_stained_glass
setblock 79 77 12 minecraft:purple_stained_glass
setblock 48 77 12 minecraft:sea_lantern
setblock 80 77 12 minecraft:sea_lantern
setblock 48 77 13 minecraft:polished_blackstone_bricks
setblock 80 77 13 minecraft:polished_blackstone_bricks
setblock 48 77 14 minecraft:polished_blackstone_bricks
setblock 80 77 14 minecraft:polished_blackstone_bricks
setblock 48 77 15 minecraft:polished_blackstone_bricks
setblock 80 77 15 minecraft:polished_blackstone_bricks
setblock 52 77 15 minecraft:purple_stained_glass
setblock 58 77 15 minecraft:purple_stained_glass
setblock 64 77 15 minecraft:purple_stained_glass
setblock 70 77 15 minecraft:purple_stained_glass
setblock 76 77 15 minecraft:purple_stained_glass
fill 48 77 16 51 77 16 minecraft:polished_blackstone_bricks
fill 53 77 16 57 77 16 minecraft:polished_blackstone_bricks
fill 59 77 16 63 77 16 minecraft:polished_blackstone_bricks
fill 65 77 16 69 77 16 minecraft:polished_blackstone_bricks
fill 71 77 16 75 77 16 minecraft:polished_blackstone_bricks
fill 77 77 16 80 77 16 minecraft:polished_blackstone_bricks
setblock 52 77 16 minecraft:sea_lantern
setblock 58 77 16 minecraft:sea_lantern
setblock 64 77 16 minecraft:sea_lantern
setblock 70 77 16 minecraft:sea_lantern
setblock 76 77 16 minecraft:sea_lantern
fill 48 78 -16 51 78 -16 minecraft:polished_blackstone_bricks
fill 53 78 -16 57 78 -16 minecraft:polished_blackstone_bricks
fill 59 78 -16 63 78 -16 minecraft:polished_blackstone_bricks
fill 65 78 -16 69 78 -16 minecraft:polished_blackstone_bricks
fill 71 78 -16 75 78 -16 minecraft:polished_blackstone_bricks
fill 77 78 -16 80 78 -16 minecraft:polished_blackstone_bricks
setblock 52 78 -16 minecraft:sea_lantern
setblock 58 78 -16 minecraft:sea_lantern
setblock 64 78 -16 minecraft:sea_lantern
setblock 70 78 -16 minecraft:sea_lantern
setblock 76 78 -16 minecraft:sea_lantern
setblock 48 78 -15 minecraft:polished_blackstone_bricks
setblock 80 78 -15 minecraft:polished_blackstone_bricks
setblock 52 78 -15 minecraft:purple_stained_glass
setblock 58 78 -15 minecraft:purple_stained_glass
setblock 64 78 -15 minecraft:purple_stained_glass
setblock 70 78 -15 minecraft:purple_stained_glass
setblock 76 78 -15 minecraft:purple_stained_glass
setblock 48 78 -14 minecraft:polished_blackstone_bricks
setblock 80 78 -14 minecraft:polished_blackstone_bricks
setblock 48 78 -13 minecraft:polished_blackstone_bricks
setblock 80 78 -13 minecraft:polished_blackstone_bricks
setblock 49 78 -12 minecraft:purple_stained_glass
setblock 79 78 -12 minecraft:purple_stained_glass
setblock 48 78 -12 minecraft:sea_lantern
setblock 80 78 -12 minecraft:sea_lantern
setblock 48 78 -11 minecraft:polished_blackstone_bricks
setblock 80 78 -11 minecraft:polished_blackstone_bricks
setblock 48 78 -10 minecraft:polished_blackstone_bricks
setblock 80 78 -10 minecraft:polished_blackstone_bricks
setblock 48 78 -9 minecraft:polished_blackstone_bricks
setblock 80 78 -9 minecraft:polished_blackstone_bricks
setblock 48 78 -8 minecraft:polished_blackstone_bricks
setblock 80 78 -8 minecraft:polished_blackstone_bricks
setblock 48 78 -7 minecraft:polished_blackstone_bricks
setblock 80 78 -7 minecraft:polished_blackstone_bricks
setblock 49 78 -6 minecraft:purple_stained_glass
setblock 79 78 -6 minecraft:purple_stained_glass
setblock 48 78 -6 minecraft:sea_lantern
setblock 80 78 -6 minecraft:sea_lantern
setblock 48 78 -5 minecraft:polished_blackstone_bricks
setblock 80 78 -5 minecraft:polished_blackstone_bricks
setblock 48 78 -4 minecraft:polished_blackstone_bricks
setblock 80 78 -4 minecraft:polished_blackstone_bricks
setblock 48 78 -3 minecraft:polished_blackstone_bricks
setblock 80 78 -3 minecraft:polished_blackstone_bricks
setblock 48 78 -2 minecraft:polished_blackstone_bricks
setblock 80 78 -2 minecraft:polished_blackstone_bricks
setblock 48 78 -1 minecraft:polished_blackstone_bricks
setblock 80 78 -1 minecraft:polished_blackstone_bricks
setblock 49 78 0 minecraft:purple_stained_glass
setblock 79 78 0 minecraft:purple_stained_glass
setblock 48 78 0 minecraft:sea_lantern
setblock 80 78 0 minecraft:sea_lantern
setblock 48 78 1 minecraft:polished_blackstone_bricks
setblock 80 78 1 minecraft:polished_blackstone_bricks
setblock 48 78 2 minecraft:polished_blackstone_bricks
setblock 80 78 2 minecraft:polished_blackstone_bricks
setblock 48 78 3 minecraft:polished_blackstone_bricks
setblock 80 78 3 minecraft:polished_blackstone_bricks
setblock 48 78 4 minecraft:polished_blackstone_bricks
setblock 80 78 4 minecraft:polished_blackstone_bricks
setblock 48 78 5 minecraft:polished_blackstone_bricks
setblock 80 78 5 minecraft:polished_blackstone_bricks
setblock 49 78 6 minecraft:purple_stained_glass
setblock 79 78 6 minecraft:purple_stained_glass
setblock 48 78 6 minecraft:sea_lantern
setblock 80 78 6 minecraft:sea_lantern
setblock 48 78 7 minecraft:polished_blackstone_bricks
setblock 80 78 7 minecraft:polished_blackstone_bricks
setblock 48 78 8 minecraft:polished_blackstone_bricks
setblock 80 78 8 minecraft:polished_blackstone_bricks
setblock 48 78 9 minecraft:polished_blackstone_bricks
setblock 80 78 9 minecraft:polished_blackstone_bricks
setblock 48 78 10 minecraft:polished_blackstone_bricks
setblock 80 78 10 minecraft:polished_blackstone_bricks
setblock 48 78 11 minecraft:polished_blackstone_bricks
setblock 80 78 11 minecraft:polished_blackstone_bricks
setblock 49 78 12 minecraft:purple_stained_glass
setblock 79 78 12 minecraft:purple_stained_glass
setblock 48 78 12 minecraft:sea_lantern
setblock 80 78 12 minecraft:sea_lantern
setblock 48 78 13 minecraft:polished_blackstone_bricks
setblock 80 78 13 minecraft:polished_blackstone_bricks
setblock 48 78 14 minecraft:polished_blackstone_bricks
setblock 80 78 14 minecraft:polished_blackstone_bricks
setblock 48 78 15 minecraft:polished_blackstone_bricks
setblock 80 78 15 minecraft:polished_blackstone_bricks
setblock 52 78 15 minecraft:purple_stained_glass
setblock 58 78 15 minecraft:purple_stained_glass
setblock 64 78 15 minecraft:purple_stained_glass
setblock 70 78 15 minecraft:purple_stained_glass
setblock 76 78 15 minecraft:purple_stained_glass
fill 48 78 16 51 78 16 minecraft:polished_blackstone_bricks
fill 53 78 16 57 78 16 minecraft:polished_blackstone_bricks
fill 59 78 16 63 78 16 minecraft:polished_blackstone_bricks
fill 65 78 16 69 78 16 minecraft:polished_blackstone_bricks
fill 71 78 16 75 78 16 minecraft:polished_blackstone_bricks
fill 77 78 16 80 78 16 minecraft:polished_blackstone_bricks
setblock 52 78 16 minecraft:sea_lantern
setblock 58 78 16 minecraft:sea_lantern
setblock 64 78 16 minecraft:sea_lantern
setblock 70 78 16 minecraft:sea_lantern
setblock 76 78 16 minecraft:sea_lantern
fill 48 79 -16 80 79 -16 minecraft:polished_blackstone_bricks
setblock 48 79 -15 minecraft:polished_blackstone_bricks
setblock 80 79 -15 minecraft:polished_blackstone_bricks
setblock 52 79 -15 minecraft:smooth_basalt
setblock 58 79 -15 minecraft:smooth_basalt
setblock 64 79 -15 minecraft:smooth_basalt
setblock 70 79 -15 minecraft:smooth_basalt
setblock 76 79 -15 minecraft:smooth_basalt
setblock 48 79 -14 minecraft:polished_blackstone_bricks
setblock 80 79 -14 minecraft:polished_blackstone_bricks
setblock 48 79 -13 minecraft:polished_blackstone_bricks
setblock 80 79 -13 minecraft:polished_blackstone_bricks
setblock 48 79 -12 minecraft:polished_blackstone_bricks
setblock 80 79 -12 minecraft:polished_blackstone_bricks
setblock 49 79 -12 minecraft:smooth_basalt
setblock 79 79 -12 minecraft:smooth_basalt
setblock 48 79 -11 minecraft:polished_blackstone_bricks
setblock 80 79 -11 minecraft:polished_blackstone_bricks
setblock 48 79 -10 minecraft:polished_blackstone_bricks
setblock 80 79 -10 minecraft:polished_blackstone_bricks
setblock 48 79 -9 minecraft:polished_blackstone_bricks
setblock 80 79 -9 minecraft:polished_blackstone_bricks
setblock 48 79 -8 minecraft:polished_blackstone_bricks
setblock 80 79 -8 minecraft:polished_blackstone_bricks
setblock 48 79 -7 minecraft:polished_blackstone_bricks
setblock 80 79 -7 minecraft:polished_blackstone_bricks
setblock 48 79 -6 minecraft:polished_blackstone_bricks
setblock 80 79 -6 minecraft:polished_blackstone_bricks
setblock 49 79 -6 minecraft:smooth_basalt
setblock 79 79 -6 minecraft:smooth_basalt
setblock 48 79 -5 minecraft:polished_blackstone_bricks
setblock 80 79 -5 minecraft:polished_blackstone_bricks
setblock 48 79 -4 minecraft:polished_blackstone_bricks
setblock 80 79 -4 minecraft:polished_blackstone_bricks
setblock 48 79 -3 minecraft:polished_blackstone_bricks
setblock 80 79 -3 minecraft:polished_blackstone_bricks
setblock 48 79 -2 minecraft:polished_blackstone_bricks
setblock 80 79 -2 minecraft:polished_blackstone_bricks
setblock 48 79 -1 minecraft:polished_blackstone_bricks
setblock 80 79 -1 minecraft:polished_blackstone_bricks
setblock 48 79 0 minecraft:polished_blackstone_bricks
setblock 80 79 0 minecraft:polished_blackstone_bricks
setblock 49 79 0 minecraft:smooth_basalt
setblock 79 79 0 minecraft:smooth_basalt
setblock 48 79 1 minecraft:polished_blackstone_bricks
setblock 80 79 1 minecraft:polished_blackstone_bricks
setblock 48 79 2 minecraft:polished_blackstone_bricks
setblock 80 79 2 minecraft:polished_blackstone_bricks
setblock 48 79 3 minecraft:polished_blackstone_bricks
setblock 80 79 3 minecraft:polished_blackstone_bricks
setblock 48 79 4 minecraft:polished_blackstone_bricks
setblock 80 79 4 minecraft:polished_blackstone_bricks
setblock 48 79 5 minecraft:polished_blackstone_bricks
setblock 80 79 5 minecraft:polished_blackstone_bricks
setblock 48 79 6 minecraft:polished_blackstone_bricks
setblock 80 79 6 minecraft:polished_blackstone_bricks
setblock 49 79 6 minecraft:smooth_basalt
setblock 79 79 6 minecraft:smooth_basalt
setblock 48 79 7 minecraft:polished_blackstone_bricks
setblock 80 79 7 minecraft:polished_blackstone_bricks
setblock 48 79 8 minecraft:polished_blackstone_bricks
setblock 80 79 8 minecraft:polished_blackstone_bricks
setblock 48 79 9 minecraft:polished_blackstone_bricks
setblock 80 79 9 minecraft:polished_blackstone_bricks
setblock 48 79 10 minecraft:polished_blackstone_bricks
setblock 80 79 10 minecraft:polished_blackstone_bricks
setblock 48 79 11 minecraft:polished_blackstone_bricks
setblock 80 79 11 minecraft:polished_blackstone_bricks
setblock 48 79 12 minecraft:polished_blackstone_bricks
setblock 80 79 12 minecraft:polished_blackstone_bricks
setblock 49 79 12 minecraft:smooth_basalt
setblock 79 79 12 minecraft:smooth_basalt
setblock 48 79 13 minecraft:polished_blackstone_bricks
setblock 80 79 13 minecraft:polished_blackstone_bricks
setblock 48 79 14 minecraft:polished_blackstone_bricks
setblock 80 79 14 minecraft:polished_blackstone_bricks
setblock 48 79 15 minecraft:polished_blackstone_bricks
setblock 80 79 15 minecraft:polished_blackstone_bricks
setblock 52 79 15 minecraft:smooth_basalt
setblock 58 79 15 minecraft:smooth_basalt
setblock 64 79 15 minecraft:smooth_basalt
setblock 70 79 15 minecraft:smooth_basalt
setblock 76 79 15 minecraft:smooth_basalt
fill 48 79 16 80 79 16 minecraft:polished_blackstone_bricks
fill 48 80 -16 80 80 -16 minecraft:polished_blackstone_bricks
fill 49 80 -15 79 80 -15 minecraft:amethyst_block
setblock 48 80 -15 minecraft:polished_blackstone_bricks
setblock 80 80 -15 minecraft:polished_blackstone_bricks
setblock 49 80 -14 minecraft:amethyst_block
setblock 79 80 -14 minecraft:amethyst_block
setblock 48 80 -14 minecraft:polished_blackstone_bricks
setblock 80 80 -14 minecraft:polished_blackstone_bricks
setblock 49 80 -13 minecraft:amethyst_block
setblock 79 80 -13 minecraft:amethyst_block
setblock 48 80 -13 minecraft:polished_blackstone_bricks
setblock 80 80 -13 minecraft:polished_blackstone_bricks
fill 49 80 -12 50 80 -12 minecraft:amethyst_block
fill 78 80 -12 79 80 -12 minecraft:amethyst_block
setblock 48 80 -12 minecraft:polished_blackstone_bricks
setblock 80 80 -12 minecraft:polished_blackstone_bricks
setblock 52 80 -12 minecraft:sea_lantern
setblock 76 80 -12 minecraft:sea_lantern
setblock 49 80 -11 minecraft:amethyst_block
setblock 79 80 -11 minecraft:amethyst_block
setblock 48 80 -11 minecraft:polished_blackstone_bricks
setblock 80 80 -11 minecraft:polished_blackstone_bricks
setblock 49 80 -10 minecraft:amethyst_block
setblock 79 80 -10 minecraft:amethyst_block
setblock 48 80 -10 minecraft:polished_blackstone_bricks
setblock 80 80 -10 minecraft:polished_blackstone_bricks
setblock 49 80 -9 minecraft:amethyst_block
setblock 79 80 -9 minecraft:amethyst_block
setblock 48 80 -9 minecraft:polished_blackstone_bricks
setblock 80 80 -9 minecraft:polished_blackstone_bricks
setblock 49 80 -8 minecraft:amethyst_block
setblock 79 80 -8 minecraft:amethyst_block
setblock 48 80 -8 minecraft:polished_blackstone_bricks
setblock 80 80 -8 minecraft:polished_blackstone_bricks
setblock 49 80 -7 minecraft:amethyst_block
setblock 79 80 -7 minecraft:amethyst_block
setblock 48 80 -7 minecraft:polished_blackstone_bricks
setblock 80 80 -7 minecraft:polished_blackstone_bricks
setblock 49 80 -6 minecraft:amethyst_block
setblock 79 80 -6 minecraft:amethyst_block
setblock 48 80 -6 minecraft:polished_blackstone_bricks
setblock 80 80 -6 minecraft:polished_blackstone_bricks
setblock 49 80 -5 minecraft:amethyst_block
setblock 79 80 -5 minecraft:amethyst_block
setblock 48 80 -5 minecraft:polished_blackstone_bricks
setblock 80 80 -5 minecraft:polished_blackstone_bricks
setblock 49 80 -4 minecraft:amethyst_block
setblock 79 80 -4 minecraft:amethyst_block
setblock 48 80 -4 minecraft:polished_blackstone_bricks
setblock 80 80 -4 minecraft:polished_blackstone_bricks
setblock 49 80 -3 minecraft:amethyst_block
setblock 79 80 -3 minecraft:amethyst_block
setblock 48 80 -3 minecraft:polished_blackstone_bricks
setblock 80 80 -3 minecraft:polished_blackstone_bricks
setblock 49 80 -2 minecraft:amethyst_block
setblock 79 80 -2 minecraft:amethyst_block
setblock 48 80 -2 minecraft:polished_blackstone_bricks
setblock 80 80 -2 minecraft:polished_blackstone_bricks
setblock 49 80 -1 minecraft:amethyst_block
setblock 79 80 -1 minecraft:amethyst_block
setblock 48 80 -1 minecraft:polished_blackstone_bricks
setblock 80 80 -1 minecraft:polished_blackstone_bricks
fill 49 80 0 50 80 0 minecraft:amethyst_block
fill 78 80 0 79 80 0 minecraft:amethyst_block
setblock 48 80 0 minecraft:polished_blackstone_bricks
setblock 80 80 0 minecraft:polished_blackstone_bricks
setblock 52 80 0 minecraft:sea_lantern
setblock 76 80 0 minecraft:sea_lantern
setblock 49 80 1 minecraft:amethyst_block
setblock 79 80 1 minecraft:amethyst_block
setblock 48 80 1 minecraft:polished_blackstone_bricks
setblock 80 80 1 minecraft:polished_blackstone_bricks
setblock 49 80 2 minecraft:amethyst_block
setblock 79 80 2 minecraft:amethyst_block
setblock 48 80 2 minecraft:polished_blackstone_bricks
setblock 80 80 2 minecraft:polished_blackstone_bricks
setblock 49 80 3 minecraft:amethyst_block
setblock 79 80 3 minecraft:amethyst_block
setblock 48 80 3 minecraft:polished_blackstone_bricks
setblock 80 80 3 minecraft:polished_blackstone_bricks
setblock 49 80 4 minecraft:amethyst_block
setblock 79 80 4 minecraft:amethyst_block
setblock 48 80 4 minecraft:polished_blackstone_bricks
setblock 80 80 4 minecraft:polished_blackstone_bricks
setblock 49 80 5 minecraft:amethyst_block
setblock 79 80 5 minecraft:amethyst_block
setblock 48 80 5 minecraft:polished_blackstone_bricks
setblock 80 80 5 minecraft:polished_blackstone_bricks
setblock 49 80 6 minecraft:amethyst_block
setblock 79 80 6 minecraft:amethyst_block
setblock 48 80 6 minecraft:polished_blackstone_bricks
setblock 80 80 6 minecraft:polished_blackstone_bricks
setblock 49 80 7 minecraft:amethyst_block
setblock 79 80 7 minecraft:amethyst_block
setblock 48 80 7 minecraft:polished_blackstone_bricks
setblock 80 80 7 minecraft:polished_blackstone_bricks
setblock 49 80 8 minecraft:amethyst_block
setblock 79 80 8 minecraft:amethyst_block
setblock 48 80 8 minecraft:polished_blackstone_bricks
setblock 80 80 8 minecraft:polished_blackstone_bricks
setblock 49 80 9 minecraft:amethyst_block
setblock 79 80 9 minecraft:amethyst_block
setblock 48 80 9 minecraft:polished_blackstone_bricks
setblock 80 80 9 minecraft:polished_blackstone_bricks
setblock 49 80 10 minecraft:amethyst_block
setblock 79 80 10 minecraft:amethyst_block
setblock 48 80 10 minecraft:polished_blackstone_bricks
setblock 80 80 10 minecraft:polished_blackstone_bricks
setblock 49 80 11 minecraft:amethyst_block
setblock 79 80 11 minecraft:amethyst_block
setblock 48 80 11 minecraft:polished_blackstone_bricks
setblock 80 80 11 minecraft:polished_blackstone_bricks
fill 49 80 12 50 80 12 minecraft:amethyst_block
fill 78 80 12 79 80 12 minecraft:amethyst_block
setblock 48 80 12 minecraft:polished_blackstone_bricks
setblock 80 80 12 minecraft:polished_blackstone_bricks
setblock 52 80 12 minecraft:sea_lantern
setblock 76 80 12 minecraft:sea_lantern
setblock 49 80 13 minecraft:amethyst_block
setblock 79 80 13 minecraft:amethyst_block
setblock 48 80 13 minecraft:polished_blackstone_bricks
setblock 80 80 13 minecraft:polished_blackstone_bricks
setblock 49 80 14 minecraft:amethyst_block
setblock 79 80 14 minecraft:amethyst_block
setblock 48 80 14 minecraft:polished_blackstone_bricks
setblock 80 80 14 minecraft:polished_blackstone_bricks
fill 49 80 15 79 80 15 minecraft:amethyst_block
setblock 48 80 15 minecraft:polished_blackstone_bricks
setblock 80 80 15 minecraft:polished_blackstone_bricks
fill 48 80 16 80 80 16 minecraft:polished_blackstone_bricks
fill 48 81 -16 80 81 -16 minecraft:polished_blackstone_bricks
setblock 52 81 -15 minecraft:amethyst_block
setblock 58 81 -15 minecraft:amethyst_block
setblock 64 81 -15 minecraft:amethyst_block
setblock 70 81 -15 minecraft:amethyst_block
setblock 76 81 -15 minecraft:amethyst_block
setblock 48 81 -15 minecraft:polished_blackstone_bricks
setblock 80 81 -15 minecraft:polished_blackstone_bricks
setblock 48 81 -14 minecraft:polished_blackstone_bricks
setblock 80 81 -14 minecraft:polished_blackstone_bricks
setblock 48 81 -13 minecraft:polished_blackstone_bricks
setblock 80 81 -13 minecraft:polished_blackstone_bricks
setblock 49 81 -12 minecraft:amethyst_block
fill 51 81 -12 53 81 -12 minecraft:amethyst_block
fill 75 81 -12 77 81 -12 minecraft:amethyst_block
setblock 79 81 -12 minecraft:amethyst_block
setblock 48 81 -12 minecraft:polished_blackstone_bricks
setblock 80 81 -12 minecraft:polished_blackstone_bricks
setblock 58 81 -12 minecraft:sea_lantern
setblock 64 81 -12 minecraft:sea_lantern
setblock 70 81 -12 minecraft:sea_lantern
setblock 48 81 -11 minecraft:polished_blackstone_bricks
setblock 80 81 -11 minecraft:polished_blackstone_bricks
setblock 48 81 -10 minecraft:polished_blackstone_bricks
setblock 80 81 -10 minecraft:polished_blackstone_bricks
setblock 48 81 -9 minecraft:polished_blackstone_bricks
setblock 80 81 -9 minecraft:polished_blackstone_bricks
setblock 48 81 -8 minecraft:polished_blackstone_bricks
setblock 80 81 -8 minecraft:polished_blackstone_bricks
setblock 48 81 -7 minecraft:polished_blackstone_bricks
setblock 80 81 -7 minecraft:polished_blackstone_bricks
setblock 49 81 -6 minecraft:amethyst_block
setblock 79 81 -6 minecraft:amethyst_block
setblock 48 81 -6 minecraft:polished_blackstone_bricks
setblock 80 81 -6 minecraft:polished_blackstone_bricks
setblock 48 81 -5 minecraft:polished_blackstone_bricks
setblock 80 81 -5 minecraft:polished_blackstone_bricks
setblock 48 81 -4 minecraft:polished_blackstone_bricks
setblock 80 81 -4 minecraft:polished_blackstone_bricks
setblock 48 81 -3 minecraft:polished_blackstone_bricks
setblock 80 81 -3 minecraft:polished_blackstone_bricks
setblock 48 81 -2 minecraft:polished_blackstone_bricks
setblock 80 81 -2 minecraft:polished_blackstone_bricks
setblock 48 81 -1 minecraft:polished_blackstone_bricks
setblock 80 81 -1 minecraft:polished_blackstone_bricks
setblock 49 81 0 minecraft:amethyst_block
fill 51 81 0 53 81 0 minecraft:amethyst_block
fill 75 81 0 77 81 0 minecraft:amethyst_block
setblock 79 81 0 minecraft:amethyst_block
setblock 48 81 0 minecraft:polished_blackstone_bricks
setblock 80 81 0 minecraft:polished_blackstone_bricks
setblock 58 81 0 minecraft:sea_lantern
setblock 64 81 0 minecraft:sea_lantern
setblock 70 81 0 minecraft:sea_lantern
setblock 48 81 1 minecraft:polished_blackstone_bricks
setblock 80 81 1 minecraft:polished_blackstone_bricks
setblock 48 81 2 minecraft:polished_blackstone_bricks
setblock 80 81 2 minecraft:polished_blackstone_bricks
setblock 48 81 3 minecraft:polished_blackstone_bricks
setblock 80 81 3 minecraft:polished_blackstone_bricks
setblock 48 81 4 minecraft:polished_blackstone_bricks
setblock 80 81 4 minecraft:polished_blackstone_bricks
setblock 48 81 5 minecraft:polished_blackstone_bricks
setblock 80 81 5 minecraft:polished_blackstone_bricks
setblock 49 81 6 minecraft:amethyst_block
setblock 79 81 6 minecraft:amethyst_block
setblock 48 81 6 minecraft:polished_blackstone_bricks
setblock 80 81 6 minecraft:polished_blackstone_bricks
setblock 48 81 7 minecraft:polished_blackstone_bricks
setblock 80 81 7 minecraft:polished_blackstone_bricks
setblock 48 81 8 minecraft:polished_blackstone_bricks
setblock 80 81 8 minecraft:polished_blackstone_bricks
setblock 48 81 9 minecraft:polished_blackstone_bricks
setblock 80 81 9 minecraft:polished_blackstone_bricks
setblock 48 81 10 minecraft:polished_blackstone_bricks
setblock 80 81 10 minecraft:polished_blackstone_bricks
setblock 48 81 11 minecraft:polished_blackstone_bricks
setblock 80 81 11 minecraft:polished_blackstone_bricks
setblock 49 81 12 minecraft:amethyst_block
fill 51 81 12 53 81 12 minecraft:amethyst_block
fill 75 81 12 77 81 12 minecraft:amethyst_block
setblock 79 81 12 minecraft:amethyst_block
setblock 48 81 12 minecraft:polished_blackstone_bricks
setblock 80 81 12 minecraft:polished_blackstone_bricks
setblock 58 81 12 minecraft:sea_lantern
setblock 64 81 12 minecraft:sea_lantern
setblock 70 81 12 minecraft:sea_lantern
setblock 48 81 13 minecraft:polished_blackstone_bricks
setblock 80 81 13 minecraft:polished_blackstone_bricks
setblock 48 81 14 minecraft:polished_blackstone_bricks
setblock 80 81 14 minecraft:polished_blackstone_bricks
setblock 52 81 15 minecraft:amethyst_block
setblock 58 81 15 minecraft:amethyst_block
setblock 64 81 15 minecraft:amethyst_block
setblock 70 81 15 minecraft:amethyst_block
setblock 76 81 15 minecraft:amethyst_block
setblock 48 81 15 minecraft:polished_blackstone_bricks
setblock 80 81 15 minecraft:polished_blackstone_bricks
fill 48 81 16 80 81 16 minecraft:polished_blackstone_bricks
fill 48 82 -16 80 82 -16 minecraft:polished_blackstone_bricks
setblock 52 82 -15 minecraft:amethyst_block
setblock 58 82 -15 minecraft:amethyst_block
setblock 64 82 -15 minecraft:amethyst_block
setblock 70 82 -15 minecraft:amethyst_block
setblock 76 82 -15 minecraft:amethyst_block
setblock 48 82 -15 minecraft:polished_blackstone_bricks
setblock 80 82 -15 minecraft:polished_blackstone_bricks
setblock 48 82 -14 minecraft:polished_blackstone_bricks
setblock 80 82 -14 minecraft:polished_blackstone_bricks
setblock 48 82 -13 minecraft:polished_blackstone_bricks
setblock 80 82 -13 minecraft:polished_blackstone_bricks
setblock 49 82 -12 minecraft:amethyst_block
fill 54 82 -12 74 82 -12 minecraft:amethyst_block
setblock 79 82 -12 minecraft:amethyst_block
setblock 48 82 -12 minecraft:polished_blackstone_bricks
setblock 80 82 -12 minecraft:polished_blackstone_bricks
setblock 48 82 -11 minecraft:polished_blackstone_bricks
setblock 80 82 -11 minecraft:polished_blackstone_bricks
setblock 48 82 -10 minecraft:polished_blackstone_bricks
setblock 80 82 -10 minecraft:polished_blackstone_bricks
setblock 48 82 -9 minecraft:polished_blackstone_bricks
setblock 80 82 -9 minecraft:polished_blackstone_bricks
setblock 48 82 -8 minecraft:polished_blackstone_bricks
setblock 80 82 -8 minecraft:polished_blackstone_bricks
setblock 48 82 -7 minecraft:polished_blackstone_bricks
setblock 80 82 -7 minecraft:polished_blackstone_bricks
setblock 49 82 -6 minecraft:amethyst_block
setblock 79 82 -6 minecraft:amethyst_block
setblock 48 82 -6 minecraft:polished_blackstone_bricks
setblock 80 82 -6 minecraft:polished_blackstone_bricks
setblock 48 82 -5 minecraft:polished_blackstone_bricks
setblock 80 82 -5 minecraft:polished_blackstone_bricks
setblock 48 82 -4 minecraft:polished_blackstone_bricks
setblock 80 82 -4 minecraft:polished_blackstone_bricks
setblock 48 82 -3 minecraft:polished_blackstone_bricks
setblock 80 82 -3 minecraft:polished_blackstone_bricks
setblock 48 82 -2 minecraft:polished_blackstone_bricks
setblock 80 82 -2 minecraft:polished_blackstone_bricks
setblock 48 82 -1 minecraft:polished_blackstone_bricks
setblock 80 82 -1 minecraft:polished_blackstone_bricks
setblock 49 82 0 minecraft:amethyst_block
fill 54 82 0 74 82 0 minecraft:amethyst_block
setblock 79 82 0 minecraft:amethyst_block
setblock 48 82 0 minecraft:polished_blackstone_bricks
setblock 80 82 0 minecraft:polished_blackstone_bricks
setblock 48 82 1 minecraft:polished_blackstone_bricks
setblock 80 82 1 minecraft:polished_blackstone_bricks
setblock 48 82 2 minecraft:polished_blackstone_bricks
setblock 80 82 2 minecraft:polished_blackstone_bricks
setblock 48 82 3 minecraft:polished_blackstone_bricks
setblock 80 82 3 minecraft:polished_blackstone_bricks
setblock 48 82 4 minecraft:polished_blackstone_bricks
setblock 80 82 4 minecraft:polished_blackstone_bricks
setblock 48 82 5 minecraft:polished_blackstone_bricks
setblock 80 82 5 minecraft:polished_blackstone_bricks
setblock 49 82 6 minecraft:amethyst_block
setblock 79 82 6 minecraft:amethyst_block
setblock 48 82 6 minecraft:polished_blackstone_bricks
setblock 80 82 6 minecraft:polished_blackstone_bricks
setblock 48 82 7 minecraft:polished_blackstone_bricks
setblock 80 82 7 minecraft:polished_blackstone_bricks
setblock 48 82 8 minecraft:polished_blackstone_bricks
setblock 80 82 8 minecraft:polished_blackstone_bricks
setblock 48 82 9 minecraft:polished_blackstone_bricks
setblock 80 82 9 minecraft:polished_blackstone_bricks
setblock 48 82 10 minecraft:polished_blackstone_bricks
setblock 80 82 10 minecraft:polished_blackstone_bricks
setblock 48 82 11 minecraft:polished_blackstone_bricks
setblock 80 82 11 minecraft:polished_blackstone_bricks
setblock 49 82 12 minecraft:amethyst_block
fill 54 82 12 74 82 12 minecraft:amethyst_block
setblock 79 82 12 minecraft:amethyst_block
setblock 48 82 12 minecraft:polished_blackstone_bricks
setblock 80 82 12 minecraft:polished_blackstone_bricks
setblock 48 82 13 minecraft:polished_blackstone_bricks
setblock 80 82 13 minecraft:polished_blackstone_bricks
setblock 48 82 14 minecraft:polished_blackstone_bricks
setblock 80 82 14 minecraft:polished_blackstone_bricks
setblock 52 82 15 minecraft:amethyst_block
setblock 58 82 15 minecraft:amethyst_block
setblock 64 82 15 minecraft:amethyst_block
setblock 70 82 15 minecraft:amethyst_block
setblock 76 82 15 minecraft:amethyst_block
setblock 48 82 15 minecraft:polished_blackstone_bricks
setblock 80 82 15 minecraft:polished_blackstone_bricks
fill 48 82 16 80 82 16 minecraft:polished_blackstone_bricks
fill 48 83 -16 80 83 -16 minecraft:polished_blackstone_bricks
fill 49 83 -15 79 83 -15 minecraft:amethyst_block
setblock 48 83 -15 minecraft:polished_blackstone_bricks
setblock 80 83 -15 minecraft:polished_blackstone_bricks
setblock 49 83 -14 minecraft:amethyst_block
setblock 79 83 -14 minecraft:amethyst_block
setblock 48 83 -14 minecraft:polished_blackstone_bricks
setblock 80 83 -14 minecraft:polished_blackstone_bricks
setblock 49 83 -13 minecraft:amethyst_block
setblock 79 83 -13 minecraft:amethyst_block
setblock 48 83 -13 minecraft:polished_blackstone_bricks
setblock 80 83 -13 minecraft:polished_blackstone_bricks
setblock 49 83 -12 minecraft:amethyst_block
setblock 79 83 -12 minecraft:amethyst_block
setblock 48 83 -12 minecraft:polished_blackstone_bricks
setblock 80 83 -12 minecraft:polished_blackstone_bricks
setblock 49 83 -11 minecraft:amethyst_block
setblock 79 83 -11 minecraft:amethyst_block
setblock 48 83 -11 minecraft:polished_blackstone_bricks
setblock 80 83 -11 minecraft:polished_blackstone_bricks
setblock 49 83 -10 minecraft:amethyst_block
setblock 79 83 -10 minecraft:amethyst_block
setblock 48 83 -10 minecraft:polished_blackstone_bricks
setblock 80 83 -10 minecraft:polished_blackstone_bricks
setblock 49 83 -9 minecraft:amethyst_block
setblock 79 83 -9 minecraft:amethyst_block
setblock 54 83 -9 minecraft:light_blue_stained_glass
setblock 71 83 -9 minecraft:light_blue_stained_glass
setblock 48 83 -9 minecraft:polished_blackstone_bricks
setblock 80 83 -9 minecraft:polished_blackstone_bricks
setblock 49 83 -8 minecraft:amethyst_block
setblock 79 83 -8 minecraft:amethyst_block
setblock 61 83 -8 minecraft:light_blue_stained_glass
setblock 48 83 -8 minecraft:polished_blackstone_bricks
setblock 80 83 -8 minecraft:polished_blackstone_bricks
setblock 49 83 -7 minecraft:amethyst_block
setblock 79 83 -7 minecraft:amethyst_block
setblock 48 83 -7 minecraft:polished_blackstone_bricks
setblock 80 83 -7 minecraft:polished_blackstone_bricks
setblock 49 83 -6 minecraft:amethyst_block
setblock 79 83 -6 minecraft:amethyst_block
setblock 48 83 -6 minecraft:polished_blackstone_bricks
setblock 80 83 -6 minecraft:polished_blackstone_bricks
setblock 49 83 -5 minecraft:amethyst_block
setblock 79 83 -5 minecraft:amethyst_block
setblock 48 83 -5 minecraft:polished_blackstone_bricks
setblock 80 83 -5 minecraft:polished_blackstone_bricks
setblock 49 83 -4 minecraft:amethyst_block
setblock 79 83 -4 minecraft:amethyst_block
setblock 74 83 -4 minecraft:light_blue_stained_glass
setblock 48 83 -4 minecraft:polished_blackstone_bricks
setblock 80 83 -4 minecraft:polished_blackstone_bricks
setblock 49 83 -3 minecraft:amethyst_block
setblock 79 83 -3 minecraft:amethyst_block
setblock 48 83 -3 minecraft:polished_blackstone_bricks
setblock 80 83 -3 minecraft:polished_blackstone_bricks
setblock 49 83 -2 minecraft:amethyst_block
setblock 79 83 -2 minecraft:amethyst_block
setblock 48 83 -2 minecraft:polished_blackstone_bricks
setblock 80 83 -2 minecraft:polished_blackstone_bricks
setblock 49 83 -1 minecraft:amethyst_block
setblock 79 83 -1 minecraft:amethyst_block
setblock 48 83 -1 minecraft:polished_blackstone_bricks
setblock 80 83 -1 minecraft:polished_blackstone_bricks
setblock 49 83 0 minecraft:amethyst_block
setblock 79 83 0 minecraft:amethyst_block
setblock 48 83 0 minecraft:polished_blackstone_bricks
setblock 80 83 0 minecraft:polished_blackstone_bricks
setblock 49 83 1 minecraft:amethyst_block
setblock 79 83 1 minecraft:amethyst_block
setblock 48 83 1 minecraft:polished_blackstone_bricks
setblock 80 83 1 minecraft:polished_blackstone_bricks
setblock 49 83 2 minecraft:amethyst_block
setblock 79 83 2 minecraft:amethyst_block
setblock 48 83 2 minecraft:polished_blackstone_bricks
setblock 80 83 2 minecraft:polished_blackstone_bricks
setblock 49 83 3 minecraft:amethyst_block
setblock 79 83 3 minecraft:amethyst_block
setblock 48 83 3 minecraft:polished_blackstone_bricks
setblock 80 83 3 minecraft:polished_blackstone_bricks
setblock 49 83 4 minecraft:amethyst_block
setblock 79 83 4 minecraft:amethyst_block
setblock 67 83 4 minecraft:light_blue_stained_glass
setblock 48 83 4 minecraft:polished_blackstone_bricks
setblock 80 83 4 minecraft:polished_blackstone_bricks
setblock 49 83 5 minecraft:amethyst_block
setblock 79 83 5 minecraft:amethyst_block
setblock 53 83 5 minecraft:light_blue_stained_glass
setblock 48 83 5 minecraft:polished_blackstone_bricks
setblock 80 83 5 minecraft:polished_blackstone_bricks
setblock 49 83 6 minecraft:amethyst_block
setblock 79 83 6 minecraft:amethyst_block
setblock 48 83 6 minecraft:polished_blackstone_bricks
setblock 80 83 6 minecraft:polished_blackstone_bricks
setblock 49 83 7 minecraft:amethyst_block
setblock 79 83 7 minecraft:amethyst_block
setblock 59 83 7 minecraft:light_blue_stained_glass
setblock 48 83 7 minecraft:polished_blackstone_bricks
setblock 80 83 7 minecraft:polished_blackstone_bricks
setblock 49 83 8 minecraft:amethyst_block
setblock 79 83 8 minecraft:amethyst_block
setblock 48 83 8 minecraft:polished_blackstone_bricks
setblock 80 83 8 minecraft:polished_blackstone_bricks
setblock 49 83 9 minecraft:amethyst_block
setblock 79 83 9 minecraft:amethyst_block
setblock 48 83 9 minecraft:polished_blackstone_bricks
setblock 80 83 9 minecraft:polished_blackstone_bricks
setblock 49 83 10 minecraft:amethyst_block
setblock 79 83 10 minecraft:amethyst_block
setblock 73 83 10 minecraft:light_blue_stained_glass
setblock 48 83 10 minecraft:polished_blackstone_bricks
setblock 80 83 10 minecraft:polished_blackstone_bricks
setblock 49 83 11 minecraft:amethyst_block
setblock 79 83 11 minecraft:amethyst_block
setblock 48 83 11 minecraft:polished_blackstone_bricks
setblock 80 83 11 minecraft:polished_blackstone_bricks
setblock 49 83 12 minecraft:amethyst_block
setblock 79 83 12 minecraft:amethyst_block
setblock 48 83 12 minecraft:polished_blackstone_bricks
setblock 80 83 12 minecraft:polished_blackstone_bricks
setblock 49 83 13 minecraft:amethyst_block
setblock 79 83 13 minecraft:amethyst_block
setblock 48 83 13 minecraft:polished_blackstone_bricks
setblock 80 83 13 minecraft:polished_blackstone_bricks
setblock 49 83 14 minecraft:amethyst_block
setblock 79 83 14 minecraft:amethyst_block
setblock 48 83 14 minecraft:polished_blackstone_bricks
setblock 80 83 14 minecraft:polished_blackstone_bricks
fill 49 83 15 79 83 15 minecraft:amethyst_block
setblock 48 83 15 minecraft:polished_blackstone_bricks
setblock 80 83 15 minecraft:polished_blackstone_bricks
fill 48 83 16 80 83 16 minecraft:polished_blackstone_bricks
fill 48 84 -16 80 84 -16 minecraft:black_concrete
fill 48 84 -15 80 84 -15 minecraft:black_concrete
fill 48 84 -14 80 84 -14 minecraft:black_concrete
fill 48 84 -13 80 84 -13 minecraft:black_concrete
fill 48 84 -12 80 84 -12 minecraft:black_concrete
fill 48 84 -11 80 84 -11 minecraft:black_concrete
fill 48 84 -10 80 84 -10 minecraft:black_concrete
fill 48 84 -9 53 84 -9 minecraft:black_concrete
fill 55 84 -9 70 84 -9 minecraft:black_concrete
fill 72 84 -9 80 84 -9 minecraft:black_concrete
setblock 54 84 -9 minecraft:sea_lantern
setblock 71 84 -9 minecraft:sea_lantern
fill 48 84 -8 60 84 -8 minecraft:black_concrete
fill 62 84 -8 80 84 -8 minecraft:black_concrete
setblock 61 84 -8 minecraft:sea_lantern
fill 48 84 -7 80 84 -7 minecraft:black_concrete
fill 48 84 -6 80 84 -6 minecraft:black_concrete
fill 48 84 -5 80 84 -5 minecraft:black_concrete
fill 48 84 -4 73 84 -4 minecraft:black_concrete
fill 75 84 -4 80 84 -4 minecraft:black_concrete
setblock 74 84 -4 minecraft:sea_lantern
fill 48 84 -3 80 84 -3 minecraft:black_concrete
fill 48 84 -2 80 84 -2 minecraft:black_concrete
fill 48 84 -1 80 84 -1 minecraft:black_concrete
fill 48 84 0 80 84 0 minecraft:black_concrete
fill 48 84 1 80 84 1 minecraft:black_concrete
fill 48 84 2 80 84 2 minecraft:black_concrete
fill 48 84 3 80 84 3 minecraft:black_concrete
fill 48 84 4 66 84 4 minecraft:black_concrete
fill 68 84 4 80 84 4 minecraft:black_concrete
setblock 67 84 4 minecraft:sea_lantern
fill 48 84 5 52 84 5 minecraft:black_concrete
fill 54 84 5 80 84 5 minecraft:black_concrete
setblock 53 84 5 minecraft:sea_lantern
fill 48 84 6 80 84 6 minecraft:black_concrete
fill 48 84 7 58 84 7 minecraft:black_concrete
fill 60 84 7 80 84 7 minecraft:black_concrete
setblock 59 84 7 minecraft:sea_lantern
fill 48 84 8 80 84 8 minecraft:black_concrete
fill 48 84 9 80 84 9 minecraft:black_concrete
fill 48 84 10 72 84 10 minecraft:black_concrete
fill 74 84 10 80 84 10 minecraft:black_concrete
setblock 73 84 10 minecraft:sea_lantern
fill 48 84 11 80 84 11 minecraft:black_concrete
fill 48 84 12 80 84 12 minecraft:black_concrete
fill 48 84 13 80 84 13 minecraft:black_concrete
fill 48 84 14 80 84 14 minecraft:black_concrete
fill 48 84 15 80 84 15 minecraft:black_concrete
fill 48 84 16 80 84 16 minecraft:black_concrete
schedule function signal:world/build_2 1t replace
