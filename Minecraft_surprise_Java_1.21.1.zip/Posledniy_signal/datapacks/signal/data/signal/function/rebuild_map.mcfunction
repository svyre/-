function signal:world/prepare
