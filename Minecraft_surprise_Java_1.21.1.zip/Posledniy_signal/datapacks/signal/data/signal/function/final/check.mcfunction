scoreboard players set @s sig.ok 0
execute if score @s sig.target matches 0 if entity @s[x=309,y=63,z=-10,dx=4,dy=4,dz=4] run scoreboard players set @s sig.ok 1
execute if score @s sig.target matches 1 if entity @s[x=327,y=63,z=-10,dx=4,dy=4,dz=4] run scoreboard players set @s sig.ok 1
execute if score @s sig.target matches 2 if entity @s[x=309,y=63,z=6,dx=4,dy=4,dz=4] run scoreboard players set @s sig.ok 1
execute if score @s sig.target matches 3 if entity @s[x=327,y=63,z=6,dx=4,dy=4,dz=4] run scoreboard players set @s sig.ok 1
execute if score @s sig.ok matches 0 run function signal:final/fail
execute if score @s sig.ok matches 1 run function signal:final/success
