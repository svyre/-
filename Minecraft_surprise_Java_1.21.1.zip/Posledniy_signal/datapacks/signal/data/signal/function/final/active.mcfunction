scoreboard players operation @s sig.left = @s sig.clock
scoreboard players operation @s sig.left /= #twenty sig.var
title @s actionbar [{"text":"Импульс ","color":"aqua"},{"score":{"name":"@s","objective":"sig.round"}},{"text":" / 6  ·  Осталось ","color":"gray"},{"score":{"name":"@s","objective":"sig.left"}},{"text":" с"}]
execute if score @s sig.clock matches 60 run execute at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.8 1.5
execute if score @s sig.clock matches 40 run execute at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.8 1.5
execute if score @s sig.clock matches 20 run execute at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.8 1.5
execute if score @s sig.clock matches 0 run function signal:final/check
