fill 309 63 -10 313 63 -6 minecraft:cyan_concrete
fill 327 63 -10 331 63 -6 minecraft:orange_concrete
fill 309 63 6 313 63 10 minecraft:lime_concrete
fill 327 63 6 331 63 10 minecraft:magenta_concrete
