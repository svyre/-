scoreboard players add @s sig.err 1
scoreboard players remove @s sig.round 1
scoreboard players set @s sig.state 2
scoreboard players set @s sig.clock 60
tp @s 320.5 64 0.5 180 0
title @s times 8 45 12
title @s subtitle {"text":"Пройденные импульсы сохранены","color":"gray"}
title @s title {"text":"ПОПРОБУЕМ ЕЩЁ","color":"yellow"}
execute at @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.65 0.6
