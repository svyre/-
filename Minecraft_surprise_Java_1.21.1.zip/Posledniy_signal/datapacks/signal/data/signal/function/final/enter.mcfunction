scoreboard players set @s sig.room 5
scoreboard players set @s sig.state 0
scoreboard players set @s sig.round 0
scoreboard players set @s sig.clock 100
scoreboard players set @s sig.cd 40
clear @s
tp @s 320.5 64 0.5 180 0
spawnpoint @s 320 64 0
title @s times 8 45 12
title @s subtitle {"text":"Выведите сигнал на поверхность","color":"gray"}
title @s title {"text":"ПОСЛЕДНЯЯ НАСТРОЙКА","color":"aqua"}
function signal:help/room5
tellraw @s {"text":"Дежурный голос: «Дальние: голубой слева, янтарный справа. Ближние: зелёный слева, пурпурный справа. Я буду называть цвет».","color":"aqua"}
function signal:final/pads
