scoreboard players add @s sig.round 1
scoreboard players set @s sig.state 1
scoreboard players set @s sig.clock 140
function signal:final/pads
execute if score @s sig.round matches 1 run scoreboard players set @s sig.target 0
execute if score @s sig.round matches 2 run scoreboard players set @s sig.target 3
execute if score @s sig.round matches 3 run scoreboard players set @s sig.target 1
execute if score @s sig.round matches 4 run scoreboard players set @s sig.target 2
execute if score @s sig.round matches 5 run scoreboard players set @s sig.target 0
execute if score @s sig.round matches 6 run scoreboard players set @s sig.target 1
execute if score @s sig.target matches 0 run function signal:final/color0
execute if score @s sig.target matches 1 run function signal:final/color1
execute if score @s sig.target matches 2 run function signal:final/color2
execute if score @s sig.target matches 3 run function signal:final/color3
