scoreboard players set @s sig.state 2
scoreboard players set @s sig.clock 30
execute at @s run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.65 1.3
execute if score @s sig.round matches 1..5 run title @s subtitle {"text":"Импульс принят","color":"green"}
execute if score @s sig.round matches 6 run function signal:final/win
