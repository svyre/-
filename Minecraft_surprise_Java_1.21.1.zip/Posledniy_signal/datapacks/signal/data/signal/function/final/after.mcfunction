execute if score @s sig.cd matches 0 if entity @s[x=319,y=63,z=11,dx=2,dy=3,dz=2] run return run function signal:hub/return
execute if score @s sig.clock matches 1.. run particle minecraft:end_rod ~ ~2 ~ 5 2 5 .04 6 force @s
execute if score @s sig.clock matches 1.. run scoreboard players remove @s sig.clock 1
