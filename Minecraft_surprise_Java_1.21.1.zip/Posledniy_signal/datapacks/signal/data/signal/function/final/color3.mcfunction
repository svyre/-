title @s times 8 45 12
title @s subtitle {"text":"Семь секунд до импульса","color":"gray"}
title @s title {"text":"ПУРПУРНЫЙ","color":"light_purple"}
setblock 329 63 8 minecraft:sea_lantern
particle minecraft:end_rod 329.5 64.4 8.5 1.4 .2 1.4 .02 45 force @s
execute at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.65 1.4
