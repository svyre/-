tag @s add sig.won
scoreboard players set @s sig.room 6
scoreboard players set @s sig.clock 100
bossbar set signal:progress name {"text":"СИГНАЛ ДОШЁЛ","color":"green"}
bossbar set signal:progress color green
title @s times 8 45 12
title @s subtitle {"text":"Станция больше не одна","color":"gray"}
title @s title {"text":"ВАС УСЛЫШАЛИ","color":"green"}
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.85 1
tellraw @s {"text":"Сначала вы слышите шум. Потом — чужое дыхание.","color":"white"}
tellraw @s {"text":"«Станция, приём. Мы думали, здесь никого не осталось. Мы идём за вами».","color":"gold"}
tellraw @s {"text":"Дежурный голос тихо отвечает: «Теперь можно закрыть смену».","color":"aqua"}
execute if score @s sig.echo matches 4 run tellraw @s {"text":"Вы узнали его голос. Четыре сохранённых эха не дали ему исчезнуть. Канал останется открыт — для тех, кто придёт после вас.","color":"light_purple"}
execute unless score @s sig.echo matches 4 run tellraw @s {"text":"В четырёх отсеках остались отголоски чужой истории. В другой экспедиции вы сможете услышать их все.","color":"gray"}
tellraw @s [{"text":"Экспедиция: ","color":"aqua"},{"score":{"name":"@s","objective":"sig.min"}},{"text":" мин "},{"score":{"name":"@s","objective":"sig.sec"}},{"text":" с  ·  Эхо "},{"score":{"name":"@s","objective":"sig.echo"}},{"text":"/4"}]
tellraw @s [{"text":"Падения: ","color":"gray"},{"score":{"name":"@s","objective":"sig.falls"}},{"text":"  ·  Сбои: "},{"score":{"name":"@s","objective":"sig.err"}},{"text":"  ·  Подсказки: "},{"score":{"name":"@s","objective":"sig.hints"}}]
tellraw @s {"text":"Конец. Спасибо за игру.","color":"white"}
function signal:help/links
