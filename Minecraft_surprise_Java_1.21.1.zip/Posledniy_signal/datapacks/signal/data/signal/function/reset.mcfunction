tag @s remove sig.k1
tag @s remove sig.k2
tag @s remove sig.k3
tag @s remove sig.k4
tag @s remove sig.e1
tag @s remove sig.e2
tag @s remove sig.e3
tag @s remove sig.e4
tag @s remove sig.won
scoreboard players set @s sig.room 0
scoreboard players set @s sig.time 0
scoreboard players set @s sig.sec 0
scoreboard players set @s sig.min 0
scoreboard players set @s sig.clock 0
scoreboard players set @s sig.mem 0
scoreboard players set @s sig.step 0
scoreboard players set @s sig.cd 0
scoreboard players set @s sig.err 0
scoreboard players set @s sig.falls 0
scoreboard players set @s sig.wave 0
scoreboard players set @s sig.round 0
scoreboard players set @s sig.state 0
scoreboard players set @s sig.keys 0
scoreboard players set @s sig.echo 0
scoreboard players set @s sig.touch 0
scoreboard players set @s sig.hold 0
scoreboard players set @s sig.ok 0
scoreboard players set @s sig.tmp 0
scoreboard players set @s sig.a 0
scoreboard players set @s sig.b 0
scoreboard players set @s sig.c 0
scoreboard players set @s sig.l1 0
scoreboard players set @s sig.l2 0
scoreboard players set @s sig.l3 0
scoreboard players set @s sig.l4 0
scoreboard players set @s sig.l5 0
scoreboard players set @s sig.target 0
scoreboard players set @s sig.left 0
scoreboard players set @s sig.hints 0
scoreboard players set @s sig.help 0
scoreboard players set @s sig.hint 0
scoreboard players set @s sig.restart 0
scoreboard players set @s sig.dead 0
scoreboard players set @s sig.hold -1
scoreboard players set @s sig.touch -1
kill @e[tag=sig.enemy]
clear @s
effect clear @s
gamemode adventure @s
effect give @s minecraft:instant_health 1 4 true
effect give @s minecraft:saturation 2 10 true
tp @s 0.5 64 8.5 180 0
spawnpoint @s 0 64 8
bossbar set signal:progress value 0
bossbar set signal:progress color blue
bossbar set signal:progress visible true
bossbar set signal:progress name {"text":"Стабильность сигнала · 0 / 4","color":"aqua"}
function signal:memory/dark
function signal:logic/render
title @s times 8 45 12
title @s subtitle {"text":"Одиночная экспедиция","color":"gray"}
title @s title {"text":"ПОСЛЕДНИЙ СИГНАЛ","color":"aqua"}
execute at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.65 0.6
tellraw @s {"text":"Вы проснулись на станции, которая давно должна была замолчать.","color":"white"}
tellraw @s {"text":"Дежурный голос: «Четыре отсека потеряли связь. Я не могу дотянуться до них. Вы — можете».","color":"aqua"}
tellraw @s {"text":"Ступайте на цветные площадки перед вами. Отсеки можно проходить в любом порядке.","color":"gray"}
tellraw @s {"text":"Белая площадка у входа в каждый отсек возвращает в зал. Прогресс сохраняется при выходе из игры.","color":"gray"}
function signal:help/links
