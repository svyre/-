execute if score @s sig.keys matches 4 run function signal:final/enter
execute unless score @s sig.keys matches 4 run tellraw @s {"text":"В центре пока тихо. Нужны все четыре модуля связи.","color":"dark_aqua"}
scoreboard players set @s sig.cd 40
