execute if score @s sig.cd matches 0 if entity @s[x=-11,y=63,z=-9,dx=2,dy=3,dz=2] run function signal:memory/enter
execute if score @s sig.cd matches 0 if entity @s[x=-4,y=63,z=-9,dx=2,dy=3,dz=2] run function signal:parkour/enter
execute if score @s sig.cd matches 0 if entity @s[x=3,y=63,z=-9,dx=2,dy=3,dz=2] run function signal:logic/enter
execute if score @s sig.cd matches 0 if entity @s[x=10,y=63,z=-9,dx=2,dy=3,dz=2] run function signal:arena/enter
execute if score @s sig.cd matches 0 if entity @s[x=-1,y=63,z=-14,dx=2,dy=3,dz=2] run function signal:hub/gate
