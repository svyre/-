kill @e[tag=sig.enemy]
kill @e[type=minecraft:arrow,x=240,y=60,z=-15,dx=32,dy=25,dz=30]
clear @s
effect clear @s
effect give @s minecraft:instant_health 1 4 true
effect give @s minecraft:saturation 2 10 true
scoreboard players set @s sig.room 0
scoreboard players set @s sig.state 0
scoreboard players set @s sig.cd 30
scoreboard players set @s sig.hold -1
tp @s 0.5 64 4.5 180 0
spawnpoint @s 0 64 8
execute at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.65 0.7
execute store result bossbar signal:progress value run scoreboard players get @s sig.keys
bossbar set signal:progress name [{"text":"Стабильность сигнала · ","color":"aqua"},{"score":{"name":"@s","objective":"sig.keys"}},{"text":" / 4"}]
