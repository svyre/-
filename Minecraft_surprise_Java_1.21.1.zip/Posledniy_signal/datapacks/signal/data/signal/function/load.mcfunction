scoreboard objectives add sig.var dummy
scoreboard objectives add sig.room dummy
scoreboard objectives add sig.time dummy
scoreboard objectives add sig.sec dummy
scoreboard objectives add sig.min dummy
scoreboard objectives add sig.clock dummy
scoreboard objectives add sig.mem dummy
scoreboard objectives add sig.step dummy
scoreboard objectives add sig.cd dummy
scoreboard objectives add sig.err dummy
scoreboard objectives add sig.falls dummy
scoreboard objectives add sig.wave dummy
scoreboard objectives add sig.round dummy
scoreboard objectives add sig.state dummy
scoreboard objectives add sig.keys dummy
scoreboard objectives add sig.echo dummy
scoreboard objectives add sig.touch dummy
scoreboard objectives add sig.hold dummy
scoreboard objectives add sig.ok dummy
scoreboard objectives add sig.tmp dummy
scoreboard objectives add sig.a dummy
scoreboard objectives add sig.b dummy
scoreboard objectives add sig.c dummy
scoreboard objectives add sig.l1 dummy
scoreboard objectives add sig.l2 dummy
scoreboard objectives add sig.l3 dummy
scoreboard objectives add sig.l4 dummy
scoreboard objectives add sig.l5 dummy
scoreboard objectives add sig.target dummy
scoreboard objectives add sig.left dummy
scoreboard objectives add sig.hints dummy
scoreboard objectives add sig.help trigger
scoreboard objectives add sig.hint trigger
scoreboard objectives add sig.restart trigger
scoreboard objectives add sig.dead deathCount
scoreboard players set #two sig.var 2
scoreboard players set #twenty sig.var 20
bossbar add signal:progress {"text":"ПОСЛЕДНИЙ СИГНАЛ","color":"aqua"}
bossbar set signal:progress color blue
bossbar set signal:progress style progress
bossbar set signal:progress max 4
gamerule doDaylightCycle false
time set midnight
gamerule doWeatherCycle false
weather clear
gamerule doMobSpawning false
gamerule mobGriefing false
gamerule keepInventory true
gamerule doFireTick false
gamerule doInsomnia false
gamerule announceAdvancements false
gamerule commandBlockOutput false
gamerule sendCommandFeedback false
gamerule doImmediateRespawn true
gamerule naturalRegeneration true
gamerule doTraderSpawning false
gamerule doPatrolSpawning false
gamerule doWardenSpawning false
gamerule spawnRadius 0
difficulty normal
setworldspawn 0 64 8
worldborder center 160 0
worldborder set 800
bossbar set signal:progress players @a
