scoreboard players add @s sig.falls 1
execute if score @s sig.step matches 0 run tp @s 128.5 64 9.5 180 0
execute if score @s sig.step matches 1 run tp @s 128.5 64 -3.5 180 0
execute at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.4 0.6
title @s actionbar {"text":"Мост помнит вашу последнюю опору. Попробуйте ещё раз.","color":"gray"}
