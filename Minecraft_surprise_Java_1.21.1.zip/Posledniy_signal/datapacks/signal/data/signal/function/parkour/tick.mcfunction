execute unless entity @s[tag=sig.e2] if entity @s[x=139,y=63,z=11,dx=2,dy=4,dz=2] run function signal:echo/2
execute if score @s sig.cd matches 0 if entity @s[x=127,y=63,z=11,dx=2,dy=3,dz=2] run function signal:hub/return
execute if score @s sig.step matches 0 if entity @s[x=128,y=63,z=-4,dx=1,dy=3,dz=1] run function signal:parkour/checkpoint
execute if entity @s[y=-64,dy=124] run function signal:parkour/fall
execute unless entity @s[tag=sig.k2] if entity @s[x=127,y=63,z=-14,dx=3,dy=4,dz=3] run function signal:award/2
