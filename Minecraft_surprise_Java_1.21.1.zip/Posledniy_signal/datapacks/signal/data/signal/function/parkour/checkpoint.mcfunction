scoreboard players set @s sig.step 1
spawnpoint @s 128 64 -4
title @s times 8 45 12
title @s subtitle {"text":"Осталось немного","color":"gray"}
title @s title {"text":"ТОЧКА ВОЗВРАТА","color":"green"}
execute at @s run playsound minecraft:block.respawn_anchor.charge master @s ~ ~ ~ 0.65 1.4
