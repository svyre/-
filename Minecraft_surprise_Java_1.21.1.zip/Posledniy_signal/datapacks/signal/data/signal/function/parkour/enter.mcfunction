scoreboard players set @s sig.room 2
scoreboard players set @s sig.state 0
scoreboard players set @s sig.step 0
scoreboard players set @s sig.mem 0
scoreboard players set @s sig.hold -1
scoreboard players set @s sig.touch -1
scoreboard players set @s sig.cd 60
tp @s 128.5 64 9.5 180 0
spawnpoint @s 128 64 9
title @s times 8 45 12
title @s subtitle {"text":"Белая площадка позади — возврат в зал","color":"gray"}
title @s title {"text":"РАЗОРВАННЫЙ МОСТ","color":"green"}
function signal:help/room2
execute if entity @s[tag=sig.k2] run tellraw @s {"text":"Этот модуль уже восстановлен. Можно осмотреть отсек или вернуться.","color":"green"}
