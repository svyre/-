scoreboard players set @s sig.state 1
scoreboard players set @s sig.clock 0
scoreboard players set @s sig.mem 0
scoreboard players set @s sig.cd 20
function signal:memory/dark
title @s times 8 45 12
title @s subtitle {"text":"Запомните пять вспышек","color":"gray"}
title @s title {"text":"СЛУШАЙТЕ СВЕТ","color":"aqua"}
execute at @s run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.65 0.8
