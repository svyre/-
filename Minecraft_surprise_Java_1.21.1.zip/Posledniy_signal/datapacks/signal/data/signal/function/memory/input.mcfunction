scoreboard players set @s sig.ok 0
execute if score @s sig.mem matches 0 if score @s sig.touch matches 2 run scoreboard players set @s sig.ok 1
execute if score @s sig.mem matches 1 if score @s sig.touch matches 0 run scoreboard players set @s sig.ok 1
execute if score @s sig.mem matches 2 if score @s sig.touch matches 3 run scoreboard players set @s sig.ok 1
execute if score @s sig.mem matches 3 if score @s sig.touch matches 1 run scoreboard players set @s sig.ok 1
execute if score @s sig.mem matches 4 if score @s sig.touch matches 2 run scoreboard players set @s sig.ok 1
execute if score @s sig.ok matches 0 run function signal:memory/fail
execute if score @s sig.ok matches 1 run function signal:memory/correct
