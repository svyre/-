execute unless entity @s[tag=sig.e1] if entity @s[x=75,y=63,z=7,dx=2,dy=4,dz=2] run function signal:echo/1
execute if score @s sig.cd matches 0 if entity @s[x=63,y=63,z=11,dx=2,dy=3,dz=2] run function signal:hub/return
execute if score @s sig.state matches 1 run function signal:memory/animation
scoreboard players set @s sig.touch -1
execute if entity @s[x=56,y=63,z=-2,dx=1,dy=3,dz=1] run scoreboard players set @s sig.touch 0
execute if entity @s[x=61,y=63,z=-2,dx=1,dy=3,dz=1] run scoreboard players set @s sig.touch 1
execute if entity @s[x=67,y=63,z=-2,dx=1,dy=3,dz=1] run scoreboard players set @s sig.touch 2
execute if entity @s[x=72,y=63,z=-2,dx=1,dy=3,dz=1] run scoreboard players set @s sig.touch 3
execute if entity @s[x=64,y=63,z=5,dx=1,dy=3,dz=1] run scoreboard players set @s sig.touch 4
execute unless entity @s[tag=sig.k1] if score @s sig.touch matches 4 if score @s sig.hold matches -1 unless score @s sig.state matches 1 run function signal:memory/show
execute unless entity @s[tag=sig.k1] if score @s sig.state matches 2 if score @s sig.touch matches 0..3 if score @s sig.hold matches -1 run function signal:memory/input
scoreboard players operation @s sig.hold = @s sig.touch
