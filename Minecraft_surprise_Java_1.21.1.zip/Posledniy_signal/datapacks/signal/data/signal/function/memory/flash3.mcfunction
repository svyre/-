setblock 72 65 -7 minecraft:sea_lantern
particle minecraft:end_rod 72.5 66.1 -6.5 .3 .3 .15 .01 18 force @s
execute at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 0.65 1.35
