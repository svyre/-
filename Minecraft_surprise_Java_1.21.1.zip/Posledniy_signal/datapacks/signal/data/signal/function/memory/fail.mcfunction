scoreboard players add @s sig.err 1
scoreboard players set @s sig.state 0
scoreboard players set @s sig.mem 0
execute at @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.65 0.6
tellraw @s {"text":"Сигнал сбился. Белый круг запустит запись ещё раз. Порядок не изменился.","color":"yellow"}
