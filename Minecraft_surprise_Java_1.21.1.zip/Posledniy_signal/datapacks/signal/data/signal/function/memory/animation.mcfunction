scoreboard players add @s sig.clock 1
execute if score @s sig.clock matches 20 run function signal:memory/flash2
execute if score @s sig.clock matches 32 run function signal:memory/dark
execute if score @s sig.clock matches 45 run function signal:memory/flash0
execute if score @s sig.clock matches 57 run function signal:memory/dark
execute if score @s sig.clock matches 70 run function signal:memory/flash3
execute if score @s sig.clock matches 82 run function signal:memory/dark
execute if score @s sig.clock matches 95 run function signal:memory/flash1
execute if score @s sig.clock matches 107 run function signal:memory/dark
execute if score @s sig.clock matches 120 run function signal:memory/flash2
execute if score @s sig.clock matches 132 run function signal:memory/dark
execute if score @s sig.clock matches 145 run function signal:memory/ready
