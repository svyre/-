scoreboard players set @s sig.state 2
title @s times 8 45 12
title @s subtitle {"text":"Наступайте на цветные площадки","color":"gray"}
title @s title {"text":"ВАША ОЧЕРЕДЬ","color":"white"}
