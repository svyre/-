setblock 56 65 -7 minecraft:dark_prismarine
setblock 61 65 -7 minecraft:dark_prismarine
setblock 67 65 -7 minecraft:dark_prismarine
setblock 72 65 -7 minecraft:dark_prismarine
