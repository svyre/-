scoreboard players add @s sig.mem 1
execute at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.65 1.3
title @s actionbar [{"text":"Верно · ","color":"green"},{"score":{"name":"@s","objective":"sig.mem"}},{"text":" / 5"}]
execute if score @s sig.mem matches 5 unless entity @s[tag=sig.k1] run function signal:award/1
