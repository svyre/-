tag @s add sig.k2
scoreboard players add @s sig.keys 1
function signal:hub/return
title @s times 8 45 12
title @s subtitle {"text":"РАЗОРВАННЫЙ МОСТ","color":"gray"}
title @s title {"text":"МОДУЛЬ ВОССТАНОВЛЕН","color":"green"}
execute at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.7 1
tellraw @s {"text":"Дежурный голос: «Слышу вас чуть лучше. Спасибо».","color":"aqua"}
execute if score @s sig.keys matches 4 run tellraw @s {"text":"Все четыре канала на связи. Центральная площадка в дальней части зала теперь отвечает.","color":"gold"}
