scoreboard players add @s sig.step 1
execute at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.65 1.4
execute if score @s sig.step matches 1..2 run tellraw @s {"text":"Контур согласован. Нижний эталон изменился — настройте следующий.","color":"green"}
execute if score @s sig.step matches 1..2 run function signal:logic/render
execute if score @s sig.step matches 3 unless entity @s[tag=sig.k3] run function signal:award/3
