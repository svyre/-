scoreboard players set @s sig.room 3
scoreboard players set @s sig.state 0
scoreboard players set @s sig.step 0
scoreboard players set @s sig.mem 0
scoreboard players set @s sig.hold -1
scoreboard players set @s sig.touch -1
scoreboard players set @s sig.cd 60
tp @s 192.5 64 9.5 180 0
spawnpoint @s 192 64 9
title @s times 8 45 12
title @s subtitle {"text":"Белая площадка позади — возврат в зал","color":"gray"}
title @s title {"text":"УЗЕЛ СВЯЗИ","color":"gold"}
function signal:help/room3
execute if entity @s[tag=sig.k3] run tellraw @s {"text":"Этот модуль уже восстановлен. Можно осмотреть отсек или вернуться.","color":"green"}
scoreboard players set @s sig.a 0
scoreboard players set @s sig.b 0
scoreboard players set @s sig.c 0
function signal:logic/render
