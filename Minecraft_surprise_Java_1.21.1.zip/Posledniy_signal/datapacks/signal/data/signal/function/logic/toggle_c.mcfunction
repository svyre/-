scoreboard players add @s sig.c 1
execute if score @s sig.c matches 2 run scoreboard players set @s sig.c 0
function signal:logic/render
execute at @s run playsound minecraft:block.copper_bulb.turn_on master @s ~ ~ ~ 0.65 1
function signal:logic/check
