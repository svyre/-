scoreboard players add @s sig.b 1
execute if score @s sig.b matches 2 run scoreboard players set @s sig.b 0
function signal:logic/render
execute at @s run playsound minecraft:block.copper_bulb.turn_on master @s ~ ~ ~ 0.65 1
function signal:logic/check
