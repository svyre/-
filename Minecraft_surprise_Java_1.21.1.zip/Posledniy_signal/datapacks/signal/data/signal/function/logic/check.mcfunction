scoreboard players set @s sig.ok 0
execute if score @s sig.step matches 0 if score @s sig.l1 matches 1 if score @s sig.l2 matches 0 if score @s sig.l3 matches 1 if score @s sig.l4 matches 1 if score @s sig.l5 matches 0 run scoreboard players set @s sig.ok 1
execute if score @s sig.step matches 1 if score @s sig.l1 matches 1 if score @s sig.l2 matches 1 if score @s sig.l3 matches 0 if score @s sig.l4 matches 1 if score @s sig.l5 matches 1 run scoreboard players set @s sig.ok 1
execute if score @s sig.step matches 2 if score @s sig.l1 matches 0 if score @s sig.l2 matches 1 if score @s sig.l3 matches 1 if score @s sig.l4 matches 0 if score @s sig.l5 matches 1 run scoreboard players set @s sig.ok 1
execute if score @s sig.ok matches 1 run function signal:logic/matched
