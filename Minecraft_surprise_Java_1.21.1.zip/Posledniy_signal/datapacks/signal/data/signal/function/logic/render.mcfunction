scoreboard players operation @s sig.l1 = @s sig.a
scoreboard players operation @s sig.l2 = @s sig.a
scoreboard players operation @s sig.l2 += @s sig.b
scoreboard players operation @s sig.l2 %= #two sig.var
scoreboard players operation @s sig.l3 = @s sig.b
scoreboard players operation @s sig.l4 = @s sig.c
scoreboard players operation @s sig.l5 = @s sig.b
scoreboard players operation @s sig.l5 += @s sig.c
scoreboard players operation @s sig.l5 %= #two sig.var
execute if score @s sig.l1 matches 0 run setblock 184 66 -10 minecraft:dark_prismarine
execute if score @s sig.l1 matches 1 run setblock 184 66 -10 minecraft:sea_lantern
execute if score @s sig.l2 matches 0 run setblock 188 66 -10 minecraft:dark_prismarine
execute if score @s sig.l2 matches 1 run setblock 188 66 -10 minecraft:sea_lantern
execute if score @s sig.l3 matches 0 run setblock 192 66 -10 minecraft:dark_prismarine
execute if score @s sig.l3 matches 1 run setblock 192 66 -10 minecraft:sea_lantern
execute if score @s sig.l4 matches 0 run setblock 196 66 -10 minecraft:dark_prismarine
execute if score @s sig.l4 matches 1 run setblock 196 66 -10 minecraft:sea_lantern
execute if score @s sig.l5 matches 0 run setblock 200 66 -10 minecraft:dark_prismarine
execute if score @s sig.l5 matches 1 run setblock 200 66 -10 minecraft:sea_lantern
execute if score @s sig.a matches 0 run fill 184 63 -2 185 63 -1 minecraft:waxed_copper_block
execute if score @s sig.a matches 1 run fill 184 63 -2 185 63 -1 minecraft:waxed_oxidized_copper
execute if score @s sig.b matches 0 run fill 192 63 -2 193 63 -1 minecraft:waxed_copper_block
execute if score @s sig.b matches 1 run fill 192 63 -2 193 63 -1 minecraft:waxed_oxidized_copper
execute if score @s sig.c matches 0 run fill 200 63 -2 201 63 -1 minecraft:waxed_copper_block
execute if score @s sig.c matches 1 run fill 200 63 -2 201 63 -1 minecraft:waxed_oxidized_copper
execute if score @s sig.step matches 0 run setblock 184 64 -10 minecraft:sea_lantern
execute if score @s sig.step matches 0 run setblock 188 64 -10 minecraft:dark_prismarine
execute if score @s sig.step matches 0 run setblock 192 64 -10 minecraft:sea_lantern
execute if score @s sig.step matches 0 run setblock 196 64 -10 minecraft:sea_lantern
execute if score @s sig.step matches 0 run setblock 200 64 -10 minecraft:dark_prismarine
execute if score @s sig.step matches 1 run setblock 184 64 -10 minecraft:sea_lantern
execute if score @s sig.step matches 1 run setblock 188 64 -10 minecraft:sea_lantern
execute if score @s sig.step matches 1 run setblock 192 64 -10 minecraft:dark_prismarine
execute if score @s sig.step matches 1 run setblock 196 64 -10 minecraft:sea_lantern
execute if score @s sig.step matches 1 run setblock 200 64 -10 minecraft:sea_lantern
execute if score @s sig.step matches 2 run setblock 184 64 -10 minecraft:dark_prismarine
execute if score @s sig.step matches 2 run setblock 188 64 -10 minecraft:sea_lantern
execute if score @s sig.step matches 2 run setblock 192 64 -10 minecraft:sea_lantern
execute if score @s sig.step matches 2 run setblock 196 64 -10 minecraft:dark_prismarine
execute if score @s sig.step matches 2 run setblock 200 64 -10 minecraft:sea_lantern
