execute unless entity @s[tag=sig.e3] if entity @s[x=203,y=63,z=7,dx=2,dy=4,dz=2] run function signal:echo/3
execute if score @s sig.cd matches 0 if entity @s[x=191,y=63,z=11,dx=2,dy=3,dz=2] run function signal:hub/return
scoreboard players set @s sig.touch -1
execute if entity @s[x=184,y=63,z=-2,dx=1,dy=3,dz=1] run scoreboard players set @s sig.touch 0
execute if entity @s[x=192,y=63,z=-2,dx=1,dy=3,dz=1] run scoreboard players set @s sig.touch 1
execute if entity @s[x=200,y=63,z=-2,dx=1,dy=3,dz=1] run scoreboard players set @s sig.touch 2
execute unless entity @s[tag=sig.k3] if score @s sig.touch matches 0 if score @s sig.hold matches -1 run function signal:logic/toggle_a
execute unless entity @s[tag=sig.k3] if score @s sig.touch matches 1 if score @s sig.hold matches -1 run function signal:logic/toggle_b
execute unless entity @s[tag=sig.k3] if score @s sig.touch matches 2 if score @s sig.hold matches -1 run function signal:logic/toggle_c
scoreboard players operation @s sig.hold = @s sig.touch
