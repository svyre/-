execute if score @s sig.help matches 1.. run function signal:help/main
execute if score @s sig.hint matches 1.. run function signal:help/hint
execute if score @s sig.restart matches 1 run function signal:help/restart
execute if score @s sig.restart matches 2.. run function signal:reset
scoreboard players enable @s sig.help
scoreboard players enable @s sig.hint
scoreboard players enable @s sig.restart
execute if score @s sig.cd matches 1.. run scoreboard players remove @s sig.cd 1
execute unless entity @s[tag=sig.won] run scoreboard players add @s sig.time 1
execute if score @s sig.time matches 20.. run function signal:player/second
execute if score @s sig.dead matches 1.. run function signal:player/respawn
execute if score @s sig.room matches 0 run function signal:hub/tick
execute if score @s sig.room matches 1 run function signal:memory/tick
execute if score @s sig.room matches 2 run function signal:parkour/tick
execute if score @s sig.room matches 3 run function signal:logic/tick
execute if score @s sig.room matches 4 run function signal:arena/tick
execute if score @s sig.room matches 5 run function signal:final/tick
execute if score @s sig.room matches 6 run function signal:final/after
execute if entity @s[y=-64,dy=120] unless score @s sig.room matches 2 run function signal:hub/return
