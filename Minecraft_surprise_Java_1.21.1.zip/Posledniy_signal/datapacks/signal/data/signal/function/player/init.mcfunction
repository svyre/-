tag @s add sig.player
function signal:reset
