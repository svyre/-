scoreboard players set @s sig.time 0
scoreboard players add @s sig.sec 1
execute if score @s sig.sec matches 60.. run scoreboard players add @s sig.min 1
execute if score @s sig.sec matches 60.. run scoreboard players set @s sig.sec 0
effect give @s minecraft:saturation 2 2 true
execute unless score @s sig.room matches 5 run title @s actionbar [{"text":"Связь ","color":"aqua"},{"score":{"name":"@s","objective":"sig.keys"}},{"text":"/4  ·  Эхо ","color":"dark_gray"},{"score":{"name":"@s","objective":"sig.echo"}},{"text":"/4  ·  /trigger sig.help","color":"gray"}]
execute if score @s sig.room matches 1 unless entity @s[tag=sig.e1] positioned 76.5 65.5 8.5 run particle minecraft:end_rod ~ ~ ~ 0.2 0.2 0.2 0.01 3 force @s
execute if score @s sig.room matches 2 unless entity @s[tag=sig.e2] positioned 140.5 65.5 12.5 run particle minecraft:end_rod ~ ~ ~ 0.2 0.2 0.2 0.01 3 force @s
execute if score @s sig.room matches 3 unless entity @s[tag=sig.e3] positioned 204.5 65.5 8.5 run particle minecraft:end_rod ~ ~ ~ 0.2 0.2 0.2 0.01 3 force @s
execute if score @s sig.room matches 4 unless entity @s[tag=sig.e4] positioned 268.5 65.5 8.5 run particle minecraft:end_rod ~ ~ ~ 0.2 0.2 0.2 0.01 3 force @s
