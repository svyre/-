scoreboard players set @s sig.dead 0
execute if score @s sig.room matches 4 run function signal:arena/fail
execute unless score @s sig.room matches 4 run function signal:hub/return
