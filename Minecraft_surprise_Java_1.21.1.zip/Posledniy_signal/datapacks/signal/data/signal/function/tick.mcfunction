execute as @a[tag=!sig.player] at @s run function signal:player/init
execute as @a[tag=sig.player] at @s run function signal:player/tick
bossbar set signal:progress players @a
