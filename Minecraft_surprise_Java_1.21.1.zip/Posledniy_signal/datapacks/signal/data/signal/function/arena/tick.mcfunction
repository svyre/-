execute unless entity @s[tag=sig.e4] if entity @s[x=267,y=63,z=7,dx=2,dy=4,dz=2] run function signal:echo/4
execute if score @s sig.cd matches 0 if entity @s[x=255,y=63,z=11,dx=2,dy=3,dz=2] run function signal:hub/return
execute if score @s sig.state matches 0 if score @s sig.cd matches 0 run function signal:arena/spawn
execute if score @s sig.state matches 2 if score @s sig.cd matches 0 run function signal:arena/spawn
execute if score @s sig.state matches 1 if score @s sig.cd matches 0 unless entity @e[tag=sig.enemy] run function signal:arena/cleared
