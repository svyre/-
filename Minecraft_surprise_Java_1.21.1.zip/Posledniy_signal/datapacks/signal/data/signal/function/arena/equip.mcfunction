clear @s
effect give @s minecraft:instant_health 1 4 true
item replace entity @s weapon.mainhand with minecraft:iron_sword[minecraft:unbreakable={}]
item replace entity @s weapon.offhand with minecraft:shield[minecraft:unbreakable={}]
item replace entity @s armor.head with minecraft:iron_helmet[minecraft:unbreakable={}]
item replace entity @s armor.chest with minecraft:iron_chestplate[minecraft:unbreakable={}]
item replace entity @s armor.legs with minecraft:iron_leggings[minecraft:unbreakable={}]
item replace entity @s armor.feet with minecraft:iron_boots[minecraft:unbreakable={}]
