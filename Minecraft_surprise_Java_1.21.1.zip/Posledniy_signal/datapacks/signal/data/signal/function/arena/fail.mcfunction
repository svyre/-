kill @e[tag=sig.enemy]
kill @e[type=minecraft:arrow,x=240,y=60,z=-15,dx=32,dy=25,dz=30]
scoreboard players add @s sig.err 1
scoreboard players set @s sig.state 2
scoreboard players set @s sig.cd 80
tp @s 256.5 64 9.5 180 0
function signal:arena/equip
title @s times 8 45 12
title @s subtitle {"text":"Текущая волна повторится","color":"gray"}
title @s title {"text":"КОНТУР ПЕРЕЗАПУЩЕН","color":"yellow"}
