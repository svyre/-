kill @e[tag=sig.enemy]
kill @e[type=minecraft:arrow,x=240,y=60,z=-15,dx=32,dy=25,dz=30]
scoreboard players set @s sig.state 1
scoreboard players set @s sig.cd 30
effect give @s minecraft:instant_health 1 2 true
execute if score @s sig.wave matches 1 run function signal:arena/wave1
execute if score @s sig.wave matches 2 run function signal:arena/wave2
execute if score @s sig.wave matches 3 run function signal:arena/wave3
title @s times 5 30 10
title @s subtitle {"text":"Щит — правая кнопка мыши","color":"gray"}
title @s title [{"text":"ВОЛНА ","color":"red"},{"score":{"name":"@s","objective":"sig.wave"}},{"text":" / 3"}]
execute at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.25 1.6
