scoreboard players add @s sig.wave 1
scoreboard players set @s sig.state 2
scoreboard players set @s sig.cd 80
effect give @s minecraft:instant_health 1 3 true
execute if score @s sig.wave matches 2..3 run tellraw @s {"text":"Чисто. Следующая волна через четыре секунды.","color":"green"}
execute if score @s sig.wave matches 4 unless entity @s[tag=sig.k4] run function signal:award/4
