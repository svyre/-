scoreboard players set @s sig.room 4
scoreboard players set @s sig.state 0
scoreboard players set @s sig.step 0
scoreboard players set @s sig.mem 0
scoreboard players set @s sig.hold -1
scoreboard players set @s sig.touch -1
scoreboard players set @s sig.cd 60
tp @s 256.5 64 9.5 180 0
spawnpoint @s 256 64 9
title @s times 8 45 12
title @s subtitle {"text":"Белая площадка позади — возврат в зал","color":"gray"}
title @s title {"text":"ЗАЩИТНЫЙ КОНТУР","color":"red"}
function signal:help/room4
execute if entity @s[tag=sig.k4] run tellraw @s {"text":"Этот модуль уже восстановлен. Можно осмотреть отсек или вернуться.","color":"green"}
function signal:arena/equip
scoreboard players set @s sig.wave 1
scoreboard players set @s sig.cd 120
execute unless entity @s[tag=sig.k4] run tellraw @s {"text":"Контур включится через шесть секунд. Приготовьте щит.","color":"yellow"}
execute if entity @s[tag=sig.k4] run scoreboard players set @s sig.state 3
